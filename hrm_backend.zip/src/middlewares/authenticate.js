const jwt = require("jsonwebtoken");
const { checking_session } = require("../DAL/session");
const { find_user_by_id } = require("../DAL/user");
const { Employee } = require("../models/employee");

const authenticate = async (req, res, next) => {
  const token = req.header("x-sh-auth");
  if (!token) {
    res.status(401).send();
  } else {
    try {
      let authorized = false;
      let login_token = "";
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      login_token = decoded.login_token;
      // logic to to authorize or not
      authorized = true;
      if (authorized) {
        authorized = true;
        //  put user inside req
        const is_sssion = await checking_session(login_token);
        if (!is_sssion) {
          return res.status(401).send({ message: "Your are un authorize" });
        }

        const user = await find_user_by_id(is_sssion.user_id);

        if (!user) {
          return res.status(401).send({ message: "Your are un authorize" });
        }

        if (user.type == 1) {
          const employee = await Employee.findOne({ user_id: user._id });
          if (
            !employee ||
            employee.active_status == false ||
            user.status == false
          ) {
            return res.status(401).send({ message: "Your are un authorize" });
          }
        }

        req.user = is_sssion.user_id;
        req.token = token;
        next();
      } else {
        res.status(401).json({
          code: 401,
          message: "Invalid Token",
        });
      }
    } catch (e) {
      console.log("error", e);
      res.status(401).send();
    }
  }
};

module.exports = { authenticate };
