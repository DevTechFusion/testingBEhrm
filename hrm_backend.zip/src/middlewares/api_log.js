const { APILog } = require("../models/api_log");

const api_log = async (req, res, next) => {
  const start = Date.now(); // Start timing the request processing

  var response_data = {};
  var request_data = {};

  request_data = {
    timestamp: new Date(),
    method: req.method,
    path: req.path,
    url: req.url,
    ip: req.connection.remoteAddress, // Get client full IP address
    request_headers: req.headers,
    request_body: req.body, // Assuming you're using body-parser or similar middleware for parsing request bodies
    request_query: req.query,
    request_params: req.params,
    request_cookies: req.cookies,
  };

  // Log the request details
  // Capture the original response methods
  const originalSend = res.send;
  const originalJson = res.json;

  // Override response methods to capture response details
  res.send = function (data) {
    const responseTime = Date.now() - start;

    // Log response details
    response_data = {
      timestamp: new Date(),
      method: req.method,
      path: req.path,
      response_status: res.statusCode,
      response_body: data,
      responseTime,
    };

    // Call the original send method
    originalSend.call(this, data);
  };

  res.json = function (data) {
    const responseTime = Date.now() - start;

    // Log response details
    response_data = {
      timestamp: new Date(),
      method: req.method,
      path: req.path,
      response_status: res.statusCode,
      response_body: data,
      responseTime,
    };
    // Call the original json method
    originalJson.call(this, data);
  };

  res.on("finish", () => {
    const apiLog = new APILog({
      request_time: request_data.timestamp,
      response_time: response_data.timestamp,
      request_method: request_data.method,
      request_path: request_data.path,
      request_body: request_data.request_body,
      request_headers: request_data.request_headers,
      response_status: response_data.response_status,
      request_query: request_data.request_query,
      request_params: request_data.request_params,
      client_ip: request_data.ip,
      client_agent: request_data.request_headers["user-agent"],
      response_body: response_data.response_body,
    });
    apiLog.save();
  });

  next();
};

// Export the middleware

module.exports = { api_log };
