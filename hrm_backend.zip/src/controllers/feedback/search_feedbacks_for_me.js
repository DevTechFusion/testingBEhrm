const {
  validate_feedbacks_search_for_me,
} = require("../../utils/validation/feedback");
const { searchFeedbacksForMe } = require("../../services/feedback");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const search_feedbacks_for_me = async (req, res) => {
  try {
    try {
      await validate_feedbacks_search_for_me(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    const { error, error_message, data } = await searchFeedbacksForMe(
      req.user,
      req.query.limit,
      req.query.page,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Feedbacks Data",
      feedback: data.feedback,
      count: data.total_pages,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = search_feedbacks_for_me;
