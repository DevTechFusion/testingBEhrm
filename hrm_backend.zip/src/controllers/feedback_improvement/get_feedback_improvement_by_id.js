const {
  getFeedbackImprovementById,
} = require("../../services/feedback_improvement");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_feedback_improvement_by_id = async (req, res) => {
  try {
    const { error, error_message, data } = await getFeedbackImprovementById(
      req.params.id
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: " Feedback Improvement Found Successfully",
      feedback_improvement: data.feedback_improvement,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_feedback_improvement_by_id;
