const {
  listFeedbackImprovement,
} = require("../../services/feedback_improvement");
const {
  validate_list_feedback_improvements,
} = require("../../utils/validation/feedback_improvement");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");
const list_feedback_improvement = async (req, res) => {
  try {
    try {
      await validate_list_feedback_improvements(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await listFeedbackImprovement(
      req.user,
      req.body,
      req.query.page,
      req.query.limit
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "List of Feedback and Improvement",
      feedback_improvement: data.feedback_improvement,
      total_pages: data.total_pages,
      total_count: data.total_feedback_improvement,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = list_feedback_improvement;
