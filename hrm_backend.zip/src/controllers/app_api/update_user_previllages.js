const { updateUserPrevillages } = require("../../services/app_api");

const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const update_user_previllages = async (req, res) => {
  try {
    const { error, error_message , data} = await updateUserPrevillages();

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
        data: data
      });
    }

    res.status(200).json({
      code: 200,
      message: "update user previllages",
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = update_user_previllages;
