const { listIncrementHistory } = require("../../services/increment_history");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");
const {
  validate_list_increment_history,
} = require("../../utils/validation/increment_history");

const list_increment_history = async (req, res) => {
  try {
    try {
      await validate_list_increment_history(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await listIncrementHistory(req.body);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "List of Increment History Found Successfully",
      increment_history: data.increment_history,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = list_increment_history;
