const { detailLoanRequest } = require("../../services/loan_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const detail_loan_request = async (req, res) => {
  try {
    const { error, error_message, data } = await detailLoanRequest(
      req.params.id
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Loan Request Details Found",
      loan_request: data.loan_request,
      employee: data.employee_data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = detail_loan_request;
