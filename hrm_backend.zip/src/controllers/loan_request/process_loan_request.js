const {
  validate_process_loan_request,
} = require("../../utils/validation/loan_request");
const { processLoanRequest } = require("../../services/loan_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const process_loan_request = async (req, res) => {
  try {
    try {
      await validate_process_loan_request(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await processLoanRequest(
      req.params.id,
      req.user,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Loan Request Processed Successfully",
      loan_request: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = process_loan_request;
