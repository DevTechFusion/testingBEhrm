const {
  validate_update_loan_installment_date,
} = require("../../utils/validation/loan_request");
const { updateLoanInstallmentDate } = require("../../services/loan_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const update_loan_installment_date = async (req, res) => {
  try {
    try {
      await validate_update_loan_installment_date(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await updateLoanInstallmentDate(
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Installment Date Updated Successfully",
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = update_loan_installment_date;
