const {
  validate_edit_loan_request,
} = require("../../utils/validation/loan_request");
const {
  editLoanRequest,
  editLoanRequestV1,
} = require("../../services/loan_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const edit_loan_request = async (req, res) => {
  try {
    try {
      await validate_edit_loan_request(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await editLoanRequestV1(
      req.user,
      req.params.id,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Loan Request Edited Successfully",
      loan_request: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = edit_loan_request;
