const {
  validate_update_installment_status,
} = require("../../utils/validation/loan_request");
const { updateInstallmentStatus } = require("../../services/loan_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const update_installment_status = async (req, res) => {
  try {
    try {
      await validate_update_installment_status(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await updateInstallmentStatus(
      req.params.id,
      req.user,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Loan Request Processed Successfully",
      loan_request: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = update_installment_status;
