const {
  validate_add_loan_request_admin,
} = require("../../utils/validation/loan_request");
const {
  addLoanRequestAdmin,
  addLoanRequestAdminV1,
} = require("../../services/loan_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const add_loan_request_admin = async (req, res) => {
  try {
    try {
      await validate_add_loan_request_admin(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    // const { error, error_message, data } = await addLoanRequestAdmin(
    //   req.user,
    //   req.body
    // );

    const { error, error_message, data } = await addLoanRequestAdminV1(
      req.user,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Loan Request Added Successfully",
      loan_request: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = add_loan_request_admin;
