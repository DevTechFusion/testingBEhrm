const {
  validate_pending_loan_request_admin,
} = require("../../utils/validation/loan_request");
const { pendingInstallmentsForAdmin } = require("../../services/loan_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");
const pending_loan_request_admin = async (req, res) => {
  try {
    try {
      await validate_pending_loan_request_admin(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await pendingInstallmentsForAdmin(
      req.user,
      req.body,
      req.query.limit,
      req.query.page,
    
    );



    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }


    res.status(200).json({
      code: 200,
      message: "Loan Requests Data for Admin",
      loan_request: data.loan_request,
      count: data.total_count,
      total_pages: data.total_pages,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = pending_loan_request_admin;

// const {
//   validate_pending_loan_request_admin,
// } = require("../../utils/validation/loan_request");
// const { RENDER_BAD_REQUEST } = require("../../utils/utils");
// const { LoanRequest } = require("../../models/loan_request");
// const { find_employee_by_user_id } = require("../../DAL/employee");
// const moment = require("moment");
// const pending_loan_request_admin = async (req, res) => {
//   try {
//     try {
//       await validate_pending_loan_request_admin(req.body);
//     } catch (e) {
//       return res
//         .status(400)
//         .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
//     }

//     let body = req.body;
//     let user_id = req.user;

//     let Limit = req.query.limit;
//     let page = req.query.page;

//     let loan_request = [];
//     const emp_details = await find_employee_by_user_id(user_id);

//     //pagination
//     let limit = parseInt(Limit);
//     if (!limit) {
//       limit = 15;
//     }

//     if (page) {
//       page = parseInt(page) + 1;
//       if (isNaN(page)) {
//         page = 1;
//       }
//     } else {
//       page = 1;
//     }
//     let skip = (page - 1) * limit;

//     if (emp_details) {
//       let query_obj = {};
//       if (body.status != "") {
//         query_obj = { "installments.status": body.status };
//       }
//       if (
//         body.date_from &&
//         body.date_to &&
//         body.date_from != "" &&
//         body.date_to != "" &&
//         body.date_from != null &&
//         body.date_to != null &&
//         body.date_from != undefined &&
//         body.date_to != undefined
//       ) {
//         query_obj = {
//           ...query_obj,
//           "installments.due_date": {
//             $gte: new Date(body.date_from),
//             $lte: new Date(body.date_to),
//           },
//         };
//       }

//       query_obj.status = "approved";
//       // console.log("query_obj: ", query_obj);
//       // loan_request = await LoanRequest.find(query_obj);
//       loan_request = await LoanRequest.aggregate([
//         {
//           $match: query_obj,
//         },
//         {
//           $addFields: {
//             installments: {
//               $filter: {
//                 input: "$installments",
//                 as: "installment",
//                 cond: {
//                   $and: [
//                     { $eq: ["$$installment.status", "pending"] },
//                     {
//                       $and: [
//                         {
//                           $gte: [
//                             "$$installment.due_date",
//                             new Date(body.date_from),
//                           ],
//                         },
//                         {
//                           $lte: [
//                             "$$installment.due_date",
//                             new Date(body.date_to),
//                           ],
//                         },
//                       ],
//                     },
//                   ],
//                 },
//               },
//             },
//           },
//         },
//         {
//           $unwind: "$installments",
//         },

//         {
//           $skip: skip,
//         },
//         {
//           $limit: limit,
//         },
//         {
//           $sort: {
//             "installments.due_date": -1,
//           },
//         },
//       ]);

//       //count total pending installments
//       var count_pending_installments = await LoanRequest.aggregate([
//         {
//           $match: query_obj,
//         },
//         {
//           $addFields: {
//             installments: {
//               $filter: {
//                 input: "$installments",
//                 as: "installment",
//                 cond: {
//                   $and: [
//                     { $eq: ["$$installment.status", "pending"] },
//                     {
//                       $and: [
//                         {
//                           $gte: [
//                             "$$installment.due_date",
//                             new Date(body.date_from),
//                           ],
//                         },
//                         {
//                           $lte: [
//                             "$$installment.due_date",
//                             new Date(body.date_to),
//                           ],
//                         },
//                       ],
//                     },
//                   ],
//                 },
//               },
//             },
//           },
//         },
//         {
//           $unwind: "$installments",
//         },
//       ]).count("installments");

//       // console.log(
//       //   "count_pending_installments: ",
//       //   count_pending_installments[0].installments
//       // );

//       var total_count = count_pending_installments[0].installments;

//       // loan_request = await LoanRequest.aggregate([
//       //   {
//       //     $unwind: "$installments" // Unwind the installments array
//       //   },
//       //   {
//       //     $match: query_obj
//       //   },
//       //   {
//       //     $group: {
//       //       _id: "$_id",
//       //       loan: { $first: "$$ROOT" }, // Preserve the original loan document
//       //       installments: { $push: "$installments" } // Collect matching installments
//       //     }
//       //   },
//       //   {
//       //     $match: {
//       //       "loan.installments.due_date": {
//       //         $not: {
//       //           $elemMatch: {
//       //             $gte: new Date (body.date_from),
//       //       $lte: new Date (body.date_to),
//       //           }
//       //         }
//       //       },

//       //     }
//       //   },
//       //   {
//       //     $replaceRoot: { newRoot: "$loan" } // Replace the root with the original loan document
//       //   }
//       // ]);
//     }

//     var total_pages = Math.ceil(total_count / limit);

//     // console.log(loan_request, "=================loan_request");
//     res.status(200).json({
//       code: 200,
//       message: "Loan Requests Data for Admin",
//       loan_request: loan_request,
//       count: total_count,
//       total_pages: total_pages,
//     });
//   } catch (e) {
//     RENDER_BAD_REQUEST(res, e);
//   }
// };

// module.exports = pending_loan_request_admin;
