const {
  validate_edit_loan_request_admin,
} = require("../../utils/validation/loan_request");
const {
  editLoanRequestAdmin,
  editLoanRequestAdminV1,
} = require("../../services/loan_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const edit_loan_request_admin = async (req, res) => {
  try {
    try {
      await validate_edit_loan_request_admin(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    // const { error, error_message, data } = await editLoanRequestAdmin(
    //   req.user,
    //   req.params.id,
    //   req.body
    // );

    const { error, error_message, data } = await editLoanRequestAdminV1(
      req.user,
      req.params.id,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Loan Request Edited Successfully",
      loan_request: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = edit_loan_request_admin;
