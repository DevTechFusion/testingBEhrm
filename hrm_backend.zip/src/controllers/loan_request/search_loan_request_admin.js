const {
  validate_search_loan_request_admin,
} = require("../../utils/validation/loan_request");
const { searchLoanRequestAdmin } = require("../../services/loan_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const search_loan_request_admin = async (req, res) => {
  try {
    try {
      await validate_search_loan_request_admin(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    const { error, error_message, data } = await searchLoanRequestAdmin(
      req.user,
      req.body,
      req.query.limit,
      req.query.page
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Loan Requests Data for Admin",
      total_amount: data.total_amount,
      total_paid_amount: data.total_paid_amount,
      total_pending_amount: data.total_pending_amount,
      loan_request: data.loan_request,
      general_settings: data.gernal_settings,
      count: data.total_pages,
      total_pending_installments: data.total_pending_installments,
      total_paid_installments: data.total_paid_installments,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = search_loan_request_admin;
