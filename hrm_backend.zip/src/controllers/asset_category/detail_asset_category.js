const { detailAssetCategory } = require("../../services/asset_category");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const detail_asset_category = async (req, res) => {
  try {
    const { error, error_message, data } = await detailAssetCategory(req.params.id);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Asset Category Details Found",
      asset_category: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = detail_asset_category;
