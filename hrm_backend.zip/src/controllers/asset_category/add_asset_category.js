const { validate_add_asset_category } = require("../../utils/validation/asset_category");
const { addAssetCategory } = require("../../services/asset_category");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const add_asset_category = async (req, res) => {
  try {
    //validate Request Body
    try {
      await validate_add_asset_category(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await addAssetCategory(req.body);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Asset Category Added Successfully",
      asset_category: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = add_asset_category;
