const {
  validate_change_leave_payment_status,
} = require("../../utils/validation/leave_request");
const { changeLeavePaymentStatus } = require("../../services/leave_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const change_leave_payment_status = async (req, res) => {
  try {
    //validate Request Body
    try {
      await validate_change_leave_payment_status(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await changeLeavePaymentStatus(
      req.params.leave_request_id,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Change Leave Payment Status",
      leave_request: data.leave_request,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = change_leave_payment_status;

