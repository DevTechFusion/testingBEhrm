const {
  getAllEmployeeLeaveRequestStats,
  getAllEmployeeLeaveRequestStatsV1,
  getAllEmployeeLeaveRequestStatsV2,
} = require("../../services/leave_request");
const {
  validate_leave_report,
} = require("../../utils/validation/leave_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_all_employee_leave_request_stats = async (req, res) => {
  try {

    // Validate the request body
    try {
      await validate_leave_report(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    // const { error, error_message, data } =
    //   await getAllEmployeeLeaveRequestStats(
    //     req.query.search,
    //     req.query.limit,
    //     req.query.page,

    //   );

    // const { error, error_message, data } =
    // await getAllEmployeeLeaveRequestStatsV1(
    //   req.query.search,
    //   req.query.limit,
    //   req.query.page,

    // );

    const { error, error_message, data } =
      await getAllEmployeeLeaveRequestStatsV2(
        req.body,
        req.query.limit,
        req.query.page
      );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "All Leave Requests Stats",
      leaves_report: data.leaves_report,
      count: data.count,
      total_pages: data.total_pages,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_all_employee_leave_request_stats;
