const {
  validate_add_leave_request,
} = require("../../utils/validation/leave_request");
const { addLeaveRequest } = require("../../services/leave_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const add_leave_request = async (req, res) => {
  try {
    //validate Request Body
    try {
      await validate_add_leave_request(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await addLeaveRequest(
      req.user,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Leave Request Added Successfully",
      leave_request: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = add_leave_request;
