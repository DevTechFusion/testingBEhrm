const {
  validate_search_leave_request,
} = require("../../utils/validation/leave_request");
const { searchLeaveRequest } = require("../../services/leave_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const search_leave_request = async (req, res) => {
  try {
    try {
      await validate_search_leave_request(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    const { error, error_message, data } = await searchLeaveRequest(
      req.user,
      req.body,
      req.query.limit,
      req.query.page,
      req.query.search
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Leave Requests Data",
      full_day_leaves_yearly: data.full_day_leaves_yearly,
      half_day_leaves_yearly: data.half_day_leaves_yearly,
      leave_request: data.leave_request,
      count: data.total_pages,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = search_leave_request;
