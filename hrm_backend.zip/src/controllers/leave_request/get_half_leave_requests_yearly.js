const { getHalfLeaveRequestsYearly } = require("../../services/leave_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_half_leave_requests_yearly = async (req, res) => {
  try {
    const { error, error_message, data } = await getHalfLeaveRequestsYearly(
      req.user
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Half Leave Requests Yearly Data",
      half_leave_requests: data.half_leave_requests,
      count: data.count,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_half_leave_requests_yearly;
