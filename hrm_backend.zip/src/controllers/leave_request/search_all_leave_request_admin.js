const {
  validate_search_all_leave_request_admin,
} = require("../../utils/validation/leave_request");
const { searchAllLeaveRequestAdmin } = require("../../services/leave_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const search_all_leave_request_admin = async (req, res) => {
  try {
    try {
      await validate_search_all_leave_request_admin(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    const { error, error_message, data } = await searchAllLeaveRequestAdmin(
      req.body,
      req.query.limit,
      req.query.page,
      req.query.search
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "All Leave Requests Data",
      leave_request: data.leave_request,
      count: data.total_pages,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = search_all_leave_request_admin;
