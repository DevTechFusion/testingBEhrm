const {
  validate_edit_leave_request_admin,
} = require("../../utils/validation/leave_request");
const { editLeaveRequestAdmin } = require("../../services/leave_request");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const edit_leave_request_admin = async (req, res) => {
  try {
    //validate Request Body
    try {
      await validate_edit_leave_request_admin(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await editLeaveRequestAdmin(
      req.user,
      req.params.id,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Leave Request Edited Successfully",
      leave_request: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = edit_leave_request_admin;
