const { validate_search_expense } = require("../../utils/validation/expense");
const { searchExpense } = require("../../services/expense");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const search_expense = async (req, res) => {
  try {
    try {
      await validate_search_expense(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    const { error, error_message, data } = await searchExpense(
      req.user,
      req.query.limit,
      req.query.page,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Expense Data",
      expense: data.expense,
      count: data.total_pages,
      available_balance: data.available_balance,
      total_expense: data.total_expense,
      tax_amount: data.tax_amount,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = search_expense;
