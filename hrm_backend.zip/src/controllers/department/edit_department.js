const {
  validate_edit_department,
} = require("../../utils/validation/department");
const { editDepartment } = require("../../services/department");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const edit_department = async (req, res) => {
  try {
    //validate Request Body
    try {
      await validate_edit_department(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await editDepartment(
      req.body,
      req.params.id
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Department Edited Successfully",
      department: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = edit_department;
