const {
  validate_update_allowance,
} = require("../../utils/validation/allowances");
const { updateAllowance } = require("../../services/allowances");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const update_allowance = async (req, res) => {
  try {
    try {
      await validate_update_allowance(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await updateAllowance(
      req.params.id,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Allowance Updated Successfully",
      allowance: data.allowance,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = update_allowance;
