const { listAllowances } = require("../../services/allowances");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");
const list_allowance = async (req, res) => {
  try {
    const { error, error_message, data } = await listAllowances(req.query.type);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "List of Allowances Found Successfully",
      allowance: data.allowances,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = list_allowance;
