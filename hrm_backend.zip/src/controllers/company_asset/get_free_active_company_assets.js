const { getAllFreeActiveCompanyAssets } = require("../../services/company_asset");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_free_active_company_assets = async (req, res) => {
  try {
    const { error, error_message, data } = await getAllFreeActiveCompanyAssets();

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "All Free Company Asset",
      company_asset: data.company_asset,
      count: data.total_pages
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_free_active_company_assets;
