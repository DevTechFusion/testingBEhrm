const { getDataForCompanyAssetList } = require("../../services/company_asset");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_data_for_company_asset_list = async (req, res) => {
  try {
    const { error, error_message, data } = await getDataForCompanyAssetList();

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Data list for company asset",
      category_list: data.category_list,
      vendor_list: data.vendor_list,
      brand_list : data.brand_list,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_data_for_company_asset_list;
