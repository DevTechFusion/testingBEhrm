const {
  searchCompanyAsset,
  searchCompanyAssetV1,
  searchCompanyAssetV2,
} = require("../../services/company_asset");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");
const {
  validate_search_company_asset,
} = require("../../utils/validation/company_asset");

const search_company_asset = async (req, res) => {
  try {
    try {
      await validate_search_company_asset(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.message.replace(/\"/g, "") });
    }
    // const { error, error_message, data } = await searchCompanyAsset(
    //   req.body,
    //   req.query.limit,
    //   req.query.page
    // );

    // const { error, error_message, data } = await searchCompanyAssetV1(
    //   req.body,
    //   req.query.limit,
    //   req.query.page
    // );

    const { error, error_message, data } = await searchCompanyAssetV2(
      req.body,
      req.query.limit,
      req.query.page
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Company Asset Data",
      total_price: data.total_price,
      company_asset: data.company_asset,
      count: data.count,
      total_pages: data.total_pages,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = search_company_asset;
