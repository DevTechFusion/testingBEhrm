const {
  validate_edit_company_asset,
} = require("../../utils/validation/company_asset");
const { editCompanyAsset } = require("../../services/company_asset");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const edit_company_asset = async (req, res) => {
  try {
    try {
      await validate_edit_company_asset(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await editCompanyAsset(
      req.body,
      req.params.id,
      req.files
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Company Asset Edited Successfully",
      company_asset: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = edit_company_asset;
