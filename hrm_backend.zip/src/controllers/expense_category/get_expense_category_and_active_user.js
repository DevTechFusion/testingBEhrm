const {
  getExpenseCategoryAndActiveUser,
} = require("../../services/expense_category");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_expense_category_and_active_user = async (req, res) => {
  try {
    const { error, error_message, data } =
      await getExpenseCategoryAndActiveUser(
        req.query.type,
      );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Expense Categories and Active User List",
      expense_category: data.expense_category,
      employee: data.employee,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_expense_category_and_active_user;
