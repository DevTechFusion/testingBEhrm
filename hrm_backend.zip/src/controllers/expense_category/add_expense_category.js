const { validate_add_expense_category } = require("../../utils/validation/expense_category");
const { addExpenseCategory } = require("../../services/expense_category");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const add_expense_category = async (req, res) => {
  try {
    //validate Request Body
    try {
      await validate_add_expense_category(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await addExpenseCategory(req.body);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Expense Category Added Successfully",
      expense_category: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = add_expense_category;
