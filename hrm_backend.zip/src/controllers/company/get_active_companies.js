const { getAllActiveCompanies } = require("../../services/company");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_active_companies = async (req, res) => {
  try {
    const { error, error_message, data } = await getAllActiveCompanies();

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "All Active Companies Data",
      company: data.company
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_active_companies;
