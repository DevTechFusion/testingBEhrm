const { detailEmployeeDeactivationByID } = require("../../services/employee_deactivation");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const detail_employee_deactivation = async (req, res) => {
  try {
    const { error, error_message, data } = await detailEmployeeDeactivationByID(req.params.id);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Member Deactivation Details Found",
      employee_deactivation: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = detail_employee_deactivation;
