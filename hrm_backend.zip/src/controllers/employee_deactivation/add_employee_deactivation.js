const { validate_add_employee_deactivation } = require("../../utils/validation/employee_deactivation");
const { addEmployeeDeactivation } = require("../../services/employee_deactivation");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const add_employee_deactivation = async (req, res) => {
  try {
    //validate Request Body
    try {
      await validate_add_employee_deactivation(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await addEmployeeDeactivation(req.body);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Member Deactivated Successfully",
      employee_deactivation: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = add_employee_deactivation;
