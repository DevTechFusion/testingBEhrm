const { deleteEmployeeDeactivation } = require("../../services/employee_deactivation");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const delete_employee_deactivation = async (req, res) => {
  try {
    const { error, error_message, data } = await deleteEmployeeDeactivation(req.params.id);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Member Deactivation Deleted Successfully!",
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = delete_employee_deactivation;
