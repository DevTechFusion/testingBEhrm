const { getDataForAddEmployee } = require("../../services/dashboard");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_data_for_add_employee = async (req, res) => {
  try {
    const { error, error_message, data } = await getDataForAddEmployee();

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Data for add employee",
      departments: data.departments,
      roles: data.roles,
      companies: data.companies,
      company_assets: data.company_assets,
      active_employees: data.active_employees,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_data_for_add_employee;
