const { getDashboardData,
  getDashboardDataV1,
  getDashboardDataV2,
 } = require("../../services/dashboard");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_dashboard_data = async (req, res) => {
  try {
    // const { error, error_message, data } = await getDashboardData(req.user);
    // const { error, error_message, data } = await getDashboardDataV1(req.user);
    const { error, error_message, data } = await getDashboardDataV2(req.user);


    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Dashboard Data",
      // birthday_employees: data.birthday_employees,
      // increment_employees: data.increment_employees,
      month_name: data.month_name,
      current_month_absents: data.current_month_absents,
      current_month_fineable_mins: data.current_month_fineable_mins,
      late_mins_monthly: data.late_mins_monthly,
      total_absents_yearly: data.total_absent_yearly,
      today_late_minutes: data.today_late_minutes,
      // seven_days_attendance: data.seven_days_attendance,
      all_on_leave: data.all_on_leave,
      on_leave_employees: data.on_leave_employees,
      is_lead: data.is_lead,
      // fines: data.fines,
      // lunches: data.lunches,
      // current_month_lunch: data.current_month_lunch,
      pending_feedbacks: data.pending_feedbacks,
      last_month_performance: data.last_month_performance,
      current_year_performance: data.current_year_performance,
      want_lunch: data.want_lunch,
      latest_tickets: data.latest_tickets,
      allowed_leaves:data.allowed_leaves
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_dashboard_data;
