const { validate_search_top_up } = require("../../utils/validation/top_up");
const { searchTopUp } = require("../../services/top_up");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const search_top_up = async (req, res) => {
  try {
    try {
      await validate_search_top_up(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    const { error, error_message, data } = await searchTopUp(
      req.user,
      req.query.limit,
      req.query.page,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Top Up Data",
      top_up: data.top_up,
      count: data.total_pages,
      top_up_balance: data.top_up_balance,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = search_top_up;
