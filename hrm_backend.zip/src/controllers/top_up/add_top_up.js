const { validate_add_top_up } = require("../../utils/validation/top_up");
const { addTopUp } = require("../../services/top_up");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const add_top_up = async (req, res) => {
  try {
    //validate Request Body
    try {
      await validate_add_top_up(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await addTopUp(req.user, req.body);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Top Up Added Successfully",
      top_up: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = add_top_up;
