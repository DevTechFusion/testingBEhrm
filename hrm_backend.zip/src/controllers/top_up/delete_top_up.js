const { deleteTopUp } = require("../../services/top_up");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const delete_top_up = async (req, res) => {
  try {
    const { error, error_message, data } = await deleteTopUp(req.params.id);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Top Up Deleted Successfully!",
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = delete_top_up;
