const { validate_add_tax_slabs } = require("../../utils/validation/tax_slabs");
const { addTaxSlabs } = require("../../services/tax_slabs");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const add_tax_slabs = async (req, res) => {
  try {
    try {
      await validate_add_tax_slabs(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await addTaxSlabs(req.body);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Tax Slab Added Successfully",
      tax_slabs: data.tax_slabs,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = add_tax_slabs;
