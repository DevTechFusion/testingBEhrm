const {
  validate_employees_for_payroll,
} = require("../../utils/validation/employee");
const { getEmployeesForPayroll ,getEmployeesForPayrollV1} = require("../../services/employee");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_employees_for_payroll = async (req, res) => {
  try {
    try {
      await validate_employees_for_payroll(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    // const { error, error_message, data } = await getEmployeesForPayroll(
    //   req.body
    // );

    const { error, error_message, data } = await getEmployeesForPayrollV1(
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "All Active Members for Payroll",
      employee: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_employees_for_payroll;
