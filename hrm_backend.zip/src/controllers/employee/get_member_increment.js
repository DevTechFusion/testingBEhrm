// const { validate_add_employee } = require("../../utils/validation/employee");
const {
  getIncrementForEmployee
} = require("../../services/employee");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_member_increment = async (req, res) => {
  try {
   

    const { error, error_message, data } = await getIncrementForEmployee(
      req.body,
      req.query.limit,
      req.query.page
     
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Increment data for employee ",
      increment_employees : data.increment_employees,
      count : data.count,
      total_pages : data.total_pages,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_member_increment;
