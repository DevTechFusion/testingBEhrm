const { getMemberListForMyTeam } = require("../../services/employee");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_member_list_for_my_team = async (req, res) => {
  try {
    const { error, error_message, data } = await getMemberListForMyTeam(
      req.user
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Team Members For My Team ",
      member_list: data.member_list,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_member_list_for_my_team;
