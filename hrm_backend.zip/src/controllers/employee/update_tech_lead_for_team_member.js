const {
  validate_tech_lead_for_member,
} = require("../../utils/validation/employee");
const { updateTechLeadForTeamMember } = require("../../services/employee");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const update_tech_lead_for_team_member = async (req, res) => {
  try {
    try {
      await validate_tech_lead_for_member(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    const { error, error_message, data } = await updateTechLeadForTeamMember(
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Members and Leads data found",
      get_member: data.get_member,
    });
  } catch (e) {
    console.log(e, "error");
    return res.status(400).json({
      code: 400,
      message: "Something went wrong",
    });
  }
};

module.exports = update_tech_lead_for_team_member;
