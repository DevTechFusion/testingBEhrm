const { deleteEmployee } = require("../../services/employee");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const delete_employee = async (req, res) => {
  try {
    const { error, error_message, data } = await deleteEmployee(req.params.id,req.token);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Member Deleted Successfully!",
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = delete_employee;
