const { validate_add_employee } = require("../../utils/validation/employee");
const { addEmployee } = require("../../services/employee");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const add_employee = async (req, res) => {
  try {
    try {
      console.log(req.body, "==========req.body");
      await validate_add_employee(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await addEmployee(
      req.body,
      req.files
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Member Added Successfully",
      employee: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = add_employee;
