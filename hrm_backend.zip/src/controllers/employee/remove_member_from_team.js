// const {
//   validate_remove_member_from_team,
// } = require("../../utils/validation/employee");
const { removeMemberFromTeam } = require("../../services/employee");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const remove_member_from_team = async (req, res) => {
  try {
    // try {
    //   await validate_remove_member_from_team(req.body);
    // } catch (e) {
    //   return res
    //     .status(400)
    //     .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    // }

    const { error, error_message, data } = await removeMemberFromTeam(
      req.user,
      req.params.member_id
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Members removed from team successfully",
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = remove_member_from_team;
