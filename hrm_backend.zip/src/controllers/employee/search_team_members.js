const {
  searchTeamMembers,
  searchTeamMembersV1,
} = require("../../services/employee");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const search_team_members = async (req, res) => {
  try {
    const { error, error_message, data } = await searchTeamMembersV1(
      req.user,
      req.query.search,
      req.query.limit,
      req.query.page
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Team Members Data Found",
      team_members: data.team_members,
      count: data.count,
      total_pages: data.total_pages,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = search_team_members;
