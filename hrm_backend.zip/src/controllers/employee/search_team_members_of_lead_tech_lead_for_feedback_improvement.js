const { searchTeamMembersForLeadTechLeadForFeedbackImprovement } = require("../../services/employee");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const search_team_members_of_lead_tech_lead_for_feedback_improvement = async (
  req,
  res
) => {
  try {
    const { error, error_message, data } =
      await searchTeamMembersForLeadTechLeadForFeedbackImprovement(
        req.user,
        req.query.search,
        req.query.filter_by
      );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Team Members Found for Lead Tech Lead",
      team_members: data.team_members,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = search_team_members_of_lead_tech_lead_for_feedback_improvement;
