const {
  validate_get_members_or_leads,
} = require("../../utils/validation/employee");
const { getMembersLeadsForEachOther } = require("../../services/employee");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_team_members_for_lead = async (req, res) => {
  try {
    try {
      await validate_get_members_or_leads(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    const { error, error_message, data } = await getMembersLeadsForEachOther(
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Members and Leads data found",
      members_leads: data.members_leads,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_team_members_for_lead;
