const { getEmployees , getEmployeesV1 , getEmployeesV2} = require("../../services/employee");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_employees_v1 = async (req, res) => {
  try {
    // const { error, error_message, data } = await getEmployees(
    //   req.query.active_status,
    //   req.query.search,
    //   req.query.limit,
    //   req.query.page
    // );

    // const { error, error_message, data } = await getEmployeesV1(
    //   req.query.active_status,
    //   req.query.search,
    //   req.query.limit,
    //   req.query.page
    // );

       const { error, error_message, data } = await getEmployeesV2(
      req.query.active_status,
      req.query.search,
      req.query.limit,
      req.query.page
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Members Data Found",
      employee: data.employee,
      count: data.total_pages,
      total_employees: data.total_employees,
      active_employees: data.active_employees,
      inactive_employees: data.inactive_employees,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_employees_v1;
