// const { validate_add_employee } = require("../../utils/validation/employee");
const {
  getMemberBirthdayAnniversary,
  getMemberBirthdayAnniversaryV1,
} = require("../../services/employee");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_member_birthday_anniversary = async (req, res) => {
  try {
    // try {
    //   console.log(req.body, "==========req.body");
    //   await validate_add_employee(req.body);
    // } catch (e) {
    //   return res
    //     .status(400)
    //     .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    // }

    const { error, error_message, data } = await getMemberBirthdayAnniversaryV1(
      req.body,
      req.query.limit,
      req.query.page
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Birthday Anniversary Data Found",
      member_list: data.member_list,
      count: data.count,
      total_pages: data.total_pages,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_member_birthday_anniversary;
