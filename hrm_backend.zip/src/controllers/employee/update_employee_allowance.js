const { validate_update_employee_allowance } = require("../../utils/validation/employee");
const { updateEmployeeAllowance } = require("../../services/employee");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const update_employee_allowance = async (req, res) => {
  try {
    try {
      await validate_update_employee_allowance(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await updateEmployeeAllowance(
      req.params.id,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Allowance Updated successfully",
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = update_employee_allowance;
