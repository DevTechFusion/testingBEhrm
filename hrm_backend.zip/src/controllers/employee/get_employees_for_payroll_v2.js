const {
  validate_employees_for_payroll,
} = require("../../utils/validation/employee");
const { getEmployeesForPayrollV2 } = require("../../services/employee");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_employees_for_payroll_v2 = async (req, res) => {
  try {
    try {
      await validate_employees_for_payroll(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await getEmployeesForPayrollV2(
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Active Members and General & Other Allowances for Payroll",
      general_allowance: data.general_allowance,
      other_allowance: data.other_allowance,
      employee: data.all_employees,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_employees_for_payroll_v2;
