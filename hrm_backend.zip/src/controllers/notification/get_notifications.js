const { getNotifications } = require("../../services/notification");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_notifications = async (req, res) => {
  try {
    const { error, error_message, data } = await getNotifications(
      req.user,
      req.query.limit,
      req.query.page
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Roles Data",
      notifications: data.notification,
      count: data.total_pages,
      total_notifications: data.total_notifications,
      total_read_notifications: data.total_read_notifications,
      total_unread_notifications: data.total_unread_notifications,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_notifications;
