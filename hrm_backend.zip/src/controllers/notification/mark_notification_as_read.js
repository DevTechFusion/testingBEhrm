const {
  validate_read_notification,
} = require("../../utils/validation/notification");
const { markNotificationAsRead } = require("../../services/notification");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const mark_notification_as_read = async (req, res) => {
  try {
    const { error, error_message, data } = await markNotificationAsRead(req.user, req.params.id);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Notification Marked as Read Successfully",
      notification: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = mark_notification_as_read;
