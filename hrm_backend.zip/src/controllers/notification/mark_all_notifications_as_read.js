const {
  validate_read_notification,
} = require("../../utils/validation/notification");
const { markAllNotificationsAsRead } = require("../../services/notification");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const mark_all_notifications_as_read = async (req, res) => {
  try {
    const { error, error_message, data } = await markAllNotificationsAsRead(req.user);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "All notifications are marked as read successfully",
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = mark_all_notifications_as_read;
