const {
  validate_edit_brand,
} = require("../../utils/validation/brand");
const { editBrand } = require("../../services/brand");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const edit_brand = async (req, res) => {
  try {
    //validate Request Body
    try {
      await validate_edit_brand(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await editBrand(
      req.body,
      req.params.id
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Brand Edited Successfully",
      brand: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = edit_brand;
