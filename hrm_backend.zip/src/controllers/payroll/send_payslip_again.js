const {
  validate_send_payslip_again,
} = require("../../utils/validation/payroll");
const { sendPayslipAgain } = require("../../services/payroll");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const send_payslip_again = async (req, res) => {
  try {
    console.log(req.body);
    try {
      await validate_send_payslip_again(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await sendPayslipAgain(req.body);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "PaySlip Send Successfully",
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = send_payslip_again;
