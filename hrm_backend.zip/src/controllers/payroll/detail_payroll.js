const { detailPayroll } = require("../../services/payroll");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const detail_payroll = async (req, res) => {
  try {
    const { error, error_message, data } = await detailPayroll(req.params.id);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Payroll Details Found",
      payroll: data.payroll,
      general_allowance: data.general_allowance,
      other_allowance: data.other_allowance,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = detail_payroll;
