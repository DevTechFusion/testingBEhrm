const { validate_email_payslip } = require("../../utils/validation/payroll");
const { emailPayslip } = require("../../services/payroll");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const email_payslip = async (req, res) => {
  try {
    try {
      await validate_email_payslip(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    const { error, error_message, data } = await emailPayslip(
      req.user,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Payslips sent successfully",
      // payroll: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = email_payslip;
