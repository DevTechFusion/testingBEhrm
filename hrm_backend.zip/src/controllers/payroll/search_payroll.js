const { validate_search_payroll } = require("../../utils/validation/payroll");
const { searchPayroll, searchPayrollV1 } = require("../../services/payroll");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const search_payroll = async (req, res) => {
  try {
    try {
      await validate_search_payroll(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    // const { error, error_message, data } = await searchPayroll(
    //   req.user,
    //   req.query.limit,
    //   req.query.page,
    //   req.body
    // );

    const { error, error_message, data } = await searchPayrollV1(
      req.user,
      req.query.limit,
      req.query.page,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Payroll Data",
      payroll: data.payroll,
      count: data.total_pages,
      total_salary: data.total_salary,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = search_payroll;
