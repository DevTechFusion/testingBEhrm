const { validate_search_announcement } = require("../../utils/validation/announcement");
const { searchAnnouncement } = require("../../services/announcement");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const search_announcement = async (req, res) => {
  try {
    try {
      await validate_search_announcement(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    const { error, error_message, data } = await searchAnnouncement(
      req.query.limit,
      req.query.page,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Announcement Data",
      announcement: data.announcement,
      count: data.total_pages,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = search_announcement;
