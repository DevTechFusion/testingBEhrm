const { validate_get_absents } = require("../../utils/validation/attendance");
const { getEmployeeAbsents } = require("../../services/attendance");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_employee_absents = async (req, res) => {
  try {
    await validate_get_absents(req.body);
  } catch (e) {
    return res
      .status(400)
      .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
  }
  try {
    const { error, error_message, data } = await getEmployeeAbsents(
      req.body,
      req.query.limit,
      req.query.page
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Attendances Data Found",
      absents: data.absents,
      count: data.count,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_employee_absents;
