const { getAttendanceForEmployee } = require("../../services/attendance");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_attendance_for_employee = async (req, res) => {
  try {
    const { error, error_message, data } = await getAttendanceForEmployee(
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Attendance Data Found",
      attendance: data.attendance,
      allowed_leaves: data.allowed_leaves,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_attendance_for_employee;
