const { validate_pay_fine } = require("../../utils/validation/attendance");
const { payFine } = require("../../services/attendance");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const pay_fine = async (req, res) => {
  try {
    await validate_pay_fine(req.body);
  } catch (e) {
    return res
      .status(400)
      .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
  }
  try {
    const { error, error_message, data } = await payFine(req.body);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Fine payement status updated successfully",
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = pay_fine;
