const { getFineUser } = require("../../services/attendance");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_fine_user = async (req, res) => {
  try {
    const { error, error_message, data } = await getFineUser(
      req.user,
      req.query.search
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Fine data found scuccessfully",
      finesheet: data.finesheet,
      count: data.count,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_fine_user;
