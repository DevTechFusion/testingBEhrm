const { getAttendancesV1 } = require("../../services/attendance");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");
const {
  validate_get_attendance_v1,
} = require("../../utils/validation/attendance");

const get_attendances_v1 = async (req, res) => {
  try {
    try {
      await validate_get_attendance_v1(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await getAttendancesV1(
      req.query.limit,
      req.query.page,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Attendances Data Found",
      attendance: data.attendance,
      count: data.total_count,
      total_pages: data.total_pages,

      // load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_attendances_v1;
