const {
  validate_grant_relax_minutes,
} = require("../../utils/validation/attendance");
const { grantRelaxMinutes } = require("../../services/attendance");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const grant_relax_minutes = async (req, res) => {
  try {
    await validate_grant_relax_minutes(req.body);
  } catch (e) {
    return res
      .status(400)
      .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
  }
  try {
    const { error, error_message, data } = await grantRelaxMinutes(req.body);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Attendance Data For Fine",
      attendance: data.attendance,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = grant_relax_minutes;
