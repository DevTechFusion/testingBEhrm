const { validate_get_finesheet } = require("../../utils/validation/attendance");
const { getFineSheet } = require("../../services/attendance");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_finesheet = async (req, res) => {
  try {
    await validate_get_finesheet(req.body);
  } catch (e) {
    return res
      .status(400)
      .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
  }
  try {
    const { error, error_message, data } = await getFineSheet(
      req.query.limit,
      req.query.page,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Attendance Data For Fine",
      finesheet: data.finesheet,
      count: data.count,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_finesheet;
