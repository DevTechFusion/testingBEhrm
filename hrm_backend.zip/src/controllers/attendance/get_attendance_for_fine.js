const {
  validate_get_attendance_for_fine,
} = require("../../utils/validation/attendance");
const { getAttendanceForFine } = require("../../services/attendance");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const get_attendance_for_fine = async (req, res) => {
  try {
    await validate_get_attendance_for_fine(req.body);
  } catch (e) {
    return res
      .status(400)
      .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
  }
  try {
    const { error, error_message, data } = await getAttendanceForFine(req.body);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Attendance Data For Fine",
      attendance: data.attendance
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_attendance_for_fine;
