const { getEmployeeLeaves ,getEmployeeLeavesV1 } = require("../../services/attendance");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");
const {
  validate_employee_leaves,
} = require("../../utils/validation/attendance");

const get_employee_leaves = async (req, res) => {
  try {
    try {
      await validate_employee_leaves(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    // const { error, error_message, data } = await getEmployeeLeaves(
    //   req.params.id,
    //   req.query.limit,
    //   req.query.page,
    //   req.body
    // );

    const { error, error_message, data } = await getEmployeeLeavesV1(
      req.params.id,
      req.query.limit,
      req.query.page,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Attendance Data Found",
      attendance: data.attendance,
      count: data.count,
      total_pages: data.total_pages,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_employee_leaves;
