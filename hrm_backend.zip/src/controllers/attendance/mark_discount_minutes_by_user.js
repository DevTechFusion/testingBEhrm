const { markDiscountMinutesByUser } = require("../../services/attendance");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const mark_discount_minutes_by_user = async (req, res) => {
  try {
    const { error, error_message, data } = await markDiscountMinutesByUser(
      req.user,
      req.query.date
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: data.message,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = mark_discount_minutes_by_user;
