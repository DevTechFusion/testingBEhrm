const {
  getAttendanceForEmployeeUser,
  getAttendanceForEmployeeUserV1,
} = require("../../services/attendance");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");
const {
  validate_get_attendance_for_employee_user,
} = require("../../utils/validation/attendance");

const get_attendance_for_employee_user = async (req, res) => {
  try {
    try {
      await validate_get_attendance_for_employee_user(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    // const { error, error_message, data } = await getAttendanceForEmployeeUser(
    //   req.params.id,
    //   req.query.limit,
    //   req.query.page,
    //   req.body
    // );
     const { error, error_message, data } = await getAttendanceForEmployeeUserV1(
      req.params.id,
      req.query.limit,
      req.query.page,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Attendance Data Found",
      attendance: data.attendance,
      count : data.count,
      total_pages: data.total_pages,
      load_more_url: data.load_more_url,
      current_month_absents: data.current_month_absents,
      current_month_late_mins: data.current_month_late_mins,
      allowed_leaves: data.allowed_leaves,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = get_attendance_for_employee_user;
