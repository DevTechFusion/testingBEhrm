const { validateAttendanceAdd } = require("../../utils/validation/attendance");
const { addAttendance } = require("../../services/attendance");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const add_attendance = async (req, res) => {
  try {
    const { error, error_message, data } = await addAttendance(req.files);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Attendance Added Successfully",
      attendance: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = add_attendance;
