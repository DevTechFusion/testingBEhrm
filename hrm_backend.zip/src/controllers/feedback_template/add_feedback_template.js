const { validate_add_feedback_template } = require("../../utils/validation/feedback_template");
const { addFeedbackTemplate } = require("../../services/feedback_template");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const add_feedback_template = async (req, res) => {
  try {
    //validate Request Body
    try {
      await validate_add_feedback_template(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await addFeedbackTemplate(req.body);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Feedback Template Added Successfully",
      feedback_template: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = add_feedback_template;
