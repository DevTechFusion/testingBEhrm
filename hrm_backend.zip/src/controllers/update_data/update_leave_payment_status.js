const { RENDER_BAD_REQUEST } = require("../../utils/utils");
const { LeaveRequest } = require("../../models/leave_request");

const update_leave_payment_status = async (req, res) => {
  try {
    //update leave payment status paid in all leave request

    await LeaveRequest.updateMany({}, { count_in_yearly_leaves: true });

    res.status(200).json({
      code: 200,
      message: "Update Leave Payment Status",
    });
  } catch (e) {
    return res.status(400).json({
      code: 400,
      message: "Something went wrong",
    });
  }
};

module.exports = update_leave_payment_status;
