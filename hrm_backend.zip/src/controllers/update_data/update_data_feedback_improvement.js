const { RENDER_BAD_REQUEST } = require("../../utils/utils");
const { FeedbackImprovement } = require("../../models/feedback_improvement");

const update_data_feedback_improvement = async (req, res) => {
  try {
    const feedback_improvement = await FeedbackImprovement.find();

    //count
    console.log("count feedback_improvement", feedback_improvement.length);
    // console.log("feedback_improvement", feedback_improvement);

    feedback_improvement.map(async (feedback) => {
      if (feedback.team_member_info) {
        feedback.team_member_info = feedback.team_member_info;
      }
      feedback.show_to_team = true;

      await feedback.save();
    });

    res.status(200).json({
      code: 200,
      message: "Update data in feedback improvement",
      // feedback_improvement: feedback_improvement,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = update_data_feedback_improvement;
