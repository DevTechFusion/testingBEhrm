const { validate_add_lunch } = require("../../utils/validation/lunch");
const { addLunch } = require("../../services/lunch");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const add_lunch = async (req, res) => {
  try {
    //validate Request Body
    try {
      await validate_add_lunch(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await addLunch(req.user, req.body);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Lunch Added Successfully",
      lunch: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = add_lunch;
