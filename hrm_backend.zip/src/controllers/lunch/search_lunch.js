const { validate_search_lunch } = require("../../utils/validation/lunch");
const { searchLunch } = require("../../services/lunch");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const search_lunch = async (req, res) => {
  try {
    try {
      await validate_search_lunch(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    const { error, error_message, data } = await searchLunch(
      req.user,
      req.query.limit,
      req.query.page,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Lunch Data",
      lunch: data.lunch,
      count: data.total_pages,
      available_balance: data.available_balance,
      total_lunch: data.total_lunch,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = search_lunch;
