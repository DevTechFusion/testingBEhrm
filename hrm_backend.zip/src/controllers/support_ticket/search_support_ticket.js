const {
  validate_search_support_ticket,
} = require("../../utils/validation/support_ticket");
const { searchSupportTicket } = require("../../services/support_ticket");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const search_support_ticket = async (req, res) => {
  try {
    try {
      await validate_search_support_ticket(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }
    const { error, error_message, data } = await searchSupportTicket(
      req.user,
      req.body,
      req.query.limit,
      req.query.page,
      req.query.search
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Support Tickets Data",
      support_ticket: data.support_ticket,
      count: data.total_pages,
      open_tickets_count: data.open_tickets_count,
      close_tickets_count: data.close_tickets_count,
      all_tickets_count: data.all_tickets_count,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = search_support_ticket;
