const { removeUnreadMessageCountSupportTicket } = require("../../services/support_ticket");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const remove_unread_message_count_support_ticket = async (req, res) => {
  try {
    const { error, error_message, data } = await removeUnreadMessageCountSupportTicket(
      req.user,
      req.params.id
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Support ticket messages are marked as read",
      // support_ticket: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = remove_unread_message_count_support_ticket;
