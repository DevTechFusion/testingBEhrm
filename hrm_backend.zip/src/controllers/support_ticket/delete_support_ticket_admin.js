const { deleteSupportTicketAdmin } = require("../../services/support_ticket");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const delete_support_ticket_admin = async (req, res) => {
  try {
    const { error, error_message, data } = await deleteSupportTicketAdmin(
      req.user,
      req.params.id
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Support Ticket Deleted Successfully!",
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = delete_support_ticket_admin;
