const {
  validate_edit_support_ticket,
} = require("../../utils/validation/support_ticket");
const { editSupportTicket } = require("../../services/support_ticket");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const edit_support_ticket = async (req, res) => {
  try {
    //validate Request Body
    try {
      await validate_edit_support_ticket(req.body);
    } catch (e) {
      return res
        .status(400)
        .json({ code: 400, message: e.details[0].message.replace(/\"/g, "") });
    }

    const { error, error_message, data } = await editSupportTicket(
      req.user,
      req.params.id,
      req.body
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Support Ticket Edited Successfully",
      support_ticket: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = edit_support_ticket;
