const { detailRole } = require("../../services/role");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const detail_role = async (req, res) => {
  try {
    const { error, error_message, data } = await detailRole(req.params.id);

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Role Details Found",
      role: data,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = detail_role;
