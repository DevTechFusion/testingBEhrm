const { searchRole } = require("../../services/role");
const { RENDER_BAD_REQUEST } = require("../../utils/utils");

const search_role = async (req, res) => {
  try {
    const { error, error_message, data } = await searchRole(
      req.query.limit,
      req.query.page,
      req.query.search
    );

    if (error) {
      return res.status(400).json({
        code: 400,
        message: error_message,
      });
    }

    res.status(200).json({
      code: 200,
      message: "Roles Data",
      role: data.role,
      count: data.total_pages,
      load_more_url: data.load_more_url,
    });
  } catch (e) {
    RENDER_BAD_REQUEST(res, e);
  }
};

module.exports = search_role;
