const { Company } = require("../models/company");

const Add_company = async (company_data) => {
  const new_company = new Company(company_data);
  return await new_company.save();
};
const find_company_by_id = async (id) => {
  return await Company.findOne({ _id: id });
};
const find_company_by_name = async (title) => {
  return await Company.findOne({ title: title });
};

const total_company = async (id) => {
  return await Company.find().count();
};

const latest_company = async (id) => {
  return await Company.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_company = async (skip, limit) => {
  return await Company.find().sort({ createdAt: -1 }).limit(limit).skip(skip);
};
const all_company_count = async () => {
  return await Company.find().countDocuments();
};

const delete_company_by_id = async (company_id) => {
  return await Company.findByIdAndDelete(company_id);
};
const get_company_search = async (search = "", skip, limit) => {
  return await Company.find({
    $or: [
      { title: { $regex: new RegExp(search, "i") } },
      { address: { $regex: new RegExp(search, "i") } },
    ],
  })
    .skip(skip)
    .limit(limit);
};
const company_search_count = async (search = "") => {
  return await Company.find({
    $or: [
      { title: { $regex: new RegExp(search, "i") } },
      { address: { $regex: new RegExp(search, "i") } },
    ],
  }).countDocuments();
};

const all_active_companies = async () => {
  return await Company.find({ active_status: true }).sort({ createdAt: -1 });
};

const all_active_companies_v1 = async () => {
  return await Company.find({ active_status: true }, { _id: 1, title: 1 })
    .sort({ createdAt: -1 })
    .lean();
};

const all_active_companies_count = async () => {
  return await Company.find({ active_status: true }).countDocuments();
};

module.exports = {
  Add_company,
  find_company_by_id,
  total_company,
  latest_company,
  find_company_by_name,
  pagination_company,
  all_company_count,
  delete_company_by_id,
  get_company_search,
  company_search_count,
  all_active_companies,
  all_active_companies_count,
  all_active_companies_v1,
};
