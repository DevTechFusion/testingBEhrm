const { Role } = require("../models/role");

const add_role = async (role_data) => {
  const new_role = new Role(role_data);
  return await new_role.save();
};
const find_role_by_id = async (id) => {
  return await Role.findOne({ _id: id });
};
const find_role_by_name = async (title) => {
  return await Role.findOne({ title: title });
};

const total_role = async (id) => {
  return await Role.find().count();
};

const latest_role = async (id) => {
  return await Role.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_role = async (skip, limit) => {
  return await Role.find().sort({ order: -1 }).limit(limit).skip(skip);
};

const all_roles_active = async () => {
  return await Role.find({ active_status: true }).sort({ order: -1 });
};

const all_roles_active_v1 = async () => {
  //select only _id and title with loan
  return await Role.find({ active_status: true }, { _id: 1, title: 1 })
    .sort({ order: -1 })
    .lean();
};

const all_roles_active_count = async () => {
  return await Role.find({ active_status: true }).countDocuments();
};

const delete_role_by_id = async (role_id) => {
  return await Role.findByIdAndDelete(role_id);
};
const get_role_search = async (limit, skip, search = "") => {
  return await Role.find({
    $or: [{ title: { $regex: new RegExp(search, "i") } }],
  })
    .sort({ order: -1 })
    .skip(skip)
    .limit(limit);
};
const role_search_count = async (search = "") => {
  return await Role.find({
    $or: [{ title: { $regex: new RegExp(search, "i") } }],
  }).countDocuments();
};

const update_company_in_roles = async (company_id, company_title) => {
  await Role.updateMany(
    { "company._id": company_id },
    {
      $set: {
        "company.title": company_title,
      },
    }
  );
};

const update_employee_roles = async (employee_id, employee_name) => {
  await Role.updateMany(
    { "assigned_employee._id": employee_id },
    {
      $set: {
        "assigned_employee.name": employee_name,
      },
    }
  );
};

const unassign_roles = async (employee_id) => {
  await Role.updateMany(
    { "assigned_employee._id": employee_id },
    {
      $set: {
        "assigned_employee._id": "",
        "assigned_employee.name": "",
      },
    }
  );
};

const get_default_role = async () => {
  return await Role.findOne({ is_default: true });
};

module.exports = {
  add_role,
  find_role_by_id,
  total_role,
  latest_role,
  find_role_by_name,
  pagination_role,
  all_roles_active,
  all_roles_active_count,
  delete_role_by_id,
  get_role_search,
  role_search_count,
  update_company_in_roles,
  update_employee_roles,
  unassign_roles,
  get_default_role,
  all_roles_active_v1,
};
