const { Notification } = require("../models/notification");

const add_notification = async (notification_data) => {
  const new_notification = new Notification(notification_data);
  return await new_notification.save();
};
const find_notification_by_id = async (id) => {
  return await Notification.findOne({ _id: id });
};
const find_notification_by_name = async (title) => {
  return await Notification.findOne({ title: title });
};

const total_notification = async (id) => {
  return await Notification.find().count();
};

const latest_notification = async (id) => {
  return await Notification.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_notification = async (skip, limit) => {
  return await Notification.find().sort({ order: -1 }).limit(limit).skip(skip);
};

const all_notifications_active = async () => {
  return await Notification.find({ active_status: true }).sort({ order: -1 });
};

const all_notifications_active_count = async () => {
  return await Notification.find({ active_status: true }).countDocuments();
};

const delete_notification_by_id = async (notification_id) => {
  return await Notification.findByIdAndDelete(notification_id);
};
const get_notification_search = async (user_id, limit, skip, search = "") => {
  return await Notification.find({
    user_id: user_id,
    $or: [{ title: { $regex: new RegExp(search, "i") } }],
  })
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);
};
const notification_search_count = async (user_id, search = "") => {
  return await Notification.find({
    user_id: user_id,
    $or: [{ title: { $regex: new RegExp(search, "i") } }],
  }).countDocuments();
};

const count_read_notifications = async (user_id) => {
  return await Notification.find({
    user_id: user_id,
    unread_status: false,
  }).countDocuments();
};

const count_unread_notifications = async (user_id) => {
  return await Notification.find({
    user_id: user_id,
    unread_status: true,
  }).countDocuments();
};

const mark_notification_as_read = async (notification_id) => {
  return await Notification.findOneAndUpdate(
    { _id: notification_id },
    { $set: { unread_status: false } }
  );
};

const mark_all_notifications_as_read = async (user_id) => {
  return await Notification.updateMany(
    { user_id },
    { $set: { unread_status: false } }
  );
};

const search_notifications_by_query_obj = async (query_obj) => {
  return await Notification.find(query_obj);
};

const get_notification_by_query_obj = async (query_obj) => {
  return await Notification.findOne(query_obj);
};

const delete_leave_request_notifications = async (leave_request_id) => {
  await Notification.deleteMany({ leave_request_id });
};

const delete_support_ticket_notifications = async (support_ticket_id) => {
  await Notification.deleteMany({ support_ticket_id });
};

const delete_announcement_notifications = async (announcement_id) => {
  await Notification.deleteMany({ announcement_id });
};

const delete_feedback_notifications = async (feedback_id) => {
  await Notification.deleteMany({ feedback_id });
};

const delete_lunch_notifications = async (lunch_id) => {
  await Notification.deleteMany({ lunch_id });
};

const delete_loan_request_notifications = async (loan_request_id) => {
  await Notification.deleteMany({ loan_request_id });
};

module.exports = {
  add_notification,
  find_notification_by_id,
  total_notification,
  latest_notification,
  find_notification_by_name,
  pagination_notification,
  all_notifications_active,
  all_notifications_active_count,
  delete_notification_by_id,
  get_notification_search,
  notification_search_count,
  count_read_notifications,
  count_unread_notifications,
  mark_notification_as_read,
  mark_all_notifications_as_read,
  search_notifications_by_query_obj,
  get_notification_by_query_obj,
  delete_leave_request_notifications,
  delete_support_ticket_notifications,
  delete_announcement_notifications,
  delete_feedback_notifications,
  delete_lunch_notifications,
  delete_loan_request_notifications,
};
