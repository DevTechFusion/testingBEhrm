const { Expense } = require("../models/expense");
const moment = require("moment");

const add_expense = async (expense_data) => {
  const new_expense = new Expense(expense_data);
  return await new_expense.save();
};
const find_expense_by_id = async (id) => {
  return await Expense.findOne({ _id: id });
};

const find_expense_by_id_for_assignable_status = async (id) => {
  return await Expense.findOne({ _id: id }, { assignable_status: 1 }).lean();
};

const get_expense_categories_for_assignable_status = async () => {
  return await Expense.find({}, { assignable_status: 1 }).lean();
};

const find_expense_by_name = async (title) => {
  return await Expense.findOne({ title: title });
};

const total_expense = async () => {
  return await Expense.find().count();
};

const latest_expense = async () => {
  return await Expense.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_expense = async (skip, limit) => {
  return await Expense.find().sort({ createdAt: -1 }).limit(limit).skip(skip);
};

const all_expense_categories_active = async () => {
  return await Expense.find({ active_status: true }).sort({
    createdAt: -1,
  });
};

const all_expense_categories_active_count = async () => {
  return await Expense.find({ active_status: true }).countDocuments();
};

const delete_expense_by_id = async (expense_id) => {
  return await Expense.findByIdAndDelete(expense_id);
};
const get_expense_search = async (limit, skip, query_obj) => {
  return await Expense.find(query_obj)
    .sort({ date: -1, createdAt: -1 })
    .skip(skip)
    .limit(limit);
};
const expense_search_count = async (query_obj) => {
  return await Expense.find(query_obj).countDocuments();
};

const expense_search_by_query_obj = async (query_obj) => {
  return await Expense.find(query_obj);
};

const expense_search_by_query_obj_count = async (query_obj) => {
  return await Expense.find(query_obj).countDocuments();
};

const update_employee_in_expense = async (employee_id, employee_name) => {
  await Expense.updateMany(
    { "employee._id": employee_id },
    {
      $set: {
        "employee.name": employee_name,
      },
    }
  );
};

const update_vendor_in_expense = async (vendor_id, vendor_name) => {
  await Expense.updateMany(
    { "vendor._id": vendor_id },
    {
      $set: {
        "vendor.name": vendor_name,
      },
    }
  );
};

const update_added_by_in_expense = async (employee_id, employee_name) => {
  await Expense.updateMany(
    { "added_by._id": employee_id },
    {
      $set: {
        "added_by.name": employee_name,
      },
    }
  );
};

const update_expense_category_in_expense = async (
  category_id,
  category_title
) => {
  await Expense.updateMany(
    { "expense_category._id": category_id },
    {
      $set: {
        "expense_category.title": category_title,
      },
    }
  );
};

const delete_expense_category_in_expenses = async (category_id) => {
  await Expense.updateMany(
    { "expense_category._id": category_id },
    {
      $set: { "expense_category._id": null, "expense_category.title": "" },
    }
  );
};

const get_expense_tax = async (query_obj) => {
  //find sum of amount , tax_amount
  const expense = await Expense.aggregate([
    { $match: query_obj },
    {
      $group: {
        _id: null,
        total_expense: { $sum: "$amount" },
        total_tax: { $sum: "$tax_amount" },
      },
    },
  ]);

  //retuen total_expense , total_tax
  return {
    total_expense: expense.length > 0 ? expense[0].total_expense : 0,
    total_tax: expense.length > 0 ? expense[0].total_tax : 0,
  };
};

module.exports = {
  add_expense,
  find_expense_by_id,
  find_expense_by_id_for_assignable_status,
  get_expense_categories_for_assignable_status,
  total_expense,
  latest_expense,
  find_expense_by_name,
  pagination_expense,
  all_expense_categories_active,
  all_expense_categories_active_count,
  delete_expense_by_id,
  get_expense_search,
  expense_search_count,
  expense_search_by_query_obj,
  expense_search_by_query_obj_count,
  update_employee_in_expense,
  update_vendor_in_expense,
  update_added_by_in_expense,
  update_expense_category_in_expense,
  delete_expense_category_in_expenses,
  get_expense_tax,
};
