const { Department } = require("../models/department");

const Add_department = async (department_data) => {
  const new_department = new Department(department_data);
  return await new_department.save();
};
const find_department_by_id = async (id) => {
  return await Department.findOne({ _id: id });
};
const find_department_by_name = async (body) => {
  return await Department.findOne({
    $and: [{ title: body.title }, { "company._id": body.company._id }],
  });
};

const total_department = async (id) => {
  return await Department.find().count();
};

const latest_department = async (id) => {
  return await Department.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_department = async (skip, limit, search = "") => {
  return await Department.find({
    $or: [{ title: { $regex: new RegExp(search, "i") } }],
  })
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(skip);
};
const department_search_count = async (search = "") => {
  return await Department.find({
    $or: [{ title: { $regex: new RegExp(search, "i") } }],
  }).countDocuments();
};
const all_department_count = async () => {
  return await Department.find().countDocuments();
};

const get_all_departments = async () => {
  return await Department.find();
};

const get_all_departments_ids = async () => {
  return await Department.find({}, { _id: 1 }).lean();
};

const get_all_active_departments = async () => {
  return await Department.find({ active_status: true });
};

const get_all_active_departments_v1 = async () => {
  return await Department.find(
    { active_status: true },
    { _id: 1, title: 1, previllages: 1 }
  ).lean();
};

const delete_department_by_id = async (department_id) => {
  return await Department.findByIdAndDelete(department_id);
};
const get_department_search = async (text = "", skip, limit) => {
  return await Department.find({
    $or: [{ title: { $regex: new RegExp(text, "i") } }],
  })
    .skip(skip)
    .limit(limit);
};

const update_company_in_department = async (company_id, company_title) => {
  await Department.updateMany(
    { "company._id": company_id },
    {
      $set: {
        "company.title": company_title,
      },
    }
  );
};

const update_employee_lead_in_department = async (
  employee_id,
  employee_name
) => {
  await Department.updateOne(
    { "lead._id": employee_id },
    {
      $set: {
        "lead.$.name": employee_name,
      },
    }
  );
};

const update_employee_in_department_members = async (
  employee_id,
  employee_name
) => {
  await Department.updateOne(
    { "members._id": employee_id },
    {
      $set: {
        "members.$.name": employee_name,
      },
    }
  );
};

const add_employee_to_department = async (
  employee_id,
  employee_name,
  department_id
) => {
  return await Department.updateOne(
    { _id: department_id },
    { $push: { members: { _id: employee_id, name: employee_name } } }
  );
};

const delete_employee_from_department = async (
  employee_id,
  employee_name,
  department_id
) => {
  return await Department.updateOne(
    { _id: department_id },
    { $pull: { members: { _id: employee_id, name: employee_name } } }
  );
};

const delete_employee_from_department_lead = async (
  employee_id,
  employee_name,
  department_id
) => {
  return await Department.updateOne(
    { _id: department_id },
    { $pull: { lead: { _id: employee_id, name: employee_name } } }
  );
};

module.exports = {
  Add_department,
  find_department_by_id,
  total_department,
  latest_department,
  find_department_by_name,
  pagination_department,
  all_department_count,
  get_all_departments,
  delete_department_by_id,
  get_department_search,
  department_search_count,
  update_company_in_department,
  update_employee_lead_in_department,
  update_employee_in_department_members,
  add_employee_to_department,
  delete_employee_from_department,
  delete_employee_from_department_lead,
  get_all_active_departments,
  get_all_departments_ids,
  get_all_active_departments_v1,
};
