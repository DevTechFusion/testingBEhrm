const { AssetCategory } = require("../models/asset_category");

const add_asset_category = async (asset_category_data) => {
  const new_asset_category = new AssetCategory(asset_category_data);
  return await new_asset_category.save();
};
const find_asset_category_by_id = async (id) => {
  return await AssetCategory.findOne({ _id: id });
};

const find_asset_category_by_id_for_assignable_status = async (id) => {
  return await AssetCategory.findOne(
    { _id: id },
    { assignable_status: 1 }
  ).lean();
};

const get_asset_categories_for_assignable_status = async () => {
  return await AssetCategory.find({}, { assignable_status: 1 }).lean();
};

const find_asset_category_by_name = async (title) => {
  return await AssetCategory.findOne({ title: title });
};

const total_asset_category = async () => {
  return await AssetCategory.find().count();
};

const latest_asset_category = async () => {
  return await AssetCategory.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_asset_category = async (skip, limit) => {
  return await AssetCategory.find()
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(skip);
};

const all_asset_categories_active = async () => {
  return await AssetCategory.find({ active_status: true }).sort({
    createdAt: -1,
  });
};

const all_asset_categories_active_count = async () => {
  return await AssetCategory.find({ active_status: true }).countDocuments();
};

const delete_asset_category_by_id = async (asset_category_id) => {
  return await AssetCategory.findByIdAndDelete(asset_category_id);
};
const get_asset_category_search = async (limit, skip, search = "") => {
  return await AssetCategory.find({
    $or: [{ title: { $regex: new RegExp(search, "i") } }],
  })
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);
};
const asset_category_search_count = async (search = "") => {
  return await AssetCategory.find({
    $or: [{ title: { $regex: new RegExp(search, "i") } }],
  }).countDocuments();
};

module.exports = {
  add_asset_category,
  find_asset_category_by_id,
  find_asset_category_by_id_for_assignable_status,
  get_asset_categories_for_assignable_status,
  total_asset_category,
  latest_asset_category,
  find_asset_category_by_name,
  pagination_asset_category,
  all_asset_categories_active,
  all_asset_categories_active_count,
  delete_asset_category_by_id,
  get_asset_category_search,
  asset_category_search_count,
};
