const { Lunch } = require("../models/lunch");
const { Employee } = require("../models/employee");
const moment = require("moment");
const { update_want_lunch_to_null } = require("./employee");

const add_lunch = async (lunch_data) => {
  const new_lunch = new Lunch(lunch_data);
  return await new_lunch.save();
};
const find_lunch_by_id = async (id) => {
  return await Lunch.findOne({ _id: id });
};

const find_lunch_for_emp_month_year = async (emp_obj_id, month, year) => {
  return await Lunch.findOne({
    "employee._id": emp_obj_id,
    month,
    year,
  });
};

const total_lunch = async () => {
  return await Lunch.find().count();
};

const latest_lunch = async () => {
  return await Lunch.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_lunch = async (skip, limit) => {
  return await Lunch.find().sort({ createdAt: -1 }).limit(limit).skip(skip);
};

const delete_lunch_by_id = async (lunch_id) => {
  return await Lunch.findByIdAndDelete(lunch_id);
};
const get_lunch_search = async (limit, skip, query_obj) => {
  return await Lunch.find(query_obj)
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit)
    .lean();
};
const lunch_search_count = async (query_obj) => {
  return await Lunch.find(query_obj).countDocuments();
};

const lunch_search_by_query_obj = async (query_obj) => {
  return await Lunch.find(query_obj);
};

const lunch_search_by_query_obj_count = async (query_obj) => {
  return await Lunch.find(query_obj).countDocuments();
};

const update_employee_in_lunch = async (employee_id, employee_name) => {
  await Lunch.updateMany(
    { "employee._id": employee_id },
    {
      $set: {
        "employee.name": employee_name,
      },
    }
  );
};

const update_added_by_in_lunch = async (employee_id, employee_name) => {
  await Lunch.updateMany(
    { "added_by._id": employee_id },
    {
      $set: {
        "added_by.name": employee_name,
      },
    }
  );
};

const get_unpaid_lunches = async (emp_obj_id) => {
  return await Lunch.find({
    "employee._id": emp_obj_id,
    paid_status: "pending",
  });
};

const update_lunches = async () => {
  console.log("Updating");
  let today = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY").utc(true);
  let late_fine = 0;
  let unpaid_lunches = await Lunch.find({ paid_status: "pending" });
  if (unpaid_lunches.length > 0) {
    for (let x = 0; x < unpaid_lunches.length; x++) {
      let total_amount = unpaid_lunches[x].amount;
      let day_diff = today
        .startOf("day")
        .diff(unpaid_lunches[x].deadline, "day");

      console.log("day_diff: ", day_diff);
      console.log("day_diff > 0: ", day_diff > 0);
      if (day_diff > 0) {
        console.log("day_diff is positive and late fine is added to the lunch");
        late_fine = Math.round(total_amount * 0.1 * day_diff);

        await Lunch.updateOne(
          { _id: unpaid_lunches[x]._id },
          { $set: { late_fine: late_fine } }
        );
        console.log("Updated in database");
      }
    }
  }
};

const add_lunch_automatically = async () => {
  console.log("Updating");
  let active_lunches = [];
  let month = moment().month() + 1;
  let year = moment().year();
  let today = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY").utc(true);

  // let prev_month_date = moment(
  //   moment().format("DD-MM-YYYY"),
  //   "DD-MM-YYYY"
  // ).subtract(1, "months");

  // let prev_month = prev_month_date.subtract(1, "months").month() + 1;

  let next_month_date = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY").add(
    1,
    "months"
  );
  let next_year = next_month_date.year();
  let next_month = next_month_date.month() + 1;

  active_lunches = await Lunch.find({
    active_status: true,
    month,
    year,
  });

  // if (prev_month == 12) {
  //   let prev_year = year - 1;
  //   active_lunches = await Lunch.find({
  //     active_status: true,
  //     month: prev_month,
  //     year: prev_year,
  //   });
  // } else {
  //   active_lunches = await Lunch.find({
  //     active_status: true,
  //     month: prev_month,
  //     year: year,
  //   });
  // }

  // console.log("Today: ", today);
  // console.log("Month: ", month);
  // console.log("Previous month: ", prev_month);
  // console.log("Year: ", year);
  // console.log("Active: ", active_lunches);

  if (active_lunches.length > 0) {
    for (let x = 0; x < active_lunches.length; x++) {
      const get_emp = await Employee.findOne({
        _id: active_lunches[x].employee._id,
        active_status: true,
        want_lunch: { $ne: false },
      }).lean();
      if (get_emp) {
        let lunch_obj = {
          month: next_month,
          year: next_year,
          employee: {
            _id: get_emp._id,
            name: get_emp.full_name,
          },
          // deadline: moment("10-" + month + "-" + year, "DD-MM-YYYY").utc(true),
          paid_status: "paid",
        };
        const if_exist = await Lunch.findOne({
          "employee._id": lunch_obj.employee._id,
          month: lunch_obj.month,
          year: lunch_obj.year,
        }).lean();
        console.log("if_exist: ", if_exist);
        if (if_exist == null) {
          const new_lunch = new Lunch(lunch_obj);
          await new_lunch.save();
          console.log(new_lunch);
        } else {
          console.log("Already Exist");
        }
        active_lunches[x].want_lunch = null;
        await active_lunches[x].save();
      }
    }
  }

  let want_lunches = await Employee.find({ want_lunch: true });

  if (want_lunches.length > 0) {
    for (let x = 0; x < want_lunches.length; x++) {
      let lunch_obj = {
        month: next_month,
        year: next_year,
        employee: {
          _id: want_lunches[x]._id,
          name: want_lunches[x].full_name,
        },
        // deadline: moment("10-" + month + "-" + year, "DD-MM-YYYY").utc(true),
        paid_status: "paid",
      };
      const if_exist = await Lunch.findOne({
        "employee._id": lunch_obj.employee._id,
        month: lunch_obj.month,
        year: lunch_obj.year,
      }).lean();
      console.log("if_exist: ", if_exist);
      if (if_exist == null) {
        const new_lunch = new Lunch(lunch_obj);
        await new_lunch.save();
        console.log(new_lunch);
      } else {
        console.log("already exist");
      }
      want_lunches[x].want_lunch = null;
      await want_lunches[x].save();
    }
  }

  await update_want_lunch_to_null();
};

const find_lunch_for_payroll = async (emp_obj_id, month, year) => {
  return await Lunch.findOne({
    "employee._id": emp_obj_id,
    month: month,
    year: year,
  });
};

module.exports = {
  add_lunch,
  find_lunch_by_id,
  find_lunch_for_emp_month_year,
  total_lunch,
  latest_lunch,
  pagination_lunch,
  delete_lunch_by_id,
  get_lunch_search,
  lunch_search_count,
  lunch_search_by_query_obj,
  lunch_search_by_query_obj_count,
  update_employee_in_lunch,
  update_added_by_in_lunch,
  get_unpaid_lunches,
  update_lunches,
  add_lunch_automatically,
  find_lunch_for_payroll,
};
