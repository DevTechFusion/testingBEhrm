const { Brand } = require("../models/brand");

const add_brand = async (brand_data) => {
  const new_brand = new Brand(brand_data);
  return await new_brand.save();
};
const find_brand_by_id = async (id) => {
  return await Brand.findOne({ _id: id });
};
const find_brand_by_name = async (title) => {
  return await Brand.findOne({ title: title });
};

const total_brand = async (id) => {
  return await Brand.find().count();
};

const latest_brand = async (id) => {
  return await Brand.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_brand = async (skip, limit) => {
  return await Brand.find()
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(skip);
};

const all_brands_active = async () => {
  return await Brand.find({active_status:true}).sort({ createdAt: -1 });
};

const all_brands_active_count = async () => {
  return await Brand.find({active_status:true}).countDocuments();
};

const delete_brand_by_id = async (brand_id) => {
  return await Brand.findByIdAndDelete(brand_id);
};
const get_brand_search = async (limit, skip, search = "") => {
  return await Brand.find({
    $or: [{ title: { $regex: new RegExp(search, "i") } }],
  })
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);
};
const brand_search_count = async (search = "") => {
  return await Brand.find({
    $or: [{ title: { $regex: new RegExp(search, "i") } }],
  }).countDocuments();
};

const update_company_in_brands = async (company_id, company_title) => {
  await Brand.updateMany(
    { "company._id": company_id },
    {
      $set: {
        "company.title": company_title,
      },
    }
  );
};

const update_employee_brands = async (employee_id, employee_name) => {
  await Brand.updateMany(
    { "assigned_employee._id": employee_id },
    {
      $set: {
        "assigned_employee.name": employee_name,
      },
    }
  );
};

const unassign_brands = async (employee_id) => {
  await Brand.updateMany(
    { "assigned_employee._id": employee_id },
    {
      $set: {
        "assigned_employee._id": "",
        "assigned_employee.name": "",
      },
    }
  );
};

module.exports = {
  add_brand,
  find_brand_by_id,
  total_brand,
  latest_brand,
  find_brand_by_name,
  pagination_brand,
  all_brands_active,
  all_brands_active_count,
  delete_brand_by_id,
  get_brand_search,
  brand_search_count,
  update_company_in_brands,
  update_employee_brands,
  unassign_brands,
};
