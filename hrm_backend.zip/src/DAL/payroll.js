const { Payroll } = require("../models/payroll");
const moment = require("moment");

const add_payroll = async (payroll_data) => {
  const new_payroll = new Payroll(payroll_data);
  return await new_payroll.save();
};
const find_payroll_by_id = async (id) => {
  return await Payroll.findOne({ _id: id });
};

const find_payroll_for_emp_month_year = async (emp_obj_id, month, year) => {
  return await Payroll.findOne({
    emp_obj_id,
    month,
    year,
  });
};

const find_payroll_for_month_year = async (month, year) => {
  return await Payroll.findOne({ month, year });
};

const total_payroll = async () => {
  return await Payroll.find().count();
};

const latest_payroll = async () => {
  return await Payroll.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_payroll = async (skip, limit) => {
  return await Payroll.find().sort({ createdAt: -1 }).limit(limit).skip(skip);
};

const delete_payroll_by_id = async (payroll_id) => {
  return await Payroll.findByIdAndDelete(payroll_id);
};

const delete_payroll_by_month_year = async (month, year) => {
  return await Payroll.deleteMany({ month, year });
};

const delete_payroll_records_v1 = async (body) => {
  // Parse date_from and date_to to extract month and year
  let [from_month, from_year] = body.date_from.split("-").map(Number);
  let [to_month, to_year] = body.date_to.split("-").map(Number);

  // Construct a query to match records within the date range
  let query = {
    $and: [
      { year: { $gte: from_year, $lte: to_year } },
      {
        $or: [
          {
            $and: [{ year: from_year }, { month: { $gte: from_month } }],
          },
          {
            $and: [{ year: to_year }, { month: { $lte: to_month } }],
          },
          {
            $and: [{ year: { $gt: from_year, $lt: to_year } }],
          },
        ],
      },
    ],
  };

  // Execute the delete operation
  return await Payroll.deleteMany(query);
};

const get_payroll_search = async (limit, skip, query_obj) => {
  return await Payroll.find(query_obj)
    .lean()
    .sort({ year: -1, month: -1 })
    .skip(skip)
    .limit(limit);
};

// const get_payroll_search_v1 = async (limit, skip, body, query_obj) => {
//   // Parse date_from and date_to to extract month and year
//   let [from_month, from_year] = body.date_from.split("-").map(Number);
//   let [to_month, to_year] = body.date_to.split("-").map(Number);

//   // Construct an aggregation pipeline
//   let pipeline = [
//     {
//       $addFields: {
//         // Convert month and year to numbers for comparison
//         numericYear: "$year",
//         numericMonth: "$month",
//       },
//     },
//     {
//       $match: {
//         ...query_obj, // Include existing query conditions
//         $expr: {
//           $and: [
//             { $gte: ["$numericYear", from_year] },
//             { $lte: ["$numericYear", to_year] },
//             {
//               $cond: {
//                 if: { $eq: ["$numericYear", from_year] },
//                 then: { $gte: ["$numericMonth", from_month] },
//                 else: true,
//               },
//             },
//             {
//               $cond: {
//                 if: { $eq: ["$numericYear", to_year] },
//                 then: { $lte: ["$numericMonth", to_month] },
//                 else: true,
//               },
//             },
//           ],
//         },
//       },
//     },
//     { $sort: { year: -1, month: -1 } },
//     { $skip: skip },
//     { $limit: limit },
//   ];

//   // Execute the aggregation pipeline
//   return await Payroll.aggregate(pipeline);
// };

const get_payroll_search_v1 = async (limit, skip, body, query_obj) => {
  // Parse date_from and date_to to extract month and year
  let [from_month, from_year] = body.date_from.split("-").map(Number);
  let [to_month, to_year] = body.date_to.split("-").map(Number);

  // Construct an aggregation pipeline
  let pipeline = [
    {
      $match: {
        ...query_obj, // Include existing query conditions
        $expr: {
          $and: [
            { $gte: ["$year", from_year] },
            { $lte: ["$year", to_year] },
            {
              $cond: {
                if: { $eq: ["$year", from_year] },
                then: { $gte: ["$month", from_month] },
                else: true,
              },
            },
            {
              $cond: {
                if: { $eq: ["$year", to_year] },
                then: { $lte: ["$month", to_month] },
                else: true,
              },
            },
          ],
        },
      },
    },
    { $sort: { year: -1, month: -1 } },
    { $skip: skip },
    { $limit: limit },
  ];

  // Execute the aggregation pipeline
  return await Payroll.aggregate(pipeline);
};
const payroll_search_count = async (query_obj) => {
  return await Payroll.find(query_obj).countDocuments();
};

// const payroll_search_count_v1 = async (body ,query_obj) => {
//   return await Payroll.find(query_obj).countDocuments();
// };

const payroll_search_count_v1 = async (body, query_obj) => {
  let [from_month, from_year] = body.date_from.split("-").map(Number);
  let [to_month, to_year] = body.date_to.split("-").map(Number);

  let pipeline = [
    {
      $addFields: {
        numericYear: "$year",
        numericMonth: "$month",
      },
    },
    {
      $match: {
        ...query_obj,
        $expr: {
          $and: [
            { $gte: ["$numericYear", from_year] },
            { $lte: ["$numericYear", to_year] },
            {
              $cond: {
                if: { $eq: ["$numericYear", from_year] },
                then: { $gte: ["$numericMonth", from_month] },
                else: true,
              },
            },
            {
              $cond: {
                if: { $eq: ["$numericYear", to_year] },
                then: { $lte: ["$numericMonth", to_month] },
                else: true,
              },
            },
          ],
        },
      },
    },
    { $count: "total" },
  ];

  const result = await Payroll.aggregate(pipeline);
  return result.length > 0 ? result[0].total : 0;
};

const payroll_search_by_query_obj = async (query_obj) => {
  return await Payroll.find(query_obj);
};

const payroll_search_by_query_obj_count = async (query_obj) => {
  return await Payroll.find(query_obj).countDocuments();
};

const update_employee_in_payroll = async (employee_id, employee_name) => {
  await Payroll.updateMany(
    { "employee._id": employee_id },
    {
      $set: {
        "employee.name": employee_name,
      },
    }
  );
};

const update_added_by_in_payroll = async (employee_id, employee_name) => {
  await Payroll.updateMany(
    { "added_by._id": employee_id },
    {
      $set: {
        "added_by.name": employee_name,
      },
    }
  );
};

const get_unpaid_payrolles = async (emp_obj_id) => {
  return await Payroll.find({
    "employee._id": emp_obj_id,
    paid_status: "pending",
  });
};

const update_payrolles = async () => {
  console.log("Updating");
  let today = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY").utc(true);
  let late_fine = 0;
  let unpaid_payrolles = await Payroll.find({ paid_status: "pending" });
  if (unpaid_payrolles.length > 0) {
    for (let x = 0; x < unpaid_payrolles.length; x++) {
      let total_amount = unpaid_payrolles[x].amount;
      let day_diff = today
        .startOf("day")
        .diff(unpaid_payrolles[x].deadline, "day");

      console.log("day_diff: ", day_diff);
      console.log("day_diff > 0: ", day_diff > 0);
      if (day_diff > 0) {
        console.log(
          "day_diff is positive and late fine is added to the payroll"
        );
        late_fine = Math.round(total_amount * 0.1 * day_diff);

        await Payroll.updateOne(
          { _id: unpaid_payrolles[x]._id },
          { $set: { late_fine: late_fine } }
        );
        console.log("Updated in database");
      }
    }
  }
};

const get_total_salary_by_month_v1 = async (body, query_obj) => {
  let [from_month, from_year] = body.date_from.split("-").map(Number);
  let [to_month, to_year] = body.date_to.split("-").map(Number);

  let pipeline = [
    {
      $match: {
        ...query_obj,
        $expr: {
          $and: [
            { $gte: ["$year", from_year] },
            { $lte: ["$year", to_year] },
            {
              $cond: {
                if: { $eq: ["$year", from_year] },
                then: { $gte: ["$month", from_month] },
                else: true,
              },
            },
            {
              $cond: {
                if: { $eq: ["$year", to_year] },
                then: { $lte: ["$month", to_month] },
                else: true,
              },
            },
          ],
        },
      },
    },
    {
      $group: {
        _id: null, // Group all documents together
        totalSalary: { $sum: "$net_salary" }, // Sum the net_salary of all documents
      },
    },
  ];

  const result = await Payroll.aggregate(pipeline);
  return result.length > 0 ? result[0].totalSalary : 0;
};

const get_total_salary_by_month = async (month, year) => {
  return await Payroll.aggregate([
    {
      $match: {
        month: month,
        year: year,
      },
    },
    {
      $group: {
        _id: null,
        totalNetSalary: { $sum: "$net_salary" },
      },
    },
    {
      $project: {
        _id: 0,
        month: month,
        year: year,
        totalNetSalary: 1,
      },
    },
  ]);
};

const find_payroll_ids_by_month_year = async (month, year) => {
  return await Payroll.find({ month, year }).select("_id");
};

module.exports = {
  add_payroll,
  find_payroll_by_id,
  find_payroll_for_emp_month_year,
  total_payroll,
  latest_payroll,
  pagination_payroll,
  delete_payroll_by_id,
  get_payroll_search,
  payroll_search_count,
  payroll_search_by_query_obj,
  payroll_search_by_query_obj_count,
  update_employee_in_payroll,
  update_added_by_in_payroll,
  get_unpaid_payrolles,
  update_payrolles,
  get_total_salary_by_month,
  find_payroll_for_month_year,
  delete_payroll_by_month_year,

  get_payroll_search_v1,
  payroll_search_count_v1,
  get_total_salary_by_month_v1,
  delete_payroll_records_v1,
  find_payroll_ids_by_month_year,
};
