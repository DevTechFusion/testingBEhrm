const { FeedbackImprovement } = require("../models/feedback_improvement");

const add_feedback_improvement = async (body) => {
  const new_feedback_improvement = new FeedbackImprovement(body);
  return await new_feedback_improvement.save();
};

const update_feedback_improvement = async (id, body) => {
  return await FeedbackImprovement.findOneAndUpdate(
    { _id: id },
    { $set: body },
    { new: true }
  );
};

const get_feedback_improvement_by_id = async (id) => {
  return await FeedbackImprovement.findOne({ _id: id });
};

const list_feedback_improvements = async (query_obj, limit, skip) => {
  return await FeedbackImprovement.find(query_obj)
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(skip)
    .select("-description")
    .lean();
};

const delete_feedback_improvement = async (id) => {
  return await FeedbackImprovement.findOneAndDelete({
    _id: id,
  });
};

const feedback_improvement_count = async (query_obj) => {
  return await FeedbackImprovement.countDocuments(query_obj);
};

//update action_info , team_member_info, show_to_team, title, description,

const update_action_info_in_feedback_improvement = async (
  employee_id,
  name,
  designation
) => {
  return await FeedbackImprovement.updateMany(
    { "action_info.employee_id": employee_id },
    {
      $set: {
        "action_info.full_name": name,
        "action_info.designation": designation,
      },
    }
  );
};

const update_team_member_info_in_feedback_improvement = async (
  employee_id,
  name,
  designation
) => {
  return await FeedbackImprovement.updateMany(
    { "team_member_info.employee_id": employee_id },
    {
      $set: {
        "team_member_info.$[elem].full_name": name,
        "team_member_info.$[elem].designation": designation,
      },
    },
    {
      arrayFilters: [{ "elem.employee_id": employee_id }],
    }
  );
};

module.exports = {
  add_feedback_improvement,
  update_feedback_improvement,
  get_feedback_improvement_by_id,
  list_feedback_improvements,
  delete_feedback_improvement,
  feedback_improvement_count,
  update_action_info_in_feedback_improvement,
  update_team_member_info_in_feedback_improvement,
};
