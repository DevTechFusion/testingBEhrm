const moment = require("moment");
const { Feedback } = require("../models/feedback");

const add_feedback = async (feedback_data) => {
  const new_feedback = new Feedback(feedback_data);
  return await new_feedback.save();
};
const find_feedback_by_id = async (id) => {
  return await Feedback.findOne({ _id: id });
};

const find_feedback_by_name = async (title) => {
  return await Feedback.findOne({ title: title });
};

const total_feedback = async () => {
  return await Feedback.find().count();
};

const latest_feedback = async () => {
  return await Feedback.find().sort({ createdAt: -1 }).limit(5);
};

const get_feedbacks_query_obj = async (query_obj) => {
  return await Feedback.find(query_obj);
};

const get_feedbacks_query_obj_count = async (query_obj) => {
  return await Feedback.find(query_obj).countDocuments();
};

const delete_feedback_by_id = async (feedback_id) => {
  return await Feedback.findByIdAndDelete(feedback_id);
};
const get_feedback_search = async (limit, skip, query_obj) => {
  return await Feedback.find(query_obj)
    .select({ private_notes: 0, questions: 0 })
    .sort({ date: -1 })
    .skip(skip)
    .limit(limit);
};
const feedback_search_count = async (query_obj) => {
  return await Feedback.find(query_obj).countDocuments();
};

const employees_not_get_feedback_to_submit_this_month = async (
  emp_arr,
  month,
  year
) => {
  return await Feedback.aggregate([
    {
      $match: { month: month, year: year },
    },
    {
      $group: {
        _id: null,
        send_to_ids: { $push: "$send_to._id" },
      },
    },
    {
      $project: {
        _id: 0,
        employeeIdsNotInSendTo: {
          $setDifference: [emp_arr, "$send_to_ids"],
        },
      },
    },
    {
      $unwind: "$employeeIdsNotInSendTo",
    },
    {
      $lookup: {
        from: "employees",
        localField: "employeeIdsNotInSendTo",
        foreignField: "_id",
        as: "employeeData",
      },
    },
    {
      $unwind: "$employeeData",
    },
    {
      $project: {
        // employeeData: 1,
        _id: "$employeeData._id",
        full_name: "$employeeData.full_name",
      },
    },
  ]);
};

const get_performance_by_emp_obj_id = async (performance_query_obj) => {
  console.log("performance_query_obj: ", performance_query_obj);
  return await Feedback.aggregate([
    {
      $match: performance_query_obj,
    },
    {
      $unwind: "$questions",
    },
    {
      $match: {
        "questions.type": "rating",
      },
    },
    {
      $group: {
        _id: "$send_for._id",
        totalRatings: {
          $sum: {
            $cond: [
              {
                $and: [
                  { $ne: ["$questions.answer", ""] },
                  { $ne: ["$questions.options_count", 0] },
                ],
              },
              { $toInt: "$questions.answer" },
              0,
            ],
          },
        },
        totalPossibleRatings: {
          $sum: {
            $cond: [
              {
                $and: [
                  { $ne: ["$questions.answer", ""] },
                  { $ne: ["$questions.options_count", 0] },
                ],
              },
              "$questions.options_count",
              0,
            ],
          },
        },
      },
    },
    {
      $project: {
        // employeeId: "$_id",
        performancePercentage: {
          $cond: [
            { $eq: ["$totalPossibleRatings", 0] },
            0,
            {
              $multiply: [
                { $divide: ["$totalRatings", "$totalPossibleRatings"] },
                100,
              ],
            },
          ],
        },
      },
    },
    // {
    //   $group: {
    //     _id: "$_id",
    //     totalRatings: {
    //       $sum: {
    //         $cond: [
    //           {
    //             $and: [
    //               { $ne: ["$questions.answer", ""] },
    //               { $ne: ["$questions.options_count", ""] },
    //             ],
    //           },
    //           { $convert: { input: "$questions.answer", to: "int" } },
    //           0,
    //         ],
    //       },
    //     },
    //     totalPossibleRatings: {
    //       $sum: {
    //         $cond: [
    //           {
    //             $and: [
    //               { $ne: ["$questions.answer", ""] },
    //               { $ne: ["$questions.options_count", ""] },
    //             ],
    //           },
    //           { $convert: { input: "$questions.options_count", to: "int" } },
    //           0,
    //         ],
    //       },
    //     },
    //   },
    // },
    // {
    //   $project: {
    //     performancePercentage: {
    //       $cond: [
    //         { $eq: ["$totalPossibleRatings", 0] },
    //         0,
    //         {
    //           $multiply: [
    //             { $divide: ["$totalRatings", "$totalPossibleRatings"] },
    //             100,
    //           ],
    //         },
    //       ],
    //     },
    //   },
    // },
    // {
    //   $group: {
    //     _id: null,
    //     averagePerformance: { $avg: "$performancePercentage" },
    //   },
    // },
    // {
    //   $project: {
    //     _id: 0,
    //     averagePerformance: 1,
    //   },
    // },
  ]);
};
const get_last_performance_month = async (perf_query_obj) => {
  return await Feedback.find(perf_query_obj)
    .select({ month: 1, year: 1 })
    .sort({ createdAt: -1 })
    .limit(1);
};
const get_employees_performance = async (limit, skip, query_obj) => {
  return await Feedback.aggregate([
    {
      $match: query_obj,
    },
    {
      $unwind: "$questions",
    },
    {
      $match: {
        "questions.type": "rating",
      },
    },
    {
      $group: {
        _id: "$send_for._id",
        totalRatings: {
          $sum: {
            $cond: [
              {
                $and: [
                  { $ne: ["$questions.answer", ""] },
                  { $ne: ["$questions.options_count", 0] },
                ],
              },
              { $toInt: "$questions.answer" },
              0,
            ],
          },
        },
        totalPossibleRatings: {
          $sum: {
            $cond: [
              {
                $and: [
                  { $ne: ["$questions.answer", ""] },
                  { $ne: ["$questions.options_count", 0] },
                ],
              },
              "$questions.options_count",
              0,
            ],
          },
        },
      },
    },
    {
      $project: {
        employeeId: "$_id",
        performancePercentage: {
          $cond: [
            { $eq: ["$totalPossibleRatings", 0] },
            0,
            {
              $multiply: [
                { $divide: ["$totalRatings", "$totalPossibleRatings"] },
                100,
              ],
            },
          ],
        },
      },
    },
    {
      $lookup: {
        from: "employees",
        localField: "employeeId",
        foreignField: "_id",
        as: "employee",
      },
    },
    {
      $unwind: "$employee",
    },
    {
      $addFields: {
        month: query_obj.month,
        year: query_obj.year,
      },
    },
    {
      $project: {
        _id: 0,
        month: 1,
        year: 1,
        emp_obj_id: "$employeeId",
        emp_name: "$employee.full_name",
        performancePercentage: 1,
      },
    },
    {
      $skip: skip,
    },
    { $limit: limit },
  ]);
};

const get_employees_performance_count = async (query_obj) => {
  return await Feedback.aggregate([
    {
      $match: query_obj,
    },
    {
      $unwind: "$questions",
    },
    {
      $match: {
        "questions.type": "rating",
      },
    },
    {
      $group: {
        _id: "$send_for._id", // Group by employee _id
        totalRatings: {
          $sum: {
            $cond: [
              {
                $and: [
                  { $ne: ["$questions.answer", ""] },
                  { $ne: ["$questions.options_count", 0] },
                ],
              },
              { $toInt: "$questions.answer" },
              0,
            ],
          },
        },
        totalPossibleRatings: {
          $sum: {
            $cond: [
              {
                $and: [
                  { $ne: ["$questions.answer", ""] },
                  { $ne: ["$questions.options_count", 0] },
                ],
              },
              "$questions.options_count",
              0,
            ],
          },
        },
      },
    },
    {
      $project: {
        employeeId: "$_id",
        performancePercentage: {
          $cond: [
            { $eq: ["$totalPossibleRatings", 0] },
            0,
            {
              $multiply: [
                { $divide: ["$totalRatings", "$totalPossibleRatings"] },
                100,
              ],
            },
          ],
        },
      },
    },
    {
      $lookup: {
        from: "employees",
        localField: "employeeId",
        foreignField: "_id",
        as: "employee",
      },
    },
    {
      $unwind: "$employee",
    },
    {
      $project: {
        _id: 0,
        employeeId: 1,
        employeeName: "$employee.full_name",
        performancePercentage: 1,
      },
    },
    {
      $group: {
        _id: null,
        count: { $sum: 1 },
      },
    },
  ]);
};

const get_performance_by_emp_obj_id_yearly = async (emp_obj_id, year) => {
  return await Feedback.aggregate(
    // [
    //   {
    //     $match: {
    //       "send_for._id": emp_obj_id,
    //       $or: [
    //         { $and: [{ month: { $gte: 7 } }, { year: year }] },
    //         { $and: [{ month: { $lte: 6 } }, { year: year + 1 }] },
    //       ],
    //     },
    //   },
    //   {
    //     $unwind: "$questions",
    //   },
    //   {
    //     $match: {
    //       "questions.type": "rating",
    //     },
    //   },
    //   {
    //     $group: {
    //       _id: {
    //         month: "$month",
    //         year: "$year",
    //       },
    //       totalRatings: {
    //         $sum: {
    //           $cond: [
    //             {
    //               $and: [
    //                 { $ne: ["$questions.answer", ""] },
    //                 { $ne: ["$questions.options_count", 0] },
    //               ],
    //             },
    //             { $toInt: "$questions.answer" },
    //             0,
    //           ],
    //         },
    //       },
    //       totalPossibleRatings: {
    //         $sum: {
    //           $cond: [
    //             {
    //               $and: [
    //                 { $ne: ["$questions.answer", ""] },
    //                 { $ne: ["$questions.options_count", 0] },
    //               ],
    //             },
    //             "$questions.options_count",
    //             0,
    //           ],
    //         },
    //       },
    //     },
    //   },
    //   {
    //     $project: {
    //       month: "$_id.month",
    //       year: "$_id.year",
    //       _id: 0,
    //       performance: {
    //         $cond: [
    //           { $eq: ["$totalPossibleRatings", 0] },
    //           0,
    //           {
    //             $multiply: [
    //               { $divide: ["$totalRatings", "$totalPossibleRatings"] },
    //               100,
    //             ],
    //           },
    //         ],
    //       },
    //     },
    //   },
    //   {
    //     $sort: { year: 1, month: 1 },
    //   },
    //   {
    //     $group: {
    //       _id: null,
    //       data: { $push: "$$ROOT" },
    //     },
    //   },
    //   {
    //     $project: {
    //       _id: 0,
    //       month_year: {
    //         $map: {
    //           input: { $range: [7, 13] },
    //           as: "month",
    //           in: {
    //             $concat: [
    //               {
    //                 $switch: {
    //                   branches: [
    //                     { case: { $eq: ["$$month", 7] }, then: "Jul" },
    //                     { case: { $eq: ["$$month", 8] }, then: "Aug" },
    //                     { case: { $eq: ["$$month", 9] }, then: "Sep" },
    //                     { case: { $eq: ["$$month", 10] }, then: "Oct" },
    //                     { case: { $eq: ["$$month", 11] }, then: "Nov" },
    //                     { case: { $eq: ["$$month", 12] }, then: "Dec" },
    //                     { case: { $eq: ["$$month", 13] }, then: "Jan" },
    //                   ],
    //                   default: "",
    //                 },
    //               },
    //               " ",
    //               {
    //                 $cond: [
    //                   { $eq: ["$$month", 13] },
    //                   { $toString: { $add: ["$year", 1] } },
    //                   { $toString: "$year" },
    //                 ],
    //               },
    //             ],
    //           },
    //         },
    //       },
    //       performance: {
    //         $map: {
    //           input: "$data",
    //           as: "item",
    //           in: {
    //             $cond: [
    //               { $eq: ["$$item.performance", null] },
    //               0,
    //               { $round: ["$$item.performance", 2] },
    //             ],
    //           },
    //         },
    //       },
    //     },
    //   },
    // ]

    // Correct for showing all month in the current year
    // [
    //   {
    //     $match: {
    //       "send_for._id": emp_obj_id,
    //       $or: [
    //         { $and: [{ month: { $gte: 7 } }, { year: year }] },
    //         { $and: [{ month: { $lte: 6 } }, { year: year + 1 }] },
    //       ],
    //     },
    //   },
    //   {
    //     $unwind: "$questions",
    //   },
    //   {
    //     $match: {
    //       "questions.type": "rating",
    //     },
    //   },
    //   {
    //     $group: {
    //       _id: {
    //         month: "$month",
    //         year: "$year",
    //       },
    //       totalRatings: {
    //         $sum: {
    //           $cond: [
    //             {
    //               $and: [
    //                 { $ne: ["$questions.answer", ""] },
    //                 { $ne: ["$questions.options_count", 0] },
    //               ],
    //             },
    //             { $toInt: "$questions.answer" },
    //             0,
    //           ],
    //         },
    //       },
    //       totalPossibleRatings: {
    //         $sum: {
    //           $cond: [
    //             {
    //               $and: [
    //                 { $ne: ["$questions.answer", ""] },
    //                 { $ne: ["$questions.options_count", 0] },
    //               ],
    //             },
    //             "$questions.options_count",
    //             0,
    //           ],
    //         },
    //       },
    //     },
    //   },
    //   {
    //     $project: {
    //       month: "$_id.month",
    //       year: "$_id.year",
    //       _id: 0,
    //       performance: {
    //         $cond: [
    //           { $eq: ["$totalPossibleRatings", 0] },
    //           0,
    //           {
    //             $multiply: [
    //               { $divide: ["$totalRatings", "$totalPossibleRatings"] },
    //               100,
    //             ],
    //           },
    //         ],
    //       },
    //     },
    //   },
    //   {
    //     $sort: { year: 1, month: 1 },
    //   },
    //   {
    //     $group: {
    //       _id: null,
    //       data: { $push: "$$ROOT" },
    //     },
    //   },
    //   {
    //     $project: {
    //       _id: 0,
    //       month_data: {
    //         $map: {
    //           input: { $range: [1, 13] },
    //           as: "month",
    //           in: {
    //             month_year: {
    //               $concat: [
    //                 {
    //                   $switch: {
    //                     branches: [
    //                       { case: { $eq: ["$$month", 1] }, then: "Jan" },
    //                       { case: { $eq: ["$$month", 2] }, then: "Feb" },
    //                       { case: { $eq: ["$$month", 3] }, then: "Mar" },
    //                       { case: { $eq: ["$$month", 4] }, then: "Apr" },
    //                       { case: { $eq: ["$$month", 5] }, then: "May" },
    //                       { case: { $eq: ["$$month", 6] }, then: "Jun" },
    //                       { case: { $eq: ["$$month", 7] }, then: "Jul" },
    //                       { case: { $eq: ["$$month", 8] }, then: "Aug" },
    //                       { case: { $eq: ["$$month", 9] }, then: "Sep" },
    //                       { case: { $eq: ["$$month", 10] }, then: "Oct" },
    //                       { case: { $eq: ["$$month", 11] }, then: "Nov" },
    //                       { case: { $eq: ["$$month", 12] }, then: "Dec" },
    //                     ],
    //                     default: "",
    //                   },
    //                 },
    //                 " ",
    //                 { $toString: year },
    //               ],
    //             },
    //             performance: {
    //               $let: {
    //                 vars: {
    //                   monthPerformance: {
    //                     $filter: {
    //                       input: "$data",
    //                       as: "item",
    //                       cond: { $eq: ["$$item.month", "$$month"] },
    //                     },
    //                   },
    //                 },
    //                 in: {
    //                   $cond: [
    //                     { $gt: [{ $size: "$$monthPerformance" }, 0] },
    //                     { $arrayElemAt: ["$$monthPerformance.performance", 0] },
    //                     0,
    //                   ],
    //                 },
    //               },
    //             },
    //           },
    //         },
    //       },
    //     },
    //   },
    //   {
    //     $project: {
    //       month_data: 1,
    //     },
    //   },
    // ]

    // Correct pipeline
    // [
    //   {
    //     $match: {
    //       "send_for._id": emp_obj_id,
    //       $or: [
    //         { $and: [{ month: { $gte: 7 } }, { year: year }] },
    //         { $and: [{ month: { $lte: 6 } }, { year: year + 1 }] },
    //       ],
    //     },
    //   },
    //   {
    //     $unwind: "$questions",
    //   },
    //   {
    //     $match: {
    //       "questions.type": "rating",
    //     },
    //   },
    //   {
    //     $group: {
    //       _id: {
    //         month: "$month",
    //         year: "$year",
    //       },
    //       totalRatings: {
    //         $sum: {
    //           $cond: [
    //             {
    //               $and: [
    //                 { $ne: ["$questions.answer", ""] },
    //                 { $ne: ["$questions.options_count", 0] },
    //               ],
    //             },
    //             { $toInt: "$questions.answer" },
    //             0,
    //           ],
    //         },
    //       },
    //       totalPossibleRatings: {
    //         $sum: {
    //           $cond: [
    //             {
    //               $and: [
    //                 { $ne: ["$questions.answer", ""] },
    //                 { $ne: ["$questions.options_count", 0] },
    //               ],
    //             },
    //             "$questions.options_count",
    //             0,
    //           ],
    //         },
    //       },
    //     },
    //   },
    //   {
    //     $project: {
    //       month: "$_id.month",
    //       year: "$_id.year",
    //       _id: 0,
    //       performance: {
    //         $cond: [
    //           { $eq: ["$totalPossibleRatings", 0] },
    //           0,
    //           {
    //             $multiply: [
    //               { $divide: ["$totalRatings", "$totalPossibleRatings"] },
    //               100,
    //             ],
    //           },
    //         ],
    //       },
    //     },
    //   },
    //   {
    //     $sort: { year: 1, month: 1 },
    //   },
    //   {
    //     $group: {
    //       _id: null,
    //       data: { $push: "$$ROOT" },
    //     },
    //   },
    //   {
    //     $project: {
    //       _id: 0,
    //       month_year: {
    //         $map: {
    //           input: "$data",
    //           as: "item",
    //           in: {
    //             $concat: [
    //               {
    //                 $switch: {
    //                   branches: [
    //                     { case: { $eq: ["$$item.month", 1] }, then: "Jan" },
    //                     { case: { $eq: ["$$item.month", 2] }, then: "Feb" },
    //                     { case: { $eq: ["$$item.month", 3] }, then: "Mar" },
    //                     { case: { $eq: ["$$item.month", 4] }, then: "Apr" },
    //                     { case: { $eq: ["$$item.month", 5] }, then: "May" },
    //                     { case: { $eq: ["$$item.month", 6] }, then: "Jun" },
    //                     { case: { $eq: ["$$item.month", 7] }, then: "Jul" },
    //                     { case: { $eq: ["$$item.month", 8] }, then: "Aug" },
    //                     { case: { $eq: ["$$item.month", 9] }, then: "Sep" },
    //                     { case: { $eq: ["$$item.month", 10] }, then: "Oct" },
    //                     { case: { $eq: ["$$item.month", 11] }, then: "Nov" },
    //                     { case: { $eq: ["$$item.month", 12] }, then: "Dec" },
    //                   ],
    //                   default: "",
    //                 },
    //               },
    //               " ",
    //               { $toString: "$$item.year" },
    //             ],
    //           },
    //         },
    //       },
    //       performance: "$data.performance",
    //     },
    //   },
    //   {
    //     $project: {
    //       month_year: 1,
    //       performance: {
    //         $map: {
    //           input: "$performance",
    //           as: "value",
    //           in: { $round: ["$$value", 0] },
    //         },
    //       },
    //     },
    //   },
    // ]

    [
      {
        $match: {
          "send_for._id": emp_obj_id,
          $or: [
            { $and: [{ month: { $gte: 7 } }, { year: year }] },
            { $and: [{ month: { $lte: 6 } }, { year: year + 1 }] },
          ],
        },
      },
      {
        $unwind: "$questions",
      },
      {
        $match: {
          "questions.type": "rating",
        },
      },
      {
        $group: {
          _id: {
            month: "$month",
            year: "$year",
          },
          totalRatings: {
            $sum: {
              $cond: [
                {
                  $and: [
                    { $ne: ["$questions.answer", ""] },
                    { $ne: ["$questions.options_count", 0] },
                  ],
                },
                { $toInt: "$questions.answer" },
                0,
              ],
            },
          },
          totalPossibleRatings: {
            $sum: {
              $cond: [
                {
                  $and: [
                    { $ne: ["$questions.answer", ""] },
                    { $ne: ["$questions.options_count", 0] },
                  ],
                },
                "$questions.options_count",
                0,
              ],
            },
          },
        },
      },
      {
        $project: {
          _id: 0,
          month: "$_id.month",
          year: "$_id.year",
          performance: {
            $cond: [
              { $eq: ["$totalPossibleRatings", 0] },
              0,
              {
                $multiply: [
                  { $divide: ["$totalRatings", "$totalPossibleRatings"] },
                  100,
                ],
              },
            ],
          },
        },
      },
      {
        $sort: { year: 1, month: 1 },
      },
    ]
  );
};

module.exports = {
  add_feedback,
  find_feedback_by_id,
  total_feedback,
  latest_feedback,
  find_feedback_by_name,
  get_feedbacks_query_obj,
  delete_feedback_by_id,
  get_feedback_search,
  feedback_search_count,
  employees_not_get_feedback_to_submit_this_month,
  get_performance_by_emp_obj_id,
  get_employees_performance,
  get_employees_performance_count,
  get_performance_by_emp_obj_id_yearly,
  get_last_performance_month,
  get_feedbacks_query_obj_count,
};
