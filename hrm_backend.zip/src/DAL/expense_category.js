const { ExpenseCategory } = require("../models/expense_category");

const add_expense_category = async (expense_category_data) => {
  const new_expense_category = new ExpenseCategory(expense_category_data);
  return await new_expense_category.save();
};
const find_expense_category_by_id = async (id) => {
  return await ExpenseCategory.findOne({ _id: id });
};

const find_expense_category_by_id_for_assignable_status = async (id) => {
  return await ExpenseCategory.findOne(
    { _id: id },
    { assignable_status: 1 }
  ).lean();
};

const get_expense_categories_for_assignable_status = async () => {
  return await ExpenseCategory.find({}, { assignable_status: 1 }).lean();
};

const find_expense_category_by_name = async (title) => {
  return await ExpenseCategory.findOne({ title: title });
};

const total_expense_category = async () => {
  return await ExpenseCategory.find().count();
};

const latest_expense_category = async () => {
  return await ExpenseCategory.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_expense_category = async (skip, limit) => {
  return await ExpenseCategory.find()
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(skip);
};

const all_expense_categories_active = async () => {
  return await ExpenseCategory.find({ active_status: true }).sort({
    createdAt: -1,
  });
};

const all_expense_categories_active_v1 = async () => {
  return await ExpenseCategory.find({ active_status: true })
    .select("_id title")
    .sort({
      createdAt: -1,
    });
};

const all_expense_categories_active_count = async () => {
  return await ExpenseCategory.find({ active_status: true }).countDocuments();
};

const delete_expense_category_by_id = async (expense_category_id) => {
  return await ExpenseCategory.findByIdAndDelete(expense_category_id);
};
const get_expense_category_search = async (limit, skip, search = "") => {
  return await ExpenseCategory.find({
    $or: [{ title: { $regex: new RegExp(search, "i") } }],
  })
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);
};
const expense_category_search_count = async (search = "") => {
  return await ExpenseCategory.find({
    $or: [{ title: { $regex: new RegExp(search, "i") } }],
  }).countDocuments();
};

module.exports = {
  add_expense_category,
  find_expense_category_by_id,
  find_expense_category_by_id_for_assignable_status,
  get_expense_categories_for_assignable_status,
  total_expense_category,
  latest_expense_category,
  find_expense_category_by_name,
  pagination_expense_category,
  all_expense_categories_active,
  all_expense_categories_active_count,
  delete_expense_category_by_id,
  get_expense_category_search,
  expense_category_search_count,
  all_expense_categories_active_v1,
};
