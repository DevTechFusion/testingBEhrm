const date = require("joi/lib/types/date");
const { LeaveRequest } = require("../models/leave_request");

const add_leave_request = async (leave_request_data) => {
  const new_leave_request = new LeaveRequest(leave_request_data);
  return await new_leave_request.save();
};

const find_leave_request_by_id = async (id) => {
  return await LeaveRequest.findOne({ _id: id });
};

const find_leave_request_by_emp_and_date = async (emp_obj_id, date) => {
  return await LeaveRequest.findOne({
    emp_obj_id: emp_obj_id,
    leave_date: date,
  });
};

const find_leave_request_by_emp_date_tomorrow_pending_approved = async (
  emp_obj_id,
  today,
  tomorrow
) => {
  return await LeaveRequest.find({
    emp_obj_id: emp_obj_id,
    status: ["approved", "pending"],
    leave_date: { $gte: today, $lte: tomorrow },
  });
};

const find_leave_requests_for_employee = async (emp_obj_id) => {
  return await LeaveRequest.find({ emp_obj_id: emp_obj_id });
};

const total_leave_request = async (id) => {
  return await LeaveRequest.find().count();
};

const latest_leave_request = async (id) => {
  return await LeaveRequest.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_leave_request = async (skip, limit) => {
  return await LeaveRequest.find()
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(skip);
};

const all_leave_requests_active = async () => {
  return await LeaveRequest.find({ active_status: true }).sort({
    createdAt: -1,
  });
};

const all_leave_requests_active_count = async () => {
  return await LeaveRequest.find({ active_status: true }).countDocuments();
};

const delete_leave_request_by_id = async (leave_request_id) => {
  return await LeaveRequest.findByIdAndDelete(leave_request_id);
};
const get_leave_request_search = async (query_obj, limit, skip) => {
  return await LeaveRequest.find(query_obj)
    .sort({ leave_date: -1 })
    .skip(skip)
    .limit(limit);
};
const leave_request_search_count = async (query_obj) => {
  return await LeaveRequest.find(query_obj).countDocuments();
};

const update_company_in_leave_requests = async (company_id, company_title) => {
  await LeaveRequest.updateMany(
    { "company._id": company_id },
    {
      $set: {
        "company.title": company_title,
      },
    }
  );
};

const update_employee_leave_requests = async (employee_id, employee_name) => {
  await LeaveRequest.updateMany(
    { emp_obj_id: employee_id },
    {
      $set: {
        emp_name: employee_name,
      },
    }
  );
};

const search_leave_requests_by_query_obj = async (query_obj) => {
  return await LeaveRequest.find(query_obj).sort({ leave_date: -1 });
};

const get_leave_requests_pending_approved_today_onwards = async (date) => {
  return await LeaveRequest.find({
    leave_date: { $gte: date },
    status: ["approved", "pending"],
  });
};

const half_leave_requests_yearly = async (emp_obj_id, year) => {
  // let emp_obj_id = new ObjectId(query_obj.emp_obj_id);
  // query_obj.emp_obj_id = emp_obj_id;
  return await LeaveRequest.aggregate([
    {
      $match: {
        emp_obj_id: emp_obj_id,
        $or: [
          {
            $and: [
              { leave_type: { $in: ["first_half", "second_half"] } },
              // { leave_date: { $lte: new Date() } },
              { $expr: { $eq: [{ $year: "$leave_date" }, year] } },
              { $expr: { $gte: [{ $month: "$leave_date" }, 7] } },
            ],
          },
          {
            $and: [
              { leave_type: { $in: ["first_half", "second_half"] } },
              // { leave_date: { $lte: new Date() } },
              { $expr: { $eq: [{ $year: "$leave_date" }, year + 1] } },
              { $expr: { $lte: [{ $month: "$leave_date" }, 6] } },
            ],
          },
        ],
      },
    },
    // {
    //   $project: {
    //     attendance: {
    //       $filter: {
    //         input: "$attendance",
    //         as: "attendanceItem",
    //         cond: {
    //           $or: [{ $in: ["$$attendanceItem.half_leave_type", [1, 2]] }],
    //         },
    //       },
    //     },
    //   },
    // },
    // { $unwind: "$attendance" },
    // {
    //   $addFields: {
    //     "attendance.dateObj": {
    //       $dateFromString: {
    //         dateString: "$attendance.date",
    //         format: "%d/%m/%Y",
    //       },
    //     },
    //   },
    // },
    // {
    //   $sort: { "attendance.dateObj": -1 },
    // },
    // { $project: { "attendance.dateObj": 0 } },
    // {
    //   $replaceRoot: {
    //     newRoot: "$attendance",
    //   },
    // },
  ]);
};
const get_leave_stats = async (query_obj) => {
  console.log(query_obj, "===============query_obj");
  console.log({ ...query_obj }, "===============query_obj");
  let aggregation = [
    {
      $match: query_obj,
    },
    {
      $group: {
        _id: {
          emp_obj_id: "$emp_obj_id",
          emp_name: "$emp_name",
          leave_type: "$leave_type",
        },
        count: { $sum: 1 },
      },
    },
    {
      $group: {
        _id: {
          emp_obj_id: "$_id.emp_obj_id",
          emp_name: "$_id.emp_name",
        },
        leaves: {
          $push: {
            leave_type: "$_id.leave_type",
            count: "$count",
          },
        },
      },
    },
    {
      $project: {
        _id: 0,

        emp_obj_id: "$_id.emp_obj_id",
        emp_name: "$_id.emp_name",
        leaves: 1,
      },
    },
    {
      $lookup: {
        from: "employees",
        localField: "emp_obj_id",
        foreignField: "_id",
        as: "employee_detail",
      },
    },

    {
      $project: {
        emp_name: 1,
        emp_obj_id: 1,
        leaves: 1,
        allowed_leaves: {
          $cond: {
            if: { $eq: [{ $size: "$employee_detail" }, 0] }, // Check if employee_detail array is empty
            then: 15, // Set default value when there's no match
            else: { $arrayElemAt: ["$employee_detail.allowed_leaves", 0] }, // Take allowed_leaves value from the array
          },
        },
        emp_status: {
          $cond: {
            if: { $eq: [{ $size: "$employee_detail" }, 0] }, // Check if employee_detail array is empty
            then: false, // Set default value when there's no match
            else: { $arrayElemAt: ["$employee_detail.active_status", 0] }, // Take active_status value from the array
          },
        },
      },
    },
  ];
  return await LeaveRequest.aggregate(aggregation).sort({ emp_obj_id: -1 });
};

const get_leave_request_for_report = async (emp_obj_id, date_from, date_to) => {
  return await LeaveRequest.find({
    emp_obj_id: emp_obj_id,
    leave_date: { $gte: date_from, $lte: date_to },
  });
};

const find_leave_for_attendance = async (emp_obj_id, date) => {
  return await LeaveRequest.findOne({
    emp_obj_id: emp_obj_id,
    leave_date: new Date(date),
  });
};

const find_leaves_from_leave_request = async (
  emp_obj_id,
  date_from,
  date_to
) => {
  return await LeaveRequest.find({
    emp_obj_id: emp_obj_id,
    status: { $ne: "rejected" },
    leave_date: { $gte: date_from, $lte: date_to },
  });
};

const find_leaves_from_leave_request_pagination = async (
  emp_obj_id,
  date_from,
  date_to,
  skip,
  limit
) => {
  console.log(
    emp_obj_id,
    date_from,
    date_to,
    limit,
    skip,
    "=================="
  );
  return await LeaveRequest.find({
    emp_obj_id: emp_obj_id,
    status: { $ne: "rejected" },
    leave_date: { $gte: date_from, $lte: date_to },
  }).sort({ leave_date: -1 });
};

const find_leaves_from_leave_request_count = async (
  emp_obj_id,
  date_from,
  date_to
) => {
  return await LeaveRequest.find({
    emp_obj_id: emp_obj_id,
    status: { $ne: "rejected" },
    leave_date: { $gte: date_from, $lte: date_to },
  }).countDocuments();
};

const find_leaves_from_leave_request_pagination_v1 = async (
  query_obj,
  skip,
  limit
) => {
  return await LeaveRequest.find(query_obj)
    .sort({ leave_date: -1 })
    .skip(skip)
    .limit(limit);
};

const find_leaves_from_leave_request_count_v1 = async (query_obj) => {
  return await LeaveRequest.find(query_obj).countDocuments();
};

// const get_leaves_request_for_admin_pagination = async (query_obj,skip ,limit) => {
//   return await LeaveRequest.find(query_obj).sort({ leave_date: -1 }).skip(skip).limit(limit);
// }

// const get_leaves_request_for_admin_count = async (query_obj) => {
// return await LeaveRequest.find(query_obj).countDocuments();
// }

const update_uncount_leave_action_by = async (
  emp_obj_id,
  emp_name,
  designation
) => {
  return await LeaveRequest.updateMany(
    { "uncount_leave_action_by.emp_obj_id": emp_obj_id },
    {
      $set: {
        "uncount_leave_action_by.emp_name": emp_name,
        "uncount_leave_action_by.designation": designation,
      },
    }
  );
};

module.exports = {
  add_leave_request,
  find_leave_request_by_id,
  total_leave_request,
  latest_leave_request,
  find_leave_request_by_emp_and_date,
  find_leave_requests_for_employee,
  pagination_leave_request,
  all_leave_requests_active,
  all_leave_requests_active_count,
  delete_leave_request_by_id,
  get_leave_request_search,
  leave_request_search_count,
  update_company_in_leave_requests,
  update_employee_leave_requests,
  search_leave_requests_by_query_obj,
  get_leave_requests_pending_approved_today_onwards,
  find_leave_request_by_emp_date_tomorrow_pending_approved,
  half_leave_requests_yearly,
  get_leave_stats,
  get_leave_request_for_report,
  find_leave_for_attendance,
  find_leaves_from_leave_request,
  find_leaves_from_leave_request_pagination,
  find_leaves_from_leave_request_count,
  find_leaves_from_leave_request_pagination_v1,
  find_leaves_from_leave_request_count_v1,
  // get_leaves_request_for_admin_pagination,
  // get_leaves_request_for_admin_count,
  update_uncount_leave_action_by,
};
