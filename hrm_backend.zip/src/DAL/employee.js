const { Employee } = require("../models/employee");
const add_employee = async (employee_data) => {
  const new_employee = new Employee(employee_data);
  return await new_employee.save();
};
const find_employee_by_id = async (id) => {
  return await Employee.findOne({ _id: id }).populate("user_id", "email");
};

const find_employee_for_lunch = async (id) => {
  return await Employee.findOne({ _id: id }).select({
    _id: 1,
    full_name: 1,
    employee_id: 1,
  });
};

const find_employee_by_ids = async (ids) => {
  return await Employee.findOne({
    _id: { $in: ids },
  }).populate("user_id", "email");
};

// const find_employee_by_id_for_settings = async (id) => {
//   return await Employee.findOne({ _id: id }).populate("user_id", "email").select({
//     _id:1,
//     first_name:1,
//     last_name:1,
//     contact_number:1,
//     address:1,
//     employee_id:1,
//     profile_pic:1,
//     // previllages:1,

//   });
// };

// const find_employee_by_id_for_popup = async (id) => {
//   return await Employee.findOne({ _id: id }).populate("user_id", "email").select({
//     _id:1,
//     profile_pic:1,
//     contact_number:1,
//     date_of_birth:1,
//     date_of_joining:1,
//     date_of_confirmation:1,
//     date_of_contract:1,
//     date_of_increment:1,
//     next_date_of_increment:1,
//     designation:1,
//     basic_salary:1,
//    full_name:1,
//    company_assets:1,

//   });
// };

const find_employee_by_id_without_populate = async (id) => {
  return await Employee.findOne({ _id: id });
};

const find_employee_by_user_id = async (id) => {
  return await Employee.findOne({ user_id: id }).populate("user_id", "email");
};

const find_employee_by_user_id_without_populate = async (id) => {
  return await Employee.findOne({ user_id: id });
};

const find_employee_by_employee_id = async (employee_id) => {
  return await Employee.findOne({ employee_id: employee_id });
};

const find_employee_by_email = async (email) => {
  return await Employee.findOne({ email: email });
};

const find_employee_by_bank_account = async (bank_account) => {
  return await Employee.findOne({ bank_account });
};

const total_employee = async (id) => {
  return await Employee.find().count();
};

const latest_employee = async (id) => {
  return await Employee.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_employee = async (skip, limit) => {
  return await Employee.find({ active_status: true })
    .sort({ createdAt: -1 })
    .populate("user_id", "email")
    .limit(limit)
    .skip(skip);
};
const all_employee_count = async () => {
  return await Employee.find({ active_status: true }).countDocuments();
};

const delete_employee_by_id = async (employee_id) => {
  return await Employee.findByIdAndDelete(employee_id);
};

const get_employee_search = async (query_obj, skip, limit) => {
  return await Employee.find(query_obj)
    .sort({ employee_id: 1 })
    .skip(skip)
    .limit(limit);
};

const get_employee_search_v1 = async (query_obj, skip, limit) => {
  return await Employee.find(query_obj)
    .sort({ employee_id: 1 })
    .skip(skip)
    .limit(limit)
    .select({
      _id: 1,
      full_name: 1,
      email: 1,
      department: 1,
      blood_group: 1,
      employee_id: 1,
      active_status: 1,
      role: 1,
      allowed_leaves: 1,
      documents_url: 1,
    });
};
const employee_search_count = async (query_obj) => {
  return await Employee.countDocuments({
    ...query_obj,
  });
};

const get_employee_search_with_query_obj = async (query_obj) => {
  return await Employee.find(query_obj).lean();
};

const get_active_inactive_and_total_employees = async () => {
  // use aggregation

  var active = 0;
  var inactive = 0;
  var total = 0;

  const data = await Employee.aggregate([
    {
      $facet: {
        active: [
          {
            $match: { active_status: true },
          },
          {
            $count: "active",
          },
        ],
        inactive: [
          {
            $match: { active_status: false },
          },
          {
            $count: "inactive",
          },
        ],
        total: [
          {
            $count: "total",
          },
        ],
      },
    },

    {
      $project: {
        active: 1,
        inactive: 1,
        total: 1,
      },
    },
  ]);

  if (data.length > 0) {
    return {
      active: data[0].active[0].active,
      inactive: data[0].inactive[0].inactive,
      total: data[0].total[0].total,
    };
  } else {
    return {
      active: 0,
      inactive: 0,
      total: 0,
    };
  }

  return {
    active,
    inactive,
    total,
  };
};

const mark_employee_inactive = async (employee_id) => {
  await Employee.updateOne(
    { _id: employee_id },
    { $set: { active_status: false } }
  );
};

const employees_for_department = async () => {
  return await Employee.find({ department: {} });
};

const delete_department_from_employees = async (department_id) => {
  return await Employee.updateMany(
    { "department._id": department_id },
    {
      $unset: {
        "department._id": "",
        "department.title": "",
      },
    }
  );
};

const update_department_name_in_employees = async (
  department_id,
  department_title
) => {
  return await Employee.updateMany(
    { "department._id": department_id },
    {
      $set: { "department.title": department_title },
    }
  );
};

const get_all_employees = async () => {
  return await Employee.find().sort({ full_name: 1 });
};

const get_all_employees_count = async () => {
  return await Employee.find().countDocuments();
};

const get_all_active_employees = async () => {
  return await Employee.find({ active_status: true }).sort({ full_name: 1 });
};

const get_all_active_employees_for_payroll = async () => {
  return await Employee.find({ active_status: true, basic_salary: { $gt: 0 } })
    .select({
      _id: 1,
      full_name: 1,
      basic_salary: 1,
      food_allowance: 1,
      medical_allowance: 1,
      conveyance_allowance: 1,
      employee_id: 1,
    })
    .sort({ employee_id: 1 });
};

const get_all_active_employees_for_payroll_v2 = async () => {
  return await Employee.find({ active_status: true, basic_salary: { $gt: 0 } })
    .select({
      _id: 1,
      full_name: 1,
      basic_salary: 1,
      employee_id: 1,
    })
    .sort({ employee_id: 1 });
};

const get_all_active_employees_for_birthday_anniversary = async () => {
  return await Employee.find({ active_status: true }).select({
    _id: 1,
    full_name: 1,
    designation: 1,
    date_of_birth: 1,
    date_of_joining: 1,
  });
};
const get_all_active_employees_v1 = async () => {
  //slect _id and full_name
  return await Employee.find({ active_status: true })
    .sort({ full_name: 1 })
    .select({ _id: 1, full_name: 1 })
    .lean();
};

const get_all_active_employees_for_loan = async (query_obj) => {
  return await Employee.find(query_obj)
    .sort({ full_name: 1 })
    .select({ _id: 1, full_name: 1, basic_salary: 1, employee_id: 1 })
    .lean()
    .limit(10);
};

const get_all_active_employees_for_payroll_sort_employee_id = async (
  query_obj
) => {
  return await Employee.find(query_obj)
    .sort({ employee_id: 1 })
    .select({ _id: 1, full_name: 1, basic_salary: 1, employee_id: 1 })
    .lean()
    .limit(10);
};

const get_all_active_employees_count = async () => {
  return await Employee.find({ active_status: true }).countDocuments();
};

const add_company_asset_to_employee = async (employee_id, asset_obj) => {
  await Employee.updateOne(
    { _id: employee_id },
    {
      $push: { company_assets: asset_obj },
    }
  );
};

const delete_company_asset_from_employee = async (employee_id, asset_obj) => {
  await Employee.updateOne(
    { _id: employee_id },
    {
      $pull: { company_assets: { _id: asset_obj._id, title: asset_obj.title } },
    }
  );
};

const get_all_employees_ids = async () => {
  return await Employee.find({ active_status: true }, { _id: 1 }).lean();
};

const update_role_title_in_employee = async (role_id, role_title) => {
  await Employee.updateMany(
    { "role._id": role_id },
    {
      $set: { "role.title": role_title },
    }
  );
};

const get_all_active_hr = async () => {
  return await Employee.find({ active_status: true, "role.title": "HR" });
};

const get_active_alls = async () => {
  return await Employee.find({ active_status: true, "role.title": "All" });
};

const get_active_alls_hrs = async () => {
  return await Employee.find({
    active_status: true,
    "role.title": { $in: ["All", "HR"] },
  });
};
const get_active_alls_hrs_and_admin = async () => {
  return await Employee.find({
    active_status: true,
    "role.title": { $in: ["All", "HR", "Admin"] },
  });
};
const get_active_admin_and_hr = async () => {
  return await Employee.find({
    active_status: true,
    "role.title": { $in: ["Admin", "HR"] },
  });
};
const get_active_employees_role_based = async (role_id) => {
  return await Employee.find({ active_status: true, "role._id": role_id });
};

const get_active_employees_role_based_except_employee = async () => {
  return await Employee.find({
    active_status: true,
    "role.title": { $nin: ["Team", "Team Lead"] },
  });
};

const update_role_in_employee = async (
  old_role_id,
  new_role_id,
  new_role_title
) => {
  await Employee.updateMany(
    { "role._id": old_role_id },
    {
      $set: { "role._id": new_role_id, "role.title": new_role_title },
    }
  );
};

const get_active_employees_for_birthday_increments = async () => {
  return await Employee.find(
    { active_status: true },
    {
      previllages: 0,
      skype_email: 0,
      webmail_email: 0,
      webmail_password: 0,
      company_assets: 0,
      sidebar_status: 0,
    }
  )
    .lean()
    .sort({
      date_of_increment: 1,
    });
};

const get_active_employees_for_increments = async () => {
  return await Employee.find(
    { active_status: true },
    {
      _id: 1,
      full_name: 1,
      date_of_increment: 1,
    }
  )
    .lean()
    .sort({
      date_of_increment: 1,
    });
};

const checking_webmail_exist = async (email) => {
  return await Employee.findOne({ webmail_email: email });
};

const delete_employee_from_leads = async (emp_obj_id) => {
  await Employee.updateMany(
    {},
    {
      $pull: { leads: { _id: emp_obj_id } },
    }
  );
};

const update_webmail_in_lead = async (old_webmail, new_webmail) => {
  await Employee.updateMany(
    { "leads.webmail": old_webmail },
    {
      $set: { "leads.$.webmail": new_webmail },
    }
  );
};

const update_employee_in_lead = async (emp_obj_id, emp_name) => {
  await Employee.updateMany(
    { "leads._id": emp_obj_id },
    {
      $set: { "leads.$.name": emp_name },
    }
  );
};

const update_employee_in_tech_lead = async (emp_obj_id, emp_name) => {
  await Employee.updateMany(
    { "tech_lead._id": emp_obj_id },
    {
      $set: { "tech_lead.name": emp_name },
    }
  );
};

const get_team_members = async (emp_obj_id) => {
  return await Employee.find({ "leads._id": emp_obj_id });
};

const get_team_members_ids = async (emp_obj_id) => {
  return await Employee.find({ "leads._id": emp_obj_id }, { _id: 1 });
};

const add_lead_to_member = async (emp_obj_id, lead_obj) => {
  await Employee.updateOne(
    { _id: emp_obj_id },
    {
      $push: { leads: lead_obj },
    }
  );
};

const team_members_search = async (user_id, search = "", skip, limit) => {
  return await Employee.find({
    "leads.user_id": user_id,
    $or: [
      { full_name: { $regex: new RegExp(search, "i") } },
      { email: { $regex: new RegExp(search, "i") } },
    ],
  })
    .select({
      _id: 1,
      full_name: 1,
      email: 1,
      skype_email: 1,
      webmail_email: 1,
      date_of_joining: 1,
      date_of_confirmation: 1,
      date_of_confirmation: 1,
      date_of_increment: 1,
      date_of_contract: 1,
      designation: 1,
      contact_number: 1,
      address: 1,
      gender: 1,
      profile_pic: 1,
      employee_id: 1,
      active_status: 1,
      department: 1,
    })
    .sort({ employee_id: 1 })
    .skip(skip)
    .limit(limit);
};
const team_members_search_count = async (user_id, search = "") => {
  return await Employee.find({
    "leads.user_id": user_id,
    $or: [
      { full_name: { $regex: new RegExp(search, "i") } },
      { email: { $regex: new RegExp(search, "i") } },
    ],
  }).countDocuments();
};

const team_members_search_v1 = async (user_id, search = "", skip, limit) => {
  return await Employee.find({
    "leads.user_id": user_id,
    $or: [
      { full_name: { $regex: new RegExp(search, "i") } },
      { email: { $regex: new RegExp(search, "i") } },
    ],
  })
    .select({
      _id: 1,
      full_name: 1,
      email: 1,
      designation: 1,
    })
    .sort({ employee_id: 1 })
    .skip(skip)
    .limit(limit);
};
const team_members_search_count_v1 = async (user_id, search = "") => {
  return await Employee.find({
    "leads.user_id": user_id,
    $or: [
      { full_name: { $regex: new RegExp(search, "i") } },
      { email: { $regex: new RegExp(search, "i") } },
    ],
  }).countDocuments();
};

const remove_member_from_team = async (emp_obj_id, lead_user_id) => {
  await Employee.updateOne(
    { _id: emp_obj_id },
    {
      $pull: { leads: { user_id: lead_user_id } },
    }
  );
};

const get_team_members_by_user_id = async (user_id) => {
  return await Employee.find(
    { "leads.user_id": user_id },
    {
      full_name: 1,
      email: 1,
      skype_email: 1,
      webmail_email: 1,
      designation: 1,
      contact_number: 1,
      address: 1,
      profile_pic: 1,
      employee_id: 1,
      active_status: 1,
      leads: 1,
      department: 1,
      role: 1,
    }
  );
};

const get_leads_with_their_teams = async (search, skip, limit) => {
  return await Employee.aggregate([
    {
      $unwind: "$leads",
    },
    {
      $match: {
        "leads.name": { $regex: new RegExp(search, "i") },
      },
    },
    {
      $group: {
        _id: "$leads._id",
        lead_name: { $first: "$leads.name" },
        team_members: {
          $push: {
            _id: "$_id",
            full_name: "$full_name",
          },
        },
      },
    },
    {
      $skip: skip,
    },
    {
      $limit: limit,
    },
  ]);
};

const get_leads_with_their_teams_count = async (search) => {
  return await Employee.aggregate([
    {
      $unwind: "$leads",
    },
    {
      $match: {
        "leads.name": { $regex: new RegExp(search, "i") },
      },
    },
    {
      $group: {
        _id: "$leads._id",
        team_members: {
          $push: {
            _id: "$_id",
            full_name: "$full_name",
          },
        },
        leadCount: { $sum: 1 },
      },
    },
    {
      $count: "count",
    },
  ]);
};

const get_members_for_lead_for_feedback = async (emp_obj_id) => {
  return await Employee.find({ "tech_lead._id": emp_obj_id }, { full_name: 1 });
};

const update_want_lunch_to_null = async () => {
  await Employee.updateMany(
    { want_lunch: { $ne: null } },
    { $set: { want_lunch: null } }
  );
};

const get_employee_name_and_salary = async (emp_obj_id) => {
  return await Employee.findOne(
    { _id: emp_obj_id },
    { _id: 1, full_name: 1, basic_salary: 1 }
  );
};

const get_member_list_for_my_team = async (user_id) => {
  return await Employee.find({
    $or: [{ "leads.user_id": { $ne: user_id } }],
    user_id: { $ne: user_id },
  }).select({
    _id: 1,
    full_name: 1,
  });
};

const get_member_for_birthday = async (month, skip, limit) => {
  return Employee.aggregate([
    {
      $addFields: {
        month: {
          $substrCP: ["$date_of_birth", 3, 2],
        },
      },
    },
    {
      $match: {
        month: { $in: month },
        active_status: true,
      },
    },
    {
      $project: {
        _id: 1,
        full_name: 1,
        designation: 1,
        date_of_birth: 1,
      },
    },
    {
      $sort: {
        date_of_birth: 1,
      },
    },
    {
      $skip: skip,
    },
    {
      $limit: limit,
    },
  ]);
};

const count_member_for_birthday = async (month) => {
  return Employee.aggregate([
    {
      $addFields: {
        month: {
          $substrCP: ["$date_of_birth", 3, 2],
        },
      },
    },
    {
      $match: {
        month: { $in: month },
        active_status: true,
      },
    },
    {
      $count: "count",
    },
  ]);
};

const get_member_for_anniversary = async (month, skip, limit) => {
  //find current year just
  let date = new Date();
  let current_year = date.getFullYear().toString();

  return Employee.aggregate([
    {
      $addFields: {
        month: {
          $substrCP: ["$date_of_joining", 3, 2],
        },
        year: {
          $substrCP: ["$date_of_joining", 6, 4],
        },
      },
    },
    {
      $match: {
        month: { $in: month },
        //if year is equal to current year then no need to show
        year: { $ne: current_year },
        active_status: true,
      },
    },
    {
      $project: {
        _id: 1,
        full_name: 1,
        designation: 1,
        date_of_joining: 1,
      },
    },
    {
      $sort: {
        date_of_joining: 1,
      },
    },
    {
      $skip: skip,
    },
    {
      $limit: limit,
    },
  ]);
};

const count_member_for_anniversary = async (month) => {
  let date = new Date();
  let current_year = date.getFullYear().toString();
  return Employee.aggregate([
    {
      $addFields: {
        month: {
          $substrCP: ["$date_of_joining", 3, 2],
        },
        year: {
          $substrCP: ["$date_of_joining", 6, 4],
        },
      },
    },
    {
      $match: {
        month: { $in: month },
        year: { $ne: current_year },
        active_status: true,
      },
    },
    {
      $count: "count",
    },
  ]);
};

// const employee_next_increment = async (date_from , date_to) => {
//   return await Employee.find({
//     ative_status: true,
//     next_date_of_increment: { $gte: date_from, $lte: date_to }

//   });
// }

const employee_next_increment = async (date_from, date_to, skip, limit) => {
  return await Employee.find({
    active_status: true,
    next_date_of_increment: { $gte: date_from, $lte: date_to },
  })
    .select({
      _id: 1,
      full_name: 1,
      date_of_increment: 1,
      next_date_of_increment: 1,
    })
    .skip(skip)
    .limit(limit)
    .sort({ next_date_of_increment: 0 });
};

const employee_next_increment_count = async (date_from, date_to) => {
  return await Employee.find({
    active_status: true,
    next_date_of_increment: { $gte: date_from, $lte: date_to },
  }).countDocuments();
};

// const get_employee_for_leave_report = async (search,limit,skip) => {
//   return await Employee.find({
//     active_status: true,
//     $or: [
//       { full_name: { $regex: new RegExp(search, "i") } },
//     ],
//   }).select({
//     _id: 1,
//     full_name: 1,
//     allowed_leaves: 1,
//   }).sort({ full_name: 1 }).skip(skip).limit(limit);
// };

// const get_employee_for_leave_report_count = async (search) => {
//   return await Employee.find({
//     active_status: true,
//     $or: [
//       { full_name: { $regex: new RegExp(search, "i") } },
//     ],
//   }).countDocuments();
// };

// const find_employee_full_name_with_emp_obj_id = async (emp_obj_id) => {

//   const info =  await Employee.findOne(
//     { _id: emp_obj_id ,
//       active_status: true
//     },
//     { _id: 1, full_name: 1 }
//   );

//   return info ? info : {}
// };

const find_employee_allowance_by_id = async (id) => {
  return await Employee.findOne({ _id: id }).select({
    food_allowance: 1,
    medical_allowance: 1,
    conveyance_allowance: 1,
  });
};

const team_members_of_lead_tech_lead = async (query_object) => {
  return await Employee.find(query_object)
    .select({
      _id: 1,
      full_name: 1,
      email: 1,
      user_id: 1,
      designation : 1,
    })
    .sort({ full_name: 1 })
    .lean();
};

const find_team_members_of_lead_tech_lead_for_feedback_improvement = async (
  user_id
) => {
  return await Employee.find({
    $or: [{ "leads.user_id": user_id }, { "tech_lead.user_id": user_id }],
  })
    .select({
      _id: 1,
      user_id: 1,
    })
    .sort({ full_name: 1 })
    .lean();
};

const get_all_active_employees_for_expense_screen = async () => {
  //role is HR , Admin , All select _id and full_name role variable
  return await Employee.find({
    active_status: true,
    "role.title": { $in: ["HR", "Admin", "All"] },
  })
    .sort({ full_name: 1 })
    .select({ _id: 1, full_name: 1, role: 1 });
};

module.exports = {
  add_employee,
  find_employee_by_id,
  find_employee_by_id_without_populate,
  find_employee_by_user_id_without_populate,
  total_employee,
  latest_employee,
  find_employee_by_user_id,
  pagination_employee,
  all_employee_count,
  delete_employee_by_id,
  get_employee_search,
  employee_search_count,
  find_employee_by_employee_id,
  mark_employee_inactive,
  employees_for_department,
  delete_department_from_employees,
  get_all_employees,
  get_all_employees_count,
  get_all_active_employees,
  get_all_active_employees_for_loan,
  get_all_active_employees_count,
  add_company_asset_to_employee,
  delete_company_asset_from_employee,
  find_employee_by_email,
  get_all_employees_ids,
  update_role_title_in_employee,
  get_all_active_hr,
  get_active_employees_role_based,
  get_active_employees_role_based_except_employee,
  update_role_in_employee,
  get_active_employees_for_birthday_increments,
  update_department_name_in_employees,
  delete_employee_from_leads,
  checking_webmail_exist,
  update_webmail_in_lead,
  update_employee_in_tech_lead,
  update_employee_in_lead,
  get_team_members,
  find_employee_by_bank_account,
  get_team_members_ids,
  add_lead_to_member,
  team_members_search,
  team_members_search_count,
  remove_member_from_team,
  get_team_members_by_user_id,
  get_leads_with_their_teams,
  get_leads_with_their_teams_count,
  get_members_for_lead_for_feedback,
  get_active_alls,
  get_active_alls_hrs,
  update_want_lunch_to_null,
  get_employee_search_with_query_obj,
  get_active_admin_and_hr,
  get_active_alls_hrs_and_admin,
  get_employee_name_and_salary,
  get_all_active_employees_v1,
  team_members_search_v1,
  team_members_search_count_v1,
  get_member_list_for_my_team,
  get_all_active_employees_for_birthday_anniversary,
  get_member_for_birthday,
  get_member_for_anniversary,
  count_member_for_birthday,
  count_member_for_anniversary,
  get_active_inactive_and_total_employees,
  get_employee_search_v1,
  get_active_employees_for_increments,
  employee_next_increment,
  employee_next_increment_count,
  get_all_active_employees_for_payroll,
  get_all_active_employees_for_payroll_v2,
  find_employee_by_ids,
  find_employee_allowance_by_id,
  team_members_of_lead_tech_lead,
  get_all_active_employees_for_payroll_sort_employee_id,
  get_all_active_employees_for_expense_screen,
  find_team_members_of_lead_tech_lead_for_feedback_improvement,
  find_employee_for_lunch,
};
