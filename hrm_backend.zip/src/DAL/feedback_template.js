const { FeedbackTemplate } = require("../models/feedback_template");

const add_feedback_template = async (feedback_template_data) => {
  const new_feedback_template = new FeedbackTemplate(feedback_template_data);
  return await new_feedback_template.save();
};
const find_feedback_template_by_id = async (id) => {
  return await FeedbackTemplate.findOne({ _id: id });
};

const find_feedback_template_by_id_for_assignable_status = async (id) => {
  return await FeedbackTemplate.findOne(
    { _id: id },
    { assignable_status: 1 }
  ).lean();
};

const find_feedback_template_by_name = async (title) => {
  return await FeedbackTemplate.findOne({ title: title });
};

const total_feedback_template = async () => {
  return await FeedbackTemplate.find().count();
};

const latest_feedback_template = async () => {
  return await FeedbackTemplate.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_feedback_template = async (skip, limit) => {
  return await FeedbackTemplate.find()
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(skip);
};

const all_active_feedback_templates = async () => {
  return await FeedbackTemplate.find({ active_status: true }).sort({
    createdAt: -1,
  });
};

const all_active_feedback_templates_count = async () => {
  return await FeedbackTemplate.find({ active_status: true }).countDocuments();
};

const delete_feedback_template_by_id = async (feedback_template_id) => {
  return await FeedbackTemplate.findByIdAndDelete(feedback_template_id);
};
const get_feedback_template_search = async (limit, skip, search = "") => {
  return await FeedbackTemplate.find({
    $or: [{ title: { $regex: new RegExp(search, "i") } }],
  }).select({
    questions: 0,
  })
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);
};
const feedback_template_search_count = async (search = "") => {
  return await FeedbackTemplate.find({
    $or: [{ title: { $regex: new RegExp(search, "i") } }],
  }).countDocuments();
};

module.exports = {
  add_feedback_template,
  find_feedback_template_by_id,
  find_feedback_template_by_id_for_assignable_status,
  total_feedback_template,
  latest_feedback_template,
  find_feedback_template_by_name,
  pagination_feedback_template,
  all_active_feedback_templates,
  all_active_feedback_templates_count,
  delete_feedback_template_by_id,
  get_feedback_template_search,
  feedback_template_search_count,
};
