const { Announcement } = require("../models/announcement");
const moment = require("moment");

const add_announcement = async (announcement_data) => {
  const new_announcement = new Announcement(announcement_data);
  return await new_announcement.save();
};
const find_announcement_by_id = async (id) => {
  return await Announcement.findOne({ _id: id });
};

const find_announcement_by_id_for_assignable_status = async (id) => {
  return await Announcement.findOne({ _id: id }, { assignable_status: 1 }).lean();
};

const get_announcement_categories_for_assignable_status = async () => {
  return await Announcement.find({}, { assignable_status: 1 }).lean();
};

const find_announcement_by_name = async (title) => {
  return await Announcement.findOne({ title: title });
};

const total_announcement = async () => {
  return await Announcement.find().count();
};

const latest_announcement = async () => {
  return await Announcement.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_announcement = async (skip, limit) => {
  return await Announcement.find().sort({ createdAt: -1 }).limit(limit).skip(skip);
};

const all_announcement_categories_active = async () => {
  return await Announcement.find({ active_status: true }).sort({
    createdAt: -1,
  });
};

const all_announcement_categories_active_count = async () => {
  return await Announcement.find({ active_status: true }).countDocuments();
};

const delete_announcement_by_id = async (announcement_id) => {
  return await Announcement.findByIdAndDelete(announcement_id);
};
const get_announcement_search = async (limit, skip, query_obj) => {
  return await Announcement.find(query_obj)
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);
};
const announcement_search_count = async (query_obj) => {
  return await Announcement.find(query_obj).countDocuments();
};

const announcement_search_by_query_obj = async (query_obj) => {
  return await Announcement.find(query_obj);
};

const announcement_search_by_query_obj_count = async (query_obj) => {
  return await Announcement.find(query_obj).countDocuments();
};

const update_role_in_announcement = async (role_id, role_title) => {
  await Announcement.updateMany(
    { "role._id": role_id },
    {
      $set: {
        "role.title": role_title,
      },
    }
  );
};

module.exports = {
  add_announcement,
  find_announcement_by_id,
  find_announcement_by_id_for_assignable_status,
  get_announcement_categories_for_assignable_status,
  total_announcement,
  latest_announcement,
  find_announcement_by_name,
  pagination_announcement,
  all_announcement_categories_active,
  all_announcement_categories_active_count,
  delete_announcement_by_id,
  get_announcement_search,
  announcement_search_count,
  announcement_search_by_query_obj,
  announcement_search_by_query_obj_count,
  update_role_in_announcement,
};
