const { SupportTicket } = require("../models/support_ticket");

const add_support_ticket = async (support_ticket_data) => {
  const new_support_ticket = new SupportTicket(support_ticket_data);
  return await new_support_ticket.save();
};
const find_support_ticket_by_id = async (id) => {
  return await SupportTicket.findOne({ _id: id });
};

const find_support_ticket_by_id_with_populate = async (id) => {
  return await SupportTicket.findOne({ _id: id }).populate({
    path: "emp_obj_id",
    select: "profile_pic",
  });
};

const find_support_ticket_by_emp_and_date = async (emp_obj_id, date) => {
  return await SupportTicket.findOne({
    emp_obj_id: emp_obj_id,
    leave_date: date,
  });
};

const find_support_tickets_for_employee = async (emp_obj_id) => {
  return await SupportTicket.find({ emp_obj_id: emp_obj_id });
};

const total_support_ticket = async (id) => {
  return await SupportTicket.find().count();
};

const latest_support_ticket = async (id) => {
  return await SupportTicket.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_support_ticket = async (skip, limit) => {
  return await SupportTicket.find()
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(skip);
};

const all_support_tickets_active = async () => {
  return await SupportTicket.find({ active_status: true }).sort({
    createdAt: -1,
  });
};

const all_support_tickets_active_count = async () => {
  return await SupportTicket.find({ active_status: true }).countDocuments();
};

const delete_support_ticket_by_id = async (support_ticket_id) => {
  return await SupportTicket.findByIdAndDelete(support_ticket_id);
};
const get_support_ticket_search = async (query_obj, limit, skip) => {
  return await SupportTicket.find(query_obj)
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);
};
const support_ticket_search_count = async (query_obj) => {
  return await SupportTicket.find(query_obj).countDocuments();
};

const update_employee_support_tickets = async (employee_id, employee_name) => {
  await SupportTicket.updateMany(
    { emp_obj_id: employee_id },
    {
      $set: {
        emp_name: employee_name,
      },
    }
  );
};

const update_role_in_support_ticket = async (role_id, role_title) => {
  await SupportTicket.updateMany(
    { "support_type._id": role_id },
    {
      $set: {
        "support_type.title": role_title,
      },
    }
  );
};

const add_message_to_unread = async (support_ticket_id, message_obj) => {
  return await SupportTicket.updateOne(
    { _id: support_ticket_id },
    { $push: { message_receivers: message_obj } }
  );
};

const search_support_tickets_by_query_obj = async (query_obj) => {
  return await SupportTicket.find(query_obj).sort({ updatedAt: -1 });
};
const latest_support_ticket_with_role = async (role_id) => {
  return await SupportTicket.find({
    $or: [{ "support_type._id": role_id }, { "support_type.title": "All" }],
    status: 0,
  })
    .sort({ createdAt: -1 })
    .limit(5);
};

//v1 of latest_support_ticket_with_role select emp_name ,title, status, createdAt

const latest_support_ticket_with_role_v1 = async (role_id) => {
  return await SupportTicket.find({
    $or: [{ "support_type._id": role_id }, { "support_type.title": "All" }],
    status: 0,
  })
    .select("emp_name title status createdAt")
    .sort({ createdAt: -1 })
    .limit(5);
}




module.exports = {
  add_support_ticket,
  find_support_ticket_by_id,
  find_support_ticket_by_id_with_populate,
  total_support_ticket,
  latest_support_ticket,
  find_support_ticket_by_emp_and_date,
  find_support_tickets_for_employee,
  pagination_support_ticket,
  all_support_tickets_active,
  all_support_tickets_active_count,
  delete_support_ticket_by_id,
  get_support_ticket_search,
  support_ticket_search_count,
  update_employee_support_tickets,
  update_role_in_support_ticket,
  search_support_tickets_by_query_obj,
  add_message_to_unread,
  latest_support_ticket_with_role,
  latest_support_ticket_with_role_v1
};
