const { Vendor } = require("../models/vendor");

const add_vendor = async (vendor_data) => {
  const new_vendor = new Vendor(vendor_data);
  return await new_vendor.save();
};
const find_vendor_by_id = async (id) => {
  return await Vendor.findOne({ _id: id });
};
const find_vendor_by_email = async (email) => {
  return await Vendor.findOne({ email: email });
};

const total_vendor = async (id) => {
  return await Vendor.find().count();
};

const latest_vendor = async (id) => {
  return await Vendor.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_vendor = async (skip, limit) => {
  return await Vendor.find().sort({ createdAt: -1 }).limit(limit).skip(skip);
};

const all_vendors_active = async () => {
  return await Vendor.find({active_status:true}).sort({ createdAt: -1 });
};

const all_vendors_active_count = async () => {
  return await Vendor.find({active_status:true}).countDocuments();
};

const delete_vendor_by_id = async (vendor_id) => {
  return await Vendor.findByIdAndDelete(vendor_id);
};
const get_vendor_search = async (limit, skip, search = "") => {
  return await Vendor.find({
    $or: [
      { name: { $regex: new RegExp(search, "i") } },
      { email: { $regex: new RegExp(search, "i") } },
      { address: { $regex: new RegExp(search, "i") } },
    ],
  })
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);
};
const vendor_search_count = async (search = "") => {
  return await Vendor.find({
    $or: [
      { name: { $regex: new RegExp(search, "i") } },
      { email: { $regex: new RegExp(search, "i") } },
      { address: { $regex: new RegExp(search, "i") } },
    ],
  }).countDocuments();
};

const update_company_in_vendors = async (company_id, company_title) => {
  await Vendor.updateMany(
    { "company._id": company_id },
    {
      $set: {
        "company.title": company_title,
      },
    }
  );
};

const update_employee_vendors = async (employee_id, employee_name) => {
  await Vendor.updateMany(
    { "assigned_employee._id": employee_id },
    {
      $set: {
        "assigned_employee.name": employee_name,
      },
    }
  );
};

const unassign_vendors = async (employee_id) => {
  await Vendor.updateMany(
    { "assigned_employee._id": employee_id },
    {
      $set: {
        "assigned_employee._id": "",
        "assigned_employee.name": "",
      },
    }
  );
};

module.exports = {
  add_vendor,
  find_vendor_by_id,
  total_vendor,
  latest_vendor,
  find_vendor_by_email,
  pagination_vendor,
  all_vendors_active,
  all_vendors_active_count,
  delete_vendor_by_id,
  get_vendor_search,
  vendor_search_count,
  update_company_in_vendors,
  update_employee_vendors,
  unassign_vendors,
};
