const { TopUp } = require("../models/top_up");
const moment = require("moment");

const add_top_up = async (top_up_data) => {
  const new_top_up = new TopUp(top_up_data);
  return await new_top_up.save();
};
const find_top_up_by_id = async (id) => {
  return await TopUp.findOne({ _id: id });
};

const find_top_up_by_id_for_assignable_status = async (id) => {
  return await TopUp.findOne({ _id: id }, { assignable_status: 1 }).lean();
};

const get_top_up_categories_for_assignable_status = async () => {
  return await TopUp.find({}, { assignable_status: 1 }).lean();
};

const find_top_up_by_name = async (title) => {
  return await TopUp.findOne({ title: title });
};

const total_top_up = async () => {
  return await TopUp.find().count();
};

const latest_top_up = async () => {
  return await TopUp.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_top_up = async (skip, limit) => {
  return await TopUp.find().sort({ createdAt: -1 }).limit(limit).skip(skip);
};

const all_top_up_categories_active = async () => {
  return await TopUp.find({ active_status: true }).sort({
    createdAt: -1,
  });
};

const all_top_up_categories_active_count = async () => {
  return await TopUp.find({ active_status: true }).countDocuments();
};

const delete_top_up_by_id = async (top_up_id) => {
  return await TopUp.findByIdAndDelete(top_up_id);
};

const get_top_up_search = async (limit, skip, query_obj) => {
  return await TopUp.find(query_obj).sort({ date: -1 }).skip(skip).limit(limit);
};

const top_up_search_count = async (query_obj) => {
  return await TopUp.find(query_obj).countDocuments();
};

const top_up_search_by_query_obj = async (query_obj) => {
  return await TopUp.find(query_obj);
};

const top_up_search_by_query_obj_count = async (query_obj) => {
  return await TopUp.find(query_obj).countDocuments();
};

const update_transfer_by_in_top_up = async (employee_id, employee_name) => {
  await TopUp.updateMany(
    { "transfer_by._id": employee_id },
    {
      $set: {
        "transfer_by.name": employee_name,
      },
    }
  );
};

const update_transfer_to_in_top_up = async (employee_id, employee_name) => {
  await TopUp.updateMany(
    { "transfer_to._id": employee_id },
    {
      $set: {
        "transfer_to.name": employee_name,
      },
    }
  );
};

const update_added_by_in_top_up = async (employee_id, employee_name) => {
  await TopUp.updateMany(
    { "added_by._id": employee_id },
    {
      $set: {
        "added_by.name": employee_name,
      },
    }
  );
};

const delete_top_up_category_in_top_ups = async (category_id) => {
  await TopUp.updateMany(
    { "top_up_category._id": category_id },
    {
      $set: { "top_up_category._id": null, "top_up_category.title": "" },
    }
  );
};

const get_top_up_by_query_obj = async (query_obj) => {
  return await TopUp.find(query_obj);
};

//find top up sum or amount by query object

const find_topup_amount_by_query_obj = async (query_obj) => {
  const find_topup = await TopUp.aggregate([
    { $match: query_obj },
    {
      $group: {
        _id: null,
        total: { $sum: "$amount" },
      },
    },
  ]);

  return find_topup.length > 0 ? find_topup[0].total : 0;
};

const get_top_up_amount_by_query_obj = async (query_obj) => {
  console.log("Query Object:", query_obj);

  const top_up = await TopUp.aggregate([
    { $match: query_obj },
    {
      $group: {
        _id: null,
        total_top_up: { $sum: "$amount" },
      },
    },
  ]);

  console.log("Aggregation Result:", top_up);

  return top_up.length > 0 ? top_up[0].total_top_up : 0;
};

module.exports = {
  add_top_up,
  find_top_up_by_id,
  find_top_up_by_id_for_assignable_status,
  get_top_up_categories_for_assignable_status,
  total_top_up,
  latest_top_up,
  find_top_up_by_name,
  pagination_top_up,
  all_top_up_categories_active,
  all_top_up_categories_active_count,
  delete_top_up_by_id,
  get_top_up_search,
  top_up_search_count,
  top_up_search_by_query_obj,
  top_up_search_by_query_obj_count,
  update_transfer_by_in_top_up,
  update_added_by_in_top_up,
  update_transfer_to_in_top_up,
  delete_top_up_category_in_top_ups,
  get_top_up_by_query_obj,
  find_topup_amount_by_query_obj,
  get_top_up_amount_by_query_obj,
};
