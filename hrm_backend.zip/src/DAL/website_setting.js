const { WebsiteSetting } = require("../../src/models/website_settings");

//adding website settings
const add_website_setting = async (body, user_id) => {
  let website_setting = new WebsiteSetting({
    support_email: body.support_email,
    privacy_policy: body.privacy_policy,
    terms_and_conditions: body.terms_and_conditions,
  });

  website_setting = await website_setting.save();
  return website_setting;
};

// Getting Website Settings
const get_website_setting = async () => {
  const website_setting = WebsiteSetting.findOne();
  return website_setting;
};

const add_website_gernal_setting = async (body) => {
  var website_setting = await WebsiteSetting.findOne();
  if (!website_setting) {
    website_setting = new WebsiteSetting({
      general_settings: body.general_settings,
    });
    website_setting = await website_setting.save();
  } else {
    website_setting.general_settings = body.general_settings;
    website_setting = await website_setting.save();
  }
  return website_setting;
};

const get_website_gernal_setting = async () => {
  const website_setting = await WebsiteSetting.findOne();
  if (!website_setting) return null;
  return website_setting;
};

const add_twilio_setting = async (body) => {
  var website_setting = await WebsiteSetting.findOne();
  if (!website_setting) {
    website_setting = new WebsiteSetting({
      twilio_settings: body,
    });
    website_setting = await website_setting.save();
  } else {
    website_setting.twilio_settings = body;
    website_setting = await website_setting.save();
  }
  return website_setting;
};
module.exports = {
  add_website_setting,
  get_website_setting,
  add_website_gernal_setting,
  get_website_gernal_setting,
  add_twilio_setting,
};
