const { CompanyAsset } = require("../models/company_asset");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;

const add_company_asset = async (company_asset_data) => {
  const new_company_asset = new CompanyAsset(company_asset_data);
  return await new_company_asset.save();
};
const find_company_asset_by_id = async (id) => {
  return await CompanyAsset.findOne({ _id: id });
};

const find_company_asset_by_device_id = async (device_id) => {
  return await CompanyAsset.findOne({ device_id: device_id });
};

const find_company_asset_by_name = async (body) => {
  return await CompanyAsset.findOne({
    $and: [{ title: body.title }, { "company._id": body.company._id }],
  });
};

const total_company_asset = async (id) => {
  return await CompanyAsset.find().count();
};

const latest_company_asset = async (id) => {
  return await CompanyAsset.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_company_asset = async (skip, limit) => {
  return await CompanyAsset.find()
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(skip);
};
const get_all_company_assets = async (id) => {
  return await CompanyAsset.find().sort({ createdAt: -1 });
};

const get_all_free_active_company_assets = async () => {
  return await CompanyAsset.find({
    active_status: true,
    assigned_status: false,
  }).sort({ createdAt: -1 });
};

const get_all_free_active_company_assets_v1 = async () => {
  //select only _id and title with lean ;
  return await CompanyAsset.find(
    { active_status: true, assigned_status: false },
    { _id: 1, title: 1 }
  )
    .sort({ createdAt: -1 })
    .lean();
};

const get_all_free_active_company_assets_count = async () => {
  return await CompanyAsset.find({
    active_status: true,
    assigned_status: false,
  }).countDocuments();
};

const all_company_asset_count = async () => {
  return await CompanyAsset.find().countDocuments();
};

const delete_company_asset_by_id = async (company_asset_id) => {
  return await CompanyAsset.findByIdAndDelete(company_asset_id);
};
const get_company_asset_search = async (query_obj, skip, limit) => {
  return await CompanyAsset.find(query_obj)
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);
};
const get_company_asset_search_v1 = async (query_obj) => {
  return await CompanyAsset.find(query_obj).sort({ createdAt: -1 });
};

const get_company_asset_search_v2 = async (
  query_obj,
  new_date_from,
  new_date_to,
  skip,
  limit
) => {
  if (
    !new_date_from &&
    !new_date_to &&
    new_date_from == "" &&
    new_date_to == ""
  ) {
    console.log("query================1");
    return await CompanyAsset.find(query_obj)
      .select("-details -image -receipt_image -warranty_card_image -link")
      .sort({ createdAt: -1 })
      .skip(parseInt(skip))
      .limit(parseInt(limit));
  } else if (new_date_from && new_date_to) {
    console.log("query================2");

    return await CompanyAsset.aggregate([
      {
        $match: query_obj,
      },
      {
        $addFields: {
          convertedPurchaseDate: {
            $dateFromString: {
              dateString: {
                $dateToString: {
                  format: "%Y-%m-%d",
                  date: {
                    $dateFromString: {
                      dateString: "$purchase_date",
                      format: "%d/%m/%Y",
                    },
                  },
                },
              },
              format: "%Y-%m-%d",
            },
          },
        },
      },

      {
        $match: {
          convertedPurchaseDate: {
            $gte: new Date(new_date_from),
            $lte: new Date(new_date_to),
          },
        },
      },
      {
        $project: {
          details: 0,
          image: 0,
          receipt_image: 0,
          warranty_card_image: 0,
          link: 0,
        },
      },
      {
        $sort: {
          createdAt: -1,
        },
      },
      {
        $skip: parseInt(skip),
      },
      {
        $limit: parseInt(limit),
      },
    ]);
  }
};

const company_asset_search_count_v2 = async (
  query_obj,
  new_date_from,
  new_date_to
) => {
  let count_1, count_2;

  if (
    !new_date_from &&
    !new_date_to &&
    new_date_from == "" &&
    new_date_to == ""
  ) {
    count_1 = await CompanyAsset.find(query_obj).countDocuments();
    console.log("count_1", count_1);
  } else if (new_date_from && new_date_to) {
    const result = await CompanyAsset.aggregate([
      {
        $match: query_obj,
      },
      {
        $addFields: {
          convertedPurchaseDate: {
            $dateFromString: {
              dateString: {
                $dateToString: {
                  format: "%Y-%m-%d",
                  date: {
                    $dateFromString: {
                      dateString: "$purchase_date",
                      format: "%d/%m/%Y",
                    },
                  },
                },
              },
              format: "%Y-%m-%d",
            },
          },
        },
      },
      {
        $match: {
          convertedPurchaseDate: {
            $gte: new Date(new_date_from),
            $lte: new Date(new_date_to),
          },
        },
      },
      {
        $count: "count",
      },
    ]);

    count_2 = result.length ? result[0].count : 0;
  }

  let final_count = count_1 !== undefined ? count_1 : count_2;

  return final_count;
};

const get_amount_of_company_assets = async (
  query_obj,
  new_date_from,
  new_date_to
) => {
  //find total of price of all company assets

  let total_price = 0;
  if (
    !new_date_from &&
    !new_date_to &&
    new_date_from == "" &&
    new_date_to == ""
  ) {
    const result = await CompanyAsset.aggregate([
      {
        $match: query_obj,
      },
      {
        $group: {
          _id: null,
          totalPrice: { $sum: "$price" },
        },
      },
      {
        $project: { _id: 0, totalPrice: 1 },
      },
    ]);

    total_price = result.length ? result[0].totalPrice : 0;
  } else if (new_date_from && new_date_to) {
    const result = await CompanyAsset.aggregate([
      {
        $match: query_obj,
      },
      {
        $addFields: {
          convertedPurchaseDate: {
            $dateFromString: {
              dateString: {
                $dateToString: {
                  format: "%Y-%m-%d",
                  date: {
                    $dateFromString: {
                      dateString: "$purchase_date",
                      format: "%d/%m/%Y",
                    },
                  },
                },
              },
              format: "%Y-%m-%d",
            },
          },
        },
      },
      {
        $match: {
          convertedPurchaseDate: {
            $gte: new Date(new_date_from),
            $lte: new Date(new_date_to),
          },
        },
      },
      {
        $group: {
          _id: null,
          totalPrice: { $sum: "$price" },
        },
      },
      {
        $project: { _id: 0, totalPrice: 1 },
      },
    ]);

    total_price = result.length ? result[0].totalPrice : 0;
  }

  return total_price;
};

const company_asset_search_count = async (query_obj) => {
  return await CompanyAsset.find(query_obj).countDocuments();
};

const company_asset_search_by_query_obj = async (query_obj) => {
  return await CompanyAsset.find(query_obj);
};

const update_company_in_company_assets = async (company_id, company_title) => {
  return await CompanyAsset.updateMany(
    { "company._id": company_id },
    {
      $set: {
        "company.title": company_title,
      },
    }
  );
};

const update_employee_company_assets = async (employee_id, employee_name) => {
  await CompanyAsset.updateMany(
    { "assigned_history.emp_obj_id": employee_id },
    {
      $set: {
        "assigned_history.$.name": employee_name,
      },
    }
  );
};

const unassign_company_assets = async (employee_id) => {
  await CompanyAsset.updateMany(
    { "assigned_employee._id": employee_id },
    {
      $set: {
        "assigned_employee._id": "",
        "assigned_employee.name": "",
      },
    }
  );
};

const update_asset_category_in_company_assets = async (
  category_id,
  category_title
) => {
  await CompanyAsset.updateMany(
    { "asset_category._id": category_id },
    {
      $set: { "asset_category.title": category_title },
    }
  );
};

const update_vendor_in_company_assets = async (vendor_id, vendor_name) => {
  await CompanyAsset.updateMany(
    { "vendor._id": vendor_id },
    {
      $set: { "vendor.name": vendor_name },
    }
  );
};

const update_vendor_in_company_asset_repair_history = async (
  vendor_id,
  vendor_name
) => {
  await CompanyAsset.updateMany(
    { "repair_history.vendor_obj_id": vendor_id },
    {
      $set: { "repair_history.$.vendor_name": vendor_name },
    }
  );
};

const update_brand_in_company_assets = async (brand_id, brand_title) => {
  await CompanyAsset.updateMany(
    { "brand._id": brand_id },
    {
      $set: { "brand.title": brand_title },
    }
  );
};

const assign_company_asset_to_employee = async (
  asset_id,
  assigned_employee_obj
) => {
  await CompanyAsset.updateOne(
    { _id: asset_id },
    {
      $set: { assigned_status: true },
      $push: { assigned_history: assigned_employee_obj },
    }
  );
};

const unassign_company_asset_to_employee = async (
  asset_id,
  assigned_employee_obj
) => {
  await CompanyAsset.updateOne(
    { _id: asset_id, "assigned_history.emp_assigned_status": true },
    {
      $set: {
        assigned_status: false,
        "assigned_history.$.emp_assigned_status": false,
        "assigned_history.$.returned_date": assigned_employee_obj.returned_date,
      },
    }
  );
};

const get_company_assets_for_employee = async (emp_obj_id) => {
  return await CompanyAsset.find({
    "assigned_history.emp_obj_id": emp_obj_id,
    "assigned_history.emp_assigned_status": true,
  });
};

const add_company_asset_repair_history = async (
  asset_id,
  repair_details_obj
) => {
  await CompanyAsset.updateOne(
    { _id: asset_id },
    {
      $push: { repair_history: repair_details_obj },
    }
  );
};

const edit_company_asset_repair_history = async (
  asset_id,
  repair_details_obj
) => {
  await CompanyAsset.updateOne(
    { _id: asset_id, "repair_history._id": repair_details_obj._id },
    {
      $set: {
        "repair_history.$.vendor_obj_id": repair_details_obj.vendor_obj_id,
        "repair_history.$.vendor_name": repair_details_obj.vendor_name,
        "repair_history.$.repair_date": repair_details_obj.repair_date,
        "repair_history.$.service_type": repair_details_obj.service_type,
        "repair_history.$.service_description":
          repair_details_obj.service_description,
        "repair_history.$.service_cost": repair_details_obj.service_cost,
        "repair_history.$.service_duration":
          repair_details_obj.service_duration,
        "repair_history.$.service_receipt_pic":
          repair_details_obj.service_receipt_pic,
      },
    }
  );
};

const find_total_cost_of_company_assets = async () => {
  return await CompanyAsset.aggregate([
    {
      $group: {
        _id: null,
        totalPrice: { $sum: "$price" },
      },
    },
    {
      $project: { _id: 0, totalPrice: 1 },
    },
  ]);
};

const delete_company_asset_repair_history = async (asset_id, history_id) => {
  await CompanyAsset.updateOne(
    {
      _id: new ObjectId(asset_id),
      "repair_history._id": new ObjectId(history_id),
    },
    {
      $pull: {
        repair_history: { _id: new ObjectId(history_id) },
      },
    }
  );
};

module.exports = {
  add_company_asset,
  find_company_asset_by_id,
  find_company_asset_by_device_id,
  total_company_asset,
  latest_company_asset,
  find_company_asset_by_name,
  pagination_company_asset,
  get_all_company_assets,
  get_all_free_active_company_assets,
  get_all_free_active_company_assets_count,
  all_company_asset_count,
  delete_company_asset_by_id,
  get_company_asset_search,
  company_asset_search_count,
  update_company_in_company_assets,
  update_employee_company_assets,
  unassign_company_assets,
  update_asset_category_in_company_assets,
  update_vendor_in_company_assets,
  update_brand_in_company_assets,
  assign_company_asset_to_employee,
  unassign_company_asset_to_employee,
  get_company_assets_for_employee,
  add_company_asset_repair_history,
  edit_company_asset_repair_history,
  update_vendor_in_company_asset_repair_history,
  find_total_cost_of_company_assets,
  company_asset_search_by_query_obj,
  delete_company_asset_repair_history,
  get_all_free_active_company_assets_v1,
  get_company_asset_search_v1,
  get_company_asset_search_v2,
  company_asset_search_count_v2,
  get_amount_of_company_assets,
};

// .populate([
//   { path: "vendor", select: "name" },
//   { path: "brand", select: "title" },
//   { path: "asset_category", select: "title" },
// ]);
