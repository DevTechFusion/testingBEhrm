const { IncrementHistory } = require("../models/increment_history");

const add_increment_history = async (body) => {
  const new_increment_history = new IncrementHistory(body);
  return await new_increment_history.save();
};

const update_increment_history = async (id, body) => {
  return await IncrementHistory.findOneAndUpdate(
    { _id: id },
    { $set: body },
    { new: true }
  );
};

const get_increment_history_by_id = async (id) => {
  return await IncrementHistory.findOne({ _id: id });
};

const list_increment_history = async (query_obj, limit, skip) => {
  return await IncrementHistory.find(query_obj)
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(skip);
};

const delete_increment_history = async (id) => {
  return await IncrementHistory.findOneAndDelete({ _id: id });
};

const update_employee_info_and_action_info_of_increment_history = async (
  id,
  user_id,
  name,
  designation
) => {
  console.log("user_id in DAL", user_id);

  await IncrementHistory.updateMany(
    { "employee_info.employee_id": id },
    {
      $set: {
        "employee_info.full_name": name,
        "employee_info.designation": designation,
      },
    }
  );

  await IncrementHistory.updateMany(
    { "action_info.user_id": user_id },
    {
      $set: {
        "action_info.full_name": name,
        "action_info.designation": designation,
      },
    }
  );
};

module.exports = {
  add_increment_history,
  update_increment_history,
  get_increment_history_by_id,
  list_increment_history,
  delete_increment_history,
  update_employee_info_and_action_info_of_increment_history,
};
