const { Employee } = require("../models/employee");


const find_employee_by_id_for_settings = async (id) => {
  return await Employee.findOne({ _id: id }).populate("user_id", "email").select({
    _id:1,
    first_name:1,
    last_name:1,
    contact_number:1,
    address:1,
    employee_id:1,
    profile_pic:1,
    // previllages:1,
  
  });
};

const find_employee_by_id_for_popup = async (id) => {
  return await Employee.findOne({ _id: id }).populate("user_id", "email").select({
    _id:1,
    profile_pic:1,
    contact_number:1,
    date_of_birth:1,
    date_of_joining:1,
    date_of_confirmation:1,
    date_of_contract:1,
    date_of_increment:1,
    next_date_of_increment:1,
    designation:1,
    bank_account:1,
    basic_salary:1,
   full_name:1,
   company_assets:1,
  
  
  });
};





const get_employee_for_leave_report = async (search,limit,skip) => {
  return await Employee.find({
    active_status: true,
    $or: [
      { full_name: { $regex: new RegExp(search, "i") } },
    ],
  }).select({
    _id: 1,
    full_name: 1,
    allowed_leaves: 1,
  }).sort({ full_name: 1 }).skip(skip).limit(limit);
};

const get_employee_for_leave_report_count = async (search) => {
  return await Employee.find({
    active_status: true,
    $or: [
      { full_name: { $regex: new RegExp(search, "i") } },
    ],
  }).countDocuments();
};

const find_employee_full_name_with_emp_obj_id = async (emp_obj_id) => {
  
  const info =  await Employee.findOne(
    { _id: emp_obj_id ,
      active_status: true
    },
    { _id: 1, full_name: 1 }
  );

  return info ? info : {}
};



module.exports = {

  find_employee_by_id_for_settings,
  find_employee_by_id_for_popup,
  get_employee_for_leave_report,
  get_employee_for_leave_report_count,
  find_employee_full_name_with_emp_obj_id,
};
