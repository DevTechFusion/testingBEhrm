const { EmployeeDeactivation } = require("../models/employee_deactivation");

const add_employee_deactivation = async (employee_data) => {
  const new_employee_deactivation = new EmployeeDeactivation(employee_data);
  return await new_employee_deactivation.save();
};
const find_employee_deactivation_by_id = async (id) => {
  return await EmployeeDeactivation.findOne({ _id: id });
};

const find_employee_deactivation_by_employee_id = async (employee_id) => {
  return await EmployeeDeactivation.findOne({ "employee._id": employee_id });
};

const total_deactivated_employee = async (id) => {
  return await EmployeeDeactivation.find().countDocuments();
};

const latest_deactivated_employee = async (id) => {
  return await EmployeeDeactivation.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_employee_deactivation = async (search, skip, limit) => {
  return await EmployeeDeactivation.find({
    $or: [{ first_name: { $regex: new RegExp(search, "i") } }],
  })
    .sort({ createdAt: -1 })
    .populate("user_id", "email")
    .limit(limit)
    .skip(skip);
};

const employee_search_count = async (search) => {
  return await EmployeeDeactivation.find({
    $or: [{ first_name: { $regex: new RegExp(search, "i") } }],
  }).countDocuments();
};
const delete_employee_deactivation_by_id = async (employee_deactivation_id) => {
  return await EmployeeDeactivation.findByIdAndDelete(employee_deactivation_id);
};

const get_employee_search = async (text, skip, limit) => {
  return await EmployeeDeactivation.find({
    $or: [{ first_name: { $regex: new RegExp(text, "i") } }],
  })
    .skip(skip)
    .limit(limit);
};

const delete_employee_deactivation_by_employee_id = async (employee_id) => {
  return await EmployeeDeactivation.deleteOne({ "employee._id": employee_id });
};

module.exports = {
  add_employee_deactivation,
  find_employee_deactivation_by_id,
  total_deactivated_employee,
  latest_deactivated_employee,
  pagination_employee_deactivation,
  delete_employee_deactivation_by_id,
  get_employee_search,
  employee_search_count,
  find_employee_deactivation_by_employee_id,
  delete_employee_deactivation_by_employee_id,
};
