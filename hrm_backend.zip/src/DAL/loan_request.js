const moment = require("moment");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const { LoanRequest } = require("../models/loan_request");

const add_loan_request = async (loan_request_data) => {
  const new_loan_request = new LoanRequest(loan_request_data);
  return await new_loan_request.save();
};

const find_loan_request_by_id = async (id) => {
  return await LoanRequest.findOne({ _id: id });
};

const find_loan_request_by_id_user = async (id, emp_obj_id) => {
  return await LoanRequest.findOne({ _id: id, emp_obj_id: emp_obj_id });
};

const find_loan_request_by_emp_and_date = async (emp_obj_id, date) => {
  return await LoanRequest.findOne({
    emp_obj_id: emp_obj_id,
    loan_request_date: date,
  });
};

const update_installment_status = async (
  loan_req_id,
  installment_id,
  status,
  payment_date,
  payment_method
) => {
  return await LoanRequest.updateOne(
    { _id: loan_req_id, "installments._id": installment_id },
    {
      $set: {
        "installments.$.status": status,
        "installments.$.payment_date": moment(payment_date, "DD-MM-YYYY")
          .utc(true)
          .format(),
        "installments.$.payment_method": payment_method,
      },
    }
  );
};

const find_loan_requests_for_employee = async (emp_obj_id) => {
  return await LoanRequest.find({ emp_obj_id: emp_obj_id });
};

const total_loan_request = async () => {
  return await LoanRequest.find().count();
};

const latest_loan_request = async () => {
  return await LoanRequest.find().sort({ createdAt: -1 }).limit(5);
};

const pagination_loan_request = async (skip, limit) => {
  return await LoanRequest.find()
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(skip);
};

const all_loan_requests_active = async () => {
  return await LoanRequest.find({ active_status: true }).sort({
    createdAt: -1,
  });
};

const all_loan_requests_active_count = async () => {
  return await LoanRequest.find({ active_status: true }).countDocuments();
};

const delete_loan_request_by_id = async (loan_request_id) => {
  return await LoanRequest.findByIdAndDelete(loan_request_id);
};
const get_loan_request_search = async (query_obj, limit, skip) => {
  return await LoanRequest.find(query_obj)
    .sort({ createdAt: -1 })
    .skip(skip)
    .limit(limit);
};

const loan_request_details = async (loan_req_id) => {
  let id = new ObjectId(loan_req_id);
  return await LoanRequest.aggregate([
    { $match: { _id: id } },
    {
      $project: {
        emp_obj_id: 1,
        emp_name: 1,
        amount: 1,
        description: 1,
        loan_type: 1,
        status: 1,
        payment_method: 1,
        release_date: 1,
        application_date: 1,
        returned_date: 1,
        installments: 1,
        returned_date: 1,
        rejection_reason: 1,
        createdAt: 1,
        updatedAt: 1,
        paid_installments_count: 1,
        pending_installments_count: 1,
        rollout_installments_count: 1,
        pending_amount: 1,
        paid_amount: 1,
        paid_installments: 1,
        no_of_installments: 1,
        installment_start_from: 1,
        pending_installments: {
          $filter: {
            input: "$installments",
            as: "installment",
            cond: { $eq: ["$$installment.status", "pending"] },
          },
        },
        paid_installments: {
          $filter: {
            input: "$installments",
            as: "installment",
            cond: { $eq: ["$$installment.status", "paid"] },
          },
        },
      },
    },
    // {
    //   $addFields: {
    //     pending_installments_count: { $size: "$pending_installments" },
    //     paid_installments_count: { $size: "$paid_installments" },
    //     pending_amount: {
    //       $reduce: {
    //         input: "$pending_installments",
    //         initialValue: 0,
    //         in: {
    //           $add: ["$$value", "$$this.amount"],
    //         },
    //       },
    //     },
    //   },
    // },
    {
      $project: {
        pending_installments: 0,
        paid_installments: 0,
      },
    },
  ]);
};

const loan_request_search_count = async (query_obj) => {
  return await LoanRequest.find(query_obj).countDocuments();
};

const search_loan_requests = async (query_obj, limit, skip) => {
  return await LoanRequest.aggregate([
    { $match: query_obj },
    {
      $project: {
        emp_obj_id: 1,
        emp_name: 1,
        amount: 1,
        description: 1,
        loan_type: 1,
        status: 1,
        payment_method: 1,
        release_date: 1,
        application_date: 1,
        returned_date: 1,
        // installments: 1,
        rejection_reason: 1,
        createdAt: 1,
        updatedAt: 1,
        paid_installments_count: 1,
        pending_installments_count: 1,
        rollout_installments_count: 1,
        pending_amount: 1,
        paid_amount: 1,
        paid_installments: 1,
        no_of_installments: 1,
        installment_start_from: 1,
        // pending_installments: {
        //   $filter: {
        //     input: "$installments",
        //     as: "installment",
        //     cond: { $eq: ["$$installment.status", "pending"] },
        //   },
        // },
        // paid_installments: {
        //   $filter: {
        //     input: "$installments",
        //     as: "installment",
        //     cond: { $eq: ["$$installment.status", "paid"] },
        //   },
        // },
      },
    },
    // {
    //   $project: {
    //     pending_installments: 0,
    //     paid_installments: 0,
    //   },
    // },
    { $sort: { createdAt: -1 } },
    { $skip: skip },
    { $limit: limit },
  ]);
};

const search_loan_requests_admin = async (query_obj, limit, skip) => {
  return await LoanRequest.aggregate([
    { $match: query_obj },
    {
      $project: {
        emp_obj_id: 1,
        emp_name: 1,
        amount: 1,
        description: 1,
        loan_type: 1,
        status: 1,
        payment_method: 1,
        release_date: 1,
        application_date: 1,
        returned_date: 1,
        // installments: 1,
        rejection_reason: 1,
        createdAt: 1,
        updatedAt: 1,
        paid_installments_count: 1,
        pending_installments_count: 1,
        rollout_installments_count: 1,
        pending_amount: 1,
        paid_amount: 1,
        paid_installments: 1,
        no_of_installments: 1,
        installment_start_from: 1,
        pending_installments: {
          $filter: {
            input: "$installments",
            as: "installment",
            cond: { $eq: ["$$installment.status", "pending"] },
          },
        },
        paid_installments: {
          $filter: {
            input: "$installments",
            as: "installment",
            cond: { $eq: ["$$installment.status", "paid"] },
          },
        },
      },
    },
    // {
    //   $addFields: {
    //     pending_installments_count: { $size: "$pending_installments" },
    //     paid_installments_count: { $size: "$paid_installments" },
    //     pending_amount: {
    //       $reduce: {
    //         input: "$pending_installments",
    //         initialValue: 0,
    //         in: {
    //           $add: ["$$value", "$$this.amount"],
    //         },
    //       },
    //     },
    //   },
    // },
    {
      $project: {
        pending_installments: 0,
        paid_installments: 0,
      },
    },
    { $sort: { createdAt: -1 } },
    { $skip: skip },
    { $limit: limit },
  ]);
};

const pending_paid_installment_counts = async (query_obj) => {
  return await LoanRequest.aggregate([
    { $match: query_obj },
    {
      $project: {
        pending_installments: {
          $filter: {
            input: "$installments",
            as: "installment",
            cond: { $eq: ["$$installment.status", "pending"] },
          },
        },
        paid_installments: {
          $filter: {
            input: "$installments",
            as: "installment",
            cond: { $eq: ["$$installment.status", "paid"] },
          },
        },
      },
    },
    {
      $facet: {
        counts: [
          {
            $project: {
              pending_installments_count: { $size: "$pending_installments" },
              paid_installments_count: { $size: "$paid_installments" },
            },
          },
          {
            $group: {
              _id: null,
              total_pending_installments: {
                $sum: "$pending_installments_count",
              },
              total_paid_installments: { $sum: "$paid_installments_count" },
              total_documents: { $sum: 1 },
            },
          },
        ],
      },
    },
    {
      $unwind: "$counts",
    },
    {
      $project: {
        total_pending_installments: "$counts.total_pending_installments",
        total_paid_installments: "$counts.total_paid_installments",
        total_documents: "$counts.total_documents",
      },
    },
  ]);
};

const update_company_in_loan_requests = async (company_id, company_title) => {
  await LoanRequest.updateMany(
    { "company._id": company_id },
    {
      $set: {
        "company.title": company_title,
      },
    }
  );
};

const update_employee_loan_requests = async (employee_id, employee_name) => {
  await LoanRequest.updateMany(
    { emp_obj_id: employee_id },
    {
      $set: {
        emp_name: employee_name,
      },
    }
  );
};

const unassign_loan_requests = async (employee_id) => {
  await LoanRequest.updateMany(
    { "assigned_employee._id": employee_id },
    {
      $set: {
        "assigned_employee._id": "",
        "assigned_employee.name": "",
      },
    }
  );
};

const search_loan_requests_by_query_obj = async (query_obj) => {
  return await LoanRequest.find(query_obj);
};

const get_loan_requests_approved_today_onwards = async (date) => {
  return await LoanRequest.find({
    loan_request_date: { $gte: date },
    status: "approved",
  });
};

//find installment by loan request id and installment id

const find_installment_by_installment_id = async (
  loan_req_id,
  installment_id
) => {
  return await LoanRequest.findOne(
    { _id: loan_req_id },
    {
      installments: {
        $elemMatch: { _id: installment_id },
      },
    },
    {
      _id: 0,
      "installments.$": 1,
    }
  );
};

const find_installment_by_installment_id_and_update = async (
  loan_req_id,
  installment_id,
  date
) => {
  return LoanRequest.updateOne(
    { _id: loan_req_id, "installments._id": installment_id },
    {
      $set: {
        "installments.$.due_date": date,
      },
    }
  );
};

const find_all_loan_requests = async () => {
  return await LoanRequest.find();
};

const get_approved_pending_loan = async (emp_obj_id) => {
  return await LoanRequest.findOne({
    emp_obj_id: emp_obj_id,
    //status : "approved" or "pending"
    status: { $in: ["approved", "pending"] },
  });
};

//get pending installments of loan
const get_pending_installments = async (loan_req_id) => {
  return await LoanRequest.find(
    { _id: loan_req_id },
    {
      installments: {
        $elemMatch: { status: "pending" },
      },
    }
  );
};

//above function is not working

const rollout_installment_status = async (loan_req_id, installment_id) => {
  return await LoanRequest.updateOne(
    { _id: loan_req_id, "installments._id": installment_id },
    {
      $set: {
        "installments.$.status": "rollout",
        "installments.$.rollout_date": moment().format("YYYY-MM-DD"),
      },
      $inc: {
        pending_installments_count: -1,
        rollout_installments_count: 1,
      },
    }
  );
};

const update_installment_objects = async (loan_req_id, amount) => {
  const loanRequest = await LoanRequest.findById(loan_req_id);
  for (const installment of loanRequest.installments) {
    if (installment.status == "pending") {
      installment.amount = amount;
    }
  }

  return await loanRequest.save();
};

const pending_installments_for_admin = async (query_obj, limit, skip, body) => {
  let loan_request = await LoanRequest.aggregate([
    {
      $match: query_obj,
    },
    {
      $addFields: {
        installments: {
          $filter: {
            input: "$installments",
            as: "installment",
            cond: {
              $and: [
                { $eq: ["$$installment.status", "pending"] },
                {
                  $and: [
                    {
                      $gte: [
                        "$$installment.due_date",
                        new Date(body.date_from),
                      ],
                    },
                    {
                      $lte: ["$$installment.due_date", new Date(body.date_to)],
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    },
    {
      $unwind: "$installments",
    },
    {
      $skip: skip,
    },
    {
      $limit: limit,
    },
    {
      $sort: {
        "installments.due_date": -1,
      },
    },
  ]);

  return loan_request;
};

const count_pending_installments = async (query_obj, body) => {
  let pending_installments = await LoanRequest.aggregate([
    {
      $match: query_obj,
    },
    {
      $addFields: {
        installments: {
          $filter: {
            input: "$installments",
            as: "installment",
            cond: {
              $and: [
                { $eq: ["$$installment.status", "pending"] },
                {
                  $and: [
                    {
                      $gte: [
                        "$$installment.due_date",
                        new Date(body.date_from),
                      ],
                    },
                    {
                      $lte: ["$$installment.due_date", new Date(body.date_to)],
                    },
                  ],
                },
              ],
            },
          },
        },
      },
    },
    {
      $unwind: "$installments",
    },
  ]).count("installments");

  return pending_installments;
};

// const update_loan_returned_date = async () => {
//   return await LoanRequest.aggregate([
//     {
//       $match: {
//         installments: {
//           $not: {
//             $elemMatch: {
//               status: "pending"
//             }
//           }
//         }
//       }
//     },
//     {
//       $unwind: "$installments"
//     },
//     {
//       $sort: {
//         "installments.payment_date": -1
//       }
//     },{
//       //group as first loan request
//       $group: {
//         _id: "$_id",
//         installments: {
//           $push: "$installments"
//         }
//       }
//     }

//   ])
// }

const update_loan_returned_date = async () => {
  return await LoanRequest.aggregate([
    {
      $match: {
        installments: {
          $not: {
            $elemMatch: {
              status: "pending",
            },
          },
        },
      },
    },
    {
      $unwind: "$installments",
    },
    {
      $sort: {
        "installments.payment_date": -1,
      },
    },
    {
      $group: {
        _id: "$_id",
        doc: { $first: "$$ROOT" },
        installments: {
          $push: "$installments",
        },
      },
    },
    {
      $addFields: {
        "doc.installments": "$installments",
      },
    },
    {
      $replaceRoot: { newRoot: "$doc" },
    },
  ]);
};

const sum_of_amount_paid_amount_pending_amount = async () => {
  return await LoanRequest.aggregate([
    {
      $project: {
        amount: 1,
        paid_amount: 1,
        pending_amount: 1,
      },
    },
    {
      $group: {
        _id: null,
        total_amount: { $sum: "$amount" },
        total_paid_amount: { $sum: "$paid_amount" },
        total_pending_amount: { $sum: "$pending_amount" },
      },
    },
  ]);
};

module.exports = {
  add_loan_request,
  find_loan_request_by_id,
  total_loan_request,
  latest_loan_request,
  find_loan_request_by_emp_and_date,
  find_loan_requests_for_employee,
  pagination_loan_request,
  all_loan_requests_active,
  all_loan_requests_active_count,
  delete_loan_request_by_id,
  get_loan_request_search,
  loan_request_search_count,
  update_company_in_loan_requests,
  update_employee_loan_requests,
  unassign_loan_requests,
  search_loan_requests_by_query_obj,
  get_loan_requests_approved_today_onwards,
  update_installment_status,
  find_loan_request_by_id_user,
  search_loan_requests,
  search_loan_requests_admin,
  pending_paid_installment_counts,
  loan_request_details,
  find_installment_by_installment_id,
  find_all_loan_requests,
  get_approved_pending_loan,
  get_pending_installments,
  rollout_installment_status,
  update_installment_objects,
  pending_installments_for_admin,
  count_pending_installments,
  update_loan_returned_date,
  find_installment_by_installment_id_and_update,
  sum_of_amount_paid_amount_pending_amount,
};
