const { Attendance } = require("../models/attendance");
const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const moment = require("moment");
const date = new Date();

const get_default_date = async () => {
  let day = date.getDate() - 1;
  let month = date.getMonth() + 1;
  let year = date.getFullYear();
  if (day < 10) {
    day = "0" + day;
  }
  if (month < 10) {
    month = "0" + month;
  }
  // let default_date = day + '/' + month + '/' + year;
  let default_date = `${day}/${month}/${year}`;
  return default_date;
};

const add_attendance = async (attendance_data) => {
  const new_attendance = new Attendance(attendance_data);
  return await new_attendance.save();
};
const find_attendance_by_id = async (id) => {
  return await Attendance.findOne({ _id: id });
};
const find_attendance_by_user_id = async (id) => {
  return await Attendance.findOne({ user_id: id });
};

const find_attendance_by_attendance_id = async (attendance_id) => {
  return await Attendance.findOne({ attendance_id: attendance_id });
};

const total_attendance = async (id) => {
  return await Attendance.find().count();
};

const latest_attendance = async () => {
  return await Attendance.find().limit(1).sort({ createdAt: -1 });
};

const pagination_attendance = async (skip, limit, search, emp_obj_id) => {
  if (!search) {
    search = await get_default_date();
  }
  let query_obj = { "attendance.date": search };
  if (emp_obj_id) {
    query_obj.emp_obj_id = emp_obj_id;
  }
  console.log("query_obj: ", query_obj);
  return await Attendance.find(query_obj, {
    emp_obj_id: 1,
    emp_id: 1,
    emp_name: 1,
    month: 1,
    year: 1,
    total_late_minutes: 1,
    total_absents: 1,
    attendance: { $elemMatch: { date: search } },
  })
    .limit(limit)
    .skip(skip);
};

const pagination_attendance_count = async (search, emp_obj_id) => {
  if (!search) {
    search = await get_default_date();
  }
  if (!search) {
    search = await get_default_date();
  }
  let query_obj = { "attendance.date": search };
  if (emp_obj_id) {
    query_obj.emp_obj_id = emp_obj_id;
  }
  // console.log("query_obj: ", query_obj);

  return await Attendance.find(query_obj).countDocuments();
};

const all_attendance_count = async () => {
  return await Attendance.find().countDocuments();
};

const delete_attendance_by_id = async (attendance_id) => {
  return await Attendance.findByIdAndDelete(attendance_id);
};
const get_attendance_search = async (skip, limit, search) => {
  if (!search) {
    search = await get_default_date();
  }
  return await Attendance.find(
    { "attendance.date": search },
    {
      emp_obj_id: 1,
      emp_id: 1,
      emp_name: 1,
      month: 1,
      year: 1,
      total_late_minutes: 1,
      total_absents: 1,
      attendance: { $elemMatch: { date: search } },
    }
  )
    .limit(limit)
    .skip(skip);
};

const attendance_search_count = async (search) => {
  if (!search) {
    search = await get_default_date();
  }
  return await Attendance.find({ "attendance.date": search }).countDocuments();
};

const mark_attendance_inactive = async (attendance_id) => {
  await Attendance.updateOne(
    { _id: attendance_id },
    {
      $set: { active_status: false },
    }
  );
};

const update_employee_in_attendance = async (
  employee_id,
  employee_name,
  emp_id
) => {
  await Attendance.updateMany(
    { emp_obj_id: employee_id },
    {
      $set: {
        emp_name: employee_name,
        emp_id: emp_id,
      },
    }
  );
};

const add_employee_to_attendance = async (emp_obj_id, emp_name, emp_id) => {
  let session = new Attendance({
    emp_obj_id: emp_obj_id,
    emp_name: emp_name,
    emp_id: emp_id,
    month: date.getMonth() + 1,
    year: date.getFullYear(),
    attendance: [],
  });

  session = await session.save();
  return session;
};

const pay_fine_on_payroll = async (emp_obj_id, month, year) => {
  await Attendance.updateOne(
    { emp_obj_id, month, year },
    { $set: { paid_status: true } }
  );
};

const delete_employee_attendance = async (emp_obj_id) => {
  return await Attendance.deleteMany({ emp_obj_id: emp_obj_id });
};

const update_employee_attendance = async (emp_id, attendance_obj) => {
  return await Attendance.updateOne(
    { emp_id: emp_id },
    { $push: { attendance: attendance_obj } }
  );
};

const find_attendance_by_emp_id = async (emp_id) => {
  return await Attendance.findOne({ emp_id: emp_id });
};

const find_attendance_by_emp_id_month_year = async (emp_id, month, year) => {
  return await Attendance.findOne({ emp_id, month, year });
};

const find_attendance_by_emp_obj_id_month_year = async (
  emp_obj_id,
  month,
  year
) => {
  return await Attendance.findOne({ emp_obj_id, month, year });
};

const get_unpaid_fines = async (emp_obj_id) => {
  return await Attendance.find(
    { emp_obj_id, paid_status: false },
    { _id: 0, attendance: 0 }
  );
};

const get_attendance_by_date = async (emp_id, month, year, search_date) => {
  return await Attendance.findOne({
    emp_id: emp_id,
    month: month,
    year: year,
    "attendance.date": search_date,
  });
};

const get_all_attendance_docs_ids_by_date = async (month, year, date) => {
  return await Attendance.find(
    { month: month, year: year, "attendance.date": date },
    { _id: 1 }
  );
};

const check_discount_minutes_status = async (emp_id, month, year) => {
  return await Attendance.findOne({
    emp_id: emp_id,
    month: month,
    year: year,
    "attendance.discounted_minutes": true,
  });
};

const attendance_for_employee_user_monthly_yearly = async (
  emp_obj_id,
  month,
  year
) => {
  return await Attendance.findOne({
    emp_obj_id: emp_obj_id,
    month: month,
    year: year,
  });
};

const attendance_for_employee_user_monthly_yearly_count = async (
  emp_obj_id,
  month,
  year
) => {
  return await Attendance.find({
    emp_obj_id: emp_obj_id,
    month: month,
    year: year,
  }).countDocuments();
};

const attendance_for_employee_user_by_date = async (
  emp_obj_id,
  month,
  year,
  search_date
) => {
  return await Attendance.findOne(
    {
      emp_obj_id: emp_obj_id,
      month: month,
      year: year,
      "attendance.date": search_date,
    },
    {
      emp_obj_id: 1,
      emp_id: 1,
      emp_name: 1,
      month: 1,
      year: 1,
      total_late_minutes: 1,
      total_absents: 1,
      attendance: { $elemMatch: { date: search_date } },
    }
  );
};

const get_employee_attendance_by_query_obj = async (query_obj, skip, limit) => {
  return await Attendance.find(query_obj);
};

const get_employee_attendance_by_query_obj_v1 = async (
  query_obj,
  date_from,
  date_to
) => {
  return await Attendance.aggregate([
    {
      $match: query_obj,
    },
    {
      $addFields: {
        compound_date: {
          $dateFromParts: {
            year: "$year",
            month: "$month",
            day: 1,
          },
        },
      },
    },
    {
      $match: {
        compound_date: { $gte: date_from, $lt: date_to },
      },
    },
  ]);
};

const attendance_for_fine = async (month, year) => {
  return await Attendance.find(
    { month, year },
    {
      total_late_minutes: 1,
      emp_id: 1,
      emp_name: 1,
      attendance: { $elemMatch: { discounted_minutes: true } },
    }
  );
};

const get_finesheet = async (query_obj, skip, limit) => {
  return await Attendance.find(query_obj, { _id: 0, attendance: 0 })
    .sort({ emp_id: 1 })
    .limit(limit)
    .skip(skip);
};

const get_finesheet_count = async (query_obj) => {
  return await Attendance.find(query_obj).countDocuments();
};

const get_fine_query_obj = async (query_obj) => {
  return await Attendance.find(query_obj, { attendance: 0 });
};

const get_fine_query_obj_count = async (query_obj) => {
  return await Attendance.find(query_obj).countDocuments();
};

const update_fines = async () => {
  console.log("Updating");
  let today = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY").utc(true);
  let late_fine = 0;
  let unpaid_fines = await Attendance.find({ paid_status: false });
  if (unpaid_fines.length > 0) {
    for (let x = 0; x < unpaid_fines.length; x++) {
      let total_fine = unpaid_fines[x].fine;
      let day_diff = today.startOf("day").diff(unpaid_fines[x].deadline, "day");
      if (day_diff > 0) {
        late_fine = Math.round(total_fine * 0.1 * day_diff);
      }
      await Attendance.updateOne(
        { _id: unpaid_fines[x]._id },
        { $set: { late_fine: late_fine } }
      );
      console.log("Updated in database");
    }
  }
};

const get_employee_absents = async (query_obj, skip, limit) => {
  let emp_obj_id = new ObjectId(query_obj.emp_obj_id);
  query_obj.emp_obj_id = emp_obj_id;
  return await Attendance.aggregate([
    {
      $match: query_obj,
    },
    {
      $match: {
        $or: [
          { "attendance.absent": true },
          { "attendance.half_leave_type": { $in: [1, 2] } },
        ],
      },
    },
    {
      $project: {
        attendance: {
          $filter: {
            input: "$attendance",
            as: "attendanceItem",
            cond: {
              $or: [
                { $eq: ["$$attendanceItem.absent", true] },
                { $in: ["$$attendanceItem.half_leave_type", [1, 2]] },
              ],
            },
          },
        },
      },
    },
    { $unwind: "$attendance" },
    {
      $addFields: {
        "attendance.dateObj": {
          $dateFromString: {
            dateString: "$attendance.date",
            format: "%d/%m/%Y",
          },
        },
      },
    },
    {
      $sort: { "attendance.dateObj": -1 },
    },
    { $project: { "attendance.dateObj": 0 } },
    {
      $replaceRoot: {
        newRoot: "$attendance",
      },
    },
    { $skip: skip },
    { $limit: limit },
  ]);
};

const get_employee_absents_count = async (query_obj) => {
  let emp_obj_id = new ObjectId(query_obj.emp_obj_id);
  query_obj.emp_obj_id = emp_obj_id;
  return await Attendance.aggregate([
    {
      $match: query_obj,
    },
    {
      $match: {
        $or: [
          { "attendance.absent": true },
          { "attendance.half_leave_type": { $in: [1, 2] } },
        ],
      },
    },
    {
      $project: {
        attendance: {
          $filter: {
            input: "$attendance",
            as: "attendanceItem",
            cond: {
              $or: [
                { $eq: ["$$attendanceItem.absent", true] },
                { $in: ["$$attendanceItem.half_leave_type", [1, 2]] },
              ],
            },
          },
        },
      },
    },
    { $unwind: "$attendance" },
    {
      $addFields: {
        "attendance.dateObj": {
          $dateFromString: {
            dateString: "$attendance.date",
            format: "%d/%m/%Y",
          },
        },
      },
    },
    {
      $sort: { "attendance.dateObj": -1 },
    },
    { $project: { "attendance.dateObj": 0 } },
    {
      $replaceRoot: {
        newRoot: "$attendance",
      },
    },
    {
      $count: "count",
    },
  ]);
};

// const getEmployeeAttendanceByDateRange = async (emp_obj_id, date_from, date_to , status) => {

//   if(!status){
//     status = [true, false]
//   } else {
//     status = [status]
//   }

//   return await Attendance.aggregate([
//     {
//       $match: { emp_obj_id: mongoose.Types.ObjectId(emp_obj_id) }
//     },
//     {
//       $unwind: "$attendance"
//     },
//     {
//       $addFields: {
//         "attendance.dateObj": {
//           $dateFromString: {
//             dateString: "$attendance.date",
//             format: "%d/%m/%Y"
//           }
//         }
//       }
//     },
//     {
//       $match: {
//         "attendance.dateObj": {
//           $gte: new Date(date_from),
//           $lt: new Date(date_to)
//         },

//         // if status is given then add this condition

//          "attendance.absent": {
//           $in : status
//          }

//       }
//     },
//     {
//       $group: {
//         _id: "$_id",
//         attendance: { $push: "" },
//       }
//     } ,{
//       $project: {
//         attendance: 1
//       }
//     } ,{
//       $unwind: "$attendance"
//     } ,{
//       $sort: { "attendance.dateObj": -1 }
//     }
//   ]);
// };

const getEmployeeAttendanceByDateRange = async (
  emp_obj_id,
  date_from,
  date_to,
  status,
  skip,
  limit
) => {
  if (status === undefined) {
    status = [true, false];
  } else {
    status = [status];
  }

  return await Attendance.aggregate([
    {
      $match: { emp_obj_id: mongoose.Types.ObjectId(emp_obj_id) },
    },
    {
      $unwind: "$attendance",
    },
    {
      $addFields: {
        "attendance.dateObj": {
          $dateFromString: {
            dateString: "$attendance.date",
            format: "%d/%m/%Y",
          },
        },
      },
    },
    {
      $match: {
        "attendance.dateObj": {
          $gte: new Date(date_from),
          $lt: new Date(date_to),
        },
        "attendance.absent": {
          $in: status,
        },
      },
    },
    {
      $group: {
        _id: "$_id",
        attendance: { $push: "$attendance" },
      },
    },
    {
      $unwind: "$attendance",
    },
    {
      $replaceRoot: { newRoot: "$attendance" },
    },
    {
      $sort: { dateObj: -1 },
    },
    {
      $skip: skip,
    },
    {
      $limit: limit,
    },
  ]);
};

const getEmployeeAttendanceByDateRangeCount = async (
  emp_obj_id,
  date_from,
  date_to,
  status
) => {
  if (status === undefined) {
    status = [true, false];
  } else {
    status = [status];
  }

  let count = await Attendance.aggregate([
    {
      $match: { emp_obj_id: mongoose.Types.ObjectId(emp_obj_id) },
    },
    {
      $unwind: "$attendance",
    },
    {
      $addFields: {
        "attendance.dateObj": {
          $dateFromString: {
            dateString: "$attendance.date",
            format: "%d/%m/%Y",
          },
        },
      },
    },
    {
      $match: {
        "attendance.dateObj": {
          $gte: new Date(date_from),
          $lt: new Date(date_to),
        },
        "attendance.absent": {
          $in: status,
        },
      },
    },
    {
      $group: {
        _id: "$_id",
        attendance: { $push: "$attendance" },
      },
    },
    {
      $unwind: "$attendance",
    },
    {
      $replaceRoot: { newRoot: "$attendance" },
    },
    {
      $count: "count",
    },
  ]);

  let countValue = 0;
  if (count.length > 0) {
    countValue = count[0].count;
  }

  return countValue;
};

const get_employee_leaves = async (
  emp_obj_id,
  date_from,
  date_to,
  status,
  skip,
  limit
) => {
  return await Attendance.aggregate([
    {
      $match: { emp_obj_id: mongoose.Types.ObjectId(emp_obj_id) },
    },
    {
      $unwind: "$attendance",
    },
    {
      $addFields: {
        "attendance.dateObj": {
          $dateFromString: {
            dateString: "$attendance.date",
            format: "%d/%m/%Y",
          },
        },
      },
    },
    {
      $match: {
        "attendance.dateObj": {
          $gte: new Date(date_from),
          $lt: new Date(date_to),
        },
        $or: [
          { "attendance.absent": status },
          {
            "attendance.half_leave_type": {
              $in: [1, 2],
            },
          },
        ],
      },
    },
    {
      $group: {
        _id: "$_id",
        attendance: { $push: "$attendance" },
      },
    },
    {
      $unwind: "$attendance",
    },
    {
      $replaceRoot: { newRoot: "$attendance" },
    },
    {
      $sort: { dateObj: -1 },
    },
    {
      $skip: skip,
    },
    {
      $limit: limit,
    },
  ]);
};

const get_employee_leaves_count = async (
  emp_obj_id,
  date_from,
  date_to,
  status
) => {
  let leave_count = await Attendance.aggregate([
    {
      $match: { emp_obj_id: mongoose.Types.ObjectId(emp_obj_id) },
    },
    {
      $unwind: "$attendance",
    },
    {
      $addFields: {
        "attendance.dateObj": {
          $dateFromString: {
            dateString: "$attendance.date",
            format: "%d/%m/%Y",
          },
        },
      },
    },
    {
      $match: {
        "attendance.dateObj": {
          $gte: new Date(date_from),
          $lt: new Date(date_to),
        },
        $or: [
          { "attendance.absent": status },
          {
            "attendance.half_leave_type": {
              $in: [1, 2],
            },
          },
        ],
      },
    },
    {
      $group: {
        _id: "$_id",
        attendance: { $push: "$attendance" },
      },
    },
    {
      $unwind: "$attendance",
    },
    {
      $replaceRoot: { newRoot: "$attendance" },
    },
    {
      $count: "count",
    },
  ]);

  if (leave_count.length > 0) {
    return leave_count[0].count;
  } else {
    return 0;
  }
};

const get_employee_leaves_for_dashboard_count = async (
  emp_obj_id,
  date_from,
  date_to
) => {
  return await Attendance.aggregate([
    {
      $match: { emp_obj_id: mongoose.Types.ObjectId(emp_obj_id) },
    },
    {
      $unwind: "$attendance",
    },
    {
      $addFields: {
        "attendance.dateObj": {
          $dateFromString: {
            dateString: "$attendance.date",
            format: "%d/%m/%Y",
          },
        },
      },
    },
    {
      $match: {
        "attendance.dateObj": {
          $gte: new Date(date_from),
          $lt: new Date(date_to),
        },
        $or: [
          { "attendance.absent": true },
          {
            "attendance.half_leave_type": {
              $in: [1, 2],
            },
          },
        ],
      },
    },
    {
      $group: {
        _id: "$_id",
        attendance: { $push: "$attendance" },
      },
    },
    {
      $unwind: "$attendance",
    },
    {
      $replaceRoot: { newRoot: "$attendance" },
    },
    {
      $sort: { dateObj: -1 },
    },
  ]);
};

const find_attendance_for_payroll = async (emp_id, month, year) => {
  return await Attendance.findOne({
    emp_id: emp_id,
    month: month,
    year: year,
  });
};

const get_attendance_v1 = async (query, from_date, to_date, skip, limit) => {
  const fromDate = moment(from_date, "YYYY-MM-DD").startOf("day").toDate();
  const toDate = moment(to_date, "YYYY-MM-DD").endOf("day").toDate();

  const result = await Attendance.aggregate([
    {
      $match: query,
    },
    {
      $unwind: "$attendance",
    },
    {
      $addFields: {
        "attendance.dateObj": {
          $dateFromString: {
            dateString: "$attendance.date",
            format: "%d/%m/%Y",
          },
        },
      },
    },
    {
      $match: {
        "attendance.dateObj": {
          $gte: fromDate,
          $lt: toDate,
        },
      },
    },
    {
      $addFields: {
        "attendance.leave_type": {
          $cond: {
            if: { $eq: ["$attendance.absent", true] },
            then: "Absent",
            else: {
              $cond: {
                if: { $eq: ["$attendance.half_leave_type", 1] },
                then: "First Half",
                else: {
                  $cond: {
                    if: { $eq: ["$attendance.half_leave_type", 2] },
                    then: "Second Half",
                    else: "Present",
                  },
                },
              },
            },
          },
        },
      },
    },
    {
      $project: {
        _id: 1,
        emp_obj_id: 1,
        emp_name: 1,
        emp_id: 1,
        month: 1,
        year: 1,
        total_late_minutes: 1,
        total_absents: 1,
        late: "$attendance.late",
        early: "$attendance.early",
        discounted_minutes: "$attendance.discounted_minutes",
        half_leave_type: "$attendance.half_leave_type",
        attendance_id: "$attendance._id",
        date: "$attendance.date",
        check_in: "$attendance.check_in",
        check_out: "$attendance.check_out",
        relax_time: "$attendance.relax_time",
        absent: "$attendance.absent",
        leave_type: "$attendance.leave_type",
        dateObj: "$attendance.dateObj",
      },
    },
    {
      $sort: { dateObj: -1 },
    },
    {
      $skip: skip,
    },
    {
      $limit: limit,
    },
  ]);

  return result;
};

const count_get_attendance_v1 = async (query, from_date, to_date) => {
  // Ensure from_date and to_date are in the correct format
  const fromDate = new Date(from_date);
  const toDate = new Date(to_date);

  const result = await Attendance.aggregate([
    {
      $match: query,
    },
    {
      $unwind: "$attendance",
    },
    {
      $addFields: {
        "attendance.dateObj": {
          $dateFromString: {
            dateString: "$attendance.date",
            format: "%d/%m/%Y",
          },
        },
      },
    },
    {
      $match: {
        "attendance.dateObj": {
          $gte: fromDate,
          $lt: toDate,
        },
      },
    },
    {
      $count: "count",
    },
  ]);

  if (result.length > 0) {
    return result[0].count;
  } else {
    return 0;
  }
};

const find_attendance_by_id_specific_day = async (id) => {
  const attendance = await Attendance.aggregate([
    {
      $match: {
        "attendance._id": ObjectId(id),
      },
    },
    {
      $unwind: "$attendance",
    },
    {
      $match: {
        "attendance._id": ObjectId(id),
      },
    },
    {
      $project: {
        emp_obj_id: 1,
        emp_name: 1,
        emp_id: 1,
        month: 1,
        year: 1,
        total_late_minutes: 1,
        total_absents: 1,
        late: "$attendance.late",
        early: "$attendance.early",
        discounted_minutes: "$attendance.discounted_minutes",
        half_leave_type: "$attendance.half_leave_type",
        date: "$attendance.date",
        check_in: "$attendance.check_in",
        check_out: "$attendance.check_out",
        relax_time: "$attendance.relax_time",
        absent: "$attendance.absent",
        leave_type: "$attendance.leave_type",
      },
    },
  ]);

  return attendance.length > 0 ? attendance[0] : null;
};

module.exports = {
  add_attendance,
  find_attendance_by_id,
  total_attendance,
  latest_attendance,
  find_attendance_by_user_id,
  pagination_attendance,
  pagination_attendance_count,
  all_attendance_count,
  delete_attendance_by_id,
  get_attendance_search,
  attendance_search_count,
  find_attendance_by_attendance_id,
  mark_attendance_inactive,
  update_employee_in_attendance,
  add_employee_to_attendance,
  delete_employee_attendance,
  find_attendance_by_emp_id,
  pay_fine_on_payroll,
  update_employee_attendance,
  find_attendance_by_emp_id_month_year,
  find_attendance_by_emp_obj_id_month_year,
  get_attendance_by_date,
  get_all_attendance_docs_ids_by_date,
  check_discount_minutes_status,
  attendance_for_employee_user_monthly_yearly,
  attendance_for_employee_user_monthly_yearly_count,
  attendance_for_employee_user_by_date,
  get_employee_attendance_by_query_obj,
  attendance_for_fine,
  get_fine_query_obj,
  get_fine_query_obj_count,
  get_finesheet,
  get_finesheet_count,
  get_unpaid_fines,
  update_fines,
  get_employee_absents,
  get_employee_absents_count,
  get_employee_attendance_by_query_obj_v1,
  getEmployeeAttendanceByDateRange,
  getEmployeeAttendanceByDateRangeCount,
  get_employee_leaves,
  get_employee_leaves_count,
  get_employee_leaves_for_dashboard_count,
  find_attendance_for_payroll,
  get_attendance_v1,
  count_get_attendance_v1,
  find_attendance_by_id_specific_day,
};
