const { Allowances } = require("../models/allowances");

const add_allowance = async (body) => {
  const new_allowance = new Allowances(body);
  return await new_allowance.save();
};

const update_allowance = async (id, body) => {
  return await Allowances.findOneAndUpdate(
    { _id: id },
    { $set: body },
    { new: true }
  );
};

const get_allowance_by_id = async (id) => {
  return await Allowances.findOne({ _id: id });
};

const list_allowances = async (query_obj) => {
  return await Allowances.find(query_obj).sort({ createdAt: -1 });
};

const delete_allowance = async (id) => {
  return await Allowances.findOneAndDelete({ _id: id });
};

const get_general_allowance = async () => {
  return await Allowances.find({
    allowance_type: "general",
    status: true,
  }).sort({ createdAt: -1 });
};

const get_other_allowance = async () => {
  return await Allowances.find({ allowance_type: "other", status: true }).sort({
    createdAt: -1,
  });
};

module.exports = {
  add_allowance,
  update_allowance,
  get_allowance_by_id,
  list_allowances,
  delete_allowance,
  get_general_allowance,
  get_other_allowance,
};
