const { TaxSlabs } = require("../models/tax_slabs");

const add_tax_slabs = async (body) => {
  const new_tax_slab = new TaxSlabs(body);
  return await new_tax_slab.save();
};

const update_tax_slabs = async (id, body) => {
  return await TaxSlabs.findOneAndUpdate(
    { _id: id },
    { $set: body },
    { new: true }
  );
};

const get_tax_slabs_by_id = async (id) => {
  return await TaxSlabs.findOne({ _id: id });
};

const list_tax_slabs = async () => {
  return await TaxSlabs.find({}).sort({ createdAt: -1 });
};

const delete_tax_slabs = async (id) => {
  return await TaxSlabs.findOneAndDelete({ _id: id });
};

module.exports = {
  add_tax_slabs,
  update_tax_slabs,
  get_tax_slabs_by_id,
  list_tax_slabs,
  delete_tax_slabs,
};
