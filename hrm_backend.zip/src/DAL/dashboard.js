const { Attendance } = require("../models/attendance");

const moment = require("moment");

const get_data_monthly_for_user = async (emp_obj_id, month, year) => {
  return await Attendance.findOne({
    emp_obj_id: emp_obj_id,
    month: month,
    year: year,
  });
};

const get_monthly_late_mins_and_absents_for_user = async (
  emp_obj_id,
  month,
  year
) => {
  return await Attendance.findOne(
    {
      emp_obj_id: emp_obj_id,
      month: month,
      year: year,
    },
    { _id: 0, total_late_minutes: 1, total_absents: 1 }
  );
};

const get_absent_count_yearly = async (query_obj) => {
  let total_absent_yearly = 0;

  function getFiscalYear() {
    const currentDate = moment();
    let fiscalYearStart, fiscalYearEnd;

    if (currentDate.month() >= 6) {
      // If the current month is July or later
      fiscalYearStart = moment({
        year: currentDate.year(),
        month: 6,
        day: 1,
      }).format("YYYY-MM-DD");
      fiscalYearEnd = moment({
        year: currentDate.year() + 1,
        month: 5,
        day: 30,
      }).format("YYYY-MM-DD");
    } else {
      // If the current month is June or earlier
      fiscalYearStart = moment({
        year: currentDate.year() - 1,
        month: 6,
        day: 1,
      }).format("YYYY-MM-DD");
      fiscalYearEnd = moment({
        year: currentDate.year(),
        month: 5,
        day: 30,
      }).format("YYYY-MM-DD");
    }

    return { fiscalYearStart, fiscalYearEnd };
  }

  const { fiscalYearStart, fiscalYearEnd } = getFiscalYear();

  const absents_data_yearly = await Attendance.aggregate([
    { $match: query_obj },
    {
      $project: {
        month: 1,
        year: 1,
        total_absents: 1,
        academicYear: {
          $cond: [{ $lt: ["$month", 7] }, "$year", { $subtract: ["$year", 1] }],
        },
      },
    },
    {
      $match: { academicYear: { $gte: fiscalYearStart, $lte: fiscalYearEnd } },
    },
    { $group: { _id: null, total_absent_yearly: { $sum: "$total_absents" } } },
  ]);

  return absents_data_yearly[0]?.total_absent_yearly || 0;

  // let total_absent_yearly = 0;
  // const date = new Date();
  // let month = date.getMonth() + 1;
  // let year = date.getFullYear();
  // let year_from = year;
  // let year_to = year;
  // let absents_query_obj = query_obj;

  // if (month < 7) {
  //   year_from -= 1;
  //   absents_query_obj.year = {
  //     $gte: year_from,
  //     $lte: year_to,
  //   };
  // } else {
  //   year_to += 1;
  //   absents_query_obj.year = {
  //     $gte: year_from,
  //     $lte: year_to,
  //   };
  // }
  // const absents_data_yearly = await Attendance.find(absents_query_obj, {
  //   _id: 0,
  //   month: 1,
  //   year: 1,
  //   total_absents: 1,
  // });

  // for (let index = 0; index < absents_data_yearly.length; index++) {
  //   const monthly_data = absents_data_yearly[index];
  //   if (
  //     (monthly_data.month < 7 && monthly_data.year == year) ||
  //     (monthly_data.month >= 7 && monthly_data.year == year - 1)
  //   ) {
  //     total_absent_yearly += monthly_data.total_absents;
  //   } else if (monthly_data.month >= 7 && monthly_data.year == year) {
  //     total_absent_yearly += monthly_data.total_absents;
  //   }
  // }
  // return total_absent_yearly;

  // const absents_data_yearly = await Attendance.aggregate([
  //   { $match: absents_query_obj },
  //   {
  //     $project: {
  //       month: 1,
  //       year: 1,
  //       total_absents: 1,
  //       academicYear: {
  //         $cond: [
  //           { $lt: ["$month", 7] },
  //           "$year",
  //           { $subtract: ["$year", 1] }
  //         ]
  //       }
  //     }
  //   },
  //   { $match: { academicYear: year } },
  //   { $group: { _id: null, total_absent_yearly: { $sum: "$total_absents" } } }
  // ]);

  // return absents_data_yearly[0]?.total_absent_yearly || 0;
};

const get_attendance_by_date_month_year_for_user = async (
  emp_obj_id,
  month,
  year,
  date
) => {
  return await Attendance.findOne(
    {
      emp_obj_id: emp_obj_id,
      month: month,
      year: year,
      "attendance.date": date,
    },
    { _id: 0, attendance: { $elemMatch: { date: date } } }
  );
};

const get_attendance_by_date_for_user = async (emp_obj_id, date) => {
  return await Attendance.findOne(
    {
      emp_obj_id: emp_obj_id,
      "attendance.date": date,
    },
    { _id: 0, attendance: { $elemMatch: { date: date } } }
  );
};

module.exports = {
  get_data_monthly_for_user,
  get_monthly_late_mins_and_absents_for_user,
  get_absent_count_yearly,
  get_attendance_by_date_for_user,
  get_attendance_by_date_month_year_for_user,
};
