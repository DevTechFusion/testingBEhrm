const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const employeeDeactivationSchema = new mongoose.Schema({
  employee: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
    name: { type: String },
  },
  leaving_type: { type: String },
  last_working_day: { type: String },
  leaving_reason: { type: String },
  leaving_reason_detail: { type: String },
  hr_comments: { type: String },
  clearance_status: { type: Boolean, default: true },
});

employeeDeactivationSchema.plugin(timestamps);

employeeDeactivationSchema.methods.toJSON = function () {
  const employeeDeactivation = this;
  const employeeDeactivationObject = employeeDeactivation.toObject();
  const employeeDeactivationJson = _.pick(employeeDeactivationObject, [
    "_id",
    "employee",
    "leaving_type",
    "last_working_day",
    "leaving_reason",
    "leaving_reason_detail",
    "hr_comments",
    "clearance_status",
    "createdAt",
    "updatedAt",
  ]);
  return employeeDeactivationJson;
};

const EmployeeDeactivation = mongoose.model(
  "employeeDeactivation",
  employeeDeactivationSchema
);
exports.EmployeeDeactivation = EmployeeDeactivation;
