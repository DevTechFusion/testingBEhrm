const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const apiLogSchema = new mongoose.Schema({
  request_time: {
    type: Date,
    default: Date.now,
    index: true,
  },
  response_time: {
    type: Date,
    default: Date.now,
    index: true,
  },
  request_method: {
    type: String,
    required: true,
  },
  request_path: {
    type: String,
    index: true,
  },
  request_body: {},
  request_headers: {},
  response_status: {},
  request_query: {},
  request_params: {},
  client_ip: {
    type: String,
    default: "",
  },
  client_agent: {
    type: String,
    default: "",
  },
  response_body: {},
});

apiLogSchema.plugin(timestamps);
apiLogSchema.index({ request_time: 1, path: 1 });

const APILog = mongoose.model("APILog", apiLogSchema);

module.exports = { APILog };
