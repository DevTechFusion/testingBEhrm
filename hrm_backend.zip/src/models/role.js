const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const roleSchema = new mongoose.Schema({
  title: { type: String },
  order: { type: Number },
  active_status: { type: Boolean, default: true },
  is_default: { type: Boolean, default: false },
});

roleSchema.plugin(timestamps);

roleSchema.methods.toJSON = function () {
  const role = this;
  const roleObject = role.toObject();
  const roleJson = _.pick(roleObject, [
    "_id",
    "title",
    "order",
    "active_status",
    "is_default",
    "createdAt",
    "updatedAt",
  ]);
  return roleJson;
};

const Role = mongoose.model("role", roleSchema);
exports.Role = Role;
