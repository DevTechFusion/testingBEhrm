const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const expenseCategorySchema = new mongoose.Schema({
  title: { type: String },
  description: { type: String },
  active_status: { type: Boolean, default: true },
});

expenseCategorySchema.plugin(timestamps);

expenseCategorySchema.methods.toJSON = function () {
  const expenseCategory = this;
  const expenseCategoryObject = expenseCategory.toObject();
  const expenseCategoryJson = _.pick(expenseCategoryObject, [
    "_id",
    "title",
    "description",
    "active_status",
    "createdAt",
    "updatedAt",
  ]);
  return expenseCategoryJson;
};

const ExpenseCategory = mongoose.model(
  "expenseCategory",
  expenseCategorySchema
);
exports.ExpenseCategory = ExpenseCategory;
