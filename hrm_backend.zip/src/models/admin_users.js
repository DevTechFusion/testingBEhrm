const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const adminUserSchema = new mongoose.Schema({
  user_id: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  full_name: { type: String },
  address: { type: String },
  profile_image: { type: String },
  contact_number: { type: String, default: "" },
});

adminUserSchema.plugin(timestamps);

adminUserSchema.methods.toJSON = function () {
  const adminUser = this;
  const adminUserObject = adminUser.toObject();
  const adminUserJson = _.pick(adminUserObject, [
    "_id",
    "user_id",
    "full_name",
    "address",
    "profile_image",
    "contact_number",
    "createdAt",
    "updatedAt",
  ]);
  return adminUserJson;
};

const adminUser = mongoose.model("adminUser", adminUserSchema);
exports.AdminUser = adminUser;
