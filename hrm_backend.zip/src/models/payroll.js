const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");
const moment = require("moment");
const { type } = require("joi/lib/types/object");

const payrollSchema = new mongoose.Schema({
  emp_obj_id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
  emp_name: { type: String, default: "" },
  month: { type: Number, default: moment().month() + 1 },
  year: { type: Number, default: moment().year() },
  basic_salary: { type: Number, default: 0 },
  conveyance_allowance: { type: Number, default: 0 },
  // education_allowance: { type: Number, default: 0 },
  medical_allowance: { type: Number, default: 0 },
  rent_allowance: { type: Number, default: 0 },
  food_allowance: { type: Number, default: 0 },
  other_payment: { type: Number, default: 0 },
  other_payment_label: { type: String, default: "" },
  commission: { type: Number, default: 0 },
  overtime: { type: Number, default: 0 },
  loan: { type: Number, default: 0 },
  monthly_tax: { type: Number, default: 0 },
  tax_file: { type: String, default: "" },
  net_salary: { type: Number, default: 0 },
  date: {
    type: Date,
    default: moment(moment().format("YYYY-MM-DD"), "YYYY-MM-DD").utc(true),
  },
  loan_deduction: { type: Number, default: 0 },
  lunch_deduction: { type: Number, default: 0 },
  fine_deduction: { type: Number, default: 0 },
  other_deduction: { type: Number, default: 0 },
  other_deduction_label: { type: String, default: "" },
  active_status: { type: Boolean, default: true },
  pay_slip: { type: String, default: "" },
  total_allowances: { type: Number, required: true },
  total_deductions: { type: Number, required: true },
  gross_earnings: { type: Number, required: true },
  is_included_general_allowances: { type: Boolean, default: false },
  general_allowances: [
    {
      _id: false,
      title: { type: String },
      amount: { type: Number },
    },
  ],
  other_allowances: [
    {
      _id: false,
      title: { type: String },
      amount: { type: Number },
    },
  ],
  other_deductions: [
    {
      _id: false,
      title: { type: String },
      amount: { type: Number },
    },
  ],
  gross_salary: { type: Number, default: 0 },
});

payrollSchema.plugin(timestamps);

payrollSchema.methods.toJSON = function () {
  const payroll = this;
  const payrollObject = payroll.toObject();
  const payrollJson = _.pick(payrollObject, [
    "_id",
    "emp_obj_id",
    "emp_name",
    "month",
    "year",
    "basic_salary",
    "conveyance_allowance",
    // "education_allowance",
    "medical_allowance",
    "rent_allowance",
    "food_allowance",
    "other_payment",
    "other_payment_label",
    "commission",
    "overtime",
    "loan",
    "monthly_tax",
    "tax_file",
    "net_salary",
    "date",
    "loan_deduction",
    "lunch_deduction",
    "fine_deduction",
    "other_deduction",
    "other_deduction_label",
    "total_allowances",
    "total_deductions",
    "general_allowances",
    "other_allowances",
    "other_deductions",
    "gross_salary",
    "gross_earnings",
    "is_included_general_allowances",
    "active_status",
    "pay_slip",
    "createdAt",
    "updatedAt",
  ]);
  return payrollJson;
};

const Payroll = mongoose.model("payroll", payrollSchema);
exports.Payroll = Payroll;
