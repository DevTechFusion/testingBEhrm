const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const incrementHistorySchema = new mongoose.Schema({
  increment_date: {
    type: Date,
  },
  increment_amount: {
    type: Number,
  },
  additional_note: {
    type: String,
    default: "",
  },
  employee_info: {},
  action_info: {},
});

incrementHistorySchema.plugin(timestamps);

incrementHistorySchema.methods.toJSON = function () {
  const incrementHistory = this;
  const incrementHistoryObject = incrementHistory.toObject();
  const incrementHistoryJson = _.pick(incrementHistoryObject, [
    "_id",
    "increment_date",
    "increment_amount",
    "additional_note",
    "employee_info",
    "action_info",
    "createdAt",
    "updatedAt",
  ]);
  return incrementHistoryJson;
};

const IncrementHistory = mongoose.model(
  "IncrementHistory",
  incrementHistorySchema
);
exports.IncrementHistory = IncrementHistory;
