const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const companySchema = new mongoose.Schema({
  title: { type: String },
  description: { type: String },
  active_status: { type: Boolean, default: true },
  phone: { type: String },
  email: { type: String },
  address: { type: String },
});

companySchema.plugin(timestamps);

companySchema.methods.toJSON = function () {
  const company = this;
  const companyObject = company.toObject();
  const companyJson = _.pick(companyObject, [
    "_id",
    "title",
    "description",
    "active_status",
    "phone",
    "email",
    "address",
    "createdAt",
    "updatedAt",
  ]);
  return companyJson;
};

const Company = mongoose.model("company", companySchema);
exports.Company = Company;
