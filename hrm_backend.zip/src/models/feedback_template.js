const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const feedbackTemplateSchema = new mongoose.Schema({
  title: { type: String },
  questions: [
    {
      title: { type: String },
      order: { type: Number },
      type: {
        type: String,
        enum: ["rating", "multiple_choice", "free_text"],
      },
      options: { type: Array },
      options_count: { type: Number },
      answer: { type: String, default: "" },
    },
  ],

  active_status: { type: Boolean, default: true },
});

feedbackTemplateSchema.plugin(timestamps);

feedbackTemplateSchema.methods.toJSON = function () {
  const feedbackTemplate = this;
  const feedbackTemplateObject = feedbackTemplate.toObject();
  const feedbackTemplateJson = _.pick(feedbackTemplateObject, [
    "_id",
    "title",
    "questions",
    "active_status",
    "createdAt",
    "updatedAt",
  ]);
  return feedbackTemplateJson;
};

const FeedbackTemplate = mongoose.model(
  "feedbackTemplate",
  feedbackTemplateSchema
);
exports.FeedbackTemplate = FeedbackTemplate;
