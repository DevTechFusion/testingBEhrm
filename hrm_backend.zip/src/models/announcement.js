const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");
const moment = require("moment");

const announcementSchema = new mongoose.Schema({
  title: { type: String },
  description: { type: String, default: "" },
  attachment: { type: String },
  date: { type: Date, default: moment().utc(true) },
  active_status: { type: Boolean, default: true },
  role: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "role" },
    title: { type: String },
  },
  reactions: [
    {
      user_id: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      emoji: { type: String },
    },
  ],
});

announcementSchema.plugin(timestamps);

announcementSchema.methods.toJSON = function () {
  const announcement = this;
  const announcementObject = announcement.toObject();
  const announcementJson = _.pick(announcementObject, [
    "_id",
    "title",
    "description",
    "attachment",
    "date",
    "active_status",
    "role",
    "reactions",
    "createdAt",
    "updatedAt",
  ]);
  return announcementJson;
};

const Announcement = mongoose.model("announcement", announcementSchema);
exports.Announcement = Announcement;
