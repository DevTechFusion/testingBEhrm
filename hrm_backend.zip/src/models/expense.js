const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");
const moment = require("moment");

const expenseSchema = new mongoose.Schema({
  title: { type: String },
  amount: { type: Number, default: 0 },
  payment_method: { type: String },
  date: { type: Date, default: moment().utc(true) },
  attachment: { type: String },
  notes: { type: String },
  vendor: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "vendor" },
    name: { type: String },
  },
  employee: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
    name: { type: String },
  },
  tax_type: { type: String, default: "" },
  tax_amount: { type: Number, default: 0 },
  expense_category: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "expenseCategory" },
    title: { type: String },
  },
  added_by: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
    name: { type: String },
  },
  link: { type: String, default: "" },
  other_link: { type: String, default: "" },
  active_status: { type: Boolean, default: true },
});

expenseSchema.plugin(timestamps);

expenseSchema.methods.toJSON = function () {
  const expense = this;
  const expenseObject = expense.toObject();
  const expenseJson = _.pick(expenseObject, [
    "_id",
    "title",
    "amount",
    "payment_method",
    "date",
    "attachment",
    "notes",
    "vendor",
    "employee",
    "tax_type",
    "tax_amount",
    "expense_category",
    "added_by",
    "link",
    "other_link",
    "active_status",
    "createdAt",
    "updatedAt",
  ]);
  return expenseJson;
};

const Expense = mongoose.model("expense", expenseSchema);
exports.Expense = Expense;
