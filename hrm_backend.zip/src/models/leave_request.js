const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");
const moment = require("moment");

const leaveRequestSchema = new mongoose.Schema({
  emp_obj_id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
  emp_name: { type: String },
  // leave_payment_status: {
  //   type: String,
  //   enum: ["paid", "unpaid"],
  //   default: "paid",
  // },
  count_in_yearly_leaves: { type: Boolean, default: true },
  uncount_leave_reason: { type: String, default: "" },
  leave_type: {
    type: String,
    enum: ["first_half", "second_half", "full"],
    default: "full",
  },
  status: {
    type: String,
    enum: ["pending", "approved", "rejected"],
    default: "pending",
  },
  leave_reason: { type: String },
  uncount_leave_action_by: {
    emp_obj_id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
    emp_name: { type: String },
    designation: { type: String },
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: "user" },
  },
  leave_date: { type: Date, default: moment().add(+1, "days") },
  rejection_reason: { type: String, default: "" },
  action_by: { type: String, default: "employee" },
  approved_by: { type: String, default: "" },
});

leaveRequestSchema.plugin(timestamps);

leaveRequestSchema.methods.toJSON = function () {
  const leaveRequest = this;
  const leaveRequestObject = leaveRequest.toObject();
  const leaveRequestJson = _.pick(leaveRequestObject, [
    "_id",
    "emp_obj_id",
    "emp_name",
    // "leave_payment_status",
    "count_in_yearly_leaves",
    "uncount_leave_reason",
    "uncount_leave_action_by",
    "leave_type",
    "status",
    "leave_reason",
    "leave_date",
    "rejection_reason",
    "action_by",
    "approved_by",
    "createdAt",
    "updatedAt",
  ]);
  return leaveRequestJson;
};

const LeaveRequest = mongoose.model("leaveRequest", leaveRequestSchema);
exports.LeaveRequest = LeaveRequest;
