const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const taxSlabsSchema = new mongoose.Schema({
  per_month_salary_from: { type: Number },
  per_month_salary_to: { type: Number },
  income_tax : { type: Number },

});

taxSlabsSchema.plugin(timestamps);

taxSlabsSchema.methods.toJSON = function () {
  const taxSlabs = this;
  const taxSlabsObject = taxSlabs.toObject();
  const taxSlabsJson = _.pick(taxSlabsObject, [
    "_id",
    "per_month_salary_from",
    "per_month_salary_to",
    "income_tax",
    "createdAt",
    "updatedAt",
  ]);
  return taxSlabsJson;
};

const TaxSlabs = mongoose.model("taxSlabs", taxSlabsSchema);

exports.TaxSlabs = TaxSlabs;