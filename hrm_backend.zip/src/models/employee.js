const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const employeeSchema = new mongoose.Schema({
  user_id: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  full_name: { type: String },
  first_name: { type: String, default: "" },
  last_name: { type: String, default: "" },
  email: { type: String, lowercase: true },
  skype_email: { type: String },
  webmail_email: { type: String },
  webmail_password: { type: String },
  date_of_birth: { type: String },
  date_of_joining: { type: String },
  date_of_confirmation: { type: String },
  date_of_increment: { type: String, default: "" },
  next_date_of_increment: { type: Date, default: null },
  date_of_contract: { type: String, default: "" },
  designation: { type: String, default: "" },
  contact_number: { type: String },
  address: { type: String },
  gender: { type: String },
  cnic: { type: String },
  profile_pic: { type: Object },
  employee_id: { type: Number },
  active_status: { type: Boolean, default: true },
  previllages: { type: Object },
  tech_lead: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    name: { type: String },
    webmail: { type: String },
    // tech_lead: { type: Boolean, default: false },
  },

  leads: [
    {
      _id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
      user_id: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      name: { type: String },
      webmail: { type: String },
      // tech_lead: { type: Boolean, default: false },
    },
  ],
  department: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "department" },
    title: { type: String },
  },
  company: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "company" },
    title: { type: String },
  },
  company_assets: [
    {
      _id: { type: mongoose.Schema.Types.ObjectId, ref: "companyAsset" },
      title: { type: String },
    },
  ],
  role: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "role" },
    title: { type: String },
  },
  documents_url: { type: String },
  socket_id: { type: String, default: "" },
  is_online: { type: Boolean, default: false },
  sidebar_status: {
    supports: { type: Boolean, default: false },
    my_supports: { type: Boolean, default: false },
    leaves: { type: Boolean, default: false },
    my_leaves: { type: Boolean, default: false },
    announcement: { type: Boolean, default: false },
    my_loans: { type: Boolean, default: false },
    loans: { type: Boolean, default: false },
  },
  total_balance: { type: Number, default: 0 },
  basic_salary: { type: Number, default: 0 },
  food_allowance: { type: Number, default: 0 },
  medical_allowance: { type: Number, default: 0 },
  conveyance_allowance: { type: Number, default: 0 },
  bank_account: { type: String, default: "" },
  want_lunch: { type: Boolean, default: null },
  blood_group: { type: String, default: "" },
  allowed_leaves: { type: Number, default: 15 },
});

employeeSchema.plugin(timestamps);

employeeSchema.methods.toJSON = function () {
  const employee = this;
  const employeeObject = employee.toObject();
  const employeeJson = _.pick(employeeObject, [
    "_id",
    "user_id",
    "full_name",
    "first_name",
    "last_name",
    "email",
    "skype_email",
    "webmail_email",
    "webmail_password",
    "date_of_birth",
    "date_of_joining",
    "date_of_confirmation",
    "date_of_increment",
    "date_of_contract",
    "designation",
    "contact_number",
    "address",
    "gender",
    "cnic",
    "profile_pic",
    "employee_id",
    "active_status",
    "previllages",
    "tech_lead",
    "leads",
    "department",
    "company",
    "company_assets",
    "role",
    "documents_url",
    "socket_id",
    "is_online",
    "sidebar_status",
    "total_balance",
    "basic_salary",
    "food_allowance",
    "medical_allowance",
    "conveyance_allowance",
    "bank_account",
    "want_lunch",
    "blood_group",
    "allowed_leaves",
    "next_date_of_increment",
    "createdAt",
    "updatedAt",
  ]);
  return employeeJson;
};

const Employee = mongoose.model("employee", employeeSchema);
exports.Employee = Employee;
