const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const allowancesSchema = new mongoose.Schema({
  title: { type: String },
  allowance_type: { type: String }, //general, other
  allowance_amount_type: { type: String }, //fixed, percentage
  allowance_amount_or_percentage: { type: Number },
  status: { type: Boolean, default: true },
  exempt_from_tax_calculation: { type: Boolean, default: false },
});

allowancesSchema.plugin(timestamps);

allowancesSchema.methods.toJSON = function () {
  const allowances = this;
  const allowancesObject = allowances.toObject();
  const allowancesJson = _.pick(allowancesObject, [
    "_id",
    "title",
    "allowance_type",
    "allowance_amount_type",
    "allowance_amount_or_percentage",
    "status",
    "exempt_from_tax_calculation",
    "createdAt",
    "updatedAt",
  ]);
  return allowancesJson;
};

const Allowances = mongoose.model("allowances", allowancesSchema);

exports.Allowances = Allowances;
