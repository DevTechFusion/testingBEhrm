const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const companyAssetSchema = new mongoose.Schema({
  title: { type: String },
  device_id: { type: String, default: "" },
  details: { type: String, default: "" },
  image: { type: Object },
  price: { type: Number, default: 0 },
  quantity: { type: Number, default: 1 },
  active_status: { type: Boolean, default: true },
  assigned_status: { type: Boolean, default: false },
  purchase_date: { type: String },
  warranty_expire_date: { type: String },
  warranty_card_image: { type: Object },
  receipt_image: { type: Object },
  link: { type: String, default: "" },
  vendor: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "vendor" },
    name: { type: String },
  },
  brand: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "brand" },
    title: { type: String },
  },
  asset_category: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "assetCategory" },
    title: { type: String },
  },
  assigned_history: [
    {
      emp_obj_id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
      name: { type: String },
      emp_assigned_status: { type: Boolean, default: false },
      assigned_date: { type: String, default: "" },
      returned_date: { type: String, default: "" },
    },
  ],
  repair_history: [
    {
      vendor_obj_id: { type: mongoose.Schema.Types.ObjectId, ref: "vendor" },
      vendor_name: { type: String, default: "" },
      repair_date: { type: String, default: "" },
      service_type: { type: String, default: "" },
      service_description: { type: String, default: "" },
      service_cost: { type: Number, default: 0 },
      service_duration: { type: Number, default: 0 },
      service_receipt_pic: { type: String, default: "" },
    },
  ],
});

companyAssetSchema.plugin(timestamps);

companyAssetSchema.methods.toJSON = function () {
  const companyAsset = this;
  const companyAssetObject = companyAsset.toObject();
  const companyAssetJson = _.pick(companyAssetObject, [
    "_id",
    "title",
    "device_id",
    "details",
    "image",
    "price",
    "quantity",
    "active_status",
    "assigned_status",
    "purchase_date",
    "warranty_expire_date",
    "warranty_card_image",
    "receipt_image",
    "link",
    "vendor",
    "brand",
    "asset_category",
    "assigned_history",
    "repair_history",
    "createdAt",
    "updatedAt",
  ]);
  return companyAssetJson;
};

const companyAsset = mongoose.model("companyAsset", companyAssetSchema);
exports.CompanyAsset = companyAsset;
