const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const assetCategorySchema = new mongoose.Schema({
  title: { type: String },
  description: { type: String },
  active_status: { type: Boolean, default: true },
  assignable_status: { type: Boolean, default: false },
});

assetCategorySchema.plugin(timestamps);

assetCategorySchema.methods.toJSON = function () {
  const assetCategory = this;
  const assetCategoryObject = assetCategory.toObject();
  const assetCategoryJson = _.pick(assetCategoryObject, [
    "_id",
    "title",
    "description",
    "active_status",
    "assignable_status",
    "createdAt",
    "updatedAt",
  ]);
  return assetCategoryJson;
};

const AssetCategory = mongoose.model("assetCategory", assetCategorySchema);
exports.AssetCategory = AssetCategory;
