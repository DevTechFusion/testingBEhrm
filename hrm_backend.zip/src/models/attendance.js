const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");
const moment = require("moment");

const attendanceSchema = new mongoose.Schema({
  emp_obj_id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
  emp_name: { type: String },
  emp_id: { type: Number },
  month: { type: Number },
  year: { type: Number },
  fine: { type: Number, default: 0 },
  late_fine: { type: Number, default: 0 },
  due_fine: { type: Number, default: 0 },
  paid_status: { type: Boolean, default: false },
  deadline: {
    type: Date,
    default: moment(
      "10-" + (moment().month() + 1) + "-" + moment().year(),
      "DD-MM-YYYY"
    ).utc(true),
  },
  total_late_minutes: { type: Number, default: 0 },
  granted_relax_minutes: { type: Number, default: 0 },
  total_absents: { type: Number, default: 0 },
  attendance: [
    {
      date: { type: String },
      check_in: { type: String },
      check_out: { type: String },
      relax_time: { type: String },
      late: { type: Number, default: 0 },
      early: { type: Number, default: 0 },
      absent: { type: Boolean },
      discounted_minutes: { type: Boolean, default: false },
      half_leave_type: { type: Number, min: 0, max: 2, default: 0 },
    },
  ],
});

attendanceSchema.plugin(timestamps);

attendanceSchema.methods.toJSON = function () {
  const attendance = this;
  const attendanceObject = attendance.toObject();
  const attendanceJson = _.pick(attendanceObject, [
    "_id",
    "emp_obj_id",
    "emp_name",
    "emp_id",
    "month",
    "year",
    "fine",
    "late_fine",
    "due_fine",
    "paid_status",
    "deadline",
    "total_late_minutes",
    "granted_relax_minutes",
    "total_absents",
    "attendance",
    "createdAt",
    "updatedAt",
  ]);
  return attendanceJson;
};

const Attendance = mongoose.model("attendance", attendanceSchema);
exports.Attendance = Attendance;
