const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const vendorSchema = new mongoose.Schema({
  name: { type: String },
  email: { type: String },
  contact_number: { type: String },
  address: { type: String },
  image: { type: Object },
  active_status: { type: Boolean, default: true },
});

vendorSchema.plugin(timestamps);

vendorSchema.methods.toJSON = function () {
  const vendor = this;
  const vendorObject = vendor.toObject();
  const vendorJson = _.pick(vendorObject, [
    "_id",
    "name",
    "email",
    "contact_number",
    "address",
    "image",
    "active_status",
    "createdAt",
    "updatedAt",
  ]);
  return vendorJson;
};

const Vendor = mongoose.model("vendor", vendorSchema);
exports.Vendor = Vendor;
