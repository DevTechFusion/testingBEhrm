const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");
const moment = require("moment");

const feedbackSchema = new mongoose.Schema({
  title: { type: String },
  month: { type: Number },
  year: { type: Number },
  feedback_requester: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
    name: { type: String },
  },
  send_to: {
    _id: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "employee",
      default: null,
    },
    name: { type: String, default: "" },
  },
  send_for: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
    name: { type: String },
  },
  questions: [
    {
      title: { type: String },
      order: { type: Number },
      type: {
        type: String,
        enum: ["rating", "multiple_choice", "free_text"],
      },
      options: { type: Array },
      options_count: { type: Number },
      answer: { type: String, default: "" },
      description: { type: String, default: "" },
    },
  ],
  submission_status: {
    type: String,
    enum: ["pending", "submitted"],
    default: "pending",
  },
  date: {
    type: Date,
    default: moment(moment().format("YYYY-MM-DD"), "YYYY-MM-DD").utc(true),
  },
  active_status: { type: Boolean, default: true },
  private_notes: { type: String, default: "" },
});

feedbackSchema.plugin(timestamps);

feedbackSchema.methods.toJSON = function () {
  const feedback = this;
  const feedbackObject = feedback.toObject();
  const feedbackJson = _.pick(feedbackObject, [
    "_id",
    "title",
    "month",
    "year",
    "feedback_requester",
    "send_to",
    "send_for",
    "questions",
    "submission_status",
    "date",
    "active_status",
    "private_notes",
    "createdAt",
    "updatedAt",
  ]);
  return feedbackJson;
};

const Feedback = mongoose.model("feedback", feedbackSchema);
exports.Feedback = Feedback;
