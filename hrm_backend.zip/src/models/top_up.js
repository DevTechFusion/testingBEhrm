const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");
const moment = require("moment");

const topUpSchema = new mongoose.Schema({
  title: { type: String },
  amount: { type: Number, default: 0 },
  payment_method: { type: String },
  date: { type: Date, default: moment().utc(true) },
  attachment: { type: String },
  notes: { type: String },
  cheque_number: { type: String, default: "" },
  transfer_by: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
    name: { type: String },
  },
  transfer_to: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
    name: { type: String },
  },
  added_by: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
    name: { type: String },
  },
  active_status: { type: Boolean, default: true },
});

topUpSchema.plugin(timestamps);

topUpSchema.methods.toJSON = function () {
  const topUp = this;
  const topUpObject = topUp.toObject();
  const topUpJson = _.pick(topUpObject, [
    "_id",
    "title",
    "amount",
    "payment_method",
    "date",
    "attachment",
    "notes",
    "cheque_number",
    "transfer_by",
    "transfer_to",
    "added_by",
    "active_status",
    "createdAt",
    "updatedAt",
  ]);
  return topUpJson;
};

const TopUp = mongoose.model("topUp", topUpSchema);
exports.TopUp = TopUp;
