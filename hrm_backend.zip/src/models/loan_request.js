const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");
const moment = require("moment");

const loanRequestSchema = new mongoose.Schema({
  emp_obj_id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
  emp_name: { type: String },
  amount: { type: Number },
  description: { type: String },
  loan_type: {
    type: String,
    enum: ["advance_salary", "general"],
    default: "general",
  },
  status: {
    type: String,
    enum: ["pending", "approved", "rejected", "returned"],
    default: "pending",
  },
  rejection_reason: { type: String, default: "" },
  payment_method: {
    type: String,
    enum: ["cheque", "cash", "account", ""],
    default: "",
  },
  release_date: { type: Date, default: null },
  application_date: {
    type: Date,
    default: Date.now,
  },
  returned_date: { type: Date},
  paid_amount: { type: Number, default: 0 },
  pending_amount: { type: Number },
  installment_start_from: { type: Date },
  no_of_installments: { type: Number, default: 0 },
  paid_installments_count: { type: Number, default: 0 },
  pending_installments_count: { type: Number, default: 0 },
  rollout_installments_count: { type: Number, default: 0 },
  installments: [
    {
      amount: { type: Number },
      due_date: { type: Date, default: Date.now },
      payment_date: { type: Date, default: null },
      rollout_date: { type: Date, default: null },
      status: {
        type: String,
        enum: ["paid", "pending", "rollout"],
        default: "pending",
      },
      payment_method: {
        type: String,
        enum: ["cheque", "cash", "account", ""],
        default: "",
      },
    },
  ],
});

loanRequestSchema.plugin(timestamps);

loanRequestSchema.methods.toJSON = function () {
  const loanRequest = this;
  const loanRequestObject = loanRequest.toObject();
  const loanRequestJson = _.pick(loanRequestObject, [
    "_id",
    "emp_obj_id",
    "emp_name",
    "amount",
    "description",
    "loan_type",
    "status",
    "rejection_reason",
    "payment_method",
    "release_date",
    "application_date",
    "returned_date",
    "paid_amount",
    "pending_amount",
    "installment_start_from",
    "no_of_installments",
    "installments",
    "paid_installments_count", // "paid_installments",
    "pending_installments_count", // "pending_installments",
    "rollout_installments_count", // "rollout_installments",
    "createdAt",
    "updatedAt",
  ]);
  return loanRequestJson;
};

const LoanRequest = mongoose.model("loanRequest", loanRequestSchema);
exports.LoanRequest = LoanRequest;
