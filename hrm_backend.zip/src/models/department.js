const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const departmentSchema = new mongoose.Schema({
  title: { type: String },
  description: { type: String },
  active_status: { type: Boolean, default: true },
  previllages: { type: Object },
  lead: [
    {
      _id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
      name: { type: String },
    },
  ],
  members: [
    {
      _id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
      name: { type: String },
    },
  ],
  company: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "company" },
    title: { type: String },
  },
});

departmentSchema.plugin(timestamps);

departmentSchema.methods.toJSON = function () {
  const department = this;
  const departmentObject = department.toObject();
  const departmentJson = _.pick(departmentObject, [
    "_id",
    "title",
    "description",
    "active_status",
    "previllages",
    "lead",
    "members",
    "company",
    "createdAt",
    "updatedAt",
  ]);
  return departmentJson;
};

const Department = mongoose.model("department", departmentSchema);
exports.Department = Department;
