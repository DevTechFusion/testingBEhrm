const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const brandSchema = new mongoose.Schema({
  title: { type: String },
  description: { type: String },
  active_status: { type: Boolean, default: true },
});

brandSchema.plugin(timestamps);

brandSchema.methods.toJSON = function () {
  const brand = this;
  const brandObject = brand.toObject();
  const brandJson = _.pick(brandObject, [
    "_id",
    "title",
    "description",
    "active_status",
    "createdAt",
    "updatedAt",
  ]);
  return brandJson;
};

const Brand = mongoose.model("brand", brandSchema);
exports.Brand = Brand;
