const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");
const moment = require("moment");

const lunchSchema = new mongoose.Schema({
  month: { type: Number, default: moment().month() + 1 },
  year: { type: Number, default: moment().year() },
  employee: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
    name: { type: String },
  },
  deadline: {
    type: Date,
    default: moment(
      "10-" + (moment().month() + 1) + "-" + moment().year(),
      "DD-MM-YYYY"
    ).utc(true),
  },
  amount: { type: Number, default: 2500 },
  late_fine: { type: Number, default: 0 },
  paid_status: {
    type: String,
    enum: ["free", "paid", "pending"],
    default: "pending",
  },
  active_status: { type: Boolean, default: true },
  // continue_popup: { type: Boolean, default: null },
});

lunchSchema.plugin(timestamps);

lunchSchema.methods.toJSON = function () {
  const lunch = this;
  const lunchObject = lunch.toObject();
  const lunchJson = _.pick(lunchObject, [
    "_id",
    "month",
    "year",
    "employee",
    "deadline",
    "amount",
    "late_fine",
    "paid_status",
    "active_status",
    // "continue_popup",
    "createdAt",
    "updatedAt",
  ]);
  return lunchJson;
};

const Lunch = mongoose.model("lunch", lunchSchema);
exports.Lunch = Lunch;
