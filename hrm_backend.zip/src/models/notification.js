const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const notificationSchema = new mongoose.Schema({
  user_id: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  emp_obj_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "employee",
    default: null,
  },
  leave_request_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "leaveRequest",
    default: null,
  },
  support_ticket_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "supportTicket",
    default: null,
  },
  announcement_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "announcement",
    default: null,
  },
  feedback_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "feedback",
    default: null,
  },
  lunch_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "lunch",
    default: null,
  },
  loan_request_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "loanRequest",
    default: null,
  },
  title: { type: String, default: "" },
  description: { type: String, default: "" },
  type: { type: String },
  unread_status: { type: Boolean, default: true },
  active_status: { type: Boolean, default: true },
});

notificationSchema.plugin(timestamps);

notificationSchema.methods.toJSON = function () {
  const notification = this;
  const notificationObject = notification.toObject();
  const notificationJson = _.pick(notificationObject, [
    "_id",
    "user_id",
    "emp_obj_id",
    "leave_request_id",
    "support_ticket_id",
    "announcement_id",
    "feedback_id",
    "lunch_id",
    "loan_request_id",
    "title",
    "description",
    "type",
    "unread_status",
    "active_status",
    "createdAt",
    "updatedAt",
  ]);
  return notificationJson;
};

const Notification = mongoose.model("notification", notificationSchema);
exports.Notification = Notification;
