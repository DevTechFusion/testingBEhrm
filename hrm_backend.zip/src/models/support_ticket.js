const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");
const moment = require("moment");

const supportTicketSchema = new mongoose.Schema({
  emp_obj_id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
  emp_name: { type: String },
  title: { type: String },
  description: { type: String },
  priority: { type: String, enum: ["high", "medium", "low"], default: "low" },
  support_type: {
    _id: { type: mongoose.Schema.Types.ObjectId, ref: "role" },
    title: { type: String },
  },
  status: { type: Number, default: 0 },
  image: { type: String, default: "" },
  messages: [
    {
      text: { type: String, default: "" },
      user_id: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
      images: [],
      date_time: { type: Date, default: moment().utc(true).format() },
    },
  ],
  message_receivers: [
    {
      message_id: { type: mongoose.Schema.Types.ObjectId },
      receiver_id: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    },
  ],
});

supportTicketSchema.plugin(timestamps);

supportTicketSchema.methods.toJSON = function () {
  const supportTicket = this;
  const supportTicketObject = supportTicket.toObject();
  const supportTicketJson = _.pick(supportTicketObject, [
    "_id",
    "emp_obj_id",
    "emp_name",
    "title",
    "description",
    "priority",
    "support_type",
    "status",
    "image",
    "messages",
    "message_receivers",
    "createdAt",
    "updatedAt",
  ]);
  return supportTicketJson;
};

const SupportTicket = mongoose.model("supportTicket", supportTicketSchema);
exports.SupportTicket = SupportTicket;
