const mongoose = require("mongoose");
const timestamps = require("mongoose-timestamp");
const _ = require("lodash");

const feedbackImprovementSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  images: [{ type: String }],
  improvement_date: { type: Date, default: Date.now() },
  deduction_number: { type: Number, default: 0 },
  show_to_team: { type: Boolean, default: true },
  team_member_info: [
    {
      employee_id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
      full_name: { type: String },
      designation: { type: String },
      user_id: { type: mongoose.Schema.Types.ObjectId, ref: "user" },
    },
  ],

  action_info: {
    user_id: { type: mongoose.Schema.Types.ObjectId, ref: "user" },
    full_name: { type: String },
    designation: { type: String },
    employee_id: { type: mongoose.Schema.Types.ObjectId, ref: "employee" },
  },
});

feedbackImprovementSchema.plugin(timestamps);

feedbackImprovementSchema.methods.toJSON = function () {
  const feedbackImprovement = this;
  const feedbackImprovementObject = feedbackImprovement.toObject();
  const feedbackImprovementJson = _.pick(feedbackImprovementObject, [
    "_id",
    "title",
    "description",
    "improvement_date",
    "images",
    "deduction_number",
    "team_member_info",
    "action_info",
    "show_to_team",
    "updatedAt",
    "createdAt",
  ]);
  return feedbackImprovementJson;
};

const FeedbackImprovement = mongoose.model(
  "FeedbackImprovement",
  feedbackImprovementSchema
);

exports.FeedbackImprovement = FeedbackImprovement;
