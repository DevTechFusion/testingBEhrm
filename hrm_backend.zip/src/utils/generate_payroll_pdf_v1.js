const PDFDocument = require("pdfkit");
const fs = require("fs");
const moment = require("moment");
const { v4: uuidv4 } = require("uuid");
const s3 = require("../../config/S3_config/s3.config");
let upload = require("../../config/S3_config/multer.config");
const path = require("path");

const generatePayslip = async (data) => {
  let pay_allowances_count = countNonZeroValues(data, pay_allowances);
  let deductions_count = countNonZeroValues(data, deductions);

  //data object have other_allowances and other_deductions array of objects count them and add them to pay_allowances_count and deductions_count

  if (data.general_allowances && data.general_allowances.length > 0) {
    //general_allowances array of objects each object have title and amount key if amount is zero or less than zero then do not count it

    data.general_allowances.forEach((allowance) => {
      if (allowance.amount > 0) {
        pay_allowances_count++;
      }
    });

    // pay_allowances_count += data.general_allowances.length;
  }

  if (data.other_allowances && data.other_allowances.length > 0) {
    pay_allowances_count += data.other_allowances.length;
  }

  if (data.other_deductions && data.other_deductions.length > 0) {
    deductions_count += data.other_deductions.length;
  }

  console.log("Pay Allowances Count", pay_allowances_count);
  console.log("Deductions Count", deductions_count);

  //check which count is greater and aggign to max_count

  let max_count =
    pay_allowances_count > deductions_count
      ? pay_allowances_count
      : deductions_count;

  console.log("Max Count", max_count);

  //draw a rectangle with rounded corners

  let rectangle_height = 20 * max_count + 80;

  //line in rectangle like table footer

  let footer_line_of_rectangle = 310 + rectangle_height - 30;

  let page_width = 720;
  let page_height = footer_line_of_rectangle + 250;

  const doc = new PDFDocument({ size: [page_width, page_height] });

  const payslip_name = `${data.emp_name.split(" ")[0]}:${data.month}:${
    data.year
  }`;

  const file_name = payslip_name + ".pdf";

  console.log(file_name);

  const outputStream = fs.createWriteStream(file_name);
  doc.pipe(outputStream);

  doc.image("public/images/logo.png", 50, 20, {
    fit: [600, 50],
    // align: "center",
  });

  // doc
  //   .fontSize(12)
  //   .text(
  //     "Address: Office #2 Ground Floor Saeed centre Farid town road Sahiwal",
  //     100,
  //     50
  //   );

  doc.font("Helvetica-Bold").fontSize(14).text("Meta Logix", 100, 30);

  doc
    .font("Times-Roman")
    .fontSize(12)
    .text(
      "Ground Floor Saeed centre Farid town road Sahiwal , Pakistan",
      100,
      50
    );

  doc
    .font("Times-Roman")
    .fontSize(12)
    .text("Payslip For the Month", page_width - 210, 30, { align: "right" });

  doc
    .font("Helvetica-Bold")
    .fontSize(14)
    .text(
      ` ${moment(data.month, "MM").format("MMMM")} ${data.year}`,
      page_width - 180,
      50,
      { align: "right" }
    );

  // 1st hortizontal line
  doc
    .moveTo(35, 80)
    .lineTo(page_width - 35, 80)
    .strokeColor("black", 0.3)
    .stroke();

  //data below 1st hortizontal line

  doc.font("Helvetica-Bold").fontSize(12).text("EMPLOYEE SUMMARY", 50, 100);
  //Employee Name , Employee Status, Designation , Employee ID , Pay Period ,

  doc.font("Helvetica-Bold").fontSize(11).text(`Employee Name`, 50, 120);
  doc.font("Times-Roman").fontSize(12).text(`:  ${data.emp_name}`, 180, 120);

  doc.font("Helvetica-Bold").fontSize(11).text(`Employee Status`, 50, 140);
  doc.font("Times-Roman").fontSize(12).text(`:  Permanent`, 180, 140);

  doc.font("Helvetica-Bold").fontSize(11).text(`Designation`, 50, 160);
  doc.font("Times-Roman").fontSize(12).text(`:  ${data.designation}`, 180, 160);

  doc.font("Helvetica-Bold").fontSize(11).text(`Employee ID`, 50, 180);
  doc.font("Times-Roman").fontSize(12).text(`:  ${data.emp_id}`, 180, 180);
  doc.font("Helvetica-Bold").fontSize(11).text(`Pay Period`, 50, 200);
  doc
    .font("Times-Roman")
    .fontSize(12)
    .text(
      `:  ${moment(data.month, "MM").format("MMMM")} ${data.year}`,
      180,
      200
    );

  //pay date

  doc.font("Helvetica-Bold").fontSize(11).text(`Pay Date`, 50, 220);
  doc.font("Times-Roman").fontSize(12).text(`:  ${data.pay_date}`, 180, 220);

  //left side above 2nd hortizontal line

  //drawa a rectangle with background color lite grey and in first line text new salary  and in 2nd line text old salary

  let net_salary_rectangle_color = data.net_salary > 0 ? "#028ed6" : "red";
  console.log("Net Salary Rectangle Color", net_salary_rectangle_color);
  console.log("Net Salary", data.net_salary);

  doc
    .roundedRect(page_width - 260, 130, 200, 80, 10)
    .fill(net_salary_rectangle_color);
  doc
    .font("Helvetica-Bold")
    .fontSize(14)
    .fillColor("black")
    .text(
      `Rupees : ${format_pak_rupees(data.net_salary)}`,
      page_width - 240,
      150
    );

  console.log(`Formate Rupees ${format_pak_rupees(data.net_salary)}`);

  doc
    .font("Times-Roman")
    .fontSize(12)
    .fillColor("black")
    .text("Employee Net Pay", page_width - 240, 180);
  //2nd hortizontal line
  doc
    .moveTo(35, 260)
    .lineTo(page_width - 35, 260)
    .strokeColor("black", 0.3)
    .stroke();

  //bank Account number

  doc.font("Helvetica-Bold").fontSize(11).text(`Bank Account Number`, 50, 280);
  doc.font("Times-Roman").fontSize(12).text(`: ${data.bank_account}`, 200, 280);

  // count pay_allowances and deductions variables which have non zero values for rectangle drawing next page height

  doc
    .roundedRect(35, 310, page_width - 70, rectangle_height, 10)
    .strokeColor("black")
    .stroke();

  // draw to line in rectangle like table header with sapce  for allowances amount  and deductions amount at left right of table head line

  let half_page_width = page_width / 2;

  doc
    .moveTo(40, 340)
    .lineTo(half_page_width - 10, 340)
    .strokeColor("black", 0.4)
    .stroke();

  //write text Pay & Allowances at left side of hortizontal line and amount at right side of hortizontal line

  doc.font("Helvetica-Bold").fontSize(12).text("Pay & Allowances", 45, 325);

  doc
    .font("Helvetica-Bold")
    .fontSize(12)
    .text("Amount", half_page_width - 90, 325);

  doc
    .moveTo(half_page_width + 10, 340)
    .lineTo(page_width - 40, 340)
    .strokeColor("black", 0.4)
    .stroke();

  // Function to format and draw each line of the first table
  function formatLine1(label, value, y) {
    const leftMargin = 45;
    const rightMargin = half_page_width - 90;
    doc.font("Helvetica-Bold").fontSize(11).text(label, leftMargin, y);
    doc.font("Times-Roman").fontSize(12).text(`Rs. ${value}`, rightMargin, y);
  }

  let currentY1 = 350; // Starting y position for the table rows

  if (data.basic_salary != 0) {
    formatLine1(
      "Basic Pay",
      `${format_pak_rupees(data.basic_salary)}`,
      currentY1
    );
    currentY1 += 20;
  }

  // formatLine1(
  //   "Basic Pay",
  //   `${format_pak_rupees(data.basic_salary)}`,
  //   currentY1
  // );
  // currentY1 += 20;

  if (data.food_allowance != 0) {
    formatLine1(
      "Food Allowance",
      `${format_pak_rupees(data.food_allowance)}`,
      currentY1
    );
    currentY1 += 20;
  }

  if (data.medical_allowance != 0) {
    formatLine1(
      "Medical Allowance",
      `${format_pak_rupees(data.medical_allowance)}`,
      currentY1
    );
    currentY1 += 20;
  }

  if (data.conveyance_allowance != 0) {
    formatLine1(
      "Conveyance Allowance",
      `${format_pak_rupees(data.conveyance_allowance)}`,
      currentY1
    );
    currentY1 += 20;
  }

  if (data.other_payment != 0) {
    formatLine1(
      data.other_payment_label,
      `${format_pak_rupees(data.other_payment)}`,
      currentY1
    );
    currentY1 += 20;
  }

  if (data.overtime != 0) {
    formatLine1("Overtime", `${format_pak_rupees(data.overtime)}`, currentY1);
    currentY1 += 20;
  }

  if (data.loan != 0) {
    formatLine1("Loan", `${format_pak_rupees(data.loan)}`, currentY1);
    currentY1 += 20;
  }

  if (data.commission != 0) {
    formatLine1(
      "Commission",
      `${format_pak_rupees(data.commission)}`,
      currentY1
    );
    currentY1 += 20;
  }

  if (data.general_allowances && data.general_allowances.length > 0) {
    data.general_allowances.forEach((allowance) => {
      if (allowance.amount > 0) {
        formatLine1(
          allowance.title,
          `${format_pak_rupees(allowance.amount)}`,
          currentY1
        );
        currentY1 += 20;
      }
    });
  }

  // Iterate over other_allowances array and format each allowance
  if (data.other_allowances && data.other_allowances.length > 0) {
    data.other_allowances.forEach((allowance) => {
      formatLine1(
        allowance.title,
        `${format_pak_rupees(allowance.amount)}`,
        currentY1
      );
      currentY1 += 20;
    });
  }

  //deductions and amount text

  doc
    .font("Helvetica-Bold")
    .fontSize(12)
    .text("Deductions", half_page_width + 15, 325);

  doc
    .font("Helvetica-Bold")
    .fontSize(12)
    .text("Amount", page_width - 135, 325);

  function formatLine2(label, value, y) {
    const leftMargin = half_page_width + 13;
    const rightMargin = page_width - 135;
    doc.font("Helvetica-Bold").fontSize(11).text(label, leftMargin, y);
    doc.font("Times-Roman").fontSize(12).text(`Rs. ${value}`, rightMargin, y);
  }

  let currentY2 = 350; // Starting y position for the table rows

  if (data.monthly_tax != 0) {
    formatLine2(
      "Income Tax Deduction",
      `${format_pak_rupees(data.monthly_tax)}`,
      currentY2
    );
    currentY2 += 20;
  }

  if (data.loan_deduction != 0) {
    formatLine2(
      "Loan Deduction",
      `${format_pak_rupees(data.loan_deduction)}`,
      currentY2
    );
    currentY2 += 20;
  }

  if (data.lunch_deduction != 0) {
    formatLine2(
      "Lunch Deduction",
      `${format_pak_rupees(data.lunch_deduction)}`,
      currentY2
    );
    currentY2 += 20;
  }

  if (data.fine_deduction != 0) {
    formatLine2(
      "Fine Deduction",
      `${format_pak_rupees(data.fine_deduction)}`,
      currentY2
    );
    currentY2 += 20;
  }

  if (data.other_deduction != 0) {
    formatLine2(
      data.other_deduction_label,
      `${format_pak_rupees(data.other_deduction)}`,
      currentY2
    );
    currentY2 += 20;
  }

  // Iterate over other_deductions array and format each deduction
  if (data.other_deductions && data.other_deductions.length > 0) {
    data.other_deductions.forEach((deduction) => {
      formatLine2(
        deduction.title,
        `${format_pak_rupees(deduction.amount)}`,
        currentY2
      );
      currentY2 += 20;
    });
  }

  doc
    .moveTo(40, footer_line_of_rectangle)
    .lineTo(page_width - 40, footer_line_of_rectangle)
    .strokeColor("black", 0.4)
    .stroke();

  // Gross Earning  and value  , Total Deduction and value

  //*************************{gross Earnings}********************/

  var allowances_to_add = 0;

  if (data.other_allowances && data.other_allowances.length > 0) {
    data.other_allowances.forEach((allowance) => {
      allowances_to_add += allowance.amount;
    });
  }

  let gross_earnings = allowances_to_add + data.gross_salary;

  console.log("Gross Earnings", gross_earnings);

  doc
    .font("Helvetica-Bold")
    .fontSize(12)
    .text("Gross Earnings", 45, footer_line_of_rectangle + 10);
  doc
    .font("Helvetica-Bold")
    .fontSize(10)
    .text(
      `Rs. ${format_pak_rupees(gross_earnings)}`,
      half_page_width - 90,
      footer_line_of_rectangle + 10
    );

  //***************************{total deductions} ***********************/

  let total_deuctions = data.total_deductions;
  // +
  // data.monthly_tax +
  // data.loan_deduction +
  // data.lunch_deduction +
  // data.fine_deduction +
  // data.other_deduction;

  console.log("Total Deductions", total_deuctions);

  doc
    .font("Helvetica-Bold")
    .fontSize(12)
    .text(
      "Total Deductions",
      half_page_width + 10,
      footer_line_of_rectangle + 10
    );
  doc
    .font("Helvetica-Bold")
    .fontSize(10)
    .text(
      `Rs. ${format_pak_rupees(total_deuctions)}`,
      page_width - 135,
      footer_line_of_rectangle + 10
      // { align: "right" }
    );

  // drawa a rectangle with rounded corners total net Payable amount and in 2nd line text gross salary - total deductions at right side of rectangle net salary

  doc
    .roundedRect(35, footer_line_of_rectangle + 40, page_width - 70, 60, 10)
    .strokeColor("black")
    .stroke();

  //draw a rectangle with rounded corners right side and not rounded corners left side and fill color with light grey

  doc
    .roundedRect(550, footer_line_of_rectangle + 40.7, 134, 58.5, 10)
    .fill(net_salary_rectangle_color);

  doc
    .font("Helvetica-Bold")
    .fontSize(12)
    .fillColor("black")
    .text("Net Payable Amount", 45, footer_line_of_rectangle + 55);

  doc
    .font("Helvetica-Bold")
    .fontSize(12)
    .fillColor("black")
    .text(
      `Rs. ${format_pak_rupees(data.net_salary)}`,
      page_width - 220,
      footer_line_of_rectangle + 66,
      { align: "right" }
    );

  doc
    .font("Times-Roman")
    .fontSize(12)
    .fillColor("black")
    .text(
      `Gross Earnings - Total Deductions`,
      45,
      footer_line_of_rectangle + 72
    );

  //net salary in words

  let net_salary_in_words =
    data.net_salary !== 0 ? convertNumberToWords(data.net_salary) : "Zero";

  doc
    .font("Times-Roman")
    .fontSize(12)
    .fillColor("black")
    .text(
      `Amount in Words : ${net_salary_in_words}`,
      45,
      footer_line_of_rectangle + 115,
      { align: "right" }
    );

  // 2nd hortizontal line

  doc
    .moveTo(35, footer_line_of_rectangle + 135)
    .lineTo(page_width - 35, footer_line_of_rectangle + 135)
    .strokeColor("black", 0.3)
    .stroke();

  doc
    .font("Times-Roman")
    .fontSize(12)
    .fillColor("black")
    .text(
      `This document is generated by the MetaLogix Support Portal; therefore, a signature is not required.`,
      45,
      footer_line_of_rectangle + 150,
      { align: "center" }
    );

  console.log("footer_line_of_rectangle", footer_line_of_rectangle + 150);

  await new Promise((resolve) => {
    outputStream.on("finish", resolve);

    doc.end();
  });

  console.log("PDF generated successfully", file_name);

  return file_name;
};

module.exports = {
  generatePayslip,
};

let pay_allowances = [
  "basic_salary",
  "food_allowance",
  "medical_allowance",
  "conveyance_allowance",
  "other_payment",
  "overtime",
  "loan",
  "commission",
];
let deductions = [
  "monthly_tax",
  "loan_deduction",
  "lunch_deduction",
  "fine_deduction",
  "other_deduction",
];

function countNonZeroValues(obj, properties) {
  let count = 0;
  for (let prop of properties) {
    if (obj[prop] !== 0) {
      count++;
    }
  }
  return count;
}

function format_pak_rupees(amount) {
  // Convert the amount to a string and remove any non-numeric characters (like commas)
  let amount_str = amount.toString().replace(/,/g, "");

  // Split the integer and decimal parts
  let [integer_part, decimal_part] = amount_str.split(".");

  // Add commas to the integer part
  let last_three_digits = integer_part.slice(-3);
  let remaining_digits = integer_part.slice(0, -3);

  if (remaining_digits) {
    last_three_digits =
      remaining_digits.replace(/\B(?=(\d{2})+(?!\d))/g, ",") +
      "," +
      last_three_digits;
  }

  // Concatenate integer part and decimal part
  let formatted_amount = last_three_digits;
  if (decimal_part) {
    formatted_amount += "." + decimal_part;
  }

  return formatted_amount;
}

function convertNumberToWords(amount) {
  var words = new Array();
  words[0] = "";
  words[1] = "One";
  words[2] = "Two";
  words[3] = "Three";
  words[4] = "Four";
  words[5] = "Five";
  words[6] = "Six";
  words[7] = "Seven";
  words[8] = "Eight";
  words[9] = "Nine";
  words[10] = "Ten";
  words[11] = "Eleven";
  words[12] = "Twelve";
  words[13] = "Thirteen";
  words[14] = "Fourteen";
  words[15] = "Fifteen";
  words[16] = "Sixteen";
  words[17] = "Seventeen";
  words[18] = "Eighteen";
  words[19] = "Nineteen";
  words[20] = "Twenty";
  words[30] = "Thirty";
  words[40] = "Forty";
  words[50] = "Fifty";
  words[60] = "Sixty";
  words[70] = "Seventy";
  words[80] = "Eighty";
  words[90] = "Ninety";
  amount = amount.toString();
  var atemp = amount.split(".");
  var number = atemp[0].split(",").join("");
  var n_length = number.length;
  var words_string = "";
  if (n_length <= 9) {
    var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
    var received_n_array = new Array();
    for (var i = 0; i < n_length; i++) {
      received_n_array[i] = number.substr(i, 1);
    }
    for (var i = 9 - n_length, j = 0; i < 9; i++, j++) {
      n_array[i] = received_n_array[j];
    }
    for (var i = 0, j = 1; i < 9; i++, j++) {
      if (i == 0 || i == 2 || i == 4 || i == 7) {
        if (n_array[i] == 1) {
          n_array[j] = 10 + parseInt(n_array[j]);
          n_array[i] = 0;
        }
      }
    }
    value = "";
    for (var i = 0; i < 9; i++) {
      if (i == 0 || i == 2 || i == 4 || i == 7) {
        value = n_array[i] * 10;
      } else {
        value = n_array[i];
      }
      if (value != 0) {
        words_string += words[value] + " ";
      }
      if (
        (i == 1 && value != 0) ||
        (i == 0 && value != 0 && n_array[i + 1] == 0)
      ) {
        words_string += "Cror ";
      }
      if (
        (i == 3 && value != 0) ||
        (i == 2 && value != 0 && n_array[i + 1] == 0)
      ) {
        words_string += "Lakh ";
      }
      if (
        (i == 5 && value != 0) ||
        (i == 4 && value != 0 && n_array[i + 1] == 0)
      ) {
        words_string += "Thousand ";
      }
      if (i == 6 && value != 0 && n_array[i + 1] != 0 && n_array[i + 2] != 0) {
        words_string += "Hundred and ";
      } else if (i == 6 && value != 0) {
        words_string += "Hundred ";
      }
    }
    words_string = words_string.split("  ").join(" ");
  }
  return `Pakistani Rupee ${words_string}Only`;
}
