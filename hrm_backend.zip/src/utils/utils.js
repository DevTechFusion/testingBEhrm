const sharp = require("sharp");
const csv_parser = require("csv-parser");
const s3 = require("../../config/S3_config/s3.config");
let upload = require("../../config/S3_config/multer.config");
const { TYPE_IMAGE, TYPE_AUDIO } = require("../utils/constants");
const { v1: uuidv4 } = require("uuid");
const fs = require("fs-extra");
const puppeteer = require("puppeteer");
const path = require("path");
const AWS = require("aws-sdk");
const nodemailer = require("nodemailer");
const sgMail = require("@sendgrid/mail");
const axios = require("axios");
sgMail.setApiKey(
  "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"
);
const { invokeApi } = require("../libs/invoke_api");

const pdf = require("html-pdf");
const moment = require("moment");
// const S3 = new AWS.S3();
// const env = require("../../config/S3_config/s3.env.js");

const { LeaveRequest } = require("../models/leave_request");
const { APILog } = require("../models/api_log");

const RENDER_BAD_REQUEST = (res, error) => {
  console.log(error);
  if (error.message) {
    res.status(400).json({
      message: error.message,
    });
  } else {
    res.status(400).send(error);
  }
};

const MAX_ORDER = async (schema) => {
  let max_order = 0;
  let doc = await schema
    .findOne({})
    .sort({ order: -1 })
    .limit(1)
    .select({ order: 1, _id: 0 });
  if (doc) {
    max_order = doc.order;
  }
  return max_order;
};

const CHANGE_DEL_ORDER = async (_id, current_order, schema) => {
  let doc = await schema.find({
    _id: {
      $ne: _id,
    },
    order: {
      $gte: current_order,
    },
  });
  const promise = doc.map(async (Obj) => {
    Obj.order = Obj.order - 1;
    await Obj.save();
  });
  await Promise.all(promise);
};

const ORDER_CHANGE_TO_LOWER = async (
  _id,
  current_order,
  past_order,
  schema
) => {
  let doc = await schema.find({
    _id: {
      $ne: _id,
    },
    order: {
      $gte: current_order,
      $lte: past_order,
    },
  });
  const promise = doc.map(async (Obj) => {
    Obj.order = Obj.order + 1;
    await Obj.save();
  });
  await Promise.all(promise);
};

const ORDER_CHANGE_TO_UPPER = async (
  _id,
  current_order,
  past_order,
  schema
) => {
  let doc = await schema.find({
    _id: {
      $ne: _id,
    },
    order: {
      $gte: past_order,
      $lte: current_order,
    },
  });
  console.log(doc, "this is doc");
  const promise = doc.map(async (Obj) => {
    Obj.order = Obj.order - 1;
    await Obj.save();
  });
  await Promise.all(promise);
};

const SEND_EMAIL = async (mail_obj) => {
  let email_body = `<!-- [if mso]>
    <style>
      table { border-collapse: collapse; }
      .o_col { float: left; }
    </style>
    <xml>
      <o:OfficeDocumentSettings>
        <o:PixelsPerInch>96</o:PixelsPerInch>
      </o:OfficeDocumentSettings>
    </xml>
    <![endif]--><!-- preview-text -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_hide" style="display: none; font-size: 0; max-height: 0; width: 0; line-height: 0; overflow: hidden; mso-hide: all; visibility: hidden;" align="center">Email Summary (Hidden)</td>
</tr>
</tbody>
</table>
<!-- header-white -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs o_pt-lg o_xs-pt-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px; padding-top: 32px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_px o_py-md o_br-t o_sans o_text" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 16px; line-height: 24px; background-color: #ffffff; border-radius: 4px 4px 0px 0px; padding-left: 16px; padding-right: 16px; padding-top: 15px;" align="center">
<p style="margin-top: 0px; margin-bottom: 0px;"><a class="o_text-primary" style="text-decoration: none; outline: none; color: #126de5;"><img style="max-width: 300px; -ms-interpolation-mode: bicubic; vertical-align: middle; border: 0; line-height: 100%; outline: none; text-decoration: none;" src="https://metalogix-support-portal-app-bucket.s3.amazonaws.com/images/61c197d0-f89b-11ed-8063-f18a55efd589.jpeg" alt="" /></a></p>
</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]--></td>
</tr>
</tbody>
</table>
<!-- hero-white-button -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_px-md o_py-xl o_xs-py-md o_sans o_text-md o_text-light" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 19px; line-height: 28px; background-color: #ffffff; color: #82899a; padding: 34px 24px 64px 24px;" align="center">
<h2 class="o_heading o_text-dark o_mb-xxs" style="font-family: Helvetica, Arial, sans-serif; font-weight: bold; margin-top: 0px; margin-bottom: 4px; color: #242b3d; font-size: 30px; line-height: 39px;">Welcome To Meta Logix Support Center</h2>
<!-- <p class="o_mb-md" style="margin-top: 0px;margin-bottom: 24px;"></p> -->
<table border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td class="o_bg-white o_px-md o_py o_sans o_text o_text-secondary" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 16px; line-height: 24px; background-color: #ffffff; color: #424651; padding: 16px 24px 16px 24px;" align="left">
<p style="margin-top: 20px; margin-bottom: 0px;">${mail_obj.body}<br /> <br /> Thank You <br />Meta Logix Support Center <br />Created by Meta Logix <br /> &nbsp;</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]--></td>
</tr>
</tbody>
</table>
<!-- content --><!-- footer-light-2cols -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs o_pb-lg o_xs-pb-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px; padding-bottom: 32px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_br-b o_sans" style="font-size: 8px; line-height: 8px; height: 8px; font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; background-color: #ffffff; border-radius: 0px 0px 4px 4px;">&nbsp;</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]-->
<div class="o_hide-xs" style="font-size: 64px; line-height: 64px; height: 64px;">&nbsp;</div>
</td>
</tr>
</tbody>
</table>`;
  const msg = {
    to: mail_obj.email_to,
    from: "arhamrumi007@gmail.com",
    subject: mail_obj.subject,
    html: email_body,
  };
  sgMail
    .send(msg)
    .then(() => {
      console.log("Email sent successfully");
    })
    .catch((error) => {
      console.log("Could not send email");
      console.log(error.response.body.errors);
    });
};

const UPLOAD_AUDIO_FILE = async (files, resp) => {
  const myPromise = new Promise(async (resolve, reject) => {
    try {
      let image_file = files.audio;
      let file_name = path.extname(files.audio.name);
      //define upload file name store url
      let audio_file_name = uuidv4() + file_name;
      let audio_path = audio_file_name;
      let file_path = "./src/utils/audio/" + audio_file_name;
      fs.mkdirsSync("./src/utils/audio/");
      image_file.mv(file_path, async (err) => {
        if (err) {
          resp.error = true;
          resp.error_message = err;
          return resp;
        } else {
          resolve(audio_path);
        }
      });
    } catch (error) {
      resp.error = true;
      resp.error_message = error;
      return resp;
    }
  });

  return myPromise;
};

const UPLOAD_AND_RESIZE_FILE = async (image_buffer_data, dir, image_size) => {
  const myPromise = new Promise(async (resolve, reject) => {
    try {
      let image_name = uuidv4() + ".jpeg";
      await sharp(image_buffer_data)
        .jpeg({
          quality: 100,
          chromaSubsampling: "4:4:4",
        })
        .resize(image_size)
        .toFile(dir + image_name, async (err, info) => {
          if (err) resolve(false);
        });
      resolve(image_name);
    } catch (error) {
      console.log(error, "error in uploading");
      resolve(false);
    }
  });

  return myPromise;
};

const UPLOAD_S3_IMAGE = async (img_name, dir, image_data) => {
  let response = {};
  let image_file_name = "";
  let savePath = dir;
  image_file_name = img_name;

  sharp(image_data)
    // .resize(300, 300)
    .toBuffer(async (err, info) => {
      if (err) {
        console.log(err, "toBuffer error in uploader");
      } else {
        upload.single("file");
        const s3Client = s3.s3Client;
        const params = s3.uploadParams;
        // console.log(s3.uploadParams);
        params.Key = savePath + image_file_name;
        params.Body = info;
        params.ContentType = "image/jpeg";
        try {
          let result = await s3Client.upload(params).promise();
          response = image_file_name;
        } catch (err) {
          console.log("error in s3 uploading", err);
        }
      }
    });

  return response;
};

const SEND_NOTIFICATION = async (message) => {
  // Send a message to devices subscribed to the provided topic.
  return admin
    .messaging()
    .send(message)
    .then((response) => {
      // Response is a message ID string.
      console.log("Successfully sent message:", response);
    })
    .catch((error) => {
      console.log("Error sending message:", error);
    });
};

const UPLOAD_IMAGE_on_S3 = async (image, image_size_array, FILE_PATH) => {
  const myPromise = new Promise(async (resolve, reject) => {
    let file_extension = path.extname(image.name);
    let main_images_obj = {};
    for (var a = 0; a < image_size_array.length; a++) {
      let height = image_size_array[a].height;
      let width = image_size_array[a].width;
      let path = FILE_PATH + uuidv4() + file_extension;

      sharp(image.data)
        .resize(width, height, {
          fit: sharp.fit.inside,
          withoutEnlargement: true,
        })
        .withMetadata()
        .toBuffer(async (err, info) => {
          if (err) {
            console.log(err, "toBuffer error in uploader");
          } else {
            upload.single("file");
            const s3Client = s3.s3Client;
            const params = s3.uploadParams;
            params.Key = path;
            params.Body = info;
            try {
              let result = await s3Client.upload(params).promise();
            } catch (err) {
              console.log("error in s3 uploading", err);
            }
          }
        });
      let obj_name = image_size_array[a].name;
      let main_image_obj = {
        [obj_name]: path,
      };
      main_images_obj = { ...main_images_obj, ...main_image_obj };
    }
    resolve(main_images_obj);
  });
  return myPromise;
};

const NOTIFY_BY_EMAIL_FROM_SES = async (
  email,
  subject,
  body,
  attachments_file_array = []
) => {
  let email_body = `<!-- [if mso]>
  <style>
    table { border-collapse: collapse; }
    .o_col { float: left; }
  </style>
  <xml>
    <o:OfficeDocumentSettings>
      <o:PixelsPerInch>96</o:PixelsPerInch>
    </o:OfficeDocumentSettings>
  </xml>
  <![endif]--><!-- preview-text -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_hide" style="display: none; font-size: 0; max-height: 0; width: 0; line-height: 0; overflow: hidden; mso-hide: all; visibility: hidden;" align="center">Email Summary (Hidden)</td>
</tr>
</tbody>
</table>
<!-- header-white -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs o_pt-lg o_xs-pt-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px; padding-top: 32px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_px o_py-md o_br-t o_sans o_text" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 16px; line-height: 24px; background-color: #ffffff; border-radius: 4px 4px 0px 0px; padding-left: 16px; padding-right: 16px; padding-top: 15px;" align="center">
<p style="margin-top: 0px; margin-bottom: 0px;"><a class="o_text-primary" style="text-decoration: none; outline: none; color: #126de5;"><img style="max-width: 300px; -ms-interpolation-mode: bicubic; vertical-align: middle; border: 0; line-height: 100%; outline: none; text-decoration: none;" src="https://metalogix-support-portal-app-bucket.s3.amazonaws.com/images/61c197d0-f89b-11ed-8063-f18a55efd589.jpeg" alt="" /></a></p>
</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]--></td>
</tr>
</tbody>
</table>
<!-- hero-white-button -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_px-md o_py-xl o_xs-py-md o_sans o_text-md o_text-light" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 19px; line-height: 28px; background-color: #ffffff; color: #82899a; padding: 34px 24px 64px 24px;" align="center">
<h2 class="o_heading o_text-dark o_mb-xxs" style="font-family: Helvetica, Arial, sans-serif; font-weight: bold; margin-top: 0px; margin-bottom: 4px; color: #242b3d; font-size: 30px; line-height: 39px;">Welcome To Meta Logix Support Center</h2>
<!-- <p class="o_mb-md" style="margin-top: 0px;margin-bottom: 24px;"></p> -->
<table border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td class="o_bg-white o_px-md o_py o_sans o_text o_text-secondary" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 16px; line-height: 24px; background-color: #ffffff; color: #424651; padding: 16px 24px 16px 24px;" align="left">
<p style="margin-top: 20px; margin-bottom: 0px;">${body}<br /> <br /> Thank You <br />Meta Logix Support Center <br />Created by Meta Logix <br /> &nbsp;</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]--></td>
</tr>
</tbody>
</table>
<!-- content --><!-- footer-light-2cols -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs o_pb-lg o_xs-pb-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px; padding-bottom: 32px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_br-b o_sans" style="font-size: 8px; line-height: 8px; height: 8px; font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; background-color: #ffffff; border-radius: 0px 0px 4px 4px;">&nbsp;</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]-->
<div class="o_hide-xs" style="font-size: 64px; line-height: 64px; height: 64px;">&nbsp;</div>
</td>
</tr>
</tbody>
</table>`;

  const SES_CONFIG = {
    accessKeyId: "AKIASFHMCRVPRU4OQX4Q",
    secretAccessKey: "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",
    region: "us-east-1",
  };
  console.log("inisde");
  const AWS_SES = new AWS.SES(SES_CONFIG);

  let params = {
    Source: "Meta Logix Tech<hr@metalogixtech.com>",
    Destination: {
      ToAddresses: [email],
    },
    ReplyToAddresses: ["hr@metalogixtech.com"],
    Message: {
      Body: {
        Html: {
          Charset: "UTF-8",
          Data: email_body,
        },
      },
      Subject: {
        Charset: "UTF-8",
        Data: subject,
      },
    },
  };
  return AWS_SES.sendEmail(params).promise(); // or something
};

const SEND_EMAIL_BY_SES = async (
  email,
  subject,
  body,
  attachments_file_array = []
) => {
  let email_body = `<!-- [if mso]>
  <style>
    table { border-collapse: collapse; }
    .o_col { float: left; }
  </style>
  <xml>
    <o:OfficeDocumentSettings>
      <o:PixelsPerInch>96</o:PixelsPerInch>
    </o:OfficeDocumentSettings>
  </xml>
  <![endif]--><!-- preview-text -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_hide" style="display: none; font-size: 0; max-height: 0; width: 0; line-height: 0; overflow: hidden; mso-hide: all; visibility: hidden;" align="center">Email Summary (Hidden)</td>
</tr>
</tbody>
</table>
<!-- header-white -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs o_pt-lg o_xs-pt-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px; padding-top: 32px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_px o_py-md o_br-t o_sans o_text" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 16px; line-height: 24px; background-color: #ffffff; border-radius: 4px 4px 0px 0px; padding-left: 16px; padding-right: 16px; padding-top: 15px;" align="center">
<p style="margin-top: 0px; margin-bottom: 0px;"><a class="o_text-primary" style="text-decoration: none; outline: none; color: #126de5;"><img style="max-width: 300px; -ms-interpolation-mode: bicubic; vertical-align: middle; border: 0; line-height: 100%; outline: none; text-decoration: none;" src="https://metalogix-support-portal-app-bucket.s3.amazonaws.com/images/61c197d0-f89b-11ed-8063-f18a55efd589.jpeg" alt="" /></a></p>
</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]--></td>
</tr>
</tbody>
</table>
<!-- hero-white-button -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_px-md o_py-xl o_xs-py-md o_sans o_text-md o_text-light" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 19px; line-height: 28px; background-color: #ffffff; color: #82899a; padding: 34px 24px 64px 24px;" align="center">
<h2 class="o_heading o_text-dark o_mb-xxs" style="font-family: Helvetica, Arial, sans-serif; font-weight: bold; margin-top: 0px; margin-bottom: 4px; color: #242b3d; font-size: 30px; line-height: 39px;">Welcome To Meta Logix Support Center</h2>
<!-- <p class="o_mb-md" style="margin-top: 0px;margin-bottom: 24px;"></p> -->
<table border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td class="o_bg-white o_px-md o_py o_sans o_text o_text-secondary" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 16px; line-height: 24px; background-color: #ffffff; color: #424651; padding: 16px 24px 16px 24px;" align="left">
<p style="margin-top: 20px; margin-bottom: 0px;">${body}<br /> <br /> Thank You <br />Meta Logix Support Center <br />Created by Meta Logix <br /> &nbsp;</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]--></td>
</tr>
</tbody>
</table>
<!-- content --><!-- footer-light-2cols -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs o_pb-lg o_xs-pb-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px; padding-bottom: 32px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_br-b o_sans" style="font-size: 8px; line-height: 8px; height: 8px; font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; background-color: #ffffff; border-radius: 0px 0px 4px 4px;">&nbsp;</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]-->
<div class="o_hide-xs" style="font-size: 64px; line-height: 64px; height: 64px;">&nbsp;</div>
</td>
</tr>
</tbody>
</table>`;

  const ses = new AWS.SES({
    apiVersion: "2010-12-01",
    region: "us-east-1",
    credentials: {
      secretAccessKey: "gWRdB96FO2LdjiGyDQa/XNLRaZ/amZS57XQSr19v",
      accessKeyId: "AKIASFHMCRVPRU4OQX4Q",
    },
  });

  const attachments = await Promise.all(
    attachments_file_array.map(async (fileUrl) => {
      const response = await axios.get(fileUrl, {
        responseType: "arraybuffer",
      });
      return {
        filename: path.basename(fileUrl),
        content: response.data,
        contentType: response.headers["content-type"],
      };
    })
  );

  // // create Nodemailer SES transporter
  let transporter = nodemailer.createTransport({
    SES: { ses, aws: AWS },
  });
  // send mail with defined transport object
  let info = await transporter.sendMail({
    from: "Meta Logix Tech<hr@metalogixtech.com>",
    replyTo: "hr@metalogixtech.com",
    to: email,
    subject: subject, // Subject line
    // text: email_body, // plaintext version
    html: email_body, // html version
    attachments: attachments,
  });

  return info; // or something
};

const SEND_EMAIL_BY_ML_MS = async (email, subject, body, attachment_path) => {
  let email_body = `<!-- [if mso]>
  <style>
    table { border-collapse: collapse; }
    .o_col { float: left; }
  </style>
  <xml>
    <o:OfficeDocumentSettings>
      <o:PixelsPerInch>96</o:PixelsPerInch>
    </o:OfficeDocumentSettings>
  </xml>
  <![endif]--><!-- preview-text -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_hide" style="display: none; font-size: 0; max-height: 0; width: 0; line-height: 0; overflow: hidden; mso-hide: all; visibility: hidden;" align="center">Email Summary (Hidden)</td>
</tr>
</tbody>
</table>
<!-- header-white -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs o_pt-lg o_xs-pt-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px; padding-top: 32px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_px o_py-md o_br-t o_sans o_text" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 16px; line-height: 24px; background-color: #ffffff; border-radius: 4px 4px 0px 0px; padding-left: 16px; padding-right: 16px; padding-top: 15px;" align="center">
<p style="margin-top: 0px; margin-bottom: 0px;"><a class="o_text-primary" style="text-decoration: none; outline: none; color: #126de5;"><img style="max-width: 300px; -ms-interpolation-mode: bicubic; vertical-align: middle; border: 0; line-height: 100%; outline: none; text-decoration: none;" src="https://metalogix-support-portal-app-bucket.s3.amazonaws.com/images/8ed76f10-4170-11ee-81be-991f320e840c.jpeg" alt="" /></a></p>
</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]--></td>
</tr>
</tbody>
</table>
<!-- hero-white-button -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_px-md o_py-xl o_xs-py-md o_sans o_text-md o_text-light" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 19px; line-height: 28px; background-color: #ffffff; color: #82899a; padding: 34px 24px 64px 24px;" align="center">
<h2 class="o_heading o_text-dark o_mb-xxs" style="font-family: Helvetica, Arial, sans-serif; font-weight: bold; margin-top: 0px; margin-bottom: 4px; color: #242b3d; font-size: 30px; line-height: 39px;">Welcome To Meta Logix Support Center</h2>
<!-- <p class="o_mb-md" style="margin-top: 0px;margin-bottom: 24px;"></p> -->
<table border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td class="o_bg-white o_px-md o_py o_sans o_text o_text-secondary" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 16px; line-height: 24px; background-color: #ffffff; color: #424651; padding: 16px 24px 16px 24px;" align="left">
<p style="margin-top: 20px; margin-bottom: 0px;">${body}<br /> <br /> Thank You <br />Meta Logix Support Center <br />Created by Meta Logix <br /> &nbsp;</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]--></td>
</tr>
</tbody>
</table>
<!-- content --><!-- footer-light-2cols -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs o_pb-lg o_xs-pb-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px; padding-bottom: 32px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_br-b o_sans" style="font-size: 8px; line-height: 8px; height: 8px; font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; background-color: #ffffff; border-radius: 0px 0px 4px 4px;">&nbsp;</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]-->
<div class="o_hide-xs" style="font-size: 64px; line-height: 64px; height: 64px;">&nbsp;</div>
</td>
</tr>
</tbody>
</table>`;

  let final_email_obj = {
    email_from: "support@mail.metalogixtech.com",
    reciever: email,
    subject: subject,
    html: email_body,
    attachment: attachment_path,
  };

  // console.log("final_email_obj: ", final_email_obj);

  try {
    let requestObj = {
      url: "https://mailserverapi.devflips.com/api/customer/send_email_without_auth",
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
    };
    requestObj["postData"] = final_email_obj;
    const result = await invokeApi(requestObj);
    if (result.code === 200) {
      let result_obj = {
        code: result.code,
        message: result.message,
      };
      console.log("Email sent successfully");
      return result_obj;
    }
    return result;
  } catch (err) {
    console.error(err);
    return err;
  }
};

const UPLOAD_DOCUMENT_ON_SERVER = async (data, dir) => {
  fs.writeFile(dir, data, (err) => {
    // throws an error, you could also catch it here
    if (err) {
      console.log("File not saved!   ", err);
      return err;
    } else {
      console.log("File saved!");
      return 200;
    }
  });
};

const READ_CSV_FILE = async (path) => {
  return new Promise((resolve, reject) => {
    // console.log(path);
    let array_of_records = [];
    const csv_file = s3.s3Client
      .getObject({ Bucket: process.env.Bucket, Key: path })
      .createReadStream();
    // console.log("File got successfully");
    csv_file
      .pipe(csv_parser())
      .on("data", async (row) => {
        // console.log(row);
        let rec_obj = {
          emp_id: row["AC-No."],
          name: row["Name"],
          date: row["Date"],
          check_in: row["Clock In"],
          check_out: row["Clock Out"],
          relax_time: row["Normal"],
          late: row["Late"],
          early: row["Early"],
          absent: row["Absent"],
        };
        // console.log(rec_obj.absent.toLowerCase());
        array_of_records.push(rec_obj);
      })
      .on("error", (err) => {
        reject(err);
      })
      .on("end", () => {
        console.log("CSV file successfully processed");
        resolve(array_of_records);
      });
  });
};

const UPLOAD_SINGLE_FILE_on_S3 = async (
  file,
  FILE_PATH,
  file_extension,
  width,
  height = 670
) => {
  let resp = {};
  if (
    file_extension == ".pdf" ||
    file_extension == ".PDF" ||
    file_extension == ".EXCEL" ||
    file_extension == ".excel" ||
    file_extension == ".DOCX" ||
    file_extension == ".docx" ||
    file_extension == ".mp3" ||
    file_extension == ".XLSX" ||
    file_extension == ".xlsx" ||
    file_extension == ".XLS" ||
    file_extension == ".xls" ||
    file_extension == ".CSV" ||
    file_extension == ".csv" ||
    file_extension == ".DOC" ||
    file_extension == ".doc"
  ) {
    const myPromise = new Promise(async (resolve, reject) => {
      let path = FILE_PATH + uuidv4() + file_extension;

      upload.single("file");
      const s3Client = s3.s3Client;
      const params = s3.uploadParams;
      // console.log(params);
      params.Key = path;
      params.Body = file.data;
      try {
        await s3Client.upload(params).promise();
      } catch (err) {
        resp.error = true;
        resp.error_message = err.message;
        reject(resp);
      }

      resolve(path);
    });
    return myPromise;
  } else {
    const myPromise = new Promise(async (resolve, reject) => {
      let path = FILE_PATH + uuidv4() + file_extension;
      sharp(file.data)
        .resize(width, height, {
          fit: sharp.fit.inside,
          withoutEnlargement: true,
        })
        .toBuffer(async (err, info) => {
          if (err) {
            resp.error = true;
            resp.error_message = err.message;
            reject(resp);
          } else {
            upload.single("file");
            const s3Client = s3.s3Client;
            const params = s3.uploadParams;
            params.Key = path;
            params.Body = file.data;
            try {
              let result = await s3Client.upload(params).promise();
            } catch (err) {
              console.log("error in s3 uploading", err);
              resp.error = true;
              resp.error_message = err.message;
              reject(resp);
            }
          }
        });
      resolve(path);
    });
    return myPromise;
  }
};

const UPLOAD_ANY_SINGLE_FILE_ON_S3 = async (
  file,
  FILE_PATH,
  file_extension
) => {
  let resp = {};

  const myPromise = new Promise(async (resolve, reject) => {
    let path = FILE_PATH + uuidv4() + file_extension;

    upload.single("file");
    const s3Client = s3.s3Client;
    const params = s3.uploadParams;
    // console.log(params);
    params.Key = path;
    params.Body = file.data;
    try {
      await s3Client.upload(params).promise();
    } catch (err) {
      resp.error = true;
      resp.error_message = err.message;
      reject(resp);
    }

    resolve(path);
  });
  return myPromise;
};

const DELETE_FILES_FROM_S3 = async (file_url) => {
  console.log("file_url: ", file_url);
  let resp = {};
  const myPromise = new Promise(async (resolve, reject) => {
    let savePath = file_url;
    const s3Client = s3.s3Client;

    // console.log(s3.uploadParams.Bucket);
    var params = {
      Bucket: s3.uploadParams.Bucket,
      Key: savePath,
    };
    console.log("params: ", params);
    try {
      s3Client.deleteObject(params, function (err, data) {
        if (err) {
          resp.error = true;
          resp.error_message = err.message;
          reject(resp); // error
        } else {
          console.log("S3 file Deleted"); // deleted
          resolve(savePath);
        }
      });
    } catch (err) {
      resp.error = true;
      resp.error_message = err.message;
      reject(resp);
    }
  });
  return myPromise;
};

const UPLOAD_FILE_on_S3_with_CONTENT_TYPE = async (
  data,
  FILE_PATH,
  file_extension,
  content_type
) => {
  let resp = {};

  const myPromise = new Promise(async (resolve, reject) => {
    let path = FILE_PATH + uuidv4() + file_extension;
    // console.log("data to upload: ", data);

    upload.single("file");
    const s3Client = s3.s3Client;
    const params = s3.uploadParams;
    // console.log("s3Client: ", s3Client);

    params.Key = path;
    params.Body = data;
    params.ContentType = content_type;

    // console.log("params: ", params);
    try {
      console.log("Trying to upload the file");
      const result = await s3Client.upload(params).promise();
      // console.log("Upload successful - result: ", result);
    } catch (err) {
      resp.error = true;
      resp.error_message = err.message;
      reject(resp);
    }

    resolve(path);
  });
  return myPromise;

  // let path = FILE_PATH + uuidv4() + file_extension;
  // upload.single("file");
  // const s3Client = s3.s3Client;
  // const params = s3.uploadParams;
  // params.Key = path;
  // params.Body = data;
  // params.ContentType = content_type;
  // s3Client.upload(params, function (s3Err, data) {
  //   if (s3Err) throw s3Err;
  //   //console.log(`File uploaded successfully at ${data.Location}`);
  // });
  // var myPromise = new Promise(function (myResolve, myReject) {
  //   myResolve(path);
  // });
  // return myPromise;
};

const GENERATE_PAYSLIP_PDF = async (
  html,
  data,
  options = {
    printBackground: true,
    margin: {
      top: "0.7in",
      right: "0.7in",
      bottom: "0.7in",
      left: "0.7in",
    },
    format: "A4",
  }
) => {
  let html_body = html;
  console.log("data: ", data);
  let emp_id = data.emp_id ? data.emp_id : "";
  let emp_name = data.emp_name ? data.emp_name : "";
  let designation = data.designation ? data.designation : "";
  let monthYear = `${moment(data.month, "MM").format("MMMM")} ${data.year}`;
  let basic_salary = data.basic_salary ? data.basic_salary : 0;
  let conveyance_allowance = data.conveyance_allowance
    ? data.conveyance_allowance
    : 0;
  // let education_allowance = data.education_allowance
  //   ? data.education_allowance
  //   : 0;
  let medical_allowance = data.medical_allowance ? data.medical_allowance : 0;
  let rent_allowance = data.rent_allowance ? data.rent_allowance : 0;
  let food_allowance = data.food_allowance ? data.food_allowance : 0;
  let other_payment = data.other_payment ? data.other_payment : 0;
  let commission = data.commission ? data.commission : 0;
  let overtime = data.overtime ? data.overtime : 0;
  let loan = data.loan ? data.loan : 0;
  let monthly_tax = data.monthly_tax ? data.monthly_tax : 0;
  let loan_deduction = data.loan_deduction ? data.loan_deduction : 0;
  let lunch_deduction = data.lunch_deduction ? data.lunch_deduction : 0;
  let fine_deduction = data.fine_deduction ? data.fine_deduction : 0;
  let totalEarning =
    basic_salary +
    conveyance_allowance +
    medical_allowance +
    rent_allowance +
    food_allowance +
    other_payment +
    commission +
    overtime +
    loan;
  // education_allowance
  let totalDeduction =
    monthly_tax + loan_deduction + lunch_deduction + fine_deduction;
  let net_salary = data.net_salary ? data.net_salary : 0;

  html_body = eval("`" + html_body + "`");

  // const browserFetcher = puppeteer.createBrowserFetcher();
  // let revisionInfo = await browserFetcher.download("884014");

  const browser = await puppeteer.launch({
    // executablePath: "/usr/bin/chromium-browser",
    args: ["--no-sandbox", "--disable-setuid-sandbox"],
    headless: false,
    executablePath: puppeteer.executablePath(),
    // ignoreDefaultArgs: ["--disable-extensions"],
  });

  const page = await browser.newPage();

  await page.setContent(html_body, {
    waitUntil: "networkidle0",
  });

  const pdf = await page.pdf(options);

  // close the browser
  await browser.close();

  let file_to_send = {
    filename: "payslip.pdf",
    content: pdf,
  };

  console.log("file_to_send: ", file_to_send);
  // Save PDF file to s3
  let upload_file = await UPLOAD_FILE_on_S3_with_CONTENT_TYPE(
    pdf,
    `payslips/`,
    ".pdf",
    "application/pdf"
  );
  console.log("upload_file: ", upload_file);

  return {
    pdf: file_to_send,
    url: upload_file,
  };
};

const SEND_PAYSLIP_TO_EMAIL_FROM_SES = async (
  email,
  subject,
  body,
  attachments_file_array = []
) => {
  let email_body = `<!-- [if mso]>
  <style>
    table { border-collapse: collapse; }
    .o_col { float: left; }
  </style>
  <xml>
    <o:OfficeDocumentSettings>
      <o:PixelsPerInch>96</o:PixelsPerInch>
    </o:OfficeDocumentSettings>
  </xml>
  <![endif]--><!-- preview-text -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_hide" style="display: none; font-size: 0; max-height: 0; width: 0; line-height: 0; overflow: hidden; mso-hide: all; visibility: hidden;" align="center">Email Summary (Hidden)</td>
</tr>
</tbody>
</table>
<!-- header-white -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs o_pt-lg o_xs-pt-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px; padding-top: 32px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_px o_py-md o_br-t o_sans o_text" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 16px; line-height: 24px; background-color: #ffffff; border-radius: 4px 4px 0px 0px; padding-left: 16px; padding-right: 16px; padding-top: 15px;" align="center">
<p style="margin-top: 0px; margin-bottom: 0px;"><a class="o_text-primary" style="text-decoration: none; outline: none; color: #126de5;"><img style="max-width: 300px; -ms-interpolation-mode: bicubic; vertical-align: middle; border: 0; line-height: 100%; outline: none; text-decoration: none;" src="https://metalogix-support-portal-app-bucket.s3.amazonaws.com/images/61c197d0-f89b-11ed-8063-f18a55efd589.jpeg" alt="" /></a></p>
</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]--></td>
</tr>
</tbody>
</table>
<!-- hero-white-button -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_px-md o_py-xl o_xs-py-md o_sans o_text-md o_text-light" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 19px; line-height: 28px; background-color: #ffffff; color: #82899a; padding: 34px 24px 64px 24px;" align="center">
<h2 class="o_heading o_text-dark o_mb-xxs" style="font-family: Helvetica, Arial, sans-serif; font-weight: bold; margin-top: 0px; margin-bottom: 4px; color: #242b3d; font-size: 30px; line-height: 39px;">Welcome To Meta Logix Support Center</h2>
<!-- <p class="o_mb-md" style="margin-top: 0px;margin-bottom: 24px;"></p> -->
<table border="0" cellspacing="0" cellpadding="0" align="center">
<tbody>
<tr>
<td class="o_bg-white o_px-md o_py o_sans o_text o_text-secondary" style="font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; font-size: 16px; line-height: 24px; background-color: #ffffff; color: #424651; padding: 16px 24px 16px 24px;" align="left">
<p style="margin-top: 20px; margin-bottom: 0px;">${body.url}<br /> <br /> Thank You <br />Meta Logix Support Center <br />Created by Meta Logix <br /> &nbsp;</p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]--></td>
</tr>
</tbody>
</table>
<!-- content --><!-- footer-light-2cols -->
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-light o_px-xs o_pb-lg o_xs-pb-xs" style="background-color: #dbe5ea; padding-left: 8px; padding-right: 8px; padding-bottom: 32px;" align="center"><!-- [if mso]><table width="432" cellspacing="0" cellpadding="0" border="0" role="presentation"><tbody><tr><td><![endif]-->
<table class="o_block-xs" style="max-width: 432px; margin: 0 auto;" border="0" width="100%" cellspacing="0" cellpadding="0">
<tbody>
<tr>
<td class="o_bg-white o_br-b o_sans" style="font-size: 8px; line-height: 8px; height: 8px; font-family: Helvetica, Arial, sans-serif; margin-top: 0px; margin-bottom: 0px; background-color: #ffffff; border-radius: 0px 0px 4px 4px;">&nbsp;</td>
</tr>
</tbody>
</table>
<!-- [if mso]></td></tr></table><![endif]-->
<div class="o_hide-xs" style="font-size: 64px; line-height: 64px; height: 64px;">&nbsp;</div>
</td>
</tr>
</tbody>
</table>`;

  const SES_CONFIG = {
    accessKeyId: "AKIASFHMCRVP4TAAGH65",
    secretAccessKey: "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",
    region: "us-east-1",
  };
  console.log("inisde");
  const AWS_SES = new AWS.SES(SES_CONFIG);

  let params = {
    Source: "Meta Logix Tech<hr@metalogixtech.com>",
    Destination: {
      ToAddresses: [email],
    },
    ReplyToAddresses: ["hr@metalogixtech.com"],
    Message: {
      Body: {
        Html: {
          Charset: "UTF-8",
          Data: email_body,
        },
      },
      Subject: {
        Charset: "UTF-8",
        Data: subject,
      },
    },
  };
  return AWS_SES.sendEmail(params).promise(); // or something
};

const CREATE_PAYSLIP_PDF = async (html) => {
  let options = {
    format: "A4",
    border: {
      top: "1cm",
      right: "1cm",
      left: "1cm",
      bottom: "1cm",
    },
    header: {
      height: "2mm",
    },
    footer: {
      height: "2mm",
    },
  };

  // var options = {
  //   format: "A4",
  //   //border: '1',
  //   border: {
  //     top: "0.7in",
  //     right: "0.7in",
  //     left: "0.7in",
  //     bottom: "0.7in",
  //   },
  //   // border: {
  //   //   top: "2in",
  //   //   right: "1in",
  //   //   bottom: "2in",
  //   //   left: "1.5in",
  //   // },
  //   // margin: { top: "0.7in", right: "0.7in", left: "0.7in", bottom: "0.7in" },
  //   header: {
  //     height: "2mm",
  //   },
  //   footer: {
  //     height: "2mm",
  //   },
  // };
  //let options = { format: 'A4' };

  // require("../utils/files")
  // let path = "../utils/files/" + uuidv4() + ".pdf";
  // console.log("path: ", path);
  // const pdf_file = pdf.create(html, options).toFile(path, function (err, res) {
  //   console.log("inside the file creation");
  //   if (err) return console.log(err);
  //   console.log(res);
  //   return res;
  // });
  // const pdf_file = new Promise(
  //   pdf.create(html, options).toBuffer(function (err, buffer) {
  //     console.log("inside the buffer: ", buffer);
  //     if (err) return console.log(err);
  //     console.log(buffer);
  //     return buffer;
  //   })
  // );

  let path = "./src/utils/files/" + uuidv4() + ".pdf";
  return new Promise((resolve, reject) => {
    pdf.create(html, options).toFile(path, function (err, res) {
      if (err) {
        console.error(err);
        reject(err);
      } else {
        // console.log("inside the res: ", res);
        resolve(res);
      }
    });
  });

  // return new Promise((resolve, reject) => {
  //   pdf.create(html, options).toBuffer(function (err, buffer) {
  //     if (err) {
  //       console.error(err);
  //       reject(err);
  //     } else {
  //       // console.log("inside the buffer: ", buffer);
  //       resolve(buffer);
  //     }
  //   });
  // });

  // let path = "./src/utils/files/" + uuidv4() + ".pdf";
  // return new Promise((resolve, reject) => {
  //   pdf.create(html, options).toStream(function (err, stream) {
  //     if (err) {
  //       console.error(err);
  //       reject(err);
  //     } else {
  //       console.log("inside the stream: ", stream);
  //       stream.pipe(fs.createWriteStream(path));
  //       resolve(path);
  //     }
  //   });
  // });
};

const APPROVED_LEAVES_BY_SYSTEM = async () => {
  //find date before one week with moment

  let date = moment().subtract(7, "days").format("YYYY-MM-DD");

  // //update many  and set status to approved and approved_by to system

  const update = await LeaveRequest.updateMany(
    {
      status: "pending",
      leave_date: { $lte: date },
    },
    {
      status: "approved",
      approved_by: "system",
    }
  );

  console.log("update: ", update);
};

const DELETE_OLD_API_LOGS = async () => {
  let get_27th_of_last_month = moment()
    .subtract(1, "month")
    .date(27)
    .startOf("day");

  let new_date = get_27th_of_last_month.format();

  await APILog.deleteMany({
    createdAt: { $lte: new_date },
  });
};

module.exports = {
  RENDER_BAD_REQUEST,
  MAX_ORDER,
  CHANGE_DEL_ORDER,
  ORDER_CHANGE_TO_LOWER,
  ORDER_CHANGE_TO_UPPER,
  SEND_EMAIL,
  UPLOAD_AND_RESIZE_FILE,
  UPLOAD_AUDIO_FILE,
  UPLOAD_S3_IMAGE,
  UPLOAD_IMAGE_on_S3,
  SEND_NOTIFICATION,
  NOTIFY_BY_EMAIL_FROM_SES,
  UPLOAD_DOCUMENT_ON_SERVER,
  READ_CSV_FILE,
  UPLOAD_SINGLE_FILE_on_S3,
  UPLOAD_ANY_SINGLE_FILE_ON_S3,
  DELETE_FILES_FROM_S3,
  UPLOAD_FILE_on_S3_with_CONTENT_TYPE,
  GENERATE_PAYSLIP_PDF,
  SEND_PAYSLIP_TO_EMAIL_FROM_SES,
  CREATE_PAYSLIP_PDF,
  SEND_EMAIL_BY_ML_MS,
  APPROVED_LEAVES_BY_SYSTEM,
  DELETE_OLD_API_LOGS,
  SEND_EMAIL_BY_SES,
};
