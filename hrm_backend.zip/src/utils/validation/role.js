const Joi = require("joi");

function validate_add_role(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
  };
  return Joi.validate(body, schema);
}
function validate_edit_role(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    order: Joi.number().required(),
    active_status: Joi.boolean().required(),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_role,
  validate_edit_role,
};
