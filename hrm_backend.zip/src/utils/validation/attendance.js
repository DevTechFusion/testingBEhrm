const Joi = require("joi");

function validate_add_attendance_manually(body) {
  const schema = {
    emp_obj_id: Joi.string().required(),
    emp_name: Joi.string().required(),
    emp_id: Joi.number().required(),
    month: Joi.number().required(),
    year: Joi.number().required(),
    attendance: Joi.object({
      date: Joi.string().trim().allow(""),
      check_in: Joi.string().trim().allow(""),
      check_out: Joi.string().trim().allow(""),
      relax_time: Joi.string().trim().allow(""),
      absent: Joi.boolean(),
      half_leave_type: Joi.string().valid("first_half", "second_half", ""),
    }),
  };
  return Joi.validate(body, schema);
}

function validate_get_attendance_for_employee_user(body) {
  const schema = {
    date_from: Joi.string().allow(""),
    date_to: Joi.string().allow(""),
    absent: Joi.boolean().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_get_attendance_for_fine(body) {
  const schema = {
    month: Joi.number().allow(""),
    year: Joi.number().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_grant_relax_minutes(body) {
  const schema = {
    month: Joi.number().allow(""),
    year: Joi.number().allow(""),
    final_attendance: Joi.array().min(1),
  };
  return Joi.validate(body, schema);
}

function validate_get_finesheet(body) {
  const schema = {
    month: Joi.number().allow(""),
    name: Joi.string().allow(""),
    year: Joi.number().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_pay_fine(body) {
  const schema = {
    emp_obj_id: Joi.string().required(),
    month: Joi.number().required(),
    year: Joi.number().required(),
    paid_status: Joi.boolean().required(),
  };
  return Joi.validate(body, schema);
}

function validate_get_absents(body) {
  const schema = {
    emp_obj_id: Joi.string().required(),
    month: Joi.number().allow(""),
    year: Joi.number().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_employee_leaves(body) {
  const schema = {
    emp_obj_id: Joi.string().required(),
    count_in_yearly_leaves : Joi.string().required().valid("all","true", "false"),
    date_from: Joi.string().required(),
    date_to: Joi.string().required(),
  };
  return Joi.validate(body, schema);
}

function validate_employee_leaves_for_report(body) {
  const schema = {
    emp_obj_id: Joi.string().required(),
    date_from: Joi.string().required(),
    date_to: Joi.string().required(),
    absent: Joi.boolean().required(),
  };
  return Joi.validate(body, schema);
}

function validate_get_attendance_v1(body) {
  const schema = {
    filter_type: Joi.string().required().valid("all", "month", "date"),
    month: Joi.number().allow(""),
    year: Joi.number().allow(""),
    date_from: Joi.date().allow(""),
    date_to: Joi.date().allow(""),
    employee_id: Joi.string().allow(""),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_attendance_manually,
  validate_get_attendance_for_employee_user,
  validate_get_attendance_for_fine,
  validate_grant_relax_minutes,
  validate_get_finesheet,
  validate_pay_fine,
  validate_get_absents,
  validate_employee_leaves,
  validate_employee_leaves_for_report,
  validate_get_attendance_v1,
};
