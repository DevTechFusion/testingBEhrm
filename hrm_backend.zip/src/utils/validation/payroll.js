const Joi = require("joi");

function validate_add_payroll(body) {
  const schema = {
    is_send_email: Joi.boolean().required(),
    payroll: Joi.array()
      .items(
        Joi.object({
          emp_obj_id: Joi.string().trim().required(),
          emp_name: Joi.string().trim().required(),
          month: Joi.number().required(),
          year: Joi.number().required(),
          basic_salary: Joi.number().required(),
          conveyance_allowance: Joi.number().allow("", null),
          // education_allowance: Joi.number().required(),
          medical_allowance: Joi.number().allow("", null),
          // rent_allowance: Joi.number().required(),
          food_allowance: Joi.number().allow("", null),
          other_payment: Joi.any().allow("", null),
          commission: Joi.number().allow("", null),
          overtime: Joi.number().allow("", null),
          loan: Joi.number().allow("", null),
          monthly_tax: Joi.number().required(),
          tax_file: Joi.string().trim().allow(""),
          net_salary: Joi.number().required(),
          loan_deduction: Joi.number().allow("", null),
          lunch_deduction: Joi.number().required(),
          fine_deduction: Joi.number().required(),
          other_deduction: Joi.any().allow("", null),
          other_deduction_label: Joi.string().allow("", null),
          other_payment_label: Joi.string().allow("", null),
          gross_salary: Joi.number().required(),
          gross_earnings: Joi.number().required(),
          is_included_general_allowances: Joi.boolean().required(),
          total_allowances: Joi.number().required(),
          total_deductions: Joi.number().required(),
          general_allowances: Joi.array()
            .items(
              Joi.object({
                title: Joi.string().trim().required(),
                amount: Joi.number().required(),
              })
            )
            .optional(),
          other_deductions: Joi.array()
            .items(
              Joi.object({
                title: Joi.string().trim().required(),
                amount: Joi.number().required(),
              })
            )
            .optional(),
          other_allowances: Joi.array()
            .items(
              Joi.object({
                title: Joi.string().trim().required(),
                amount: Joi.number().required(),
              })
            )
            .optional(),
        })
      )
      .min(1),
  };
  return Joi.validate(body, schema);
}
function validate_edit_payroll(body) {
  const schema = {
    is_send_email: Joi.boolean().required(),
    emp_obj_id: Joi.string().trim().required(),
    emp_name: Joi.string().trim().required(),
    month: Joi.number().required(),
    year: Joi.number().required(),
    basic_salary: Joi.number().required(),
    conveyance_allowance: Joi.number().allow("", null),
    // education_allowance: Joi.number().required(),
    medical_allowance: Joi.number().allow("", null),
    // rent_allowance: Joi.number().required(),
    food_allowance: Joi.number().allow("", null),
    other_payment: Joi.number().required(),
    commission: Joi.number().allow("", null),
    overtime: Joi.number().allow("", null),
    loan: Joi.number().allow("", null),
    monthly_tax: Joi.number().required(),
    tax_file: Joi.string().trim().allow(""),
    net_salary: Joi.number().required(),
    loan_deduction: Joi.number().allow("", null),
    lunch_deduction: Joi.number().required(),
    fine_deduction: Joi.number().required(),
    other_deduction: Joi.number().allow("", null),
    other_deduction_label: Joi.string().allow("", null),
    other_payment_label: Joi.string().allow("", null),
    gross_salary: Joi.number().required(),
    gross_earnings: Joi.number().required(),
    is_included_general_allowances: Joi.boolean().required(),
    total_allowances: Joi.number().required(),
    total_deductions: Joi.number().required(),
    general_allowances: Joi.array()
      .items(
        Joi.object({
          title: Joi.string().trim().required(),
          amount: Joi.number().required(),
        })
      )
      .optional(),
    other_deductions: Joi.array()
      .items(
        Joi.object({
          title: Joi.string().trim().required(),
          amount: Joi.number().required(),
        })
      )
      .optional(),
    other_allowances: Joi.array()
      .items(
        Joi.object({
          title: Joi.string().trim().required(),
          amount: Joi.number().required(),
        })
      )
      .optional(),
  };
  return Joi.validate(body, schema);
}

function validate_search_payroll(body) {
  const schema = {
    // month: Joi.number().allow(""),
    // year: Joi.number().allow(""),
    date_from: Joi.string().required(),
    date_to: Joi.string().required(),
    search: Joi.string().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_email_payslip(body) {
  const schema = {
    employees: Joi.array()
      .items(
        Joi.object({
          _id: Joi.string().trim().required(),
          full_name: Joi.string().trim().required(),
          designation: Joi.string().trim().required(),
          webmail_email: Joi.string().trim().required(),
          employee_id: Joi.number().required(),
          bank_account: Joi.string().trim().allow(""),
          month: Joi.number().required(),
          year: Joi.number().required(),
        })
      )
      .min(1),
  };
  return Joi.validate(body, schema);
}

function validate_delete_payroll(body) {
  const schema = {
    date_from: Joi.string().required(),
    date_to: Joi.string().required(),
  };
  return Joi.validate(body, schema);
}

function validate_send_payslip_again(body) {
  const schema = {
    payroll_id: Joi.string().required(),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_payroll,
  validate_edit_payroll,
  validate_search_payroll,
  validate_email_payslip,
  validate_delete_payroll,
  validate_send_payslip_again,
};
