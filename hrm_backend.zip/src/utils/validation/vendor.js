const Joi = require("joi");

function validate_add_vendor(body) {
  const schema = {
    name: Joi.string().required().min(2).trim(),
    email: Joi.string().trim().email().allow(""),
    contact_number: Joi.string().trim().allow(""),
    address: Joi.string().trim(),
    image: Joi.string().label("image").allow(""),
  };
  return Joi.validate(body, schema);
}
function validate_edit_vendor(body) {
  const schema = {
    name: Joi.string().required().min(2).trim(),
    email: Joi.string().trim().email().allow(""),
    contact_number: Joi.string().trim().allow(""),
    address: Joi.string().trim(),
    active_status: Joi.boolean().required(),
    image: Joi.string().label("image").allow(""),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_vendor,
  validate_edit_vendor,
};
