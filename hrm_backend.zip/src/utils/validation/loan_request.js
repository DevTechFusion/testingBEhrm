const Joi = require("joi");

function validate_add_loan_request(body) {
  const schema = {
    amount: Joi.number().required(),
    description: Joi.string().required().trim(),
    loan_type: Joi.string().valid("advance_salary", "general"),
    installments: Joi.array().when("loan_type", {
      is: "general",
      then: Joi.array()
        .items(
          Joi.object({
            amount: Joi.number().required(),
            due_date: Joi.string().required().trim(),
          })
        )
        .required()
        .min(1),

      otherwise: Joi.array().forbidden(),
    }),
    no_of_installments: Joi.number().allow("", 0),
    installment_start_from: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}
function validate_edit_loan_request(body) {
  const schema = {
    amount: Joi.number().required(),
    description: Joi.string().required().trim(),
    loan_type: Joi.string().valid("advance_salary", "general"),
    installments: Joi.array().when("loan_type", {
      is: "general",
      then: Joi.array()
        .items(
          Joi.object({
            amount: Joi.number().required(),
            due_date: Joi.string().required().trim(),
            status: Joi.string().valid("paid", "pending"),
            payment_method: Joi.string()
              .valid("cheque", "cash", "account", "")
              .allow("", null),
            payment_date: Joi.string().trim().allow("", null),
          })
        )
        .required()
        .min(1),
      otherwise: Joi.array().forbidden(),
    }),

    no_of_installments: Joi.number().allow("", 0),
    installment_start_from: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_process_loan_request(body) {
  const schema = {
    status: Joi.string().valid("pending", "approved", "rejected", "returned"),
    payment_method: Joi.string().valid("cheque", "cash", "account", ""),
    rejection_reason: Joi.string().allow(""),
    release_date: Joi.string().trim(),
  };
  return Joi.validate(body, schema);
}

function validate_search_loan_request(body) {
  const schema = {
    search: Joi.string().allow(""),
    tab: Joi.string().valid("all", "active", "returned")
    // date_from: Joi.string().trim().allow(""),
    // date_to: Joi.string().trim().allow(""),
    // status: Joi.string().valid("pending", "approved", "rejected", ""),
    // loan_type: Joi.string().valid("advance_salary", "general", ""),
  };
  return Joi.validate(body, schema);
}

function validate_add_loan_request_admin(body) {
  const schema = {
    emp_obj_id: Joi.string().required(),
    amount: Joi.number().required(),
    description: Joi.string().required().trim(),
    loan_type: Joi.string().valid("advance_salary", "general"),
    installments: Joi.array().when("loan_type", {
      is: "general",
      then: Joi.array()
        .items(
          Joi.object({
            amount: Joi.number().required(),
            due_date: Joi.string().required().trim(),
            // status: Joi.string().valid("paid", "pending"),
            // payment_method: Joi.string().valid("cheque", "cash", "account", ""),
            payment_date: Joi.string().trim(),
          })
        )
        .required()
        .min(1),
      otherwise: Joi.array().forbidden(),
    }),
    status: Joi.string().valid("pending", "approved"),
    payment_method: Joi.string().valid("cheque", "cash", "account", ""),
    release_date: Joi.string().trim().allow(""),
    no_of_installments: Joi.number().allow("", 0),
    installment_start_from: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_edit_loan_request_admin(body) {
  const schema = {
    amount: Joi.number().required(),
    description: Joi.string().required().trim(),
    loan_type: Joi.string().valid("advance_salary", "general"),
    installments: Joi.array().when("loan_type", {
      is: "general",
      then: Joi.array()
        .items(
          Joi.object({
            amount: Joi.number().required(),
            due_date: Joi.string().required().trim(),
            // status: Joi.string().valid("paid", "pending"),
            // payment_method: Joi.string().valid("cheque", "cash", "account", ""),
            // payment_date: Joi.string().trim(),
          })
        )
        .required()
        .min(1),
      otherwise: Joi.array().forbidden(),
    }),
    status: Joi.string().valid("pending", "approved"),
    payment_method: Joi.string().valid("cheque", "cash", "account", ""),
    release_date: Joi.string().trim().allow(""),
    no_of_installments: Joi.number().allow("", 0),
    installment_start_from: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_update_installment_status(body) {
  const schema = {
    installment_id: Joi.string().required(),
    status: Joi.string().valid("paid", "pending"),
    payment_method: Joi.string().valid("cheque", "cash", "account", ""),
    payment_date: Joi.string().required().trim(),
  };
  return Joi.validate(body, schema);
}

function validate_search_loan_request_admin(body) {
  const schema = {

    emp_name: Joi.string().allow(""),
    loan_type: Joi.string().valid("advance_salary", "general", ""),
    status: Joi.string().valid(
      "pending",
      "approved",
      "rejected",
      "returned",
      "active",
      "all",
      ""
    ),
    date_from: Joi.string().trim().allow(""),
    date_to: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_team_loan_requests_for_lead(body) {
  const schema = {
    emp_obj_id: Joi.string().allow(""),
    date_from: Joi.string().trim().allow(""),
    date_to: Joi.string().trim().allow(""),
    status: Joi.string().valid("pending", "approved", "rejected", ""),
  };
  return Joi.validate(body, schema);
}
function validate_pending_loan_request_admin(body) {
  const schema = {
    loan_type: Joi.string().valid("advance_salary", "general", ""),
    emp_name: Joi.string().allow(""),
    date_from: Joi.string().trim().allow(""),
    date_to: Joi.string().trim().allow(""),
    status: Joi.string().valid("pending", "paid", ""),
  };
  return Joi.validate(body, schema);
}

function validate_update_loan_installment_date(body) {
  const schema = {
    loan_id: Joi.string().required(),
    installment_id: Joi.string().required(),
    date: Joi.string().required().trim(),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_loan_request,
  validate_edit_loan_request,
  validate_process_loan_request,
  validate_search_loan_request,
  validate_add_loan_request_admin,
  validate_edit_loan_request_admin,
  validate_update_installment_status,
  validate_search_loan_request_admin,
  validate_team_loan_requests_for_lead,
  validate_pending_loan_request_admin,
  validate_update_loan_installment_date,
};
