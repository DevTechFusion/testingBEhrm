const Joi = require("joi");

function validate_add_lunch(body) {
  const schema = {
    employee: Joi.string().trim().required(),
    date: Joi.string().required().trim(),
    amount: Joi.number().required(),
    paid_status: Joi.string().valid("free", "paid", "pending").required(),
  };
  return Joi.validate(body, schema);
}
function validate_edit_lunch(body) {
  const schema = {
    employee: Joi.string().trim().required(),
    date: Joi.string().required().trim(),
    amount: Joi.number().required(),
    paid_status: Joi.string().valid("free", "paid", "pending").required(),
    active_status: Joi.boolean().required(),
  };
  return Joi.validate(body, schema);
}

function validate_search_lunch(body) {
  const schema = {
    search: Joi.string().trim().allow(""),
    date_from: Joi.string().trim().allow(""),
    date_to: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_continue_lunch(body) {
  const schema = {
    want_lunch: Joi.boolean().required(),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_lunch,
  validate_edit_lunch,
  validate_search_lunch,
  validate_continue_lunch,
};
