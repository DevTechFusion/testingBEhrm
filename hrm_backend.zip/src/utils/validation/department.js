const Joi = require("joi");

function validate_add_department(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    description: Joi.string().required().min(2).trim(),
    previllages: Joi.object(),
    // lead: Joi.array()
    //   .items(
    //     Joi.object({
    //       _id: Joi.string().trim(),
    //       name: Joi.string().trim(),
    //     })
    //   )
    //   .min(0),
    // members: Joi.array()
    //   .items(
    //     Joi.object({
    //       _id: Joi.string().trim(),
    //       name: Joi.string().trim(),
    //     })
    //   )
    //   .min(0),
    company: Joi.object({
      _id: Joi.string().trim(),
      title: Joi.string().trim(),
    }).required(),
  };
  return Joi.validate(body, schema);
}
function validate_edit_department(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    description: Joi.string().required().min(2).trim(),
    active_status: Joi.boolean(),
    previllages: Joi.object(),
    lead: Joi.array().min(0),
    members: Joi.array()
      .items(
        Joi.object({
          _id: Joi.string().trim(),
          name: Joi.string().trim(),
        })
      )
      .min(0),
    company: Joi.object({
      _id: Joi.string().trim(),
      title: Joi.string().trim(),
    }).required(),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_department,
  validate_edit_department,
};
