const Joi = require("joi");

function validate_add_feedback_improvement(body) {
  const schema = Joi.object({
    team_member_info: Joi.array()
      .items(
        Joi.object({
          employee_id: Joi.string().required(),
          full_name: Joi.string().required(),
          designation: Joi.string().required(),
          user_id: Joi.string().required(),
        })
      )
      .allow(null),
    // employee_id: Joi.string().allow("", null),
    show_to_team: Joi.boolean().required(),
    title: Joi.string().required().trim(),
    description: Joi.string().required().trim(),
    improvement_date: Joi.date().required(),
    images: Joi.array().items(Joi.string()).optional(),
    deduction_number: Joi.number().min(0).max(10).required(),
  });
  return schema.validate(body);
}

function validate_update_feedback_improvement(body) {
  const schema = Joi.object({
    title: Joi.string().required().trim(),
    show_to_team: Joi.boolean().required(),
    team_member_info: Joi.array()
      .items(
        Joi.object({
          employee_id: Joi.string().required(),
          full_name: Joi.string().required(),
          designation: Joi.string().required(),
          user_id: Joi.string().required(),
        })
      )
      .allow(null),
    description: Joi.string().required().trim(),
    improvement_date: Joi.date().required(),
    images: Joi.array().items(Joi.string()).optional(),
    deduction_number: Joi.number().min(0).max(10).required(),
  });
  return schema.validate(body);
}

function validate_list_feedback_improvements(body) {
  const schema = Joi.object({
    employee_id: Joi.string().allow("", null),
    search: Joi.string().allow("", null),
    filter_type: Joi.string().allow("", null).valid("All"),
  });
  return schema.validate(body);
}

module.exports = {
  validate_add_feedback_improvement,
  validate_update_feedback_improvement,
  validate_list_feedback_improvements,
};
