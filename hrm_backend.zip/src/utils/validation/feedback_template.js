const Joi = require("joi");

function validate_add_feedback_template(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    questions: Joi.array().items(
      Joi.object({
        title: Joi.string().min(2).required().trim(),
        order: Joi.number().integer().positive().required(),
        type: Joi.string()
          .valid("rating", "multiple_choice", "free_text")
          .required(),
        options: Joi.array().required(),
        options_count: Joi.number().required(),
      })
    ),
    // order: Joi.number().integer().positive().min(1).allow(null, ""),
  };
  return Joi.validate(body, schema);
}

function validate_edit_feedback_template(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    questions: Joi.array().items(
      Joi.object({
        _id: Joi.string().min(24).allow(""),
        title: Joi.string().min(2).required().trim(),
        order: Joi.number().integer().positive().required(),
        type: Joi.string()
          .valid("rating", "multiple_choice", "free_text")
          .required(),
        options: Joi.array().required(),
        options_count: Joi.number().required(),
        answer: Joi.string().trim().allow(""),
      })
    ),
    // order: Joi.number().integer().positive().min(1).allow(null, ""),
    active_status: Joi.boolean().required(),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_feedback_template,
  validate_edit_feedback_template,
};
