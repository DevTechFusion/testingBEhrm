const Joi = require("joi");


function validate_read_notification(body) {
  const schema = {
    mark_read: Joi.boolean().required(),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_read_notification
};
