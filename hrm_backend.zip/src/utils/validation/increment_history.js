const Joi = require("joi");

function validate_add_increment_history(body) {
  const schema = {
    employee_id: Joi.string().required(),
    increment_date: Joi.string().required().trim(),
    increment_amount: Joi.number().required(),
    additional_note: Joi.string().trim().allow(null, ""),
  };
  return Joi.validate(body, schema);
}

function validate_update_increment_history(body) {
  const schema = {
    increment_date: Joi.string().required().trim(),
    increment_amount: Joi.number().required(),
    additional_note: Joi.string().trim().allow(null, ""),
  };
  return Joi.validate(body, schema);
}

function validate_list_increment_history(body) {
  const schema = {
    employee_id: Joi.string().required(),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_increment_history,
  validate_update_increment_history,
  validate_list_increment_history,
};
