const Joi = require("joi");

function validate_website_setting(user) {
  const schema = {
    support_email: Joi.string().required().email().trim(),
    privacy_policy: Joi.string().trim().allow(null, ""),
    terms_and_conditions: Joi.string().trim().allow(null, ""),
    all_previllages: Joi.object(),
  };
  return Joi.validate(user, schema);
}
/*********************************************** Update Twilio Settings ****************************/
function validate_twilio_setting(body) {
  const schema = {
    account_sid: Joi.string().required(),
    auth_token: Joi.string().required(),
    twilio_number: Joi.string().required(),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_website_setting,
  validate_twilio_setting,
};
