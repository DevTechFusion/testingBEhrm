const Joi = require("joi");

function validate_add_top_up(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    amount: Joi.number().required(),
    payment_method: Joi.string().required().trim(),
    date: Joi.string().required().trim(),
    attachment: Joi.string().trim().allow(""),
    notes: Joi.string().trim().allow(""),
    cheque_number: Joi.string().trim().allow(""),
    transfer_by: Joi.string().trim().required(),
    transfer_to: Joi.string().trim().required(),
  };
  return Joi.validate(body, schema);
}
function validate_edit_top_up(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    amount: Joi.number().required(),
    payment_method: Joi.string().required().trim(),
    date: Joi.string().required().trim(),
    attachment: Joi.string().trim().allow(""),
    notes: Joi.string().trim().allow(""),
    cheque_number: Joi.string().trim().allow(""),
    transfer_by: Joi.string().trim().required(),
    transfer_to: Joi.string().trim().required(),
    active_status: Joi.boolean().required(),
  };
  return Joi.validate(body, schema);
}

function validate_search_top_up(body) {
  const schema = {
    search: Joi.string().allow(""),
    added_by: Joi.string().allow(""),
    transfer_by: Joi.string().allow(""),
    date_from: Joi.string().trim().allow(""),
    date_to: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}
module.exports = {
  validate_add_top_up,
  validate_edit_top_up,
  validate_search_top_up,
};
