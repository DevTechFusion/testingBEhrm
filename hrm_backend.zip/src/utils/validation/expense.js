const Joi = require("joi");

function validate_add_expense(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    amount: Joi.number().required(),
    payment_method: Joi.string().required().trim(),
    date: Joi.string().required().trim(),
    attachment: Joi.string().trim().allow(""),
    notes: Joi.string().trim().allow(""),
    vendor: Joi.string().trim().required(),
    employee: Joi.string().trim().allow(""),
    tax_type: Joi.string().trim().allow(""),
    tax_amount: Joi.number().allow(""),
    expense_category: Joi.string().trim().required(),
    link: Joi.string().trim().allow(""),
    other_link: Joi.string().trim().allow(""),

  };
  return Joi.validate(body, schema);
}
function validate_edit_expense(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    amount: Joi.number().required(),
    payment_method: Joi.string().required().trim(),
    date: Joi.string().required().trim(),
    attachment: Joi.string().trim().allow(""),
    notes: Joi.string().trim().allow(""),
    vendor: Joi.string().trim().required(),
    employee: Joi.string().trim().allow(""),
    tax_type: Joi.string().trim().allow(""),
    tax_amount: Joi.number().allow(""),
    expense_category: Joi.string().trim().required(),
    link: Joi.string().trim().allow(""),
    other_link: Joi.string().trim().allow(""),
    active_status: Joi.boolean().required(),
  };
  return Joi.validate(body, schema);
}

function validate_search_expense(body) {
  const schema = {
    expense_category: Joi.string().allow(""),
    payment_method: Joi.string().allow(""),
    search: Joi.string().allow(""),
    tax_type: Joi.string().allow(""),
    date_from: Joi.string().trim().allow(""),
    date_to: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}
module.exports = {
  validate_add_expense,
  validate_edit_expense,
  validate_search_expense,
};
