const Joi = require("joi");

function validate_add_feedback(body) {
  const schema = {
    title: Joi.string().required().trim(),
    feedback_template: Joi.string().required().trim(),
    send_to: Joi.string().trim().allow(""),
    send_for: Joi.array().items(Joi.string().required().trim()).min(1),
    // month: Joi.number().required(),
    // year: Joi.number().required(),
    date: Joi.string().required().trim(),
    // order: Joi.number().integer().positive().min(1).allow(null, ""),
  };
  return Joi.validate(body, schema);
}

function validate_edit_feedback(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    feedback_template: Joi.string().required().trim(),
    active_status: Joi.boolean().required(),
    // order: Joi.number().integer().positive().min(1).allow(null, ""),
  };
  return Joi.validate(body, schema);
}

function validate_submit_feedback(body) {
  const schema = {
    questions: Joi.array().items(
      Joi.object({
        _id: Joi.string().min(24).allow(""),
        title: Joi.string().min(2).required().trim(),
        order: Joi.number().integer().positive().required(),
        type: Joi.string()
          .valid("rating", "multiple_choice", "free_text")
          .required(),
        options: Joi.array().required(),
        options_count: Joi.number().required(),
        answer: Joi.string().trim().allow(""),
        description: Joi.string().trim().allow(""),
      })
    ),
    private_notes: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_submitted_feedbacks_search(body) {
  const schema = {
    emp_name: Joi.string().allow(""),
    search: Joi.string().allow(""),
    date: Joi.string().trim().allow(""),
    // date_from: Joi.string().trim().allow(""),
    // date_to: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_feedbacks_search(body) {
  const schema = {
    emp_name: Joi.string().allow(""),
    search: Joi.string().allow(""),
    date: Joi.string().trim().allow(""),
    // date_from: Joi.string().trim().allow(""),
    // date_to: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_get_performance(body) {
  const schema = {
    emp_name: Joi.string().allow(""),
    date: Joi.string().trim().allow(""),
    // search: Joi.string().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_feedbacks_search_for_me(body) {
  const schema = {
    search: Joi.string().allow(""),
    date: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_feedback,
  validate_edit_feedback,
  validate_submit_feedback,
  validate_submitted_feedbacks_search,
  validate_feedbacks_search,
  validate_get_performance,
  validate_feedbacks_search_for_me,
};
