const Joi = require("joi");

function validate_add_tax_slabs(body) {
  const schema = Joi.object({
    per_month_salary_from: Joi.number().required(),
    per_month_salary_to: Joi.number().required(),
    income_tax: Joi.number().required(),
  });
  return schema.validate(body);
}

function validate_update_tax_slabs(body) {
  const schema = Joi.object({
    per_month_salary_from: Joi.number().required(),
    per_month_salary_to: Joi.number().required(),
    income_tax: Joi.number().required(),
  });
  return schema.validate(body);
}

module.exports = {
  validate_add_tax_slabs,
  validate_update_tax_slabs,
};
