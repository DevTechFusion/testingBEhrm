const Joi = require("joi");

function validate_add_announcement(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    description: Joi.string().trim().allow(""),
    attachment: Joi.string().trim().allow(""),
    role: Joi.string().trim().required(),
    // reactions: Joi.array().min(0),
  };
  return Joi.validate(body, schema);
}
function validate_edit_announcement(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    description: Joi.string().trim().allow(""),
    attachment: Joi.string().trim().allow(""),
    role: Joi.string().trim().required(),
    active_status: Joi.boolean().required(),
    reactions: Joi.array().min(0),
  };
  return Joi.validate(body, schema);
}

function validate_search_announcement(body) {
  const schema = {
    search: Joi.string().allow(""),
    date_from: Joi.string().trim().allow(""),
    date_to: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}
module.exports = {
  validate_add_announcement,
  validate_edit_announcement,
  validate_search_announcement,
};
