const Joi = require("joi");

function validate_add_leave_request(body) {
  const schema = {
    leave_type: Joi.string().valid(
      "first_half",
      "second_half",
      "full",
      "range"
    ),
    leave_reason: Joi.string().required().trim(),
    leave_date_from: Joi.string().required().trim(),
    leave_date_to: Joi.string().trim().allow(""),
    rejection_reason: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}
function validate_edit_leave_request(body) {
  const schema = {
    leave_type: Joi.string().valid("first_half", "second_half", "full"),
    leave_reason: Joi.string().required().trim(),
    leave_date_from: Joi.string().required().trim(),
    rejection_reason: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_process_leave_request(body) {
  const schema = {
    rejection_reason: Joi.string().trim().allow(""),
    status: Joi.string().valid("approved", "rejected"),
  };
  return Joi.validate(body, schema);
}

function validate_search_leave_request(body) {
  const schema = {
    date_from: Joi.string().trim().allow(""),
    date_to: Joi.string().trim().allow(""),
    status: Joi.string().valid("pending", "approved", "rejected", ""),
  };
  return Joi.validate(body, schema);
}

function validate_add_leave_request_admin(body) {
  const schema = {
    emp_obj_id: Joi.string().required(),
    leave_type: Joi.string().valid(
      "first_half",
      "second_half",
      "full",
      "range"
    ),
    // status: Joi.string().valid("pending", "approved", "rejected"),
    leave_reason: Joi.string().required().trim(),
    leave_date_from: Joi.string().required().trim(),
    leave_date_to: Joi.string().trim().allow(""),
    // rejection_reason: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_edit_leave_request_admin(body) {
  const schema = {
    emp_obj_id: Joi.string().required(),
    leave_type: Joi.string().valid("first_half", "second_half", "full"),
    status: Joi.string().valid("pending", "approved", "rejected"),
    leave_reason: Joi.string().required().trim(),
    leave_date_from: Joi.string().required().trim(),
    rejection_reason: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_process_leave_request_admin(body) {
  const schema = {
    emp_obj_id: Joi.string().required(),
    rejection_reason: Joi.string().trim().allow(""),
    status: Joi.string().valid("approved", "rejected"),
  };
  return Joi.validate(body, schema);
}

function validate_search_leave_request_admin(body) {
  const schema = {
    emp_obj_id: Joi.string().allow(""),
    date_from: Joi.string().trim().allow(""),
    date_to: Joi.string().trim().allow(""),
    status: Joi.string().valid("pending", "approved", "rejected", ""),
  };
  return Joi.validate(body, schema);
}
function validate_search_all_leave_request_admin(body) {
  const schema = {
    emp_obj_id: Joi.string().allow(""),
    date_from: Joi.string().trim().allow(""),
    date_to: Joi.string().trim().allow(""),
    status: Joi.string().valid("pending", "approved", "rejected", ""),
  };
  return Joi.validate(body, schema);
}
function validate_team_leave_requests_for_lead(body) {
  const schema = {
    emp_obj_id: Joi.string().allow(""),
    date_from: Joi.string().trim().allow(""),
    date_to: Joi.string().trim().allow(""),
    status: Joi.string().valid("pending", "approved", "rejected", ""),
  };
  return Joi.validate(body, schema);
}

function validate_leave_report(body) {
  const schema = {
    date_from: Joi.string().required(),
    date_to: Joi.string().required(),
    search: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_change_leave_payment_status(body) {
  const schema = {
    leave_payment_status: Joi.string().valid("paid", "unpaid").required(),
  };
  return Joi.validate(body, schema);
}

function validate_count_in_yearly_leaves(body) {
  const schema = Joi.object({
    count_in_yearly_leaves: Joi.boolean().required(),
    uncount_leave_reason: Joi.string()
      .trim()
      .when("count_in_yearly_leaves", {
        is: false,
        then: Joi.required(),
        otherwise: Joi.optional().allow(""),
      }),
  });

  return schema.validate(body);
}

module.exports = {
  validate_add_leave_request,
  validate_edit_leave_request,
  validate_process_leave_request,
  validate_search_leave_request,
  validate_add_leave_request_admin,
  validate_edit_leave_request_admin,
  validate_process_leave_request_admin,
  validate_search_leave_request_admin,
  validate_team_leave_requests_for_lead,
  validate_search_all_leave_request_admin,
  validate_leave_report,
  validate_change_leave_payment_status,
  validate_count_in_yearly_leaves,
};
