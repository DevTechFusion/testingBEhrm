const Joi = require("joi");

function validate_add_support_ticket(body) {
  const schema = {
    title: Joi.string().required().trim(),
    description: Joi.string().required().trim(),
    priority: Joi.string().valid("high", "medium", "low"),
    support_type: Joi.string().trim(),
    status: Joi.number(),
    image: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}
function validate_edit_support_ticket(body) {
  const schema = {
    title: Joi.string().required().trim(),
    description: Joi.string().required().trim(),
    priority: Joi.string().valid("high", "medium", "low"),
    support_type: Joi.string().trim(),
    status: Joi.number(),
    image: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_process_support_ticket(body) {
  const schema = {
    status: Joi.number().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_search_support_ticket(body) {
  const schema = {
    date_from: Joi.string().trim().allow(""),
    date_to: Joi.string().trim().allow(""),
    status: Joi.number().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_add_support_ticket_admin(body) {
  const schema = {
    emp_obj_id: Joi.string().required().trim(),
    title: Joi.string().required().trim(),
    description: Joi.string().required().trim(),
    priority: Joi.string().valid("high", "medium", "low"),
    support_type: Joi.string().trim(),
    status: Joi.number(),
    image: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_edit_support_ticket_admin(body) {
  const schema = {
    emp_obj_id: Joi.string().required(),
    title: Joi.string().required().trim(),
    description: Joi.string().required().trim(),
    priority: Joi.string().valid("high", "medium", "low"),
    support_type: Joi.string().trim(),
    status: Joi.number(),
    image: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_search_support_ticket_admin(body) {
  const schema = {
    emp_obj_id: Joi.string().allow(""),
    date_from: Joi.string().trim().allow(""),
    date_to: Joi.string().trim().allow(""),
    status: Joi.number().allow(""),
  };
  return Joi.validate(body, schema);
}

function validate_add_message_support_ticket(body) {
  const schema = {
    text: Joi.string().min(1).trim(),
    images: Joi.array().min(0),
  };
  return Joi.validate(body, schema);
}

function validate_delete_message_support_ticket(body) {
  const schema = {
    message_id: Joi.string().required().trim(),
  };
  return Joi.validate(body, schema);
}

function validate_edit_message_support_ticket(body) {
  const schema = {
    message_id: Joi.string().required().trim(),
    text: Joi.string().min(1).trim(),
    images: Joi.array().min(0),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_support_ticket,
  validate_edit_support_ticket,
  validate_process_support_ticket,
  validate_search_support_ticket,
  validate_add_support_ticket_admin,
  validate_edit_support_ticket_admin,
  validate_search_support_ticket_admin,
  validate_add_message_support_ticket,
  validate_delete_message_support_ticket,
  validate_edit_message_support_ticket,
};
