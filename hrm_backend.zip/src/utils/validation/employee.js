const Joi = require("joi");

function validate_add_employee(body) {
  const schema = {
    email: Joi.string().required().email().trim(),
    password: Joi.string().min(5).max(255).trim(),
    first_name: Joi.string().required().min(2).trim(),
    last_name: Joi.string().required().min(2).trim(),
    skype_email: Joi.string().required().email().trim(),
    webmail_email: Joi.string().required().email().trim(),
    webmail_password: Joi.string().min(5).max(255).trim(),
    date_of_birth: Joi.string().trim().required(),
    date_of_joining: Joi.string().required().trim().allow(""),
    date_of_confirmation: Joi.string().trim().allow(""),
    date_of_increment: Joi.string().trim().allow(""),
    date_of_contract: Joi.string().trim().allow(""),
    designation: Joi.string().trim().required(),
    contact_number: Joi.string().trim().min(10).required(),
    address: Joi.string().trim().required(),
    gender: Joi.string().required().trim(),
    cnic: Joi.string().trim().allow(""),
    employee_id: Joi.number(),
    previllages: Joi.object(),
    department: Joi.string().trim().required(),
    company: Joi.string().trim().required(),
    company_assets: Joi.array().min(0),
    documents_url: Joi.string().trim().allow(""),
    role: Joi.string().trim().required(),
    leads: Joi.array().items(Joi.string().trim()).min(0),
    tech_lead: Joi.string().trim().required(),
    basic_salary: Joi.number().required(),
    bank_account: Joi.string().trim().required(),
    blood_group: Joi.string().trim().allow(""),
    allowed_leaves: Joi.number().required(),
  };
  return Joi.validate(body, schema);
}
function validate_edit_employee(body) {
  const schema = {
    email: Joi.string().required().email().trim(),
    password: Joi.string().max(255).trim().allow(""),
    first_name: Joi.string().required().min(2).trim(),
    last_name: Joi.string().required().min(2).trim(),
    skype_email: Joi.string().required().email().trim(),
    webmail_email: Joi.string().required().email().trim(),
    webmail_password: Joi.string().min(5).max(255).trim(),
    date_of_birth: Joi.string().trim().required(),
    date_of_joining: Joi.string().required().trim().allow(""),
    date_of_confirmation: Joi.string().trim().allow(""),
    date_of_increment: Joi.string().trim().allow(""),
    next_date_of_increment: Joi.string().trim().allow(""),
    date_of_contract: Joi.string().trim().allow(""),
    designation: Joi.string().trim().required(),
    contact_number: Joi.string().trim().min(10).required(),
    address: Joi.string().trim().required(),
    gender: Joi.string().required().trim(),
    cnic: Joi.string().trim().allow(""),
    employee_id: Joi.number(),
    previllages: Joi.object(),
    active_status: Joi.boolean(),
    department: Joi.string().trim().required(),
    company: Joi.string().trim().required(),
    company_assets: Joi.array().min(0),
    documents_url: Joi.string().trim().allow(""),
    role: Joi.string().trim().required(),
    leads: Joi.array().items(Joi.string().trim()).min(0),
    tech_lead: Joi.string().trim().required(),
    basic_salary: Joi.number().required(),
    bank_account: Joi.string().trim().required(),
    blood_group: Joi.string().trim().allow(""),
    allowed_leaves: Joi.number().required(),
  };
  return Joi.validate(body, schema);
}

function validate_edit_employee_for_settings(body) {
  const schema = {
    first_name: Joi.string().required().min(2).trim(),
    last_name: Joi.string().required().min(2).trim(),
    contact_number: Joi.string().trim().min(10).required(),
    address: Joi.string().trim().required(),
    employee_id: Joi.string().trim().required(),
  };
  return Joi.validate(body, schema);
}

function validate_update_sidebar_status(body) {
  const schema = {
    sidebar_status: Joi.object({
      leaves: Joi.boolean(),
      my_leaves: Joi.boolean(),
      supports: Joi.boolean(),
      my_supports: Joi.boolean(),
      announcement: Joi.boolean(),
      my_loans: Joi.boolean(),
      loans: Joi.boolean(),
    }).required(),
  };
  return Joi.validate(body, schema);
}

function validate_employees_for_payroll(body) {
  const schema = {
    month: Joi.number().required(),
    year: Joi.number().required(),
  };
  return Joi.validate(body, schema);
}

function validate_add_member_to_team(body) {
  const schema = {
    team_members: Joi.array()
      .items(
        Joi.object({
          emp_obj_id: Joi.string().trim().required(),
        })
      )
      .min(1)
      .required(),
  };
  return Joi.validate(body, schema);
}

function validate_remove_member_from_team(body) {
  const schema = {
    emp_obj_id: Joi.string().trim().required(),
  };
  return Joi.validate(body, schema);
}

function validate_get_members_or_leads(body) {
  const schema = {
    emp_obj_id: Joi.string().trim().required(),
    selection_type: Joi.string()
      .trim()
      .required()
      .valid("get_members", "get_leads"),
  };
  return Joi.validate(body, schema);
}

function validate_tech_lead_for_member(body) {
  const schema = {
    tech_lead_id: Joi.string().trim().required(),
    team_member_id: Joi.string().trim().required(),
  };
  return Joi.validate(body, schema);
}

function validate_update_employee_allowance(body) {
  const schema = {
    conveyance_allowance: Joi.number().required(),
    medical_allowance: Joi.number().required(),
    food_allowance: Joi.number().required(),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_employee,
  validate_edit_employee,
  validate_update_sidebar_status,
  validate_employees_for_payroll,
  validate_add_member_to_team,
  validate_remove_member_from_team,
  validate_get_members_or_leads,
  validate_tech_lead_for_member,
  validate_edit_employee_for_settings,
  validate_update_employee_allowance,
};

