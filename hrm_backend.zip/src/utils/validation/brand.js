const Joi = require("joi");

function validate_add_brand(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    description: Joi.string().trim().allow(""),
    // active_status: Joi.boolean().required(),
  };
  return Joi.validate(body, schema);
}
function validate_edit_brand(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    description: Joi.string().trim().allow(""),
    active_status: Joi.boolean().required(),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_brand,
  validate_edit_brand,
};
