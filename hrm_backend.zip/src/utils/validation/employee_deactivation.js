const Joi = require("joi");

function validate_add_employee_deactivation(body) {
  const schema = {
    employee: Joi.object({
      _id: Joi.string().trim(),
      name: Joi.string().trim(),
    }),
    leaving_type: Joi.string().trim(),
    last_working_day: Joi.string().trim(),
    leaving_reason: Joi.string().required().min(2).trim(),
    leaving_reason_detail: Joi.string().required().min(2).trim(),
    hr_comments: Joi.string().required().min(2).trim(),
    clearance_status: Joi.boolean().required(),
  };
  return Joi.validate(body, schema);
}
function validate_edit_employee_deactivation(body) {
  const schema = {
    employee: Joi.object({
      _id: Joi.string().trim(),
      name: Joi.string().trim(),
    }),
    leaving_type: Joi.string().trim(),
    last_working_day: Joi.string().trim(),
    leaving_reason: Joi.string().required().min(2).trim(),
    leaving_reason_detail: Joi.string().required().min(2).trim(),
    hr_comments: Joi.string().required().min(2).trim(),
    clearance_status: Joi.boolean().required(),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_employee_deactivation,
  validate_edit_employee_deactivation,
};
