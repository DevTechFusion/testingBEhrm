const Joi = require("joi");

function validate_add_allowance(body) {
  const schema = Joi.object({
    title: Joi.string().required().trim(),
    allowance_type: Joi.string().required().valid("general", "other"),
    allowance_amount_type: Joi.string().required().valid("fixed", "percentage"),
    allowance_amount_or_percentage: Joi.number().required(),
    status: Joi.boolean().required(),
    exempt_from_tax_calculation: Joi.boolean().required(),
  });
  return schema.validate(body);
}

function validate_update_allowance(body) {
  const schema = Joi.object({
    title: Joi.string().required().trim(),
    allowance_type: Joi.string().required().valid("general", "other"),
    allowance_amount_type: Joi.string().required().valid("fixed", "percentage"),
    allowance_amount_or_percentage: Joi.number().required(),
    status: Joi.boolean().required(),
    exempt_from_tax_calculation: Joi.boolean().required(),
  });
  return schema.validate(body);
}

module.exports = {
  validate_add_allowance,
  validate_update_allowance,
};
