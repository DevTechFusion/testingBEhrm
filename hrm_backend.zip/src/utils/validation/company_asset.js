const Joi = require("joi");

function validate_add_company_asset(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    device_id: Joi.string().trim().allow(""),
    details: Joi.string().trim().required(),
    purchase_date: Joi.string().required(),
    price: Joi.number().allow(""),
    quantity: Joi.number().allow(""),
    warranty_expire_date: Joi.string().trim().allow(""),
    vendor: Joi.string().trim().required(),
    brand: Joi.string().trim().required(),
    asset_category: Joi.string().trim().required(),
    link: Joi.string().trim().allow(""),
    // assigned_employee: Joi.object({
    //   _id: Joi.string().trim(),
    //   name: Joi.string().trim(),
    // }),
  };
  return Joi.validate(body, schema);
}
function validate_edit_company_asset(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    device_id: Joi.string().trim().allow(""),
    details: Joi.string().trim().required(),
    purchase_date: Joi.string().required(),
    price: Joi.number().allow(""),
    quantity: Joi.number().allow(""),
    active_status: Joi.boolean(),
    warranty_expire_date: Joi.string().trim().allow(""),
    vendor: Joi.string().trim().required(),
    brand: Joi.string().trim().required(),
    asset_category: Joi.string().trim().required(),
    link: Joi.string().trim().allow(""),
    // assigned_status: Joi.boolean(),
    // assigned_employee: Joi.object({
    //   _id: Joi.string().trim(),
    //   name: Joi.string().trim(),
    // }),
  };
  return Joi.validate(body, schema);
}

function validate_assign_company_asset(body) {
  const schema = {
    // device_id: Joi.string().trim().allow(""),
    assigned_employee: Joi.object({
      emp_obj_id: Joi.string().trim().allow(""),
      name: Joi.string().trim().allow(""),
      emp_assigned_status: Joi.boolean().required(),
      assigned_date: Joi.string().trim().allow(""),
      returned_date: Joi.string().trim().allow(""),
    }),
  };
  return Joi.validate(body, schema);
}

function validate_add_repair_history_company_asset(body) {
  const schema = {
    // device_id: Joi.string().trim().allow(""),
    repair_details: Joi.object({
      vendor_obj_id: Joi.string().trim().allow(""),
      vendor_name: Joi.string().trim().allow(""),
      repair_date: Joi.string().trim().required(),
      service_type: Joi.string().trim().required(),
      service_description: Joi.string().trim().allow(""),
      service_cost: Joi.number().required(),
      service_duration: Joi.number().required(),
      service_receipt_pic: Joi.string().trim().allow(""),
    }),
  };
  return Joi.validate(body, schema);
}

function validate_edit_repair_history_company_asset(body) {
  const schema = {
    // device_id: Joi.string().trim().allow(""),
    repair_details: Joi.object({
      _id: Joi.string().trim().required(),
      vendor_obj_id: Joi.string().trim().allow(""),
      vendor_name: Joi.string().trim().allow(""),
      repair_date: Joi.string().trim().required(),
      service_type: Joi.string().trim().required(),
      service_description: Joi.string().trim().allow(""),
      service_cost: Joi.number().required(),
      service_duration: Joi.number().required(),
      service_receipt_pic: Joi.string().trim().allow(""),
    }),
  };
  return Joi.validate(body, schema);
}

function validate_delete_repair_history_company_asset(body) {
  const schema = {
    _id: Joi.string().trim().required(),
  };
  return Joi.validate(body, schema);
}

function validate_search_company_asset(body) {
  const schema = {
    assigned_status : Joi.boolean().allow(""),
    brand: Joi.string().trim().allow(""),
    vendor: Joi.string().trim().allow(""),
    asset_category: Joi.string().trim().allow(""),
    search: Joi.string().trim().allow(""),
    date_from: Joi.string().trim().allow(""),
    date_to: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_company_asset,
  validate_edit_company_asset,
  validate_assign_company_asset,
  validate_add_repair_history_company_asset,
  validate_edit_repair_history_company_asset,
  validate_delete_repair_history_company_asset,
  validate_search_company_asset,
};
