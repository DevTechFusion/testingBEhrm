const Joi = require("joi");

function validate_add_company(body) {
  const schema = {
    title: Joi.string().required().min(2).trim(),
    description: Joi.string().required().min(2).trim(),
    phone: Joi.string().trim().required().min(8),
    email: Joi.string().trim().email(),
    address: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}
function validate_edit_company(body) {
  const schema = {
    title: Joi.string().min(2).trim(),
    description: Joi.string().min(2).trim(),
    active_status: Joi.boolean(),
    phone: Joi.string().trim().required().min(8),
    email: Joi.string().trim().email(),
    address: Joi.string().trim().allow(""),
  };
  return Joi.validate(body, schema);
}

module.exports = {
  validate_add_company,
  validate_edit_company,
};
