const twilio = require("twilio");
const SEND_TWILIO_SMS = async (accountSid, authToken, from, body, to) => {
  try {
    const client = new twilio(accountSid, authToken);
    const message = await client.messages.create({
      body: body,
      from: from,
      to: to,
    });
    console.log(`Message sent successfully! Message SID: ${message.sid}`);
    return message;
  } catch (error) {
    console.error("Error sending message:", error);
    return null;
  }
};

module.exports = {
  SEND_TWILIO_SMS,
};
