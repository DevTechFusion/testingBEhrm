const PDFDocument = require("pdfkit");
const fs = require("fs");
const moment = require("moment");
const { v4: uuidv4 } = require("uuid");
const s3 = require("../../config/S3_config/s3.config");
let upload = require("../../config/S3_config/multer.config");

const generatePayslip = async (data) => {
  const path = require("path");

  const doc = new PDFDocument();

  const payslip_name = `${data.emp_name.split(" ")[0]}:${data.month}:${
    data.year
  }`;

  const file_name = payslip_name + ".pdf";

  console.log(file_name);

  const outputStream = fs.createWriteStream(file_name);
  doc.pipe(outputStream);

  const pageHeight = doc.page.height;
  const pageWidth = doc.page.width;

  //hortizontal line
  // doc.moveTo(0, 20).lineTo(pageWidth, 20).strokeColor("black", 0.2).stroke();
  // Add content to the PDF
  doc.image("public/images/logo.png", 20, 40, {
    fit: [600, 70],
    align: "center",
  });

  doc.fontSize(14).text("Payslip", 98, 115, { align: "center" });

  doc.moveTo(50, 135).lineTo(562, 135).strokeColor("black", 0.4).stroke();

  doc.fontSize(10).text(`Employee ID:  ${data.emp_id}`, 50, 150);
  doc
    .fontSize(10)
    .text(`Employee Status:   Permanent`, 380, 150, { align: "right" });

  doc
    .fontSize(10)
    .text(
      `Salary for the month of ${moment(data.month, "MM").format("MMMM")} ${
        data.year
      }`,
      0,
      175,
      { align: "center", width: pageWidth }
    );

  doc.fontSize(10).text(`Employee Name:   ${data.emp_name}`, 50, 200);

  doc
    .fontSize(10)
    .text(`Designation:     ${data.designation}`, 350, 200, { align: "right" });

  doc.moveTo(50, 215).lineTo(562, 215).strokeColor("black", 0.4).stroke();

  //count data object how many keys have 0 value

  let count = 0;
  for (const key in data) {
    if (data[key] == 0) {
      count++;
    }
  }

  //less than or eqaul to 6 keys have 0 value
  let moveDown = 2.5;
  let font_size = 11;
  if (count <= 3) {
    font_size = 8;
  }
  if (count > 3 && count <= 8) {
    moveDown = 3;
  } else if (count >= 9) {
    moveDown = 7;
  }

  doc.moveDown(moveDown);

  const tableWidth = 200; // Adjust based on your desired table width
  const leftMargin = 70; // Adjust for desired left margin
  const rightMargin = doc.page.width - tableWidth - leftMargin; // Calculate right margin

  function formatLine(label, value) {
    const textWidth = doc.widthOfString(label + ": ");
    const currentY = doc.y; // Capture the current y position

    doc
      .fontSize(font_size)
      .text(label + ":", leftMargin, currentY, { align: "left" });

    const valueX = 440; // Adjust value position
    doc.text(value, valueX, currentY, { align: "left" });

    doc.moveDown(); // Move to the next line
  }

  // Pay & Allowances section
  const text1_1 = "Pay & Allowances";
  const fontSize_1 = 15;

  // Set the font size to measure the text width
  doc.fontSize(fontSize_1);
  const textWidth_1 = doc.widthOfString(text1_1);
  const textHeight_1 = doc.heightOfString(text1_1);

  // Calculate the position for the text
  const x_1 = pageWidth / 2.5;
  const y_1 = doc.y;

  // Draw the rectangle with background color
  doc
    .rect(x_1 - 5, y_1 - 5, textWidth_1 + 10, textHeight_1 + 5)
    .fill("#D3D3D3");

  // Add the text on top of the rectangle
  doc.fillColor("black").text(text1_1, x_1, y_1);

  if (data.basic_salary != 0) {
    formatLine("Basic Pay", `${data.basic_salary}`);
  }

  // if (data.rent_allowance != 0) {
  //   formatLine("House Rent Allowance", `${data.rent_allowance}`);
  // }

  if (data.food_allowance != 0) {
    formatLine("Food Allowance", `${data.food_allowance}`);
  }

  if (data.medical_allowance != 0) {
    formatLine("Medical Allowance", `${data.medical_allowance}`);
  }

  if (data.conveyance_allowance != 0) {
    formatLine("Conveyance Allowance", `${data.conveyance_allowance}`);
  }

  if (data.other_payment != 0) {
    formatLine(data.other_payment_label, `${data.other_payment}`);
  }
  if (data.overtime != 0) {
    formatLine("Overtime", `${data.overtime}`);
  }
  if (data.loan != 0) {
    formatLine("Loan", `${data.loan}`);
  }
  if (data.commission != 0) {
    formatLine("Commission", `${data.commission}`);
  }

  // Deductions section (conditional with similar formatting)

  const text2_2 = "Deductions";
  const fontSize_2 = 15;

  // Set the font size to measure the text width
  doc.fontSize(fontSize_2);
  const textWidth_2 = doc.widthOfString(text2_2);
  const textHeight_2 = doc.heightOfString(text2_2);

  // Calculate the position fogeneratePayslipr the text
  const x_2 = pageWidth / 2.3;
  const y_2 = doc.y;

  // Draw the rectangle with background color
  if (
    data.monthly_tax !== 0 ||
    data.loan_deduction !== 0 ||
    data.lunch_deduction !== 0 ||
    data.fine_deduction !== 0 ||
    data.other_deduction !== 0
  ) {
    doc
      .rect(x_2 - 5, y_2 - 5, textWidth_2 + 10, textHeight_2 + 5)
      .fill("#D3D3D3");

    // Add the text on top of the rectangle
    doc.fillColor("black").text(text2_2, x_2, y_2);
  }

  if (data.monthly_tax != 0) {
    formatLine("Income Tax Deduction", `${data.monthly_tax}`);
  }

  if (data.loan_deduction != 0) {
    formatLine("Loan Deduction", `${data.loan_deduction}`);
  }
  if (data.lunch_deduction != 0) {
    formatLine("Lunch Deduction", `${data.lunch_deduction}`);
  }
  if (data.fine_deduction != 0) {
    formatLine("Fine Deduction", `${data.fine_deduction}`);
  }
  if (data.other_deduction != 0) {
    formatLine(data.other_deduction_label, `${data.other_deduction}`);
  }

  // Calculate total earnings and deductions
  const totalEarning =
    parseInt(data.basic_salary) +
    parseInt(data.food_allowance) +
    parseInt(data.medical_allowance) +
    parseInt(data.conveyance_allowance) +
    parseInt(data.overtime) +
    parseInt(data.loan) +
    parseInt(data.commission) +
    parseInt(data.other_payment);

  const totalDeduction =
    parseInt(data.monthly_tax) +
    parseInt(data.loan_deduction) +
    parseInt(data.lunch_deduction) +
    parseInt(data.fine_deduction) +
    parseInt(data.other_deduction);

  // Totals section
  //line above total earning
  doc.moveTo(50, 560).lineTo(562, 560).strokeColor("black", 0.4).stroke();

  doc
    .fontSize(12)
    .text(`Total Earning: Rs.${totalEarning}/-`, 0, 570, { align: "right" });
  doc.text(`Total Deduction: Rs.${totalDeduction}/-`, 0, 585, {
    align: "right",
  });
  // doc.text(`Net Salary: Rs.${data.net_salary}/-`, 0, 600, { align: "right" });
  doc.text(`Net Salary: Rs.${data.net_salary}/-`, 0, 600, {
    align: "right",
  });

  // Salary credited message
  doc.moveDown();
  doc
    .fontSize(10)
    .text(
      `Salary credited to your account # ${
        data.bank_account ? data.bank_account : "00000000"
      } at Meezan Bank, High Street, Sahiwal`,
      0,
      640,
      { align: "center", width: pageWidth }
    );

  // Assuming you have a local path for the footer image
  doc.image("public/images/footer.png", 0, pageHeight - 130, {
    fit: [pageWidth, 50],
    align: "center",
  });

  doc.moveDown();
  doc
    .fontSize(10)
    .text(
      "Address: Office #2 Ground Floor Saeed centre Farid town road Sahiwal",
      0,
      705,
      { align: "center", width: pageWidth }
    );

  //line at the bottom
  // doc
  //   .moveTo(0, pageHeight - 50)
  //   .lineTo(pageWidth, pageHeight - 50)
  //   .strokeColor("black", 0.2)
  //   .stroke();
  // Finalize the PDF and end the stream

  await new Promise((resolve) => {
    outputStream.on("finish", resolve);

    doc.end();
  });

  console.log("PDF generated successfully", file_name);

  return file_name;
};

module.exports = {
  generatePayslip,
};
