let baseUrl = "https://checklistnodeapi.dynamitedigital.info/";
const endPoint = {
  customerSignUp: baseUrl + "api/customer/signup_portal_customer",
  customerLogin: baseUrl + "api/app_api/login",
  changePassword: baseUrl + "api/app_api/change_password",
  editCustomer: baseUrl + "api/customer/edit_customer/",
  uploadS3: baseUrl + "api/app_api/upload_image_s3",
  addCustomers: baseUrl + "api/customer/add_customers",
  deleteCustomer: baseUrl + "api/customer/delete_customer/",
  editPortalCustomerPassword: baseUrl + "api/app_api/change_password_portal_user",
};

module.exports = {
  endPoint,
};
