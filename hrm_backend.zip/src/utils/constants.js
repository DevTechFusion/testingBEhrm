COMPANY = "company/";

const TYPE_IMAGE = "image/jpeg";
const TYPE_AUDIO = "audio/mpeg";

module.exports = {
  TYPE_IMAGE,
  TYPE_AUDIO,
};

module.exports.PREVILLAGES = {
  project: {
    add: false,
    alter: false,
    delete: false,
    view: false,
  },
  support: {
    add: false,
    alter: false,
    delete: false,
    view: false,
  },
  announcement: {
    add: false,
    alter: false,
    delete: false,
    view: false,
  },
  attendance: {
    add: false,
    alter: false,
    delete: false,
    view: false,
  },
  department: {
    add: false,
    alter: false,
    delete: false,
    view: false,
  },
  employee: {
    add: false,
    alter: false,
    delete: false,
    view: false,
  },
};

module.exports.IMAGE_EXTENSIONS = [
  ".png",
  ".HEIC",
  ".jpg",
  ".jpeg",
  ".webp",
  ".gif",
  ".JPG",
  ".JPEG",
  ".PNG",
  ".WEBP",
  ".GIF",
];

module.exports.EMPLOYEE_IMAGE_SIZES = [
  {
    name: "large",
    height: 1024,
    width: 1024,
  },
  {
    name: "medium",
    height: 512,
    width: 512,
  },
  {
    name: "small",
    height: 250,
    width: 250,
  },
];
module.exports.EMPLOYEE_FILE_PATH = "EMPLOYEE/";

module.exports.VENDOR_IMAGE_SIZES = [
  {
    name: "large",
    height: 1024,
    width: 1024,
  },
  {
    name: "medium",
    height: 512,
    width: 512,
  },
  {
    name: "small",
    height: 250,
    width: 250,
  },
];
module.exports.VENDOR_FILE_PATH = "VENDOR/";

module.exports.ASSET_IMAGE_SIZES = [
  {
    name: "large",
    height: 1024,
    width: 1024,
  },
  {
    name: "medium",
    height: 512,
    width: 512,
  },
  {
    name: "small",
    height: 250,
    width: 250,
  },
];
module.exports.ASSET_FILE_PATH = "ASSET/";

module.exports.NOTIFICATION_TYPE = {
  leave_request: "leave_request",
  support_ticket: "support_ticket",
  announcement: "announcement",
  feedback: "feedback",
  lunch: "lunch",
  loan_request: "loan_request",
};

module.exports.ALL_FILE_PATH = "ALL_FILES/";
