const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_feedback = require("../../../controllers/feedback/add_feedback");
const edit_feedback = require("../../../controllers/feedback/edit_feedback");
const detail_feedback = require("../../../controllers/feedback/detail_feedback");
const delete_feedback = require("../../../controllers/feedback/delete_feedback");
const search_feedback = require("../../../controllers/feedback/search_feedback");
const submitted_feedbacks = require("../../../controllers/feedback/submitted_feedbacks");
const submit_feedback = require("../../../controllers/feedback/submit_feedback");
const get_performance = require("../../../controllers/feedback/get_performance");
const search_feedbacks_for_me = require("../../../controllers/feedback/search_feedbacks_for_me");

register_route({
  router,
  route: "/add_feedback",
  auth_enable: true,
  post_method: add_feedback,
});

register_route({
  router,
  route: "/edit_feedback/:id",
  auth_enable: true,
  put_method: edit_feedback,
});

register_route({
  router,
  route: "/detail_feedback/:id",
  auth_enable: true,
  get_method: detail_feedback,
});

register_route({
  router,
  route: "/delete_feedback/:id",
  auth_enable: true,
  delete_method: delete_feedback,
});

register_route({
  router,
  route: "/search_feedback",
  auth_enable: true,
  post_method: search_feedback,
});

register_route({
  router,
  route: "/submitted_feedbacks",
  auth_enable: true,
  post_method: submitted_feedbacks,
});

register_route({
  router,
  route: "/submit_feedback/:id",
  auth_enable: true,
  put_method: submit_feedback,
});

register_route({
  router,
  route: "/get_performance",
  auth_enable: true,
  post_method: get_performance,
});

register_route({
  router,
  route: "/search_feedbacks_for_me",
  auth_enable: true,
  post_method: search_feedbacks_for_me,
});

module.exports = router;
