const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_expense = require("../../../controllers/expense/add_expense");
const edit_expense = require("../../../controllers/expense/edit_expense");
const detail_expense = require("../../../controllers/expense/detail_expense");
const delete_expense = require("../../../controllers/expense/delete_expense");
const search_expense = require("../../../controllers/expense/search_expense");
const maintain_expense = require("../../../controllers/expense/maintain_expense");

register_route({
  router,
  route: "/add_expense",
  auth_enable: true,
  post_method: add_expense,
});

register_route({
  router,
  route: "/edit_expense/:id",
  auth_enable: true,
  put_method: edit_expense,
});

register_route({
  router,
  route: "/detail_expense/:id",
  auth_enable: true,
  get_method: detail_expense,
});

register_route({
  router,
  route: "/delete_expense/:id",
  auth_enable: true,
  delete_method: delete_expense,
});

register_route({
  router,
  route: "/search_expense",
  auth_enable: true,
  post_method: search_expense,
});

register_route({
  router,
  route: "/maintain_expense",
  auth_enable: true,
  get_method: maintain_expense,
});

module.exports = router;
