const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_announcement = require("../../../controllers/announcement/add_announcement");
const edit_announcement = require("../../../controllers/announcement/edit_announcement");
const detail_announcement = require("../../../controllers/announcement/detail_announcement");
const delete_announcement = require("../../../controllers/announcement/delete_announcement");
const search_announcement = require("../../../controllers/announcement/search_announcement");
register_route({
  router,
  route: "/add_announcement",
  auth_enable: true,
  post_method: add_announcement,
});

register_route({
  router,
  route: "/edit_announcement/:id",
  auth_enable: true,
  put_method: edit_announcement,
});

register_route({
  router,
  route: "/detail_announcement/:id",
  auth_enable: true,
  get_method: detail_announcement,
});

register_route({
  router,
  route: "/delete_announcement/:id",
  auth_enable: true,
  delete_method: delete_announcement,
});
register_route({
  router,
  route: "/search_announcement",
  auth_enable: true,
  post_method: search_announcement,
});

module.exports = router;
