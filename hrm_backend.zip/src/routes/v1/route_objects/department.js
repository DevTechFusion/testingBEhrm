const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_department = require("../../../controllers/department/add_department");
const edit_department = require("../../../controllers/department/edit_department");
const get_departments = require("../../../controllers/department/get_departments");
const detail_department = require("../../../controllers/department/detail_department");
const delete_department = require("../../../controllers/department/delete_department");
const get_active_departments = require("../../../controllers/department/get_active_departments");
register_route({
  router,
  route: "/add_department",
  auth_enable: true,
  post_method: add_department,
});

register_route({
  router,
  route: "/edit_department/:id",
  auth_enable: true,
  put_method: edit_department,
});

register_route({
  router,
  route: "/get_departments",
  auth_enable: true,
  get_method: get_departments,
});

register_route({
  router,
  route: "/detail_department/:id",
  auth_enable: true,
  get_method: detail_department,
});

register_route({
  router,
  route: "/delete_department/:id",
  auth_enable: true,
  delete_method: delete_department,
});

register_route({
  router,
  route: "/get_active_departments",
  auth_enable: true,
  get_method: get_active_departments,
});

module.exports = router;
