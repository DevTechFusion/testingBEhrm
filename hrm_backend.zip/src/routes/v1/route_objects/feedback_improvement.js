const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");

const add_feedback_improvement = require("../../../controllers/feedback_improvement/add_feedback_improvement");
const get_feedback_improvement_by_id = require("../../../controllers/feedback_improvement/get_feedback_improvement_by_id");
const list_feedback_improvement = require("../../../controllers/feedback_improvement/list_feedback_improvement");
const delete_feedback_improvement = require("../../../controllers/feedback_improvement/delete_feedback_improvement");
const update_feedback_improvement = require("../../../controllers/feedback_improvement/update_feedback_improvement");

register_route({
  router,
  route: "/add_feedback_improvement",
  auth_enable: true,
  post_method: add_feedback_improvement,
});

register_route({
  router,
  route: "/get_feedback_improvement_by_id/:id",
  auth_enable: true,
  get_method: get_feedback_improvement_by_id,
});

register_route({
  router,
  route: "/list_feedback_improvement",
  auth_enable: true,
  post_method: list_feedback_improvement,
});

register_route({
  router,
  route: "/delete_feedback_improvement/:id",
  auth_enable: true,
  delete_method: delete_feedback_improvement,
});

register_route({
  router,
  route: "/update_feedback_improvement/:id",
  auth_enable: true,
  put_method: update_feedback_improvement,
});

module.exports = router;
