const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_increment_history = require("../../../controllers/increment_history/add_increment_history");
const get_increment_history_by_id = require("../../../controllers/increment_history/get_increment_history_by_id");
const delete_increment_history = require("../../../controllers/increment_history/delete_increment_history");
const list_increment_history = require("../../../controllers/increment_history/list_increment_history");
const update_increment_history = require("../../../controllers/increment_history/update_increment_history");

register_route({
  router,
  route: "/add_increment_history",
  auth_enable: true,
  post_method: add_increment_history,
});

register_route({
  router,
  route: "/get_increment_history_by_id/:id",
  auth_enable: true,
  get_method: get_increment_history_by_id,
});

register_route({
  router,
  route: "/delete_increment_history/:id",
  auth_enable: true,
  delete_method: delete_increment_history,
});

register_route({
  router,
  route: "/list_increment_history",
  auth_enable: true,
  post_method: list_increment_history,
});

register_route({
  router,
  route: "/update_increment_history/:id",
  auth_enable: true,
  put_method: update_increment_history,
});
module.exports = router;
