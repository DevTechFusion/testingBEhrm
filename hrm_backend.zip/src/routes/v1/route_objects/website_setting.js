const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const edit_website_settings = require("../../../controllers/website_setting/edit_website_settings");
const get_website_setting = require("../../../controllers/website_setting/get_website_setting");
const get_gernal_setting = require("../../../controllers/website_setting/get_gernal_setting");
const update_gernal_setting = require("../../../controllers/website_setting/update_gernal_setting");
const update_twilio_setting = require("../../../controllers/website_setting/update_twilio_setting");
const get_twilio_setting = require("../../../controllers/website_setting/get_twilio_setting");

register_route({
  router,
  route: "/",
  auth_enable: true,
  get_method: get_website_setting,
});

register_route({
  router,
  route: "/edit_website_setting/",
  auth_enable: true,
  put_method: edit_website_settings,
});

register_route({
  router,
  route: "/get_gernal_setting",
  auth_enable: true,
  get_method: get_gernal_setting,
});

register_route({
  router,
  route: "/update_gernal_setting",
  auth_enable: true,
  put_method: update_gernal_setting,
});

// register_route({
//   router,
//   route: "/update_twilio_setting",
//   auth_enable: true,
//   put_method: update_twilio_setting,
// });

// register_route({
//   router,
//   route: "/get_twilio_setting",
//   auth_enable: true,
//   get_method: get_twilio_setting,
// });
module.exports = router;
