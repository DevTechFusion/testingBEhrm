const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_brand = require("../../../controllers/brand/add_brand");
const edit_brand = require("../../../controllers/brand/edit_brand");
const get_brand = require("../../../controllers/brand/get_brand");
const detail_brand = require("../../../controllers/brand/detail_brand");
const delete_brand = require("../../../controllers/brand/delete_brand");
const search_brand = require("../../../controllers/brand/search_brand");
register_route({
  router,
  route: "/add_brand",
  auth_enable: true,
  post_method: add_brand,
});

register_route({
  router,
  route: "/edit_brand/:id",
  auth_enable: true,
  put_method: edit_brand,
});

register_route({
  router,
  route: "/get_brand",
  auth_enable: true,
  get_method: get_brand,
});

register_route({
  router,
  route: "/detail_brand/:id",
  auth_enable: true,
  get_method: detail_brand,
});

register_route({
  router,
  route: "/delete_brand/:id",
  auth_enable: true,
  delete_method: delete_brand,
});
register_route({
  router,
  route: "/search_brand",
  auth_enable: true,
  get_method: search_brand,
});

module.exports = router;
