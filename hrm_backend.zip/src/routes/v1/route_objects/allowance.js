const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");

const add_allowance = require("../../../controllers/allowance/add_allowance");
const get_allowance_by_id = require("../../../controllers/allowance/get_allowance_by_id");
const delete_allowance = require("../../../controllers/allowance/delete_allowance");
const list_allowance = require("../../../controllers/allowance/list_allowance");
const update_allowance = require("../../../controllers/allowance/update_allowance");
register_route({
  router,
  route: "/add_allowance",
  auth_enable: true,
  post_method: add_allowance,
});

register_route({
  router,
  route: "/get_allowance_by_id/:id",
  auth_enable: true,
  get_method: get_allowance_by_id,
});

register_route({
  router,
  route: "/delete_allowance/:id",
  auth_enable: true,
  delete_method: delete_allowance,
});

register_route({
  router,
  route: "/list_allowance",
  auth_enable: true,
  get_method: list_allowance,
});

register_route({
  router,
  route: "/update_allowance/:id",
  auth_enable: true,
  put_method: update_allowance,
});
module.exports = router;
