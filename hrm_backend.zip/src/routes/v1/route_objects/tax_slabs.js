const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");

const add_tax_slabs = require("../../../controllers/tax_slabs/add_tax_slabs");
const list_tax_slabs = require("../../../controllers/tax_slabs/list_tax_slabs");
const get_tax_slabs_by_id = require("../../../controllers/tax_slabs/get_tax_slabs_by_id");
const delete_tax_slabs = require("../../../controllers/tax_slabs/delete_tax_slabs");
const update_tax_slabs = require("../../../controllers/tax_slabs/update_tax_slabs");

register_route({
  router,
  route: "/add_tax_slabs",
  auth_enable: true,
  post_method: add_tax_slabs,
});

register_route({
  router,
  route: "/list_tax_slabs",
  auth_enable: true,
  get_method: list_tax_slabs,
});

register_route({
  router,
  route: "/get_tax_slabs_by_id/:id",
  auth_enable: true,
  get_method: get_tax_slabs_by_id,
});

register_route({
  router,
  route: "/delete_tax_slabs/:id",
  auth_enable: true,
  delete_method: delete_tax_slabs,
});

register_route({
  router,
  route: "/update_tax_slabs/:id",
  auth_enable: true,
  put_method: update_tax_slabs,
});

module.exports = router;
