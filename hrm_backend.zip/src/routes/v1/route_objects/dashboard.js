const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const get_dashboard_data = require("../../../controllers/dashboard/get_dashboard_data");
const get_data_for_add_employee = require("../../../controllers/dashboard/get_data_for_add_employee");
register_route({
  router,
  route: "/get_dashboard_data",
  auth_enable: true,
  get_method: get_dashboard_data,
});

register_route({
  router,
  route: "/get_data_for_add_employee",
  auth_enable: true,
  get_method: get_data_for_add_employee,
});

module.exports = router;
