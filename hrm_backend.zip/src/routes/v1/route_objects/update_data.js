const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");

const update_leave_payment_status = require("../../../controllers/update_data/update_leave_payment_status");
const update_data_feedback_improvement = require("../../../controllers/update_data/update_data_feedback_improvement");
const update_payroll_data = require("../../../controllers/update_data/update_payroll_data");
register_route({
  router,
  route: "/update_leave_payment_status",
  auth_enable: true,
  get_method: update_leave_payment_status,
});

register_route({
  router,
  route: "/update_data_feedback_improvement",
  auth_enable: true,
  get_method: update_data_feedback_improvement,
});

register_route({
  router,
  route: "/update_payroll_data",
  auth_enable: false,
  post_method: update_payroll_data,
});

module.exports = router;
