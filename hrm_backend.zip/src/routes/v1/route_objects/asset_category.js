const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_asset_category = require("../../../controllers/asset_category/add_asset_category");
const edit_asset_category = require("../../../controllers/asset_category/edit_asset_category");
const get_asset_category = require("../../../controllers/asset_category/get_asset_category");
const detail_asset_category = require("../../../controllers/asset_category/detail_asset_category");
const delete_asset_category = require("../../../controllers/asset_category/delete_asset_category");
const search_asset_category = require("../../../controllers/asset_category/search_asset_category");
register_route({
  router,
  route: "/add_asset_category",
  auth_enable: true,
  post_method: add_asset_category,
});

register_route({
  router,
  route: "/edit_asset_category/:id",
  auth_enable: true,
  put_method: edit_asset_category,
});

register_route({
  router,
  route: "/get_asset_category",
  auth_enable: true,
  get_method: get_asset_category,
});

register_route({
  router,
  route: "/detail_asset_category/:id",
  auth_enable: true,
  get_method: detail_asset_category,
});

register_route({
  router,
  route: "/delete_asset_category/:id",
  auth_enable: true,
  delete_method: delete_asset_category,
});
register_route({
  router,
  route: "/search_asset_category",
  auth_enable: true,
  get_method: search_asset_category,
});

module.exports = router;
