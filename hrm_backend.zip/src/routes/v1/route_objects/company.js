const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_company = require("../../../controllers/company/add_company");
const edit_company = require("../../../controllers/company/edit_company");
const get_company = require("../../../controllers/company/get_company");
const get_active_companies = require("../../../controllers/company/get_active_companies");
const detail_company = require("../../../controllers/company/detail_company");
const delete_company = require("../../../controllers/company/delete_company");
register_route({
  router,
  route: "/add_company",
  auth_enable: true,
  post_method: add_company,
});

register_route({
  router,
  route: "/edit_company/:id",
  auth_enable: true,
  put_method: edit_company,
});

register_route({
  router,
  route: "/get_company",
  auth_enable: true,
  get_method: get_company,
});

register_route({
  router,
  route: "/get_active_companies",
  auth_enable: true,
  get_method: get_active_companies,
});

register_route({
  router,
  route: "/detail_company/:id",
  auth_enable: true,
  get_method: detail_company,
});

register_route({
  router,
  route: "/delete_company/:id",
  auth_enable: true,
  delete_method: delete_company,
});


module.exports = router;
