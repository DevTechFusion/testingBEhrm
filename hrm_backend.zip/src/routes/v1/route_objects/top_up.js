const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_top_up = require("../../../controllers/top_up/add_top_up");
const edit_top_up = require("../../../controllers/top_up/edit_top_up");
const detail_top_up = require("../../../controllers/top_up/detail_top_up");
const detail_top_up_for_edit = require("../../../controllers/top_up/detail_top_up_for_edit");
const delete_top_up = require("../../../controllers/top_up/delete_top_up");
const search_top_up = require("../../../controllers/top_up/search_top_up");
const maintain_top_up = require("../../../controllers/top_up/maintain_top_up");

register_route({
  router,
  route: "/add_top_up",
  auth_enable: true,
  post_method: add_top_up,
});

register_route({
  router,
  route: "/edit_top_up/:id",
  auth_enable: true,
  put_method: edit_top_up,
});

register_route({
  router,
  route: "/detail_top_up/:id",
  auth_enable: true,
  get_method: detail_top_up,
});

register_route({
  router,
  route: "/detail_top_up_for_edit/:id",
  auth_enable: true,
  get_method: detail_top_up_for_edit,
});

register_route({
  router,
  route: "/delete_top_up/:id",
  auth_enable: true,
  delete_method: delete_top_up,
});

register_route({
  router,
  route: "/search_top_up",
  auth_enable: true,
  post_method: search_top_up,
});

register_route({
  router,
  route: "/maintain_top_up",
  auth_enable: true,
  get_method: maintain_top_up,
});

module.exports = router;
