const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_payroll = require("../../../controllers/payroll/add_payroll");
const edit_payroll = require("../../../controllers/payroll/edit_payroll");
const detail_payroll = require("../../../controllers/payroll/detail_payroll");
const delete_payroll = require("../../../controllers/payroll/delete_payroll");
const search_payroll = require("../../../controllers/payroll/search_payroll");
const email_payslip = require("../../../controllers/payroll/email_payslip");
const send_payslip_again = require("../../../controllers/payroll/send_payslip_again");
register_route({
  router,
  route: "/add_payroll",
  auth_enable: true,
  post_method: add_payroll,
});

register_route({
  router,
  route: "/edit_payroll/:id",
  auth_enable: true,
  put_method: edit_payroll,
});

register_route({
  router,
  route: "/detail_payroll/:id",
  auth_enable: true,
  get_method: detail_payroll,
});

register_route({
  router,
  route: "/delete_payroll",
  auth_enable: true,
  delete_method: delete_payroll,
});

register_route({
  router,
  route: "/search_payroll",
  auth_enable: true,
  post_method: search_payroll,
});

register_route({
  router,
  route: "/email_payslip",
  auth_enable: true,
  post_method: email_payslip,
});

register_route({
  router,
  route: "/send_payslip_again",
  auth_enable: true,
  post_method: send_payslip_again,
});
module.exports = router;
