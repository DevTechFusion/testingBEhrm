const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_vendor = require("../../../controllers/vendor/add_vendor");
const edit_vendor = require("../../../controllers/vendor/edit_vendor");
const get_active_vendors = require("../../../controllers/vendor/get_active_vendors");
const detail_vendor = require("../../../controllers/vendor/detail_vendor");
const delete_vendor = require("../../../controllers/vendor/delete_vendor");
const search_vendor = require("../../../controllers/vendor/search_vendor");
register_route({
  router,
  route: "/add_vendor",
  auth_enable: true,
  post_method: add_vendor,
});

register_route({
  router,
  route: "/edit_vendor/:id",
  auth_enable: true,
  put_method: edit_vendor,
});

register_route({
  router,
  route: "/get_active_vendors",
  auth_enable: true,
  get_method: get_active_vendors,
});

register_route({
  router,
  route: "/detail_vendor/:id",
  auth_enable: true,
  get_method: detail_vendor,
});

register_route({
  router,
  route: "/delete_vendor/:id",
  auth_enable: true,
  delete_method: delete_vendor,
});
register_route({
  router,
  route: "/search_vendor",
  auth_enable: true,
  get_method: search_vendor,
});

module.exports = router;
