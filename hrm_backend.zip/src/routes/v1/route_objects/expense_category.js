const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_expense_category = require("../../../controllers/expense_category/add_expense_category");
const edit_expense_category = require("../../../controllers/expense_category/edit_expense_category");
const get_expense_category = require("../../../controllers/expense_category/get_expense_category");
const detail_expense_category = require("../../../controllers/expense_category/detail_expense_category");
const delete_expense_category = require("../../../controllers/expense_category/delete_expense_category");
const search_expense_category = require("../../../controllers/expense_category/search_expense_category");
const get_expense_category_and_active_user = require("../../../controllers/expense_category/get_expense_category_and_active_user");

register_route({
  router,
  route: "/add_expense_category",
  auth_enable: true,
  post_method: add_expense_category,
});

register_route({
  router,
  route: "/edit_expense_category/:id",
  auth_enable: true,
  put_method: edit_expense_category,
});

register_route({
  router,
  route: "/get_expense_category",
  auth_enable: true,
  get_method: get_expense_category,
});

register_route({
  router,
  route: "/detail_expense_category/:id",
  auth_enable: true,
  get_method: detail_expense_category,
});

register_route({
  router,
  route: "/delete_expense_category/:id",
  auth_enable: true,
  delete_method: delete_expense_category,
});
register_route({
  router,
  route: "/search_expense_category",
  auth_enable: true,
  get_method: search_expense_category,
});

register_route({
  router,
  route: "/get_expense_category_and_active_user",
  auth_enable: true,
  get_method: get_expense_category_and_active_user,
});

module.exports = router;
