const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const get_notifications = require("../../../controllers/notification/get_notifications");
const mark_notification_as_read = require("../../../controllers/notification/mark_notification_as_read");
const mark_all_notifications_as_read = require("../../../controllers/notification/mark_all_notifications_as_read");

register_route({
  router,
  route: "/get_notifications",
  auth_enable: true,
  get_method: get_notifications,
});

register_route({
  router,
  route: "/mark_notification_as_read/:id",
  auth_enable: true,
  get_method: mark_notification_as_read,
});

register_route({
  router,
  route: "/mark_all_notifications_as_read",
  auth_enable: true,
  get_method: mark_all_notifications_as_read,
});

module.exports = router;
