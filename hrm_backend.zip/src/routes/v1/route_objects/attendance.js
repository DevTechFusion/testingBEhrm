const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_attendance = require("../../../controllers/attendance/add_attendance");
const add_attendance_manually = require("../../../controllers/attendance/add_attendance_manually");
const get_attendances = require("../../../controllers/attendance/get_attendance");
const detail_attendance = require("../../../controllers/attendance/detail_attendance");
const delete_attendance = require("../../../controllers/attendance/delete_attendance");
const delete_attendance_individually = require("../../../controllers/attendance/delete_attendance_individually");
const get_attendance_for_employee = require("../../../controllers/attendance/get_attendance_for_employee");
const get_attendance_for_employee_user = require("../../../controllers/attendance/get_attendance_for_employee_user");
const get_employee_absents = require("../../../controllers/attendance/get_employee_absents");
const mark_discount_minutes = require("../../../controllers/attendance/mark_discount_minutes");
const mark_discount_minutes_by_user = require("../../../controllers/attendance/mark_discount_minutes_by_user");
const get_attendance_for_fine = require("../../../controllers/attendance/get_attendance_for_fine");
const grant_relax_minutes = require("../../../controllers/attendance/grant_relax_minutes");
const get_finesheet = require("../../../controllers/attendance/get_finesheet");
const pay_fine = require("../../../controllers/attendance/pay_fine");
const get_fine_user = require("../../../controllers/attendance/get_fine_user");
const get_employee_leaves = require("../../../controllers/attendance/get_employee_leaves");
const get_employee_leaves_for_report = require("../../../controllers/attendance/get_employee_leaves_for_report");
const get_attendances_v1 = require("../../../controllers/attendance/get_attendance_v1");
const get_attendance_by_id_specific_day = require("../../../controllers/attendance/get_attendance_by_id_specific_day");
register_route({
  router,
  route: "/add_attendance",
  auth_enable: true,
  post_method: add_attendance,
});

register_route({
  router,
  route: "/add_attendance_manually",
  auth_enable: true,
  post_method: add_attendance_manually,
});

register_route({
  router,
  route: "/get_attendance_for_employee",
  auth_enable: true,
  post_method: get_attendance_for_employee,
});

register_route({
  router,
  route: "/get_attendance_for_employee_user/:id",
  auth_enable: true,
  post_method: get_attendance_for_employee_user,
});

register_route({
  router,
  route: "/get_employee_absents",
  auth_enable: true,
  post_method: get_employee_absents,
});

register_route({
  router,
  route: "/get_attendances",
  auth_enable: true,
  get_method: get_attendances,
});

register_route({
  router,
  route: "/detail_attendance",
  auth_enable: true,
  get_method: detail_attendance,
});

register_route({
  router,
  route: "/delete_attendance",
  auth_enable: true,
  post_method: delete_attendance,
});
register_route({
  router,
  route: "/delete_attendance_individually",
  auth_enable: true,
  post_method: delete_attendance_individually,
});

register_route({
  router,
  route: "/mark_discount_minutes",
  auth_enable: true,
  post_method: mark_discount_minutes,
});

register_route({
  router,
  route: "/mark_discount_minutes_by_user",
  auth_enable: true,
  get_method: mark_discount_minutes_by_user,
});

register_route({
  router,
  route: "/get_attendance_for_fine",
  auth_enable: true,
  post_method: get_attendance_for_fine,
});

register_route({
  router,
  route: "/grant_relax_minutes",
  auth_enable: true,
  post_method: grant_relax_minutes,
});

register_route({
  router,
  route: "/get_finesheet",
  auth_enable: true,
  post_method: get_finesheet,
});

register_route({
  router,
  route: "/pay_fine",
  auth_enable: true,
  post_method: pay_fine,
});

register_route({
  router,
  route: "/get_fine_user",
  auth_enable: true,
  get_method: get_fine_user,
});

register_route({
  router,
  route: "/get_employee_leaves",
  auth_enable: true,
  post_method: get_employee_leaves,
});

register_route({
  router,
  route: "/get_employee_leaves_for_report",
  auth_enable: true,
  post_method: get_employee_leaves_for_report,
});

register_route({
  router,
  route: "/get_attendances_v1",
  auth_enable: true,
  post_method: get_attendances_v1,
});

register_route({
  router,
  route: "/get_attendance_by_id_specific_day/:id",
  auth_enable: true,
  get_method: get_attendance_by_id_specific_day,
});

module.exports = router;
