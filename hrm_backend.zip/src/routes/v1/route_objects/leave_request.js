const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_leave_request = require("../../../controllers/leave_request/add_leave_request");
const edit_leave_request = require("../../../controllers/leave_request/edit_leave_request");
const detail_leave_request = require("../../../controllers/leave_request/detail_leave_request");
const delete_leave_request = require("../../../controllers/leave_request/delete_leave_request");
const search_leave_request = require("../../../controllers/leave_request/search_leave_request");
const process_leave_request = require("../../../controllers/leave_request/process_leave_request");
const add_leave_request_admin = require("../../../controllers/leave_request/add_leave_request_admin");
const edit_leave_request_admin = require("../../../controllers/leave_request/edit_leave_request_admin");
const delete_leave_request_admin = require("../../../controllers/leave_request/delete_leave_request_admin");
const process_leave_request_admin = require("../../../controllers/leave_request/process_leave_request_admin");
const search_leave_request_admin = require("../../../controllers/leave_request/search_leave_request_admin");
const search_all_leave_request_admin = require("../../../controllers/leave_request/search_all_leave_request_admin");
const get_all_employee_leave_request_stats = require("../../../controllers/leave_request/get_all_employee_leave_request_stats");
const get_team_leave_requests_for_lead = require("../../../controllers/leave_request/get_team_leave_requests_for_lead");
const get_half_leave_requests_yearly = require("../../../controllers/leave_request/get_half_leave_requests_yearly");
const change_leave_payment_status = require("../../../controllers/leave_request/change_leave_payment_status");
const update_count_in_yearly_leaves = require("../../../controllers/leave_request/update_count_in_yearly_leaves");
register_route({
  router,
  route: "/add_leave_request",
  auth_enable: true,
  post_method: add_leave_request,
});

register_route({
  router,
  route: "/edit_leave_request/:id",
  auth_enable: true,
  put_method: edit_leave_request,
});

register_route({
  router,
  route: "/detail_leave_request/:id",
  auth_enable: true,
  get_method: detail_leave_request,
});

register_route({
  router,
  route: "/delete_leave_request/:id",
  auth_enable: true,
  delete_method: delete_leave_request,
});
register_route({
  router,
  route: "/search_leave_request",
  auth_enable: true,
  post_method: search_leave_request,
});

register_route({
  router,
  route: "/process_leave_request/:id",
  auth_enable: true,
  put_method: process_leave_request,
});

register_route({
  router,
  route: "/add_leave_request_admin",
  auth_enable: true,
  post_method: add_leave_request_admin,
});

register_route({
  router,
  route: "/edit_leave_request_admin/:id",
  auth_enable: true,
  put_method: edit_leave_request_admin,
});

register_route({
  router,
  route: "/delete_leave_request_admin/:id",
  auth_enable: true,
  delete_method: delete_leave_request_admin,
});

register_route({
  router,
  route: "/process_leave_request_admin/:id",
  auth_enable: true,
  put_method: process_leave_request_admin,
});

register_route({
  router,
  route: "/search_leave_request_admin",
  auth_enable: true,
  post_method: search_leave_request_admin,
});
register_route({
  router,
  route: "/search_all_leave_request_admin",
  auth_enable: true,
  post_method: search_all_leave_request_admin,
});
register_route({
  router,
  route: "/get_all_employee_leave_request_stats",
  auth_enable: false,
  post_method: get_all_employee_leave_request_stats,
});
register_route({
  router,
  route: "/get_team_leave_requests_for_lead",
  auth_enable: true,
  post_method: get_team_leave_requests_for_lead,
});

register_route({
  router,
  route: "/get_half_leave_requests_yearly",
  auth_enable: true,
  get_method: get_half_leave_requests_yearly,
});

// register_route({
//   router,
//   route: "/change_leave_payment_status/:leave_request_id",
//   auth_enable: true,
//   put_method: change_leave_payment_status,
// });

register_route({
  router,
  route: "/update_count_in_yearly_leaves/:leave_request_id",
  auth_enable: true,
  put_method: update_count_in_yearly_leaves,
});

module.exports = router;
