const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_company_asset = require("../../../controllers/company_asset/add_company_asset");
const assign_company_asset = require("../../../controllers/company_asset/assign_company_asset");
const add_repair_history_company_asset = require("../../../controllers/company_asset/add_repair_history_company_asset");
const edit_repair_history_company_asset = require("../../../controllers/company_asset/edit_repair_history_company_asset");
const edit_company_asset = require("../../../controllers/company_asset/edit_company_asset");
const get_free_active_company_assets = require("../../../controllers/company_asset/get_free_active_company_assets");
const detail_company_asset = require("../../../controllers/company_asset/detail_company_asset");
const delete_company_asset = require("../../../controllers/company_asset/delete_company_asset");
const search_company_asset = require("../../../controllers/company_asset/search_company_asset");
const delete_repair_history_company_asset = require("../../../controllers/company_asset/delete_repair_history_company_asset");
const get_data_for_company_asset_list = require("../../../controllers/company_asset/get_data_for_company_asset_list");
register_route({
  router,
  route: "/add_company_asset",
  auth_enable: true,
  post_method: add_company_asset,
});

register_route({
  router,
  route: "/assign_company_asset/:id",
  auth_enable: true,
  post_method: assign_company_asset,
});

register_route({
  router,
  route: "/add_repair_history_company_asset/:id",
  auth_enable: true,
  post_method: add_repair_history_company_asset,
});

register_route({
  router,
  route: "/edit_repair_history_company_asset/:id",
  auth_enable: true,
  put_method: edit_repair_history_company_asset,
});

register_route({
  router,
  route: "/delete_repair_history_company_asset/:id",
  auth_enable: true,
  put_method: delete_repair_history_company_asset,
});

register_route({
  router,
  route: "/edit_company_asset/:id",
  auth_enable: true,
  put_method: edit_company_asset,
});

register_route({
  router,
  route: "/get_free_active_company_assets",
  auth_enable: true,
  get_method: get_free_active_company_assets,
});

register_route({
  router,
  route: "/detail_company_asset/:id",
  auth_enable: true,
  get_method: detail_company_asset,
});

register_route({
  router,
  route: "/delete_company_asset/:id",
  auth_enable: true,
  delete_method: delete_company_asset,
});
register_route({
  router,
  route: "/search_company_asset",
  auth_enable: true,
  post_method: search_company_asset,
});

register_route({
  router,
  route: "/get_data_for_company_asset_list",
  auth_enable: true,
  get_method: get_data_for_company_asset_list,
});
module.exports = router;
