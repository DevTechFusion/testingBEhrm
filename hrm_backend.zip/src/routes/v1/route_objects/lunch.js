const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_lunch = require("../../../controllers/lunch/add_lunch");
const edit_lunch = require("../../../controllers/lunch/edit_lunch");
const detail_lunch = require("../../../controllers/lunch/detail_lunch");
const delete_lunch = require("../../../controllers/lunch/delete_lunch");
const search_lunch = require("../../../controllers/lunch/search_lunch");
const continue_lunch = require("../../../controllers/lunch/continue_lunch");

register_route({
  router,
  route: "/add_lunch",
  auth_enable: true,
  post_method: add_lunch,
});

register_route({
  router,
  route: "/edit_lunch/:id",
  auth_enable: true,
  put_method: edit_lunch,
});

register_route({
  router,
  route: "/detail_lunch/:id",
  auth_enable: true,
  get_method: detail_lunch,
});

register_route({
  router,
  route: "/delete_lunch/:id",
  auth_enable: true,
  delete_method: delete_lunch,
});

register_route({
  router,
  route: "/search_lunch",
  auth_enable: true,
  post_method: search_lunch,
});

register_route({
  router,
  route: "/continue_lunch",
  auth_enable: true,
  put_method: continue_lunch,
});

module.exports = router;
