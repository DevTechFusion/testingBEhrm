const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_employee_deactivation = require("../../../controllers/employee_deactivation/add_employee_deactivation");
const edit_employee_deactivation = require("../../../controllers/employee_deactivation/edit_employee_deactivation");
const get_employee_deactivations = require("../../../controllers/employee_deactivation/get_employee_deactivation");
const detail_employee_deactivation = require("../../../controllers/employee_deactivation/detail_employee_deactivation");
const delete_employee_deactivation = require("../../../controllers/employee_deactivation/delete_employee_deactivation");
register_route({
  router,
  route: "/add_employee_deactivation",
  auth_enable: true,
  post_method: add_employee_deactivation,
});

register_route({
  router,
  route: "/edit_employee_deactivation/:id",
  auth_enable: true,
  put_method: edit_employee_deactivation,
});

register_route({
  router,
  route: "/get_employee_deactivations",
  auth_enable: true,
  get_method: get_employee_deactivations,
});

register_route({
  router,
  route: "/detail_employee_deactivation/:id",
  auth_enable: true,
  get_method: detail_employee_deactivation,
});

register_route({
  router,
  route: "/delete_employee_deactivation/:id",
  auth_enable: true,
  delete_method: delete_employee_deactivation,
});

module.exports = router;
