const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_loan_request = require("../../../controllers/loan_request/add_loan_request");
const edit_loan_request = require("../../../controllers/loan_request/edit_loan_request");
const detail_loan_request = require("../../../controllers/loan_request/detail_loan_request");
const delete_loan_request = require("../../../controllers/loan_request/delete_loan_request");
const search_loan_request = require("../../../controllers/loan_request/search_loan_request");
const process_loan_request = require("../../../controllers/loan_request/process_loan_request");
const add_loan_request_admin = require("../../../controllers/loan_request/add_loan_request_admin");
const edit_loan_request_admin = require("../../../controllers/loan_request/edit_loan_request_admin");
const delete_loan_request_admin = require("../../../controllers/loan_request/delete_loan_request_admin");
const update_installment_status = require("../../../controllers/loan_request/update_installment_status");
const search_loan_request_admin = require("../../../controllers/loan_request/search_loan_request_admin");
const get_team_loan_requests_for_lead = require("../../../controllers/loan_request/get_team_loan_requests_for_lead");
const pending_loan_request_admin = require("../../../controllers/loan_request/pending_loan_request_admin");
const update_old_loan_request = require("../../../controllers/loan_request/update_old_loan_request");
const rollout_installment_status = require("../../../controllers/loan_request/rollout_installment_status");
const update_loan_returned_date = require("../../../controllers/loan_request/update_loan_returned_date");
const update_loan_installment_date = require("../../../controllers/loan_request/update_loan_installment_date");
register_route({
  router,
  route: "/add_loan_request",
  auth_enable: true,
  post_method: add_loan_request,
});

register_route({
  router,
  route: "/edit_loan_request/:id",
  auth_enable: true,
  put_method: edit_loan_request,
});

register_route({
  router,
  route: "/detail_loan_request/:id",
  auth_enable: true,
  get_method: detail_loan_request,
});

register_route({
  router,
  route: "/delete_loan_request/:id",
  auth_enable: true,
  delete_method: delete_loan_request,
});
register_route({
  router,
  route: "/search_loan_request",
  auth_enable: true,
  post_method: search_loan_request,
});

register_route({
  router,
  route: "/process_loan_request/:id",
  auth_enable: true,
  put_method: process_loan_request,
});

register_route({
  router,
  route: "/add_loan_request_admin",
  auth_enable: true,
  post_method: add_loan_request_admin,
});

register_route({
  router,
  route: "/edit_loan_request_admin/:id",
  auth_enable: true,
  put_method: edit_loan_request_admin,
});

register_route({
  router,
  route: "/delete_loan_request_admin/:id",
  auth_enable: true,
  delete_method: delete_loan_request_admin,
});

register_route({
  router,
  route: "/update_installment_status/:id",
  auth_enable: true,
  put_method: update_installment_status,
});

register_route({
  router,
  route: "/search_loan_request_admin",
  auth_enable: false,
  post_method: search_loan_request_admin,
});
register_route({
  router,
  route: "/pending_loan_request_admin",
  auth_enable: true,
  post_method: pending_loan_request_admin,
});
register_route({
  router,
  route: "/get_team_loan_requests_for_lead",
  auth_enable: true,
  post_method: get_team_loan_requests_for_lead,
});

register_route({
  router,
  route: "/update_old_loan_request",
  auth_enable: true,
  get_method: update_old_loan_request,
});

register_route({
  router,
  route: "/rollout_installment_status/:id",
  auth_enable: true,
  put_method: rollout_installment_status,
});

register_route({
  router,
  route: "/update_loan_returned_date",
  auth_enable: true,
  get_method: update_loan_returned_date,
});

register_route({
  router,
  route: "/update_loan_installment_date",
  auth_enable: true,
  put_method: update_loan_installment_date,
});

module.exports = router;
