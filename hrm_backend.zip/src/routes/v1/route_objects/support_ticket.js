const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_support_ticket = require("../../../controllers/support_ticket/add_support_ticket");
const edit_support_ticket = require("../../../controllers/support_ticket/edit_support_ticket");
const detail_support_ticket = require("../../../controllers/support_ticket/detail_support_ticket");
const delete_support_ticket = require("../../../controllers/support_ticket/delete_support_ticket");
const search_support_ticket = require("../../../controllers/support_ticket/search_support_ticket");
const process_support_ticket = require("../../../controllers/support_ticket/process_support_ticket");
const add_support_ticket_admin = require("../../../controllers/support_ticket/add_support_ticket_admin");
const edit_support_ticket_admin = require("../../../controllers/support_ticket/edit_support_ticket_admin");
const delete_support_ticket_admin = require("../../../controllers/support_ticket/delete_support_ticket_admin");
const search_support_ticket_admin = require("../../../controllers/support_ticket/search_support_ticket_admin");
const add_message_support_ticket = require("../../../controllers/support_ticket/add_message_support_ticket");
const delete_message_support_ticket = require("../../../controllers/support_ticket/delete_message_support_ticket");
const edit_message_support_ticket = require("../../../controllers/support_ticket/edit_message_support_ticket");
const remove_unread_message_count_support_ticket = require("../../../controllers/support_ticket/remove_unread_message_count_support_ticket");

register_route({
  router,
  route: "/add_support_ticket",
  auth_enable: true,
  post_method: add_support_ticket,
});

register_route({
  router,
  route: "/edit_support_ticket/:id",
  auth_enable: true,
  put_method: edit_support_ticket,
});

register_route({
  router,
  route: "/detail_support_ticket/:id",
  auth_enable: true,
  get_method: detail_support_ticket,
});

register_route({
  router,
  route: "/delete_support_ticket/:id",
  auth_enable: true,
  delete_method: delete_support_ticket,
});
register_route({
  router,
  route: "/search_support_ticket",
  auth_enable: true,
  post_method: search_support_ticket,
});

register_route({
  router,
  route: "/process_support_ticket/:id",
  auth_enable: true,
  put_method: process_support_ticket,
});

register_route({
  router,
  route: "/add_support_ticket_admin",
  auth_enable: true,
  post_method: add_support_ticket_admin,
});

register_route({
  router,
  route: "/edit_support_ticket_admin/:id",
  auth_enable: true,
  put_method: edit_support_ticket_admin,
});

register_route({
  router,
  route: "/delete_support_ticket_admin/:id",
  auth_enable: true,
  delete_method: delete_support_ticket_admin,
});

register_route({
  router,
  route: "/search_support_ticket_admin",
  auth_enable: true,
  post_method: search_support_ticket_admin,
});

register_route({
  router,
  route: "/add_message_support_ticket/:id",
  auth_enable: true,
  post_method: add_message_support_ticket,
});

register_route({
  router,
  route: "/delete_message_support_ticket/:id",
  auth_enable: true,
  post_method: delete_message_support_ticket,
});

register_route({
  router,
  route: "/edit_message_support_ticket/:id",
  auth_enable: true,
  put_method: edit_message_support_ticket,
});

register_route({
  router,
  route: "/remove_unread_message_count_support_ticket/:id",
  auth_enable: true,
  get_method: remove_unread_message_count_support_ticket,
});

module.exports = router;
