const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_role = require("../../../controllers/role/add_role");
const edit_role = require("../../../controllers/role/edit_role");
const get_role = require("../../../controllers/role/get_role");
const detail_role = require("../../../controllers/role/detail_role");
const delete_role = require("../../../controllers/role/delete_role");
const search_role = require("../../../controllers/role/search_role");
register_route({
  router,
  route: "/add_role",
  auth_enable: true,
  post_method: add_role,
});

register_route({
  router,
  route: "/edit_role/:id",
  auth_enable: true,
  put_method: edit_role,
});

register_route({
  router,
  route: "/get_role",
  auth_enable: true,
  get_method: get_role,
});

register_route({
  router,
  route: "/detail_role/:id",
  auth_enable: true,
  get_method: detail_role,
});

register_route({
  router,
  route: "/delete_role/:id",
  auth_enable: true,
  delete_method: delete_role,
});
register_route({
  router,
  route: "/search_role",
  auth_enable: true,
  get_method: search_role,
});

module.exports = router;
