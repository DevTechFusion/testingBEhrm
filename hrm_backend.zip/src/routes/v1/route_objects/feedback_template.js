const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_feedback_template = require("../../../controllers/feedback_template/add_feedback_template");
const edit_feedback_template = require("../../../controllers/feedback_template/edit_feedback_template");
const get_feedback_template = require("../../../controllers/feedback_template/get_feedback_template");
const detail_feedback_template = require("../../../controllers/feedback_template/detail_feedback_template");
const delete_feedback_template = require("../../../controllers/feedback_template/delete_feedback_template");
const search_feedback_template = require("../../../controllers/feedback_template/search_feedback_template");
register_route({
  router,
  route: "/add_feedback_template",
  auth_enable: true,
  post_method: add_feedback_template,
});

register_route({
  router,
  route: "/edit_feedback_template/:id",
  auth_enable: true,
  put_method: edit_feedback_template,
});

register_route({
  router,
  route: "/get_feedback_template",
  auth_enable: true,
  get_method: get_feedback_template,
});

register_route({
  router,
  route: "/detail_feedback_template/:id",
  auth_enable: true,
  get_method: detail_feedback_template,
});

register_route({
  router,
  route: "/delete_feedback_template/:id",
  auth_enable: true,
  delete_method: delete_feedback_template,
});
register_route({
  router,
  route: "/search_feedback_template",
  auth_enable: true,
  get_method: search_feedback_template,
});

module.exports = router;
