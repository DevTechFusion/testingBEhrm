const router = require("express").Router();
const { register_route } = require("../../../utils/reg_routes");
const add_employee = require("../../../controllers/employee/add_employee");
const edit_employee = require("../../../controllers/employee/edit_employee");
const get_employees = require("../../../controllers/employee/get_employees");
const get_all_employees = require("../../../controllers/employee/get_all_employees");
const get_active_employees = require("../../../controllers/employee/get_active_employees");
const detail_employee = require("../../../controllers/employee/detail_employee");
const delete_employee = require("../../../controllers/employee/delete_employee");
const detail_employee_by_id = require("../../../controllers/employee/detail_employee_by_id");
const get_employees_for_department = require("../../../controllers/employee/get_employee_for_department");
const update_sidebar_status_for_employee = require("../../../controllers/employee/update_sidebar_status_for_employee");
const get_employees_for_payroll = require("../../../controllers/employee/get_employees_for_payroll");
const add_member_to_team = require("../../../controllers/employee/add_member_to_team");
const search_team_members = require("../../../controllers/employee/search_team_members");
const remove_member_from_team = require("../../../controllers/employee/remove_member_from_team");
const get_all_team_members = require("../../../controllers/employee/get_all_team_members");
const get_leads_and_their_teams = require("../../../controllers/employee/get_leads_and_their_teams");
const get_members_leads_for_each_other = require("../../../controllers/employee/get_members_leads_for_each_other");
const update_tech_lead_for_team_member = require("../../../controllers/employee/update_tech_lead_for_team_member");
const get_active_employees_for_loan = require("../../../controllers/employee/get_active_employees_for_loan");
const get_member_list_for_my_team = require("../../../controllers/employee/get_member_list_for_my_team");
const get_member_birthday_anniversary = require("../../../controllers/employee/get_member_birthday_anniversary");
const get_employees_v1 = require("../../../controllers/employee/get_employees_v1");
const get_member_increment = require("../../../controllers/employee/get_member_increment");
const detail_employee_by_id_for_settings = require("../../../controllers/employee/detail_employee_by_id_for_settings");
const edit_employee_for_settings = require("../../../controllers/employee/edit_employee_for_settings");
const detail_employee_by_id_popup = require("../../../controllers/employee/detail_employee_by_id_popup");
const update_employee_allowance = require("../../../controllers/employee/update_employee_allowance");
const get_employee_allowance = require("../../../controllers/employee/get_employee_allowance");
const get_active_employees_with_search = require("../../../controllers/employee/get_active_employees_with_search");
const search_team_members_of_lead_tech_lead = require("../../../controllers/employee/search_team_members_of_lead_tech_lead");
const get_employees_for_payroll_v2 = require("../../../controllers/employee/get_employees_for_payroll_v2");
const search_team_members_of_lead_tech_lead_for_feedback_improvement = require("../../../controllers/employee/search_team_members_of_lead_tech_lead_for_feedback_improvement");

register_route({
  router,
  route: "/add_employee",
  auth_enable: true,
  post_method: add_employee,
});

register_route({
  router,
  route: "/edit_employee/:id",
  auth_enable: true,
  put_method: edit_employee,
});

register_route({
  router,
  route: "/get_employees",
  auth_enable: false,
  get_method: get_employees,
});

register_route({
  router,
  route: "/get_all_employees",
  auth_enable: true,
  get_method: get_all_employees,
});

register_route({
  router,
  route: "/get_active_employees_for_loan",
  auth_enable: true,
  get_method: get_active_employees_for_loan,
});

register_route({
  router,
  route: "/get_active_employees",
  auth_enable: true,
  get_method: get_active_employees,
});

register_route({
  router,
  route: "/get_employees_for_department",
  auth_enable: true,
  get_method: get_employees_for_department,
});

register_route({
  router,
  route: "/detail_employee",
  auth_enable: true,
  get_method: detail_employee,
});

register_route({
  router,
  route: "/detail_employee_by_id/:id",
  auth_enable: true,
  get_method: detail_employee_by_id,
});

register_route({
  router,
  route: "/delete_employee/:id",
  auth_enable: true,
  delete_method: delete_employee,
});

register_route({
  router,
  route: "/update_sidebar_status_for_employee",
  auth_enable: true,
  put_method: update_sidebar_status_for_employee,
});

register_route({
  router,
  route: "/get_employees_for_payroll",
  auth_enable: true,
  post_method: get_employees_for_payroll,
});

register_route({
  router,
  route: "/add_member_to_team",
  auth_enable: true,
  post_method: add_member_to_team,
});

register_route({
  router,
  route: "/search_team_members",
  auth_enable: true,
  get_method: search_team_members,
});

register_route({
  router,
  route: "/remove_member_from_team/:member_id",
  auth_enable: true,
  delete_method: remove_member_from_team,
});

register_route({
  router,
  route: "/get_all_team_members",
  auth_enable: true,
  get_method: get_all_team_members,
});

register_route({
  router,
  route: "/get_leads_and_their_teams",
  auth_enable: true,
  get_method: get_leads_and_their_teams,
});

register_route({
  router,
  route: "/get_members_leads_for_each_other",
  auth_enable: true,
  post_method: get_members_leads_for_each_other,
});

register_route({
  router,
  route: "/update_tech_lead_for_team_member",
  auth_enable: true,
  post_method: update_tech_lead_for_team_member,
});

register_route({
  router,
  route: "/get_member_list_for_my_team",
  auth_enable: true,
  get_method: get_member_list_for_my_team,
});

register_route({
  router,
  route: "/get_member_birthday_anniversary",
  auth_enable: true,
  post_method: get_member_birthday_anniversary,
});

register_route({
  router,
  route: "/get_employees_v1",
  auth_enable: true,
  get_method: get_employees_v1,
});

register_route({
  router,
  route: "/get_member_increment",
  auth_enable: true,
  post_method: get_member_increment,
});

register_route({
  router,
  route: "/detail_employee_by_id_for_settings/:id",
  auth_enable: true,
  get_method: detail_employee_by_id_for_settings,
});

register_route({
  router,
  route: "/edit_employee_for_settings/:id",
  auth_enable: true,
  put_method: edit_employee_for_settings,
});

register_route({
  router,
  route: "/detail_employee_by_id_popup/:id",
  auth_enable: true,
  get_method: detail_employee_by_id_popup,
});

register_route({
  router,
  route: "/update_employee_allowance/:id",
  auth_enable: true,
  put_method: update_employee_allowance,
});

register_route({
  router,
  route: "/get_employee_allowance/:id",
  auth_enable: true,
  get_method: get_employee_allowance,
});

register_route({
  router,
  route: "/get_active_employees_with_search",
  auth_enable: true,
  post_method: get_active_employees_with_search,
});

register_route({
  router,
  route: "/search_team_members_of_lead_tech_lead",
  auth_enable: true,
  get_method: search_team_members_of_lead_tech_lead,
});

register_route({
  router,
  route: "/get_employees_for_payroll_v2",
  auth_enable: true,
  post_method: get_employees_for_payroll_v2,
});

register_route({
  router,
  route: "/search_team_members_of_lead_tech_lead_for_feedback_improvement",
  auth_enable: true,
  get_method: search_team_members_of_lead_tech_lead_for_feedback_improvement,
});

module.exports = router;
