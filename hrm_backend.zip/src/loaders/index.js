// tasks to perform on application load.
// example; cache some metadata