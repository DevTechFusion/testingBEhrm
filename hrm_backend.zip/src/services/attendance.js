const mongoose = require("mongoose");
const ObjectId = mongoose.Types.ObjectId;
const { find_user_by_id } = require("../DAL/user");
const {
  add_attendance,
  find_attendance_by_id,
  pagination_attendance,
  pagination_attendance_count,
  all_attendance_count,
  delete_attendance_by_id,
  get_attendance_search,
  attendance_search_count,
  find_attendance_by_user_id,
  find_attendance_by_attendance_id,
  update_employee_attendance,
  find_attendance_by_emp_id,
  latest_attendance,
  find_attendance_by_emp_id_month_year,
  find_attendance_by_emp_obj_id_month_year,
  get_attendance_by_date,
  get_all_attendance_docs_ids_by_date,
  check_discount_minutes_status,
  attendance_for_employee_user_monthly_yearly,
  attendance_for_employee_user_monthly_yearly_count,
  attendance_for_employee_user_by_date,
  get_employee_attendance_by_query_obj,
  get_fine_query_obj,
  get_fine_query_obj_count,
  attendance_for_fine,
  get_finesheet,
  get_finesheet_count,
  get_employee_absents,
  get_employee_absents_count,
  get_employee_attendance_by_query_obj_v1,
  getEmployeeAttendanceByDateRange,
  getEmployeeAttendanceByDateRangeCount,
  get_employee_leaves,
  get_employee_leaves_count,
  get_attendance_v1,
  count_get_attendance_v1,
  find_attendance_by_id_specific_day,
} = require("../DAL/attendance");

const {
  find_employee_by_employee_id,
  find_employee_by_user_id,
  find_employee_by_id,
  count_member_for_anniversary,
} = require("../DAL/employee");
const {
  find_employee_full_name_with_emp_obj_id,
} = require("../DAL/employee-v1");
const {
  get_leave_request_for_report,
  find_leaves_from_leave_request_pagination,
  find_leaves_from_leave_request_count,
  find_leaves_from_leave_request_pagination_v1,
  find_leaves_from_leave_request_count_v1,
  find_leaves_from_leave_request,
} = require("../DAL/leave_request");
const { get_absent_count_yearly } = require("../DAL/dashboard");
const {
  DELETE_FILES_FROM_S3,
  READ_CSV_FILE,
  UPLOAD_SINGLE_FILE_on_S3,
} = require("../utils/utils");

const _ = require("lodash");
const path = require("path");
const moment = require("moment/moment");

const _addAttendance = async (files, resp) => {
  const {
    find_leave_for_attendance,
    add_leave_request,
  } = require("../DAL/leave_request");
  const { find_employee_by_employee_id } = require("../DAL/employee");

  let csv;
  if (!_.isEmpty(files)) {
    csv = files.attendance_file;
  } else {
    resp.error = true;
    resp.error_message = "You did not select a CSV file";
    return resp;
  }
  if (!csv) {
    resp.error = true;
    resp.error_message = "Please upload a CSV file";
    return resp;
  }
  let file_extension = path.extname(csv.name);
  if (file_extension !== ".csv" && file_extension !== ".CSV") {
    resp.error = true;
    resp.error_message = "Only CSV files are allowed. Kindly upload CSV file";
    return resp;
  }
  let file_path = "attendance/";
  const return_path = await UPLOAD_SINGLE_FILE_on_S3(
    csv,
    file_path,
    file_extension
  );
  let all_attendance_arr = await READ_CSV_FILE(return_path);
  if (all_attendance_arr.length === 0) {
    resp.error = true;
    resp.error_message = "Please upload a CSV file again";
    return resp;
  }

  let final_date;
  const date_d_m_yyyy = moment(
    all_attendance_arr[0].date,
    "D/M/YYYY",
    true
  ).isValid();
  const date_dd_m_yyyy = moment(
    all_attendance_arr[0].date,
    "DD/M/YYYY",
    true
  ).isValid();
  const date_d_mm_yyyy = moment(
    all_attendance_arr[0].date,
    "D/MM/YYYY",
    true
  ).isValid();
  const date_dd_mm_yyyy = moment(
    all_attendance_arr[0].date,
    "DD/MM/YYYY",
    true
  ).isValid();

  if (date_d_m_yyyy) {
    final_date = moment(all_attendance_arr[0].date, "D/M/YYYY").format(
      "DD/MM/YYYY"
    );
  } else if (date_dd_m_yyyy) {
    final_date = moment(all_attendance_arr[0].date, "DD/M/YYYY").format(
      "DD/MM/YYYY"
    );
  } else if (date_d_mm_yyyy) {
    final_date = moment(all_attendance_arr[0].date, "D/MM/YYYY").format(
      "DD/MM/YYYY"
    );
  } else if (date_dd_mm_yyyy) {
    final_date = moment(all_attendance_arr[0].date, "DD/MM/YYYY").format(
      "DD/MM/YYYY"
    );
  }
  // final_date = moment(all_attendance_arr[0].date).format("DD/MM/YYYY");

  let [day, month, year] = final_date.split("/");

  //final date dd-mm-yyyy formate with moment js is yyyy-mm-dd
  let date_yyyy_mm_dd = moment(final_date, "DD/MM/YYYY").format("YYYY-MM-DD");

  for (let i = 0; i < all_attendance_arr.length; i++) {
    const get_emp_for_status = await find_employee_by_employee_id(
      parseInt(all_attendance_arr[i].emp_id)
    );
    if (get_emp_for_status) {
      if (!get_emp_for_status.active_status) {
        continue;
      }
    }

    let absent_status = false;
    if (all_attendance_arr[i].absent.toLowerCase() === "true") {
      absent_status = true;
    }

    //add leave request if user is absent on that day ,
    //if already exists leave request then no need to add

    if (absent_status === true) {
      const employee_id = get_emp_for_status ? get_emp_for_status._id : "";
      const full_name = get_emp_for_status ? get_emp_for_status.full_name : "";
      if (!!employee_id) {
        const leave_request = await find_leave_for_attendance(
          employee_id,
          date_yyyy_mm_dd
        );

        console.log("check_leave_request", leave_request);
        console.log("date==============", date_yyyy_mm_dd);

        if (!leave_request) {
          const leave_request_obj = {
            emp_obj_id: employee_id,
            emp_name: full_name,
            leave_type: "full",
            status: "pending",
            leave_reason: "Absent",
            leave_date: date_yyyy_mm_dd,
            action_by: "system",
          };
          await add_leave_request(leave_request_obj);
        }
      }
    }

    let current_late_minutes = 0;
    if (
      all_attendance_arr[i].late == "00:00" ||
      all_attendance_arr[i].late == ""
    ) {
      current_late_minutes = 0;
    } else {
      let [current_hours, current_minutes] =
        all_attendance_arr[i].late.split(":");
      current_late_minutes =
        parseInt(current_hours) * 60 + parseInt(current_minutes);
    }
    let current_early_minutes;
    if (
      all_attendance_arr[i].late == "00:00" ||
      all_attendance_arr[i].early == ""
    ) {
      current_early_minutes = 0;
    } else {
      let [early_hours, early_minutes] = all_attendance_arr[i].early.split(":");
      current_early_minutes =
        parseInt(early_hours) * 60 + parseInt(early_minutes);
    }
    let employe_detail = await find_attendance_by_emp_id_month_year(
      parseInt(all_attendance_arr[i].emp_id),
      month,
      year
    );

    if (employe_detail) {
      let index = -1;
      let employee_attendance_by_date = {};
      let attendance_arr = employe_detail.attendance;
      for (let i = 0; i < attendance_arr.length; i++) {
        if (attendance_arr[i].date == final_date) {
          employee_attendance_by_date = employe_detail;
          index = i;
        }
      }

      // let employee_attendance_by_date = await get_attendance_by_date(
      //   parseInt(all_attendance_arr[i].emp_id),
      //   month,
      //   year,
      //   final_date
      // );
      if (!_.isEmpty(employee_attendance_by_date)) {
        if (!employee_attendance_by_date.attendance[index].discounted_minutes) {
          if (
            employee_attendance_by_date.attendance[index].absent ==
            absent_status
          ) {
            if (employee_attendance_by_date.attendance[index].absent == false) {
              if (
                employee_attendance_by_date.attendance[index].late !==
                  current_late_minutes ||
                employee_attendance_by_date.attendance[index].early !==
                  current_early_minutes ||
                employee_attendance_by_date.attendance[index].check_in !==
                  all_attendance_arr[i].check_in ||
                employee_attendance_by_date.attendance[index].check_out !==
                  all_attendance_arr[i].check_out
              ) {
                employee_attendance_by_date.total_late_minutes -=
                  employee_attendance_by_date.attendance[index].late;
                employee_attendance_by_date.total_late_minutes +=
                  current_late_minutes;
                employee_attendance_by_date.attendance[index].check_in =
                  all_attendance_arr[i].check_in;
                employee_attendance_by_date.attendance[index].check_out =
                  all_attendance_arr[i].check_out;
                employee_attendance_by_date.attendance[index].relax_time =
                  all_attendance_arr[i].relax_time;
                employee_attendance_by_date.attendance[index].late =
                  current_late_minutes;
                employee_attendance_by_date.attendance[index].early =
                  current_early_minutes;
              }
              employee_attendance_by_date.deadline = moment(
                "10-" + month + "-" + year,
                "DD-MM-YYYY"
              ).utc(true);
              employee_attendance_by_date.save();
            }
          } else {
            if (absent_status == true) {
              employee_attendance_by_date.total_late_minutes -=
                employee_attendance_by_date.attendance[index].late;
              employee_attendance_by_date.attendance[index].absent =
                absent_status;
              employee_attendance_by_date.attendance[index].check_in = 0;
              employee_attendance_by_date.attendance[index].check_out = 0;
              employee_attendance_by_date.attendance[index].late = 0;
              employee_attendance_by_date.attendance[index].early = 0;
              employee_attendance_by_date.total_absents += 1;
              await employee_attendance_by_date.save();
            } else {
              if (employee_attendance_by_date.total_absents <= 0) {
                employee_attendance_by_date.total_absents = 0;
              } else {
                employee_attendance_by_date.total_absents -= 1;
              }
              employee_attendance_by_date.total_late_minutes +=
                current_late_minutes;
              employee_attendance_by_date.attendance[index].check_in =
                all_attendance_arr[i].check_in;
              employee_attendance_by_date.attendance[index].check_out =
                all_attendance_arr[i].check_out;
              employee_attendance_by_date.attendance[index].late =
                current_late_minutes;
              employee_attendance_by_date.attendance[index].early =
                current_early_minutes;
              employee_attendance_by_date.attendance[index].absent =
                absent_status;
              employee_attendance_by_date.deadline = moment(
                "10-" + month + "-" + year,
                "DD-MM-YYYY"
              ).utc(true);
              await employee_attendance_by_date.save();
            }
          }
        }
      } else {
        let prev_late_minutes = employe_detail.total_late_minutes;
        let total_late_minutes_so_far =
          prev_late_minutes + current_late_minutes;

        let attendance_array_obj = {
          date: final_date,
          check_in: all_attendance_arr[i].check_in,
          check_out: all_attendance_arr[i].check_out,
          relax_time: all_attendance_arr[i].relax_time,
          late: current_late_minutes,
          early: current_early_minutes,
          absent: absent_status,
        };
        if (absent_status) {
          employe_detail.total_absents += 1;
        }
        employe_detail.total_late_minutes = total_late_minutes_so_far;
        employe_detail.attendance.push(attendance_array_obj);
        employe_detail.deadline = moment(
          "10-" + month + "-" + year,
          "DD-MM-YYYY"
        ).utc(true);
        await employe_detail.save();
      }
    } else {
      const get_employee = await find_employee_by_employee_id(
        parseInt(all_attendance_arr[i].emp_id)
      );
      if (get_employee) {
        let attendance_array_obj = {
          date: final_date,
          check_in: all_attendance_arr[i].check_in,
          check_out: all_attendance_arr[i].check_out,
          relax_time: all_attendance_arr[i].relax_time,
          late: current_late_minutes,
          early: current_early_minutes,
          absent: absent_status,
        };
        let array = [];
        array.push(attendance_array_obj);
        let attendance_obj = {
          emp_obj_id: get_employee._id,
          emp_id: parseInt(all_attendance_arr[i].emp_id),
          emp_name: get_employee.full_name,
          month: month,
          year: year,
          total_late_minutes: current_late_minutes,
          total_absents: absent_status ? 1 : 0,
          attendance: array,
          deadline: moment("10-" + month + "-" + year, "DD-MM-YYYY").utc(true),
        };
        const added_attendance_obj = await add_attendance(attendance_obj);
      }
    }
  }
  await DELETE_FILES_FROM_S3(return_path);
  resp.data = all_attendance_arr;
  return resp;
};
const addAttendance = async (files) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addAttendance(files, resp);
  return resp;
};

const _addAttendanceManually = async (body, resp) => {
  const { find_employee_by_employee_id } = require("../DAL/employee");
  const get_emp_for_status = await find_employee_by_employee_id(
    parseInt(body.emp_id)
  );
  if (get_emp_for_status) {
    if (!get_emp_for_status.active_status) {
      resp.error = true;
      resp.error_message = "This Member is Inactive";
      return resp;
    }
  }

  let final_date;
  const date_d_m_yyyy = moment(
    body.attendance.date,
    "D/M/YYYY",
    true
  ).isValid();
  const date_dd_m_yyyy = moment(
    body.attendance.date,
    "DD/M/YYYY",
    true
  ).isValid();
  const date_d_mm_yyyy = moment(
    body.attendance.date,
    "D/MM/YYYY",
    true
  ).isValid();
  const date_dd_mm_yyyy = moment(
    body.attendance.date,
    "DD/MM/YYYY",
    true
  ).isValid();

  if (date_d_m_yyyy) {
    final_date = moment(body.attendance.date, "D/M/YYYY").format("DD/MM/YYYY");
  } else if (date_dd_m_yyyy) {
    final_date = moment(body.attendance.date, "DD/M/YYYY").format("DD/MM/YYYY");
  } else if (date_d_mm_yyyy) {
    final_date = moment(body.attendance.date, "D/MM/YYYY").format("DD/MM/YYYY");
  } else if (date_dd_mm_yyyy) {
    final_date = moment(body.attendance.date, "DD/MM/YYYY").format(
      "DD/MM/YYYY"
    );
  }

  let [day, month, year] = final_date.split("/");
  let added_attendance = {};
  let half_leave_type = 0;
  let absent_status = false;
  if (body.attendance.absent === "true") {
    absent_status = true;
  }
  // calulate current late minutes
  let current_late_minutes = 0;
  let diff_hours = 0;
  let diff_minutes = 0;
  if (body.attendance.check_in && body.attendance.check_in != "") {
    let [ch_in_hours, ch_in_minutes] = body.attendance.check_in.split(":");
    if (ch_in_hours >= 9 && ch_in_minutes >= 6) {
      diff_hours = ch_in_hours - 9;
      diff_minutes = ch_in_minutes;
      current_late_minutes = parseInt(diff_hours) * 60 + parseInt(diff_minutes);
    }
  }
  let current_early_minutes = 0;
  let diff_hours_early = 0;
  if (body.attendance.check_out && body.attendance.check_out != "") {
    let [ch_out_hours, ch_out_minutes] = body.attendance.check_out.split(":");

    if (ch_out_hours == 17) {
      diff_hours_early = 0;
    } else if (ch_out_hours < 17) {
      diff_hours_early = 18 - ch_out_hours - 1;
    }
    current_early_minutes =
      parseInt(diff_hours_early) * 60 + (60 - parseInt(ch_out_minutes));
    if (ch_out_hours >= 18) {
      current_early_minutes = 0;
    }
  }
  if (
    body.attendance.half_leave_type &&
    body.attendance.half_leave_type != "" &&
    (body.attendance.half_leave_type == "first_half" ||
      body.attendance.half_leave_type == "second_half")
  ) {
    absent_status = false;
    if (body.attendance.half_leave_type == "first_half") {
      current_late_minutes = 0;
      half_leave_type = 1;
      if (body.attendance.check_in && body.attendance.check_in != "") {
        let [ch_in_hours_1, ch_in_minutes_1] =
          body.attendance.check_in.split(":");
        if (ch_in_hours_1 >= 14) {
          diff_hours = ch_in_hours_1 - 14;
          diff_minutes = ch_in_minutes_1;
          current_late_minutes =
            parseInt(diff_hours) * 60 + parseInt(diff_minutes);
        }
      }
    } else {
      half_leave_type = 2;
      let [ch_in_hours_2, ch_out_minutes_2] =
        body.attendance.check_out.split(":");

      if (ch_in_hours_2 == 12) {
        diff_hours_early = 0;
      } else if (ch_in_hours_2 < 12) {
        diff_hours_early = 13 - ch_in_hours_2 - 1;
      }
      current_early_minutes =
        parseInt(diff_hours_early) * 60 + (60 - parseInt(ch_out_minutes_2));
      if (ch_in_hours_2 >= 13) {
        current_early_minutes = 0;
      }
    }
  }
  let employe_detail = await find_attendance_by_emp_id_month_year(
    parseInt(body.emp_id),
    month,
    year
  );

  if (employe_detail) {
    let index = -1;
    let employee_attendance_by_date = {};
    let attendance_arr = employe_detail.attendance;
    for (let i = 0; i < attendance_arr.length; i++) {
      if (attendance_arr[i].date == final_date) {
        employee_attendance_by_date = employe_detail;
        index = i;
      }
    }
    if (!_.isEmpty(employee_attendance_by_date)) {
      if (employee_attendance_by_date.attendance[index].discounted_minutes) {
        resp.error = true;
        resp.error_message =
          "This date is marked for discounted minutes. You cannot update data for this date";
        return resp;
      }
      if (
        employee_attendance_by_date.attendance[index].absent == absent_status
      ) {
        if (employee_attendance_by_date.attendance[index].absent == false) {
          // We are supposed to code here for 1st half and 2nd half leave in update case
          if (
            employee_attendance_by_date.attendance[index].check_in !=
              body.attendance.check_in ||
            employee_attendance_by_date.attendance[index].check_out !=
              body.attendance.check_out ||
            employee_attendance_by_date.attendance[index].late !=
              current_late_minutes ||
            employee_attendance_by_date.attendance[index].early !=
              current_early_minutes ||
            employee_attendance_by_date.attendance[index].half_leave_type !=
              half_leave_type
          ) {
            if (employee_attendance_by_date.total_absents <= 0) {
              employee_attendance_by_date.total_absents = 0;
            } else if (
              employee_attendance_by_date.attendance[index].half_leave_type != 0
            ) {
              employee_attendance_by_date.total_absents -= 0.5;
            }
            employee_attendance_by_date.total_late_minutes -=
              employee_attendance_by_date.attendance[index].late;
            employee_attendance_by_date.total_late_minutes +=
              current_late_minutes;
            employee_attendance_by_date.attendance[index].check_in =
              body.attendance.check_in;
            employee_attendance_by_date.attendance[index].check_out =
              body.attendance.check_out;
            employee_attendance_by_date.attendance[index].relax_time =
              body.attendance.relax_time;
            employee_attendance_by_date.attendance[index].late =
              current_late_minutes;
            employee_attendance_by_date.attendance[index].early =
              current_early_minutes;
            employee_attendance_by_date.attendance[index].half_leave_type =
              half_leave_type;
            if (half_leave_type == 1 || half_leave_type == 2) {
              employee_attendance_by_date.total_absents += 0.5;
            }
          } else if (
            employee_attendance_by_date.attendance[index].check_in !=
              body.attendance.check_in ||
            employee_attendance_by_date.attendance[index].check_out !=
              body.attendance.check_out ||
            employee_attendance_by_date.attendance[index].late !=
              current_late_minutes ||
            employee_attendance_by_date.attendance[index].early !=
              current_early_minutes
          ) {
            employee_attendance_by_date.total_late_minutes -=
              employee_attendance_by_date.attendance[index].late;
            employee_attendance_by_date.total_late_minutes +=
              current_late_minutes;
            employee_attendance_by_date.attendance[index].check_in =
              body.attendance.check_in;
            employee_attendance_by_date.attendance[index].check_out =
              body.attendance.check_out;
            employee_attendance_by_date.attendance[index].relax_time =
              body.attendance.relax_time;
            employee_attendance_by_date.attendance[index].late =
              current_late_minutes;
            employee_attendance_by_date.attendance[index].early =
              current_early_minutes;
            employee_attendance_by_date.attendance[index].half_leave_type = 0;
          }
          employee_attendance_by_date.deadline = moment(
            "10-" + month + "-" + year,
            "DD-MM-YYYY"
          ).utc(true);
          await employee_attendance_by_date.save();
        }
      } else {
        if (absent_status == true) {
          if (employee_attendance_by_date.total_absents <= 0) {
            employee_attendance_by_date.total_absents = 0;
          } else if (
            employee_attendance_by_date.attendance[index].half_leave_type != 0
          ) {
            employee_attendance_by_date.total_absents -= 0.5;
          }
          employee_attendance_by_date.total_late_minutes -=
            employee_attendance_by_date.attendance[index].late;
          employee_attendance_by_date.attendance[index].absent = absent_status;
          employee_attendance_by_date.attendance[index].check_in = "";
          employee_attendance_by_date.attendance[index].check_out = "";
          employee_attendance_by_date.attendance[index].late = 0;
          employee_attendance_by_date.attendance[index].early = 0;
          employee_attendance_by_date.total_absents += 1;
          employee_attendance_by_date.attendance[index].half_leave_type = 0;
          employee_attendance_by_date.deadline = moment(
            "10-" + month + "-" + year,
            "DD-MM-YYYY"
          ).utc(true);
          await employee_attendance_by_date.save();
        } else {
          if (employee_attendance_by_date.total_absents <= 0) {
            employee_attendance_by_date.total_absents = 0;
          } else {
            if (
              employee_attendance_by_date.attendance[index].half_leave_type != 0
            ) {
              employee_attendance_by_date.total_absents -= 0.5;
            } else {
              employee_attendance_by_date.total_absents -= 1;
            }
          }
          if (half_leave_type == 1 || half_leave_type == 2) {
            employee_attendance_by_date.total_absents += 0.5;
          }
          // We have to update here for 1st or 2nd half leave too
          employee_attendance_by_date.total_late_minutes +=
            current_late_minutes;
          employee_attendance_by_date.attendance[index].check_in =
            body.attendance.check_in;
          employee_attendance_by_date.attendance[index].check_out =
            body.attendance.check_out;
          employee_attendance_by_date.attendance[index].late =
            current_late_minutes;
          employee_attendance_by_date.attendance[index].early =
            current_early_minutes;
          employee_attendance_by_date.attendance[index].absent = absent_status;
          employee_attendance_by_date.attendance[index].half_leave_type =
            half_leave_type;
          employee_attendance_by_date.deadline = moment(
            "10-" + month + "-" + year,
            "DD-MM-YYYY"
          ).utc(true);
          await employee_attendance_by_date.save();
        }
      }
    } else {
      // We are supposed to code here for 1st half and 2nd half leave in add case for same month and year
      let prev_late_minutes = employe_detail.total_late_minutes;
      let total_late_minutes_so_far = prev_late_minutes + current_late_minutes;

      let attendance_array_obj = {
        date: final_date,
        check_in: body.attendance.check_in,
        check_out: body.attendance.check_out,
        relax_time: body.attendance.relax_time,
        late: current_late_minutes,
        early: current_early_minutes,
        absent: absent_status,
        half_leave_type: half_leave_type,
      };
      if (absent_status) {
        employe_detail.total_absents += 1;
      } else if (half_leave_type == 1 || half_leave_type == 2) {
        employe_detail.total_absents += 0.5;
      }

      employe_detail.total_late_minutes = total_late_minutes_so_far;
      employe_detail.attendance.push(attendance_array_obj);
      employe_detail.deadline = moment(
        "10-" + month + "-" + year,
        "DD-MM-YYYY"
      ).utc(true);
      await employe_detail.save();
    }
  } else {
    // We are supposed to code here for 1st half and 2nd half leave in add case for new month and year
    const get_employee = await find_employee_by_employee_id(
      parseInt(body.emp_id)
    );
    if (get_employee) {
      let attendance_array_obj = {
        date: final_date,
        check_in: body.attendance.check_in,
        check_out: body.attendance.check_out,
        relax_time: body.attendance.relax_time,
        late: current_late_minutes,
        early: current_early_minutes,
        absent: absent_status,
        half_leave_type: half_leave_type,
      };
      let array = [];
      array.push(attendance_array_obj);
      let count_absents = 0;
      if (absent_status) {
        count_absents += 1;
      } else if (half_leave_type == 1 || half_leave_type == 2) {
        count_absents += 0.5;
      }
      let attendance_obj = {
        emp_obj_id: get_employee._id,
        emp_id: parseInt(body.emp_id),
        emp_name: body.emp_name,
        month: month,
        year: year,
        total_late_minutes: current_late_minutes,
        total_absents: count_absents,
        attendance: array,
        deadline: moment("10-" + month + "-" + year, "DD-MM-YYYY").utc(true),
      };
      const added_attendance_obj = await add_attendance(attendance_obj);
    } else {
      resp.error = true;
      resp.error_message = "Member with this ID does not exist";
      return resp;
    }
  }

  resp.data = added_attendance;
  return resp;
};
const addAttendanceManually = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addAttendanceManually(body, resp);
  return resp;
};

const _getAttendances = async (Limit, page, search, emp_obj_id, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;
  const attendance = await pagination_attendance(
    skip,
    limit,
    search,
    emp_obj_id
  );
  const total_pages = await pagination_attendance_count(search, emp_obj_id);

  let final_attendance = [];

  attendance.forEach((attendance_obj) => {
    let emp_attendance_obj = {
      _id: attendance_obj._id,
      emp_obj_id: attendance_obj.emp_obj_id,
      emp_name: attendance_obj.emp_name,
      emp_id: attendance_obj.emp_id,
      month: attendance_obj.month,
      year: attendance_obj.year,
      total_late_minutes: attendance_obj.total_late_minutes,
      total_absents: attendance_obj.total_absents,
      attendance: [],
    };
    let final_attendance_arr = [];
    attendance_obj.attendance.forEach((attendance) => {
      let attendance_obj = {
        late: attendance.late,
        early: attendance.early,
        discounted_minutes: attendance.discounted_minutes,
        half_leave_type: attendance.half_leave_type,
        _id: attendance._id,
        date: attendance.date,
        check_in: attendance.check_in,
        check_out: attendance.check_out,
        relax_time: attendance.relax_time,
        absent: attendance.absent,
      };
      if (attendance.absent) {
        attendance_obj.leave_type = "Absent";
      } else if (attendance.half_leave_type == 1) {
        attendance_obj.leave_type = "First Half";
      } else if (attendance.half_leave_type == 2) {
        attendance_obj.leave_type = "Second Half";
      } else {
        attendance_obj.leave_type = "Present";
      }
      final_attendance_arr.push(attendance_obj);
    });
    emp_attendance_obj.attendance = final_attendance_arr;
    final_attendance.push(emp_attendance_obj);
  });

  const data = {
    attendance: final_attendance,
    total_pages: total_pages,
    load_more_url: `/attendance/get_attendances?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getAttendances = async (limit, page, search, emp_obj_id) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getAttendances(limit, page, search, emp_obj_id, resp);
  return resp;
};

const _getAttendancesV1 = async (Limit, page, body, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let query = {};

  if (!!body.employee_id) {
    query.emp_obj_id = ObjectId(body.employee_id);
  }

  let from_date;
  let to_date;

  if (body.filter_type == "date") {
    from_date = body.date_from;
    to_date = body.date_to;
  } else if (body.filter_type == "month") {
    from_date = moment(`${body.year}-${body.month}-01`)
      .startOf("month")
      .format("YYYY-MM-DD");
    to_date = moment(`${body.year}-${body.month}-01`)
      .endOf("month")
      .format("YYYY-MM-DD");
  } else if (body.filter_type == "all") {
    from_date = moment("2021-01-01").format("YYYY-MM-DD");
    to_date = moment().format("YYYY-MM-DD");
  }

  const get_attendance = await get_attendance_v1(
    query,
    from_date,
    to_date,
    skip,
    limit
  );

  const count_attendance = await count_get_attendance_v1(
    query,
    from_date,
    to_date
  );

  let total_pages = Math.ceil(count_attendance / limit);

  const data = {
    attendance: get_attendance,
    total_count: count_attendance,
    total_pages: total_pages - 1,
    // load_more_url: `/attendance/get_attendances_v1?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getAttendancesV1 = async (limit, page, body) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getAttendancesV1(limit, page, body, resp);
  return resp;
};

const _detailAttendance = async (user_id, resp) => {
  const user = await find_user_by_id(user_id);
  if (!user) {
    resp.error = true;
    resp.error_message = "Invalid User";
    return resp;
  }
  if (user.type != 0 && user.type != 1) {
    resp.error = true;
    resp.error_message = "You are unauthorized!";
    return resp;
  }
  const attendance = await find_attendance_by_user_id(user_id);
  if (!attendance) {
    resp.error = true;
    resp.error_message = "Invalid Attendance ID!";
    return resp;
  }
  resp.data = attendance;
  return resp;
};

const detailAttendance = async (user_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailAttendance(user_id, resp);
  return resp;
};

const _detailAttendanceByID = async (attendance_id, resp) => {
  const attendance = await find_attendance_by_id(attendance_id);
  if (!attendance) {
    resp.error = true;
    resp.error_message = "Invalid Attendance ID!";
    return resp;
  }
  resp.data = attendance;
  return resp;
};

const detailAttendanceByID = async (attendance_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailAttendanceByID(attendance_id, resp);
  return resp;
};

const _deleteAttendance = async (body, resp) => {
  let [day, month, year] = body.date.split("/");
  const all_attendances_arr = await get_all_attendance_docs_ids_by_date(
    month,
    year,
    body.date
  );
  if (!all_attendances_arr) {
    resp.error = true;
    resp.error_message = "Attendance with given date not found";
    return resp;
  }
  for (let i = 0; i < all_attendances_arr.length; i++) {
    const emp_doc = await find_attendance_by_id(all_attendances_arr[i]._id);
    const index = _.findIndex(emp_doc.attendance, { date: body.date });
    let attendance_obj = emp_doc.attendance[index];

    // Manage absents or late minutes here
    if (attendance_obj.absent) {
      if (emp_doc.total_absents <= 0) {
        emp_doc.total_absents = 0;
      } else {
        emp_doc.total_absents -= 1;
      }
    } else {
      if (!attendance_obj.discounted_minutes) {
        emp_doc.total_late_minutes -= attendance_obj.late;
      } else {
        if (attendance_obj.late <= 90) {
          emp_doc.total_late_minutes -= attendance_obj.late;
        } else if (attendance_obj.late > 90) {
          emp_doc.total_late_minutes += 90;
          emp_doc.total_late_minutes -= attendance_obj.late;
        }
      }
    }
    if (attendance_obj.half_leave_type != 0) {
      emp_doc.total_absents -= 0.5;
    }
    emp_doc.attendance.splice(index, 1);
    emp_doc.save();
  }
  return resp;
};

const deleteAttendance = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteAttendance(body, resp);
  return resp;
};

const _deleteAttendanceIndividually = async (body, resp) => {
  let [day, month, year] = body.date.split("/");
  const emp_doc = await get_attendance_by_date(
    parseInt(body.emp_id),
    month,
    year,
    body.date
  );
  if (!emp_doc) {
    resp.error = true;
    resp.error_message = "Attendance with given date not found";
    return resp;
  }
  const index = _.findIndex(emp_doc.attendance, { date: body.date });

  let attendance_obj = emp_doc.attendance[index];

  if (attendance_obj.absent) {
    if (emp_doc.total_absents <= 0) {
      emp_doc.total_absents = 0;
    } else {
      emp_doc.total_absents -= 1;
    }
  } else {
    if (!attendance_obj.discounted_minutes) {
      if (
        emp_doc.total_late_minutes <= 0 ||
        emp_doc.total_late_minutes <= attendance_obj.late
      ) {
        emp_doc.total_late_minutes = 0;
      } else {
        emp_doc.total_late_minutes -= attendance_obj.late;
      }
    } else {
      if (attendance_obj.late > 90) {
        if (
          emp_doc.total_late_minutes <= 0 ||
          emp_doc.total_late_minutes <= attendance_obj.late
        ) {
          emp_doc.total_late_minutes = 0;
        } else {
          emp_doc.total_late_minutes += 90;
          emp_doc.total_late_minutes -= attendance_obj.late;
        }
      }
    }
  }
  if (attendance_obj.half_leave_type != 0) {
    emp_doc.total_absents -= 0.5;
  }
  emp_doc.attendance.splice(index, 1);
  emp_doc.save();
  return resp;
};

const deleteAttendanceIndividually = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteAttendanceIndividually(body, resp);
  return resp;
};

const _markDiscountMinutes = async (body, resp) => {
  let [day, month, year] = body.date.split("/");
  const check_for_discount_status = await check_discount_minutes_status(
    parseInt(body.emp_id),
    month,
    year
  );
  if (check_for_discount_status) {
    resp.error = true;
    resp.error_message = "You have already used your late minutes";
    return resp;
  }
  const emp_doc = await get_attendance_by_date(
    parseInt(body.emp_id),
    month,
    year,
    body.date
  );
  if (!emp_doc) {
    resp.error = true;
    resp.error_message = "Attendance with given date not found";
    return resp;
  }
  const index = _.findIndex(emp_doc.attendance, { date: body.date });
  let attendance_obj = emp_doc.attendance[index];

  if (attendance_obj.absent) {
    resp.error = true;
    resp.error_message = "You were absent that day";
    return resp;
  }
  if (attendance_obj.late <= 90) {
    if (
      emp_doc.total_late_minutes <= 0 ||
      emp_doc.total_late_minutes <= attendance_obj.late
    ) {
      emp_doc.total_late_minutes = 0;
    } else {
      emp_doc.total_late_minutes -= attendance_obj.late;
    }
    emp_doc.attendance[index].discounted_minutes = true;
  } else if (attendance_obj.late > 90) {
    if (emp_doc.total_late_minutes <= 0) {
      emp_doc.total_late_minutes = 0;
    } else {
      emp_doc.total_late_minutes -= 90;
    }
    emp_doc.attendance[index].discounted_minutes = true;
  }

  emp_doc.save();
  return resp;
};

const markDiscountMinutes = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _markDiscountMinutes(body, resp);
  return resp;
};

const _markDiscountMinutesByUser = async (user_id, date, resp) => {
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  const current_date = new Date();
  let day = current_date.getDate() - 1;
  let month = current_date.getMonth() + 1;
  let year = current_date.getFullYear();
  let final_date;
  if (date && date != "" && date != undefined && date != null) {
    final_date = date;
    const date_d_m_yyyy = moment(date, "D/M/YYYY", true).isValid();
    const date_dd_m_yyyy = moment(date, "DD/M/YYYY", true).isValid();
    const date_d_mm_yyyy = moment(date, "D/MM/YYYY", true).isValid();
    const date_dd_mm_yyyy = moment(date, "DD/MM/YYYY", true).isValid();

    if (date_d_m_yyyy) {
      final_date = moment(date, "D/M/YYYY").format("DD/MM/YYYY");
    } else if (date_dd_m_yyyy) {
      final_date = moment(date, "DD/M/YYYY").format("DD/MM/YYYY");
    } else if (date_d_mm_yyyy) {
      final_date = moment(date, "D/MM/YYYY").format("DD/MM/YYYY");
    } else if (date_dd_mm_yyyy) {
      final_date = moment(date, "DD/MM/YYYY").format("DD/MM/YYYY");
    }

    [day, month, year] = final_date.split("/");
  } else {
    resp.error = true;
    resp.error_message = "Invalid date. Required format is DD/MM/YYYY";
    return resp;
  }

  const check_for_discount_status = await check_discount_minutes_status(
    parseInt(emp_details.employee_id),
    month,
    year
  );
  if (check_for_discount_status) {
    resp.error = true;
    resp.error_message = "You have already used your late minutes";
    return resp;
  }
  const emp_doc = await attendance_for_employee_user_monthly_yearly(
    emp_details._id,
    month,
    year
  );
  if (!emp_doc) {
    resp.error = true;
    resp.error_message = "Attendance not found";
    return resp;
  }
  const index = _.findIndex(emp_doc.attendance, { date: final_date });
  let attendance_obj = emp_doc.attendance[index];
  if (attendance_obj.absent) {
    resp.error = true;
    resp.error_message = "You were absent that day";
    return resp;
  }

  if (attendance_obj.late <= 90) {
    if (
      emp_doc.total_late_minutes <= 0 ||
      emp_doc.total_late_minutes <= attendance_obj.late
    ) {
      emp_doc.total_late_minutes = 0;
    } else {
      emp_doc.total_late_minutes -= attendance_obj.late;
    }
    emp_doc.attendance[index].discounted_minutes = true;
  } else if (attendance_obj.late > 90) {
    if (emp_doc.total_late_minutes <= 0) {
      emp_doc.total_late_minutes = 0;
    } else {
      emp_doc.total_late_minutes -= 90;
    }
    emp_doc.attendance[index].discounted_minutes = true;
  }

  emp_doc.save();
  resp.data = {
    message:
      "Late minutes discounted successfully for " +
      emp_doc.attendance[index].date,
  };
  return resp;
};

const markDiscountMinutesByUser = async (user_id, date) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _markDiscountMinutesByUser(user_id, date, resp);
  return resp;
};

const _getAttendanceForEmployee = async (body, resp) => {
  const { find_employee_by_employee_id } = require("../DAL/employee");
  const get_employee = await find_employee_by_employee_id(
    parseInt(body.emp_id)
  );

  let attendance_data = {
    monthly_absents: 0,
    total_late_minutes: 0,
    total_absents: 0,
    attendance: [],
  };
  const get_attendance_data = await find_attendance_by_emp_id_month_year(
    parseInt(body.emp_id),
    body.month,
    body.year
  );
  if (!_.isEmpty(get_attendance_data)) {
    attendance_data.attendance = get_attendance_data.attendance;

    attendance_data.total_late_minutes =
      get_attendance_data.total_late_minutes >
      get_attendance_data.granted_relax_minutes
        ? get_attendance_data.total_late_minutes -
          get_attendance_data.granted_relax_minutes
        : 0;

    // attendance_data.monthly_absents = get_attendance_data.total_absents;
    attendance_data.attendance.sort((a, b) => {
      const dateA = new Date(a.date.split("/").reverse().join("-"));
      const dateB = new Date(b.date.split("/").reverse().join("-"));
      return dateB - dateA;
    });

    let final_attendance_arr = [];
    attendance_data.attendance.forEach((attendance) => {
      let attendance_obj = {
        _id: attendance._id,
        date: attendance.date,
        check_in: attendance.check_in,
        check_out: attendance.check_out,
        relax_time: attendance.relax_time,
        absent: attendance.absent,
        late: attendance.late,
        early: attendance.early,
        discounted_minutes: attendance.discounted_minutes,
        half_leave_type: attendance.half_leave_type,
      };

      if (attendance.absent) {
        attendance_obj.leave_type = "Absent";
      } else if (attendance.half_leave_type == 1) {
        attendance_obj.leave_type = "First Half";
      } else if (attendance.half_leave_type == 2) {
        attendance_obj.leave_type = "Second Half";
      } else {
        attendance_obj.leave_type = "Present";
      }
      final_attendance_arr.push(attendance_obj);
    });
    attendance_data.attendance = final_attendance_arr;
  }

  // let query_obj_search = {};
  // const date = new Date();
  // let month = date.getMonth() + 1;
  // let year = date.getFullYear();
  // let year_from = year;
  // let year_to = year;

  // if (month < 7) {
  //   year_from -= 1;
  // } else {
  //   year_to += 1;
  // }
  // query_obj_search.month = {
  //   $gte: 2,
  //   $lt: 7,
  // };
  // query_obj_search.year = {
  //   $gte: year_from,
  //   $lte: year_to,
  // };
  // let absent_count = 0;
  // query_obj_search.emp_id = parseInt(body.emp_id);
  // const yearly_attendance = await get_employee_attendance_by_query_obj(
  //   query_obj_search
  // );
  // for (let j = 0; j < yearly_attendance.length; j++) {
  //   if (yearly_attendance[j].month < 7 && yearly_attendance[j].year == year) {
  //     absent_count += yearly_attendance[j].total_absents;
  //   } else if (
  //     yearly_attendance[j].month >= 7 &&
  //     yearly_attendance[j].year == year_from
  //   ) {
  //     absent_count += yearly_attendance[j].total_absents;
  //   }
  // }
  // attendance_data.total_absents = absent_count;

  //current year absent count
  //find current year with moment

  function getFiscalYear() {
    const currentDate = moment();
    let fiscalYearStart, fiscalYearEnd;

    if (currentDate.month() >= 6) {
      // If the current month is July or later
      fiscalYearStart = moment({
        year: currentDate.year(),
        month: 6,
        day: 1,
      }).format("YYYY-MM-DD");
      fiscalYearEnd = moment({
        year: currentDate.year() + 1,
        month: 5,
        day: 30,
      }).format("YYYY-MM-DD");
    } else {
      // If the current month is June or earlier
      fiscalYearStart = moment({
        year: currentDate.year() - 1,
        month: 6,
        day: 1,
      }).format("YYYY-MM-DD");
      fiscalYearEnd = moment({
        year: currentDate.year(),
        month: 5,
        day: 30,
      }).format("YYYY-MM-DD");
    }

    return { fiscalYearStart, fiscalYearEnd };
  }

  const { fiscalYearStart, fiscalYearEnd } = getFiscalYear();

  let total_absent_yearly = 0;

  let current_year_absent = await find_leaves_from_leave_request(
    get_employee._id,
    fiscalYearStart,
    fiscalYearEnd
  );
  // console.log("current_year_absent", current_year_absent);
  if (current_year_absent.length > 0) {
    current_year_absent.forEach((element) => {
      if (element.leave_type == "full") {
        total_absent_yearly += 1;
      } else if (
        element.leave_type == "first_half" ||
        element.leave_type == "second_half"
      ) {
        total_absent_yearly += 0.5;
      }
    });
  }

  attendance_data.total_absents = total_absent_yearly;

  //current month absent count
  //find current month start and end date

  function getMonthStartEndDates() {
    const currentDate = moment();
    let monthStart, monthEnd;

    monthStart = moment({
      year: currentDate.year(),
      month: currentDate.month(),
      day: 1,
    }).format("YYYY-MM-DD");

    monthEnd = moment({
      year: currentDate.year(),
      month: currentDate.month(),
      day: currentDate.daysInMonth(),
    }).format("YYYY-MM-DD");

    return { monthStart, monthEnd };
  }

  const { monthStart, monthEnd } = getMonthStartEndDates();

  let total_absent_monthly = 0;

  let current_month_absent = await find_leaves_from_leave_request(
    get_employee._id,
    monthStart,
    monthEnd
  );

  if (current_month_absent.length > 0) {
    current_month_absent.forEach((element) => {
      if (element.leave_type == "full") {
        total_absent_monthly += 1;
      } else if (
        element.leave_type == "first_half" ||
        element.leave_type == "second_half"
      ) {
        total_absent_monthly += 0.5;
      }
    });

    attendance_data.monthly_absents = total_absent_monthly;
  }

  // if (get_employee) {
  //   let absent_query = { emp_obj_id: get_employee._id };
  //   const absents_yearly = await get_absent_count_yearly(absent_query);
  //   attendance_data.total_absents = absents_yearly;
  // }

  const data = {
    attendance: attendance_data,
    allowed_leaves: get_employee.allowed_leaves,
  };
  resp.data = data;
  return resp;
};

const getAttendanceForEmployee = async (body) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getAttendanceForEmployee(body, resp);
  return resp;
};

const _getAttendanceForEmployeeUser = async (user, Limit, page, body, resp) => {
  let attendance_obj = {
    emp_obj_id: null,
    emp_name: null,
    emp_id: null,
    total_late_minutes: null,
    total_absents: null,
    attendance: [],
  };
  // console.log("attendance_obj: ", attendance_obj);
  let total_pages = 0;
  let current_month_absents = 0;
  let current_month_late_mins = 0;

  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  const date = new Date();
  let day = date.getDate() - 1;
  let month = date.getMonth() + 1;
  let year = date.getFullYear();

  const get_employee = await find_employee_by_id(user);
  if (get_employee) {
    attendance_obj.emp_obj_id = get_employee._id;
    attendance_obj.emp_name = get_employee.full_name;
    attendance_obj.emp_id = get_employee.employee_id;

    let query_obj = { emp_obj_id: get_employee._id };
    query_obj.month = month;
    query_obj.year = year;
    let absent_count = 0;
    let date_from = undefined;
    let date_to = undefined;
    if (
      body.date_from &&
      body.date_to &&
      body.date_from != "" &&
      body.date_to != ""
    ) {
      date_from = moment(body.date_from, "DD/MM/YYYY").utc(true);
      date_to = moment(body.date_to, "DD/MM/YYYY").utc(true);

      const valid_from = moment(body.date_from, "DD/MM/YYYY", true).isValid();
      const valid_to = moment(body.date_to, "DD/MM/YYYY", true).isValid();
      if (valid_from && valid_to) {
        let [day_from, month_from, year_from] = body.date_from.split("/");
        let [day_to, month_to, year_to] = body.date_to.split("/");
        query_obj.month = {
          $gte: month_from,
          $lte: month_to,
        };
        query_obj.year = {
          $gte: year_from,
          $lte: year_to,
        };
      } else {
        resp.error = true;
        resp.error_message =
          "Date must be in DD/MM/YYYY format and a valid date";
        return resp;
      }
    }

    //new logic for testing ;

    let get_attendance = await get_employee_attendance_by_query_obj(query_obj);

    if (get_attendance.length > 0) {
      if (body.absent && body.absent == "true") {
        for (let i = 0; i < get_attendance.length; i++) {
          let attendance_arr = get_attendance[i].attendance;
          for (let j = 0; j < attendance_arr.length; j++) {
            if (date_from != undefined && date_to != undefined) {
              let db_date = moment(attendance_arr[j].date, "DD/MM/YYYY").utc(
                true
              );

              if (
                db_date.isSameOrAfter(date_from) &&
                db_date.isSameOrBefore(date_to) &&
                attendance_arr[j].absent == true
              ) {
                absent_count += 1;
                attendance_obj.attendance.push(attendance_arr[j]);
              }
            } else {
              if (attendance_arr[j].absent == true) {
                absent_count += 1;
                attendance_obj.attendance.push(attendance_arr[j]);
              }
            }
          }
        }
        attendance_obj.total_absents = absent_count;
        // console.log("attendance_obj", attendance_obj);
      } else if (body.absent && body.absent == "false") {
        for (let i = 0; i < get_attendance.length; i++) {
          let attendance_arr = get_attendance[i].attendance;
          for (let j = 0; j < attendance_arr.length; j++) {
            if (date_from != undefined && date_to != undefined) {
              let db_date = moment(attendance_arr[j].date, "DD/MM/YYYY").utc(
                true
              );

              if (
                db_date.isSameOrAfter(date_from) &&
                db_date.isSameOrBefore(date_to) &&
                attendance_arr[j].absent == false
              ) {
                attendance_obj.attendance.push(attendance_arr[j]);
              }
            } else {
              if (attendance_arr[j].absent == false) {
                attendance_obj.attendance.push(attendance_arr[j]);
              }
            }
          }
        }
        // attendance_obj.total_absents = absent_count;
        // console.log("attendance_obj", attendance_obj);
      } else {
        for (let i = 0; i < get_attendance.length; i++) {
          let attendance_arr = get_attendance[i].attendance;
          for (let j = 0; j < attendance_arr.length; j++) {
            let db_date = moment(attendance_arr[j].date, "DD/MM/YYYY").utc(
              true
            );
            if (
              db_date.isSameOrAfter(date_from) &&
              db_date.isSameOrBefore(date_to)
            ) {
              attendance_obj.attendance.push(attendance_arr[j]);
            }
          }
        }
        // attendance_obj.total_absents = absent_count;
        // console.log("attendance_obj", attendance_obj);
      }
      if (
        _.isEmpty(body) ||
        (body.date_from == "" && body.date_to == "" && body.absent == "")
      ) {
        // attendance_obj = get_attendance[0];
        attendance_obj.total_late_minutes =
          get_attendance[0].total_late_minutes;
        attendance_obj.total_absents = get_attendance[0].total_absents;
        attendance_obj.attendance = get_attendance[0].attendance;
        if (!_.isEmpty(attendance_obj)) {
          // total_pages = attendance_obj.attendance.length;
          current_month_absents = attendance_obj.total_absents;
          current_month_late_mins = attendance_obj.total_late_minutes;
        }
      }
      attendance_obj.attendance.sort((a, b) => {
        const dateA = new Date(a.date.split("/").reverse().join("-"));
        const dateB = new Date(b.date.split("/").reverse().join("-"));
        return dateB - dateA;
      });
    }
  }

  if (!_.isEmpty(attendance_obj)) {
    console.log("Adding Leave type in Attendance");
    // console.log("attendance_obj: ", attendance_obj);

    let final_attendance_arr = [];
    attendance_obj.attendance.forEach((attendance) => {
      // console.log("attendance: ", attendance);
      let attendance_data = {
        _id: attendance._id,
        date: attendance.date,
        check_in: attendance.check_in,
        check_out: attendance.check_out,
        relax_time: attendance.relax_time,
        absent: attendance.absent,
        late: attendance.late,
        early: attendance.early,
        discounted_minutes: attendance.discounted_minutes,
        half_leave_type: attendance.half_leave_type,
      };

      if (attendance.absent) {
        attendance_data.leave_type = "Absent";
      } else if (attendance.half_leave_type == 1) {
        attendance_data.leave_type = "First Half";
      } else if (attendance.half_leave_type == 2) {
        attendance_data.leave_type = "Second Half";
      } else {
        attendance_data.leave_type = "Present";
      }
      // console.log("attendance_data: ", attendance_data);
      final_attendance_arr.push(attendance_data);
    });
    // console.log("final_attendance_arr: ", final_attendance_arr);

    total_pages = final_attendance_arr.length;
    let new_final_attendance_arr = [];

    // Use slicing for pagination of the array final_attendance_arr
    let start = skip;
    let end = skip + limit;

    // Ensure end doesn't exceed the length of final_attendance_arr
    if (end > final_attendance_arr.length) {
      end = final_attendance_arr.length;
    }

    new_final_attendance_arr = final_attendance_arr.slice(start, end);

    attendance_obj.attendance = new_final_attendance_arr;

    // attendance_obj.attendance = final_attendance_arr;
    // console.log("attendance_obj.attendance: ", attendance_obj.attendance);
  }

  let current_month_attendance =
    await attendance_for_employee_user_monthly_yearly(user, month, year);
  console.log("current_month_attendance: ", current_month_attendance);
  if (!_.isEmpty(current_month_attendance)) {
    // attendance_obj = current_month_attendance;
    // total_pages = current_month_attendance.attendance.length;
    current_month_absents = current_month_attendance.total_absents;

    current_month_late_mins =
      current_month_attendance.total_late_minutes >
      current_month_attendance.granted_relax_minutes
        ? current_month_attendance.total_late_minutes -
          current_month_attendance.granted_relax_minutes
        : 0;
  }

  const data = {
    attendance: attendance_obj,
    total_pages: total_pages,
    current_month_absents,
    current_month_late_mins,
    allowed_leaves: get_employee.allowed_leaves,
    load_more_url: `/api/attendance/get_attendance_for_employee_user/${user}?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getAttendanceForEmployeeUser = async (user, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getAttendanceForEmployeeUser(user, limit, page, body, resp);
  return resp;
};

const _getAttendanceForEmployeeUserV1 = async (
  user,
  Limit,
  page,
  body,
  resp
) => {
  const { find_employee_by_id } = require("../DAL/employee");

  const get_employee = await find_employee_by_id(user);
  if (!get_employee) {
    resp.error = true;
    resp.error_message = "Employee not found";
    return resp;
  }

  //attendance object
  let attendance_obj = {
    emp_obj_id: null,
    emp_name: null,
    emp_id: null,
    total_late_minutes: null,
    total_absents: null,
    attendance: [],
  };

  //assigning values to attendance object emp_obj_id, emp_name, emp_id
  attendance_obj.emp_obj_id = get_employee._id;
  attendance_obj.emp_name = get_employee.full_name;
  attendance_obj.emp_id = get_employee.employee_id;

  //variables
  let current_month_absents = 0;
  let current_month_late_mins = 0;
  // let absent_count = 0;

  //pagination variables
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 25;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  // var query_obj = { emp_obj_id: get_employee._id };

  let date_from = undefined;
  let date_to = undefined;
  let month;
  let year;

  const date = new Date();
  let day = date.getDate() - 1;
  month = date.getMonth() + 1;
  year = date.getFullYear();

  if (!body.date_from && !body.date_to) {
    //current moth start and end date with moment

    let startOfMonth = moment().startOf("month").format("YYYY-MM-DD");
    let endOfMonth = moment().endOf("month").format("YYYY-MM-DD");

    date_from = startOfMonth;
    date_to = endOfMonth;
  }

  if (body.date_from && body.date_to) {
    date_from = moment(body.date_from, "DD/MM/YYYY").utc(true);
    date_to = moment(body.date_to, "DD/MM/YYYY").utc(true);

    const valid_from = moment(body.date_from, "DD/MM/YYYY", true).isValid();
    const valid_to = moment(body.date_to, "DD/MM/YYYY", true).isValid();
    if (valid_from && valid_to) {
      let [day_from, month_from, year_from] = body.date_from.split("/");
      let [day_to, month_to, year_to] = body.date_to.split("/");

      //chage date format to DD/MM/YYYY to YYYY-MM-DD
      date_from = moment(body.date_from, "DD/MM/YYYY").format("YYYY-MM-DD");
      date_to = moment(body.date_to, "DD/MM/YYYY").format("YYYY-MM-DD");
    } else {
      resp.error = true;
      resp.error_message = "Date must be in DD/MM/YYYY format and a valid date";
      return resp;
    }
  }

  // let get_attendance = await get_employee_attendance_by_query_obj_v1(query_obj , date_from, date_to);

  let get_attendance = await getEmployeeAttendanceByDateRange(
    get_employee._id,
    date_from,
    date_to,
    body.absent,
    skip,
    limit
  );

  let get_attendance_count = await getEmployeeAttendanceByDateRangeCount(
    get_employee._id,
    date_from,
    date_to,
    body.absent
  );

  let total_pages = Math.ceil(get_attendance_count / limit);

  //length of get_attendance

  attendance_obj.attendance = get_attendance;

  // check if attendance_obj is not empty then add leave type in attendance
  let final_attendance_arr = [];

  if (!_.isEmpty(attendance_obj)) {
    attendance_obj.attendance.forEach((attendance) => {
      let attendance_data = {
        _id: attendance._id,
        date: attendance.date,
        check_in: attendance.check_in,
        check_out: attendance.check_out,
        relax_time: attendance.relax_time,
        absent: attendance.absent,
        late: attendance.late,
        early: attendance.early,
        discounted_minutes: attendance.discounted_minutes,
        half_leave_type: attendance.half_leave_type,
      };

      if (attendance.absent) {
        attendance_data.leave_type = "Absent";
      } else if (attendance.half_leave_type == 1) {
        attendance_data.leave_type = "First Half";
      } else if (attendance.half_leave_type == 2) {
        attendance_data.leave_type = "Second Half";
      } else {
        attendance_data.leave_type = "Present";
      }

      final_attendance_arr.push(attendance_data);
    });
  }

  attendance_obj.attendance = final_attendance_arr;

  //get current month attendance and current month absents , current month late minutes
  let current_month_attendance =
    await attendance_for_employee_user_monthly_yearly(user, month, year);

  if (!_.isEmpty(current_month_attendance)) {
    current_month_absents = current_month_attendance.total_absents;

    current_month_late_mins =
      current_month_attendance.total_late_minutes >
      current_month_attendance.granted_relax_minutes
        ? current_month_attendance.total_late_minutes -
          current_month_attendance.granted_relax_minutes
        : 0;
  }

  //  //current month absent count from leave request
  //     //find current month start and end date

  //     function getMonthStartEndDates() {
  //       const currentDate = moment();
  //       let monthStart, monthEnd;

  //       monthStart = moment({
  //         year: currentDate.year(),
  //         month: currentDate.month(),
  //         day: 1,
  //       }).format("YYYY-MM-DD");

  //       monthEnd = moment({
  //         year: currentDate.year(),
  //         month: currentDate.month(),
  //         day: currentDate.daysInMonth(),
  //       }).format("YYYY-MM-DD");

  //       return { monthStart, monthEnd };

  //     }

  //     const { monthStart, monthEnd } = getMonthStartEndDates();

  //     let total_absent_monthly = 0;

  //     let current_month_absent = await find_leaves_from_leave_request(get_employee._id,monthStart,monthEnd);

  //     if (current_month_absent.length > 0) {
  //       current_month_absent.forEach((element) => {
  //         if (element.leave_type == "full") {
  //           total_absent_monthly += 1;
  //         } else if (element.leave_type == "first_half" || element.leave_type == "second_half"){
  //           total_absent_monthly += 0.5;
  //         }

  //       });

  //       current_month_absents = total_absent_monthly;
  //     }

  const data = {
    attendance: attendance_obj,
    count: get_attendance_count,
    total_pages: total_pages - 1,
    current_month_absents,
    current_month_late_mins,
    allowed_leaves: get_employee.allowed_leaves,
    load_more_url: `/api/attendance/get_attendance_for_employee_user/${user}?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getAttendanceForEmployeeUserV1 = async (user, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getAttendanceForEmployeeUserV1(user, limit, page, body, resp);
  return resp;
};

const _getEmployeeLeaves = async (user, Limit, page, body, resp) => {
  // const get_employee = await find_employee_by_id(user);
  // if (!get_employee) {
  //   resp.error = true;
  //   resp.error_message = "Employee not found";
  //   return resp;
  // }

  //pagination variables
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 25;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  // var query_obj = { emp_obj_id: get_employee._id };

  let date_from = undefined;
  let date_to = undefined;

  if (body.date_from && body.date_to) {
    date_from = moment(body.date_from, "DD/MM/YYYY").utc(true);
    date_to = moment(body.date_to, "DD/MM/YYYY").utc(true);

    const valid_from = moment(body.date_from, "DD/MM/YYYY", true).isValid();
    const valid_to = moment(body.date_to, "DD/MM/YYYY", true).isValid();
    if (valid_from && valid_to) {
      let [day_from, month_from, year_from] = body.date_from.split("/");
      let [day_to, month_to, year_to] = body.date_to.split("/");

      //chage date format to DD/MM/YYYY to YYYY-MM-DD
      date_from = moment(body.date_from, "DD/MM/YYYY").format("YYYY-MM-DD");
      date_to = moment(body.date_to, "DD/MM/YYYY").format("YYYY-MM-DD");
    } else {
      resp.error = true;
      resp.error_message = "Date must be in DD/MM/YYYY format and a valid date";
      return resp;
    }
  }

  // let get_attendance = await get_employee_attendance_by_query_obj_v1(query_obj , date_from, date_to);

  let get_attendance = await get_employee_leaves(
    body.emp_obj_id,
    date_from,
    date_to,
    body.absent,
    skip,
    limit
  );

  const get_attendance_count = await get_employee_leaves_count(
    body.emp_obj_id,
    date_from,
    date_to,
    body.absent
  );

  console.log("get_attendance:=========", get_attendance);

  // check if attendance_obj is not empty then add leave type in attendance
  let final_attendance_arr = [];

  if (!_.isEmpty(get_attendance)) {
    get_attendance.forEach((attendance) => {
      let attendance_data = {
        _id: attendance._id,
        date: attendance.date,
        check_in: attendance.check_in,
        check_out: attendance.check_out,
        relax_time: attendance.relax_time,
        absent: attendance.absent,
        late: attendance.late,
        early: attendance.early,
        discounted_minutes: attendance.discounted_minutes,
        half_leave_type: attendance.half_leave_type,
      };

      if (attendance.absent) {
        attendance_data.leave_type = "Absent";
      } else if (attendance.half_leave_type == 1) {
        attendance_data.leave_type = "First Half";
      } else if (attendance.half_leave_type == 2) {
        attendance_data.leave_type = "Second Half";
      } else {
        attendance_data.leave_type = "Present";
      }

      final_attendance_arr.push(attendance_data);
    });
  }

  console.log("final_attendance_arr: ", final_attendance_arr);

  let total_pages = Math.ceil(get_attendance_count / limit);

  const data = {
    attendance: final_attendance_arr,
    count: get_attendance_count,
    total_pages: total_pages - 1,
    load_more_url: `/api/attendance/get_employee_leaves/${body.emp_obj_id}?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getEmployeeLeaves = async (user, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getEmployeeLeaves(user, limit, page, body, resp);
  return resp;
};

const _getEmployeeLeavesV1 = async (user, Limit, page, body, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 25;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let query_object = {
    emp_obj_id: body.emp_obj_id,
  };



  if (
    body.count_in_yearly_leaves == "true" ||
    body.count_in_yearly_leaves == "false"
  ) {
    query_object = {
      ...query_object,
      count_in_yearly_leaves:
        body.count_in_yearly_leaves == "true" ? true : false,
    };
  }

  if (!!body.status) {
    query_object = {
      ...query_object,
      status: body.status,
    };
  }

  if (!!body.date_from && !!body.date_to) {
    query_object = {
      ...query_object,
      leave_date: {
        $gte: new Date(body.date_from),
        $lte: new Date(body.date_to),
      },
    };
  }

  const leaves = await find_leaves_from_leave_request_pagination_v1(
    query_object,
    skip,
    limit
  );

  const leaves_count = await find_leaves_from_leave_request_count_v1(
    query_object
  );

  let total_pages = Math.ceil(leaves_count / limit);

  let new_leaves = [];
  if (leaves.length > 0) {
    leaves.forEach((leave) => {
      let leave_data = {
        _id: leave._id,
        leave_type: leave.leave_type,
        status: leave.status,
        leave_date: leave.leave_date,
        rejection_reason: leave.rejection_reason,
        emp_name: leave.emp_name,
        emp_obj_id: leave.emp_obj_id,
        leave_reason: leave.leave_reason,
        count_in_yearly_leaves: leave.count_in_yearly_leaves,
        uncount_leave_reason: leave.uncount_leave_reason
          ? leave.uncount_leave_reason
          : "",
        uncount_leave_action_by: leave.uncount_leave_action_by
          ? leave.uncount_leave_action_by
          : {},
        updatedAt: leave.updatedAt,
        createdAt: leave.createdAt,
      };

      if (leave.leave_type == "full") {
        leave_data.leave_type = "Full";
      } else if (leave.leave_type == "first_half") {
        leave_data.leave_type = "First Half";
      } else if (leave.leave_type == "second_half") {
        leave_data.leave_type = "Second Half";
      }

      new_leaves.push(leave_data);
    });
  }

  const data = {
    attendance: new_leaves,
    count: leaves_count,
    total_pages: total_pages - 1,
    load_more_url: `/api/attendance/get_employee_leaves/${body.emp_obj_id}?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getEmployeeLeavesV1 = async (user, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getEmployeeLeavesV1(user, limit, page, body, resp);
  return resp;
};

const _getEmployeeLeavesForReport = async (user, Limit, page, body, resp) => {
  //pagination variables
  const {
    find_employee_full_name_with_emp_obj_id,
  } = require("../DAL/employee-v1");
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 25;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  // var query_obj = { emp_obj_id: get_employee._id };

  let date_from = undefined;
  let date_to = undefined;

  if (body.date_from && body.date_to) {
    date_from = moment(body.date_from, "DD/MM/YYYY").utc(true);
    date_to = moment(body.date_to, "DD/MM/YYYY").utc(true);

    const valid_from = moment(body.date_from, "DD/MM/YYYY", true).isValid();
    const valid_to = moment(body.date_to, "DD/MM/YYYY", true).isValid();
    if (valid_from && valid_to) {
      let [day_from, month_from, year_from] = body.date_from.split("/");
      let [day_to, month_to, year_to] = body.date_to.split("/");

      //chage date format to DD/MM/YYYY to YYYY-MM-DD
      date_from = moment(body.date_from, "DD/MM/YYYY").format("YYYY-MM-DD");
      date_to = moment(body.date_to, "DD/MM/YYYY").format("YYYY-MM-DD");
    } else {
      resp.error = true;
      resp.error_message = "Date must be in DD/MM/YYYY format and a valid date";
      return resp;
    }
  }

  let full_name = "";

  console.log("body.emp_obj_id: ", body.emp_obj_id);

  const emp_details = await find_employee_full_name_with_emp_obj_id(
    body.emp_obj_id
  );

  if (emp_details) {
    full_name = emp_details.full_name;
  }

  // let get_attendance = await get_employee_attendance_by_query_obj_v1(query_obj , date_from, date_to);

  let get_attendance = await get_employee_leaves(
    body.emp_obj_id,
    date_from,
    date_to,
    body.absent,
    skip,
    limit
  );

  const get_attendance_count = await get_employee_leaves_count(
    body.emp_obj_id,
    date_from,
    date_to,
    body.absent
  );
  let total_pages = Math.ceil(get_attendance_count / limit);

  const leave_request = await get_leave_request_for_report(
    body.emp_obj_id,
    date_from,
    date_to
  );

  console.log("leave_request:=========", leave_request);

  // console.log("get_attendance:=========", get_attendance);

  // check if attendance_obj is not empty then add leave type in attendance
  let final_attendance_arr = [];

  if (!_.isEmpty(get_attendance)) {
    get_attendance.forEach((attendance) => {
      let attendance_data = {
        _id: attendance._id,
        date: attendance.date,
        absent: attendance.absent,
        half_leave_type: attendance.half_leave_type,
      };

      if (attendance.absent) {
        attendance_data.leave_type = "Full";
      } else if (attendance.half_leave_type == 1) {
        attendance_data.leave_type = "First Half";
      } else if (attendance.half_leave_type == 2) {
        attendance_data.leave_type = "Second Half";
      } else {
        attendance_data.leave_type = "Present";
      }

      final_attendance_arr.push(attendance_data);
    });
  }

  // //final_attendance_arr have date in this formate
  // { "_id": "64e891912e62892b35150a8d", "date": "25/02/2024", "absent": true, "half_leave_type": 0, "leave_type": "Full" }, and
  // leave request { leave_type: 'full', status: 'approved', leave_date: 2023-07-11T00:00:00.000Z, rejection_reason: '', _id: 64ace123b66d3934d177a554, emp_obj_id: 6448b874e68076b8bdbf3088, emp_name: 'Dynamic Logix', leave_reason: 'sd', updatedAt: 2023-07-11T04:59:17.299Z, createdAt: 2023-07-11T04:57:07.769Z, __v: 0 },

  let new_final_attendance_arr = [];

  if (final_attendance_arr.length > 0) {
    for (let i = 0; i < final_attendance_arr.length; i++) {
      let new_obj = {
        _id: "",
        full_name: full_name,
        date: final_attendance_arr[i].date,
        absent: final_attendance_arr[i].absent,
        // half_leave_type: final_attendance_arr[i].half_leave_type,
        leave_type: final_attendance_arr[i].leave_type,
        status: "",
        rejection_reason: "",
        leave_reason: "",
      };

      for (let j = 0; j < leave_request.length; j++) {
        if (
          moment(final_attendance_arr[i].date, "DD/MM/YYYY").format(
            "YYYY-MM-DD"
          ) === moment(leave_request[j].leave_date).format("YYYY-MM-DD")
        ) {
          new_obj._id = leave_request[j]._id;
          new_obj.status = leave_request[j].status;
          new_obj.rejection_reason = leave_request[j].rejection_reason;
          new_obj.leave_reason = leave_request[j].leave_reason;
          break;
        }
      }

      new_final_attendance_arr.push(new_obj);
    }
  }

  console.log("new_final_attendance_arr: ", new_final_attendance_arr);

  // console.log("final_attendance_arr: ", final_attendance_arr);

  const data = {
    employee_name: full_name,
    attendance: new_final_attendance_arr,
    count: get_attendance_count,
    total_pages: total_pages - 1,
    load_more_url: `/api/attendance/get_employee_leaves_for_report/${body.emp_obj_id}?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getEmployeeLeavesForReport = async (user, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getEmployeeLeavesForReport(user, limit, page, body, resp);
  return resp;
};

const _getEmployeeLeavesForReportV1 = async (user, Limit, page, body, resp) => {
  //pagination variables
  const {
    find_employee_full_name_with_emp_obj_id,
  } = require("../DAL/employee-v1");
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 25;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  // var query_obj = { emp_obj_id: get_employee._id };

  let date_from = undefined;
  let date_to = undefined;

  if (body.date_from && body.date_to) {
    date_from = moment(body.date_from, "DD/MM/YYYY").utc(true);
    date_to = moment(body.date_to, "DD/MM/YYYY").utc(true);

    const valid_from = moment(body.date_from, "DD/MM/YYYY", true).isValid();
    const valid_to = moment(body.date_to, "DD/MM/YYYY", true).isValid();
    if (valid_from && valid_to) {
      let [day_from, month_from, year_from] = body.date_from.split("/");
      let [day_to, month_to, year_to] = body.date_to.split("/");

      //chage date format to DD/MM/YYYY to YYYY-MM-DD
      date_from = moment(body.date_from, "DD/MM/YYYY").format("YYYY-MM-DD");
      date_to = moment(body.date_to, "DD/MM/YYYY").format("YYYY-MM-DD");
    } else {
      resp.error = true;
      resp.error_message = "Date must be in DD/MM/YYYY format and a valid date";
      return resp;
    }
  }

  let full_name = "";

  console.log("body.emp_obj_id: ", body.emp_obj_id);

  const emp_details = await find_employee_full_name_with_emp_obj_id(
    body.emp_obj_id
  );

  if (emp_details) {
    full_name = emp_details.full_name;
  }

  //new logic from leaves_request

  const leaves = await find_leaves_from_leave_request_pagination(
    body.emp_obj_id,
    new Date(date_from),
    new Date(date_to),
    skip,
    limit
  );

  const leaves_count = await find_leaves_from_leave_request_count(
    body.emp_obj_id,
    new Date(date_from),
    new Date(date_to)
  );

  let total_pages = Math.ceil(leaves_count / limit);

  let new_leaves = [];
  if (leaves.length > 0) {
    leaves.forEach((leave) => {
      let leave_data = {
        _id: leave._id,
        leave_type: leave.leave_type,
        status: leave.status,
        leave_date: leave.leave_date,
        rejection_reason: leave.rejection_reason,
        emp_name: leave.emp_name,
        emp_obj_id: leave.emp_obj_id,
        leave_reason: leave.leave_reason,
        updatedAt: leave.updatedAt,
        createdAt: leave.createdAt,
      };

      if (leave.leave_type == "full") {
        leave_data.leave_type = "Full";
      } else if (leave.leave_type == "first_half") {
        leave_data.leave_type = "First Half";
      } else if (leave.leave_type == "second_half") {
        leave_data.leave_type = "Second Half";
      }

      new_leaves.push(leave_data);
    });
  }

  const data = {
    employee_name: full_name,
    attendance: new_leaves,
    count: leaves_count,
    total_pages: total_pages - 1,
    load_more_url: `/api/attendance/get_employee_leaves_for_report/${body.emp_obj_id}?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getEmployeeLeavesForReportV1 = async (user, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getEmployeeLeavesForReportV1(user, limit, page, body, resp);
  return resp;
};

const _getEmployeeAbsents = async (body, Limit, page, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let final_attendance_arr = [];
  let count = 0;
  const date = new Date();
  // let day = date.getDate() - 1;
  // let month = date.getMonth() + 1;
  let year = date.getFullYear();
  let query_obj = { emp_obj_id: body.emp_obj_id };

  if (body.month && body.month != "" && body.year && body.year != "") {
    query_obj.month = parseInt(body.month);
    query_obj.year = parseInt(body.year);
  } else {
    query_obj.$or = [
      { $and: [{ month: { $gte: 7 } }, { year: year }] },
      { $and: [{ month: { $lte: 6 } }, { year: year + 1 }] },
    ];
  }

  const absents = await get_employee_absents(query_obj, skip, limit);
  const absents_count = await get_employee_absents_count(query_obj);
  if (absents_count.length > 0) {
    count = absents_count[0].count;
  }
  // console.log("absents: ", absents);
  // console.log("absents[0].attendance: ", absents[0].attendance);

  // let all_absents = [];
  // absents.forEach((absent) => {
  //   all_absents.push(...absent.attendance);
  // });

  // console.log("all_absents: ", all_absents);

  if (!_.isEmpty(absents)) {
    absents.sort((a, b) => {
      const dateA = new Date(a.date.split("/").reverse().join("-"));
      const dateB = new Date(b.date.split("/").reverse().join("-"));
      return dateB - dateA;
    });

    // console.log("absents after sorting: ", absents);

    absents.forEach((attendance) => {
      let attendance_obj = {
        _id: attendance._id,
        date: attendance.date,
        check_in: attendance.check_in,
        check_out: attendance.check_out,
        relax_time: attendance.relax_time,
        absent: attendance.absent,
        late: attendance.late,
        early: attendance.early,
        discounted_minutes: attendance.discounted_minutes,
        half_leave_type: attendance.half_leave_type,
      };
      if (attendance.absent) {
        attendance_obj.leave_type = "Absent";
      } else if (attendance.half_leave_type == 1) {
        attendance_obj.leave_type = "First Half";
      } else if (attendance.half_leave_type == 2) {
        attendance_obj.leave_type = "Second Half";
      } else {
        attendance_obj.leave_type = "Present";
      }
      final_attendance_arr.push(attendance_obj);
    });
  }

  // console.log("final_attendance_arr: ", final_attendance_arr);

  const data = {
    absents: final_attendance_arr,
    count: count,
    load_more_url: `/attendance/get_employee_absents?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getEmployeeAbsents = async (body, limit, page) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getEmployeeAbsents(body, limit, page, resp);
  return resp;
};

const _getAttendanceForFine = async (body, resp) => {
  const { find_employee_by_employee_id } = require("../DAL/employee");

  const date = new Date();
  // let day = date.getDate() - 1;
  let month = date.getMonth() + 1;
  let year = date.getFullYear();

  if (body.month && body.month != "") {
    month = body.month;
  }
  if (body.year && body.year != "") {
    year = body.year;
  }

  let prev_month = month - 1;
  let prev_year = year;
  if (month == 1) {
    prev_month = 12;
    prev_year = year - 1;
  }

  let final_attendance = [];

  const attendance = await attendance_for_fine(month, year);
  for (let i = 0; i < attendance.length; i++) {
    let fineable_minutes = 0;
    let discounted_mins = 0;
    let prev_month_fine = 0;
    let salary = 0;
    const get_emp = await find_employee_by_employee_id(attendance[i].emp_id);
    if (get_emp) {
      salary += parseInt(get_emp.basic_salary);
    }
    if (attendance[i].total_late_minutes >= 60) {
      fineable_minutes = attendance[i].total_late_minutes - 60;
    }
    if (attendance[i].attendance.length > 0) {
      discounted_mins = attendance[i].attendance[0].late;
    }
    const prev_month_attendance = await find_attendance_by_emp_id_month_year(
      attendance[i].emp_id,
      prev_month,
      prev_year
    );
    // console.log("prev_month_attendance: ", prev_month_attendance);
    if (prev_month_attendance) {
      prev_month_fine = prev_month_attendance.fine;
    }
    let fine_obj = {
      _id: attendance[i]._id,
      emp_id: attendance[i].emp_id,
      emp_name: attendance[i].emp_name,
      total_late_minutes: fineable_minutes,
      discounted_minutes: discounted_mins,
      prev_month_fine: prev_month_fine,
      salary,
    };
    final_attendance.push(fine_obj);
  }
  const data = {
    attendance: final_attendance,
  };
  resp.data = data;
  return resp;
};

const getAttendanceForFine = async (body) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getAttendanceForFine(body, resp);
  return resp;
};

const _grantRelaxMinutes = async (body, resp) => {
  const date = new Date();
  // let day = date.getDate() - 1;
  let month = date.getMonth() + 1;
  let year = date.getFullYear();

  if (body.month && body.month != "") {
    month = body.month;
  }
  if (body.year && body.year != "") {
    year = body.year;
  }

  // Checking if the granted relax minutes are greater than total fineable late minutes
  // const fine_attendance = await attendance_for_fine(month, year);

  // for (let x = 0; x < body.final_attendance.length; x++) {
  //   for (let y = 0; y < fine_attendance.length; y++) {
  //     if (body.final_attendance[x].emp_id == fine_attendance[y].emp_id) {
  //       if (
  //         body.final_attendance[x].granted_relax_minutes >
  //         fine_attendance[y].total_late_minutes - 60
  //       ) {
  //         resp.error = true;
  //         resp.error_message =
  //           "Granted relax minutes for " +
  //           body.final_attendance[x].emp_name +
  //           " must be less than their total late minutes.";
  //         return resp;
  //       }
  //     }
  //   }
  // }

  for (let i = 0; i < body.final_attendance.length; i++) {
    const attendance = await find_attendance_by_emp_id_month_year(
      body.final_attendance[i].emp_id,
      month,
      year
    );
    if (!_.isEmpty(attendance)) {
      // if (!attendance.paid_status || attendance.fine == 0) {
      let due_fine = 0;
      if (
        body.final_attendance[i].due_fine &&
        body.final_attendance[i].due_fine != undefined &&
        body.final_attendance[i].due_fine != null &&
        body.final_attendance[i].due_fine != "" &&
        !isNaN(body.final_attendance[i].due_fine)
      ) {
        due_fine = parseInt(body.final_attendance[i].due_fine);
      }
      attendance.fine = body.final_attendance[i].fine;
      attendance.granted_relax_minutes =
        body.final_attendance[i].granted_relax_minutes;

      attendance.due_fine = due_fine;

      if (attendance.fine == 0) {
        paid_status = true;
      }

      await attendance.save();
      // }
    }
  }

  resp.data = {};
  return resp;
};

const grantRelaxMinutes = async (body) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _grantRelaxMinutes(body, resp);
  return resp;
};

const _getFineSheet = async (Limit, page, body, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  const date = new Date();
  // let day = date.getDate() - 1;
  let month = date.getMonth() + 1;
  let year = date.getFullYear();

  if (body.month && body.month != "") {
    month = body.month;
  }
  if (body.year && body.year != "") {
    year = body.year;
  }

  let query_obj = { month, year };
  if (body.name && body.name != "") {
    query_obj.emp_name = { $regex: new RegExp(body.name, "i") };
  }

  let final_finesheet = [];
  const finesheet = await get_finesheet(query_obj, skip, limit);
  const count = await get_finesheet_count(query_obj);

  // console.log("finesheet: ", finesheet);
  for (let i = 0; i < finesheet.length; i++) {
    if (finesheet[i].fine > 0) {
      let updated_late_mins = 0;
      updated_late_mins =
        finesheet[i].total_late_minutes -
        finesheet[i].granted_relax_minutes -
        60;
      if (updated_late_mins < 0) {
        updated_late_mins = 0;
      }
      let obj = {
        emp_obj_id: finesheet[i].emp_obj_id,
        emp_name: finesheet[i].emp_name,
        emp_id: finesheet[i].emp_id,
        month: finesheet[i].month,
        year: finesheet[i].year,
        fine: finesheet[i].fine,
        due_fine: finesheet[i].due_fine,
        granted_relax_minutes: finesheet[i].granted_relax_minutes,
        total_absents: finesheet[i].total_absents,
        paid_status: finesheet[i].paid_status,
        createdAt: finesheet[i].createdAt,
        updatedAt: finesheet[i].updatedAt,
        total_late_minutes: updated_late_mins,
      };
      final_finesheet.push(obj);
    }
  }

  const data = {
    finesheet: final_finesheet,
    count,
    load_more_url: `/attendance/get_finesheets?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getFineSheet = async (limit, page, body) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getFineSheet(limit, page, body, resp);
  return resp;
};

const _getFineUser = async (user_id, search, resp) => {
  const emp_details = await find_employee_by_user_id(user_id);

  const date = new Date();
  let year = date.getFullYear();

  if (search && search != "") {
    year = search;
  }
  let query_obj = { year };

  if (!_.isEmpty(emp_details)) {
    query_obj.emp_obj_id = emp_details._id;
  }

  let final_finesheet = [];
  const finesheet = await get_fine_query_obj(query_obj);
  const count = await get_fine_query_obj_count(query_obj);

  for (let i = 0; i < finesheet.length; i++) {
    let total_fine = 0;
    total_fine = finesheet[i].fine + finesheet[i].late_fine;

    let obj = {
      _id: finesheet[i]._id,
      month: finesheet[i].month,
      year: finesheet[i].year,
      fine: finesheet[i].fine,
      due_fine: finesheet[i].due_fine,
      late_fine: finesheet[i].late_fine,
      paid_status: finesheet[i].paid_status,
      total_fine: total_fine,
    };
    final_finesheet.push(obj);
  }

  const data = {
    finesheet: final_finesheet,
    count,
  };
  resp.data = data;
  return resp;
};

const getFineUser = async (user_id, search) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getFineUser(user_id, search, resp);
  return resp;
};

const _payFine = async (body, resp) => {
  const attendance = await find_attendance_by_emp_obj_id_month_year(
    body.emp_obj_id,
    body.month,
    body.year
  );
  if (!_.isEmpty(attendance)) {
    if (body.paid_status != undefined && body.paid_status != null) {
      if (body.paid_status) {
        attendance.paid_status = true;
      } else {
        attendance.paid_status = false;
      }
    }
    await attendance.save();
  } else {
    resp.error = true;
    resp.error_message = "Fine not found";
    return resp;
  }

  return resp;
};

const payFine = async (body) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _payFine(body, resp);
  return resp;
};

const _getAttendanceByIdSpecificDay = async (id, resp) => {
  const attendance = await find_attendance_by_id_specific_day(id);

  if (attendance == null) {
    resp.error = true;
    resp.error_message = "Attendance not found";
    return resp;
  }

  console.log("attendance:=========", attendance);

  resp.data = {
    attendance: attendance,
  };
  return resp;
};

const getAttendanceByIdSpecificDay = async (id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getAttendanceByIdSpecificDay(id, resp);
  return resp;
};

module.exports = {
  addAttendance,
  addAttendanceManually,
  getAttendances,
  detailAttendance,
  detailAttendanceByID,
  deleteAttendance,
  deleteAttendanceIndividually,
  getAttendanceForEmployee,
  markDiscountMinutes,
  getAttendanceForEmployeeUser,
  getAttendanceForEmployeeUserV1,
  getEmployeeAbsents,
  getAttendanceForFine,
  markDiscountMinutesByUser,
  grantRelaxMinutes,
  getFineSheet,
  getFineUser,
  payFine,
  getEmployeeLeaves,
  getEmployeeLeavesV1,
  getEmployeeLeavesForReport,
  getEmployeeLeavesForReportV1,
  getAttendancesV1,
  getAttendanceByIdSpecificDay,
};
