const { find_user, find_user_by_id } = require("../DAL/user");
const {
  add_feedback,
  find_feedback_by_id,
  employees_not_get_feedback_to_submit_this_month,
  delete_feedback_by_id,
  get_feedback_search,
  feedback_search_count,
  find_feedback_by_name,
  get_employees_performance,
  get_employees_performance_count,
} = require("../DAL/feedback");
const {
  find_employee_by_user_id,
  find_employee_by_id,
  get_all_employees_ids,
} = require("../DAL/employee");
const {
  add_notification,
  delete_feedback_notifications,
} = require("../DAL/notification");
const { NOTIFICATION_TYPE } = require("../utils/constants");
const { find_feedback_template_by_id } = require("../DAL/feedback_template");
const moment = require("moment");

const _addFeedback = async (user_id, body, resp) => {
  [year, month] = body.date.split("-");
  const added_employee_detail = await find_employee_by_user_id(user_id);
  if (!added_employee_detail) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  let feedback_requester = {
    _id: added_employee_detail._id,
    name: added_employee_detail.full_name,
  };

  const feedback_template = await find_feedback_template_by_id(
    body.feedback_template
  );
  if (!feedback_template) {
    resp.error = true;
    resp.error_message = "Feedback template not found";
    return resp;
  }

  let sender = undefined;
  let send_to = { _id: null, name: "" };
  if (
    body.send_to &&
    body.send_to != "" &&
    body.send_to != null &&
    body.send_to != undefined
  ) {
    sender = await find_employee_by_id(body.send_to);
    if (!sender) {
      resp.error = true;
      resp.error_message = "Member not found";
      return resp;
    }
    send_to._id = sender._id;
    send_to.name = sender.full_name;
  }

  let send_for_arr = [];
  let feedback_arr = [];

  // let all_send_fors = [];
  for (let i = 0; i < body.send_for.length; i++) {
    const get_employee = await find_employee_by_id(body.send_for[i]);
    if (!get_employee) {
      resp.error = true;
      resp.error_message =
        "Member with this ID " +
        body.send_for[i] +
        " not found. First select all the members with valid IDs";
      return resp;
    }
    send_for_arr.push({ _id: get_employee._id, name: get_employee.full_name });
    // all_send_fors.push(get_employee);

    if (send_to._id == null || send_to._id == undefined) {
      send_to._id = get_employee._id;
      send_to.name = get_employee.full_name;
      sender = get_employee;
    }
  }

  for (let i = 0; i < send_for_arr.length; i++) {
    let feedback_obj = {
      title: body.title,
      questions: feedback_template.questions,
      feedback_requester: feedback_requester,
      send_to: send_to,
      send_for: send_for_arr[i],
      year: year,
      month: month,
      // date: moment(body.date, "DD-MM-YYYY").utc(true),
    };

    const final_feedback = await add_feedback(feedback_obj);
    feedback_arr.push(final_feedback);

    if (final_feedback) {
      if (sender != undefined && sender != null) {
        if (sender.previllages.feedback.view) {
          let notification_obj = {
            user_id: sender.user_id._id,
            feedback_id: final_feedback._id,
            title: "Feedback",
            description: "Hi! You received a new feedback to complete",
            type: NOTIFICATION_TYPE.feedback,
          };
          await add_notification(notification_obj);
        }
      }
      // else {
      //   if (all_send_fors[i].previllages.feedback.view) {
      //     let notification_obj = {
      //       user_id: all_send_fors[i].user_id._id,
      //       feedback_id: final_feedback._id,
      //       title: "Feedback",
      //       description: "Hi! You received a new feedback to complete",
      //       type: NOTIFICATION_TYPE.feedback,
      //     };
      //     await add_notification(notification_obj);
      //   }
      // }
    }
  }
  resp.data = feedback_arr;
  return resp;
};

const addFeedback = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addFeedback(user_id, body, resp);
  return resp;
};

const _editFeedback = async (body, feedback_id, resp) => {
  const feedback_detail = await find_feedback_by_id(feedback_id);
  if (!feedback_detail) {
    resp.error = true;
    resp.error_message = "Invalid Feedback Template";
    return resp;
  }
  // const old_title = feedback_detail.title;
  // let active_status = false;
  // if (body.active_status.toLowerCase() == "true") {
  //   active_status = true;
  // }

  feedback_detail.title = body.title;
  feedback_detail.questions = body.questions;
  feedback_detail.active_status = body.active_status;

  // if (old_title != body.title) {
  //   const feedback_check = await find_feedback_by_name(
  //     body.title
  //   );
  //   if (feedback_check) {
  //     resp.error = true;
  //     resp.error_message = "Feedback Template already exists";
  //     return resp;
  //   }
  //   await update_feedback_in_expense(feedback_id, body.title);
  // }

  await feedback_detail.save();
  resp.data = feedback_detail;
  return resp;
};
const editFeedback = async (body, feedback_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editFeedback(body, feedback_id, resp);
  return resp;
};

const _detailFeedback = async (user_id, feedback_id, resp) => {
  const user = await find_employee_by_user_id(user_id);
  if (!user) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  const feedback = await find_feedback_by_id(feedback_id);
  if (!feedback) {
    resp.error = true;
    resp.error_message = "Invalid Feedback Template ID!";
    return resp;
  }

  let final_feedback = {
    _id: feedback._id,
    title: feedback.title,
    month: feedback.month,
    year: feedback.year,
    feedback_requester: feedback.feedback_requester,
    send_to: feedback.send_to,
    send_for: feedback.send_for,
    questions: feedback.questions,
    submission_status: feedback.submission_status,
    date: feedback.date,
    active_status: feedback.active_status,
    createdAt: feedback.createdAt,
    updatedAt: feedback.updatedAt,
  };

  // console.log("feedback: ", feedback);
  // console.log("user._id: ", user._id);
  // console.log("feedback.send_to._id: ", feedback.send_to._id);
  if (feedback.send_to._id == user._id.toString()) {
    final_feedback.private_notes = feedback.private_notes;
  }

  resp.data = final_feedback;
  return resp;
};

const detailFeedback = async (user_id, feedback_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailFeedback(user_id, feedback_id, resp);
  return resp;
};

const _deleteFeedback = async (user_id, feedback_id, resp) => {
  const employee_detail = await find_employee_by_user_id(user_id);
  if (!employee_detail) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  if (
    employee_detail.role.title == "HR" ||
    employee_detail.role.title == "Admin" ||
    employee_detail.role.title == "All"
  ) {
    const deleted_feedback = await delete_feedback_by_id(feedback_id);
    if (!deleted_feedback) {
      resp.error = true;
      resp.error_message = "Invalid Feedback Template ID!";
      return resp;
    }
    await delete_feedback_notifications(deleted_feedback._id);
  } else {
    resp.error = true;
    resp.error_message = "You can't delete feedback";
    return resp;
  }
  return resp;
};

const deleteFeedback = async (user_id, feedback_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteFeedback(user_id, feedback_id, resp);
  return resp;
};

const _searchFeedback = async (user_id, Limit, page, body, resp) => {
  // console.log("body: ", body);
  // let date_from = moment().startOf("month").format("YYYY-MM-DD");
  // let date_to = moment().endOf("month").format("YYYY-MM-DD");
  let date = new Date();
  let month = date.getMonth();
  let year = date.getFullYear();
  let remaining_emps = [];
  let pending_count = 0;

  let query_obj = { submission_status: "pending" };
  // console.log("pending_count: ", pending_count);

  if (
    body.date &&
    body.date != "" &&
    body.date != null &&
    body.date != undefined
  ) {
    [year, month] = body.date.split("-");
    query_obj.month = month;
    query_obj.year = year;
  }

  const get_employee = await find_employee_by_user_id(user_id);
  // console.log("get_employee: ", get_employee);
  if (get_employee) {
    if (
      get_employee.role.title != "All" &&
      get_employee.role.title != "HR" &&
      get_employee.role.title != "Admin"
    ) {
      query_obj["send_to._id"] = get_employee._id;
    }
    if (
      get_employee.role.title == "All" ||
      get_employee.role.title == "HR" ||
      get_employee.role.title == "Admin"
    ) {
      pending_count = await feedback_search_count(query_obj);
      let all_emp_ids = await get_all_employees_ids();
      // console.log("all_emp_ids: ", all_emp_ids);
      all_emp_ids = all_emp_ids.map((emp) => emp._id);
      // console.log("all_emp_ids: ", all_emp_ids);

      remaining_emps = await employees_not_get_feedback_to_submit_this_month(
        all_emp_ids,
        month,
        year
      );
      // console.log("remaining_emps: ", remaining_emps);
    }
  }

  if (body.search && body.search != "") {
    query_obj.$or = [{ title: { $regex: new RegExp(body.search, "i") } }];
  }

  if (body.emp_name && body.emp_name != "") {
    query_obj["send_for.name"] = { $regex: new RegExp(body.emp_name, "i") };
  }

  // console.log("query_obj: ", query_obj);
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;
  const feedback = await get_feedback_search(limit, skip, query_obj);
  const total_pages = await feedback_search_count(query_obj);

  resp.data = {
    feedback,
    total_pages,
    pending_count,
    remaining_emps,
    load_more_url: `/feedback/get_feedback?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchFeedback = async (user_id, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchFeedback(user_id, limit, page, body, resp);
  return resp;
};

const _submitFeedback = async (body, feedback_id, resp) => {
  const feedback_detail = await find_feedback_by_id(feedback_id);
  if (!feedback_detail) {
    resp.error = true;
    resp.error_message = "Invalid Feedback ID";
    return resp;
  }

  if (feedback_detail.submission_status == "submitted") {
    resp.error = true;
    resp.error_message = "Feedback already submitted";
    return resp;
  }

  feedback_detail.questions = body.questions;
  feedback_detail.private_notes = body.private_notes;
  feedback_detail.submission_status = "submitted";

  await feedback_detail.save();
  resp.data = feedback_detail;
  return resp;
};
const submitFeedback = async (body, feedback_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _submitFeedback(body, feedback_id, resp);
  return resp;
};

const _submittedFeedbacks = async (user_id, Limit, page, body, resp) => {
  let date = new Date();
  let month = date.getMonth();
  let year = date.getFullYear();
  let query_obj = { submission_status: "submitted" };
  const get_employee = await find_employee_by_user_id(user_id);
  if (get_employee) {
    if (
      get_employee.role.title != "All" &&
      get_employee.role.title != "HR" &&
      get_employee.role.title != "Admin"
    ) {
      query_obj["send_to._id"] = get_employee._id;
    }
  }

  if (body.search && body.search != "") {
    query_obj.$or = [{ title: { $regex: new RegExp(body.search, "i") } }];
  }

  if (body.emp_name && body.emp_name != "") {
    query_obj["send_for.name"] = { $regex: new RegExp(body.emp_name, "i") };
  }

  if (
    body.date &&
    body.date != "" &&
    body.date != null &&
    body.date != undefined
  ) {
    [year, month] = body.date.split("-");
    query_obj.month = month;
    query_obj.year = year;
  }

  console.log("query_obj: ", query_obj);
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;
  const feedback = await get_feedback_search(limit, skip, query_obj);
  const total_pages = await feedback_search_count(query_obj);

  resp.data = {
    feedback,
    total_pages,
    load_more_url: `/feedback/get_feedback?page=${page}&limit=${limit}`,
  };

  return resp;
};

const submittedFeedbacks = async (user_id, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _submittedFeedbacks(user_id, limit, page, body, resp);
  return resp;
};

const _getPerformance = async (user_id, Limit, page, body, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let date = new Date();
  let month = date.getMonth();
  let year = date.getFullYear();
  let query_obj = { submission_status: "submitted", month, year };
  let feedback = [];
  let total_pages = 0;
  const get_employee = await find_employee_by_user_id(user_id);
  if (get_employee) {
    if (
      get_employee.role.title == "All" ||
      get_employee.role.title == "HR" ||
      get_employee.role.title == "Admin"
    ) {
      if (body.emp_name && body.emp_name != "") {
        query_obj["send_for.name"] = { $regex: new RegExp(body.emp_name, "i") };
      }

      if (
        body.date &&
        body.date != "" &&
        body.date != null &&
        body.date != undefined
      ) {
        [year, month] = body.date.split("-");
        query_obj.month = parseInt(month);
        query_obj.year = parseInt(year);
      }

      console.log("query_obj 2: ", query_obj);

      let get_feedback = await get_employees_performance(
        limit,
        skip,
        query_obj
      );
      let get_count = await get_employees_performance_count(query_obj);
      if (get_feedback.length > 0) {
        feedback = get_feedback;
        console.log("feedback: ", get_feedback);
      }
      if (get_count.length > 0) {
        total_pages = get_count[0].count;
        console.log("total_pages: ", get_count[0].count);
      }
    }
  }

  resp.data = {
    feedback,
    total_pages,
    load_more_url: `/feedback/get_feedback?page=${page}&limit=${limit}`,
  };

  return resp;
};

const getPerformance = async (user_id, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getPerformance(user_id, limit, page, body, resp);
  return resp;
};

const _searchFeedbacksForMe = async (user_id, Limit, page, body, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  // console.log("body: ", body);
  // let date_from = moment().startOf("month").format("YYYY-MM-DD");
  // let date_to = moment().endOf("month").format("YYYY-MM-DD");
  let date = new Date();
  let month = date.getMonth();
  let year = date.getFullYear();
  let feedback = [];
  let total_pages = 0;

  let query_obj = { submission_status: "submitted" };
  // console.log("pending_count: ", pending_count);

  if (
    body.date &&
    body.date != "" &&
    body.date != null &&
    body.date != undefined
  ) {
    [year, month] = body.date.split("-");
    query_obj.month = month;
    query_obj.year = year;
  }

  const get_employee = await find_employee_by_user_id(user_id);
  // console.log("get_employee: ", get_employee);
  if (get_employee) {
    query_obj["send_for._id"] = get_employee._id;

    if (body.search && body.search != "") {
      query_obj.$or = [
        { title: { $regex: new RegExp(body.search, "i") } },
        { "send_to.name": { $regex: new RegExp(body.search, "i") } },
      ];
    }

    // console.log("query_obj: ", query_obj);

    let skip = (page - 1) * limit;
    feedback = await get_feedback_search(limit, skip, query_obj);
    total_pages = await feedback_search_count(query_obj);
  }
  resp.data = {
    feedback,
    total_pages,
    load_more_url: `/feedback/get_feedback?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchFeedbacksForMe = async (user_id, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchFeedbacksForMe(user_id, limit, page, body, resp);
  return resp;
};

module.exports = {
  addFeedback,
  editFeedback,
  detailFeedback,
  deleteFeedback,
  searchFeedback,
  submitFeedback,
  submittedFeedbacks,
  getPerformance,
  searchFeedbacksForMe,
};
