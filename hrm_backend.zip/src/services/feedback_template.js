const { find_user, find_user_by_id } = require("../DAL/user");
const {
  add_feedback_template,
  find_feedback_template_by_id,
  pagination_feedback_template,
  all_active_feedback_templates,
  all_active_feedback_templates_count,
  delete_feedback_template_by_id,
  get_feedback_template_search,
  feedback_template_search_count,
  find_feedback_template_by_name,
} = require("../DAL/feedback_template");

const _addFeedbackTemplate = async (body, resp) => {
  const feedback_template_detail = await find_feedback_template_by_name(
    body.title
  );
  if (feedback_template_detail) {
    resp.error = true;
    resp.error_message = "Feedback Template already exists";
    return resp;
  }
  let feedback_template_obj = {
    title: body.title,
    questions: body.questions,
  };

  const final_feedback_template = await add_feedback_template(
    feedback_template_obj
  );
  resp.data = final_feedback_template;
  return resp;
};
const addFeedbackTemplate = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addFeedbackTemplate(body, resp);
  return resp;
};

const _editFeedbackTemplate = async (body, feedback_template_id, resp) => {
  const feedback_template_detail = await find_feedback_template_by_id(
    feedback_template_id
  );
  if (!feedback_template_detail) {
    resp.error = true;
    resp.error_message = "Invalid Feedback Template";
    return resp;
  }
  // const old_title = feedback_template_detail.title;
  // let active_status = false;
  // if (body.active_status.toLowerCase() == "true") {
  //   active_status = true;
  // }

  feedback_template_detail.title = body.title;
  feedback_template_detail.questions = body.questions;
  feedback_template_detail.active_status = body.active_status;

  // if (old_title != body.title) {
  //   const feedback_template_check = await find_feedback_template_by_name(
  //     body.title
  //   );
  //   if (feedback_template_check) {
  //     resp.error = true;
  //     resp.error_message = "Feedback Template already exists";
  //     return resp;
  //   }
  //   await update_feedback_template_in_expense(feedback_template_id, body.title);
  // }

  await feedback_template_detail.save();
  resp.data = feedback_template_detail;
  return resp;
};
const editFeedbackTemplate = async (body, feedback_template_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editFeedbackTemplate(body, feedback_template_id, resp);
  return resp;
};

const _getFeedbackTemplate = async (resp) => {
  const feedback_template = await all_active_feedback_templates();
  // const total_pages = await all_active_feedback_templates_count();
  const data = {
    feedback_template: feedback_template,
  };
  resp.data = data;
  return resp;
};

const getFeedbackTemplate = async () => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getFeedbackTemplate(resp);
  return resp;
};
const _detailFeedbackTemplate = async (feedback_template_id, resp) => {
  const feedback_template = await find_feedback_template_by_id(
    feedback_template_id
  );
  if (!feedback_template) {
    resp.error = true;
    resp.error_message = "Invalid Feedback Template ID!";
    return resp;
  }
  resp.data = feedback_template;
  return resp;
};

const detailFeedbackTemplate = async (feedback_template_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailFeedbackTemplate(feedback_template_id, resp);
  return resp;
};

const _deleteFeedbackTemplate = async (feedback_template_id, resp) => {
  const deleted_feedback_template = await delete_feedback_template_by_id(
    feedback_template_id
  );
  if (!deleted_feedback_template) {
    resp.error = true;
    resp.error_message = "Invalid Feedback Template ID!";
    return resp;
  }
  return resp;
};

const deleteFeedbackTemplate = async (feedback_template_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteFeedbackTemplate(feedback_template_id, resp);
  return resp;
};

const _searchFeedbackTemplate = async (Limit, page, search, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;
  const feedback_template = await get_feedback_template_search(
    limit,
    skip,
    search
  );
  const total_pages = await feedback_template_search_count(search);
  resp.data = {
    feedback_template: feedback_template,
    total_pages: total_pages,
    load_more_url: `/feedback_template/get_feedback_template?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchFeedbackTemplate = async (limit, page, search) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchFeedbackTemplate(limit, page, search, resp);
  return resp;
};
module.exports = {
  addFeedbackTemplate,
  editFeedbackTemplate,
  getFeedbackTemplate,
  detailFeedbackTemplate,
  deleteFeedbackTemplate,
  searchFeedbackTemplate,
};
