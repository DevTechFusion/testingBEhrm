const {all_employee_count} = require("../DAL/employee");
const _initStat = async (resp) => {
  const employees = await all_employee_count();
  resp.data = {employees: employees};
  return resp;
};
const initStat = async () => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };
  resp = await _initStat(resp);
  return resp;
};

module.exports = {
  initStat,
};
