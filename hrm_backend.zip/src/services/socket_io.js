const socketio = require("socket.io");
const { find_role_by_id } = require("../DAL/role");
const { find_user_by_id } = require("../DAL/user");
const { User } = require("../models/users");
const {
  find_employee_by_user_id,
  find_employee_by_id,
  find_employee_by_id_without_populate,
  find_employee_by_user_id_without_populate,
  get_all_active_hr,
  get_active_alls_hrs,
  get_active_employees_role_based_except_employee,
  get_active_employees_role_based,
  get_all_active_employees,
  get_team_members_ids,
  get_active_alls_hrs_and_admin,
} = require("../DAL/employee");
const {
  search_leave_requests_by_query_obj,
  find_leave_request_by_id,
  leave_request_search_count,
} = require("../DAL/leave_request");
const {
  search_support_tickets_by_query_obj,
  add_message_to_unread,
  find_support_ticket_by_id,
} = require("../DAL/support_ticket");
const { get_notification_by_query_obj } = require("../DAL/notification");
const { NOTIFICATION_TYPE } = require("../utils/constants");
const _ = require("lodash");
const moment = require("moment");

let EMP_OBJ_ID = null;
let EMP_SOCKET_ID = null;
//************************************************ Creating Connection ********************************************************/
const create_socket = (server) => {
  // async (req, res) => {
  //   const user = await find_employee_by_user_id_without_populate(req.user);
  //   if (!user) {
  //     return res.status(400).json({
  //       code: 400,
  //       message: "User not found",
  //     });
  //   }
  //   user_id = user.user_id;
  // };

  const io = socketio(server, {
    cors: {
      origin: "*",
    },
  });
  io.on("connection", async (socket) => {
    const { roomId } = socket.handshake.query;
    // socket.join(roomId);

    let data = await find_employee_by_user_id(roomId);
    if (data) {
      EMP_OBJ_ID = data._id;
      data.is_online = true;
      data.socket_id = socket.id;
      await data.save();
      EMP_SOCKET_ID = data.socket_id;
      // console.log("EMP_OBJ_ID: ", data._id);
      // console.log("data: ", data);
    }

    socket.on("create", async function (room) {
      socket.join(room);

      // let data = await find_employee_by_user_id(room);
      // if (data) {
      //   data.is_online = true;
      //   data.socket_id = socket.id;
      //   await data.save();
      // }
    });

    //************************************* leave request event call ******************************************/

    socket.on("leave_request_sent", async (msg) => {
      if (!_.isEmpty(msg)) {
        const all_hrs = await get_all_active_hr();
        const emp_details = await find_employee_by_id(msg[0].emp_obj_id);
        for (let x = 0; x < emp_details.leads.length; x++) {
          const get_lead = await find_employee_by_id_without_populate(
            emp_details.leads[x]._id
          );
          all_hrs.push(get_lead);
        }
        for (let j = 0; j < all_hrs.length; j++) {
          if (all_hrs[j].previllages.leaves.view) {
            let query_obj = {
              leave_request_id: msg[0]._id,
              user_id: all_hrs[j].user_id,
            };
            let get_notification_data = await get_notification_by_query_obj(
              query_obj
            );
            if (get_notification_data) {
              let notification_obj = {
                _id: get_notification_data._id,
                user_id: all_hrs[j].user_id,
                leave_request_id: msg[0]._id,
                title: "Leave Request",
                description:
                  "Hi! " + msg[0].emp_name + " just requested a leave",
                type: NOTIFICATION_TYPE.leave_request,
                createdAt: get_notification_data.createdAt,
              };
              if (msg.length > 1) {
                notification_obj.description =
                  "Hi! " +
                  msg[0].emp_name +
                  " just requested a leave from " +
                  moment(msg[0].leave_date).format("DD-MM-YYYY") +
                  " to " +
                  moment(msg[msg.length - 1].leave_date).format("DD-MM-YYYY");
              } else {
                if (msg[0].leave_type == "first_half") {
                  notification_obj.description =
                    "Hi! " +
                    msg[0].emp_name +
                    " just requested a first half leave request on " +
                    moment(msg[0].leave_date).format("DD-MM-YYYY");
                } else if (msg[0].leave_type == "second_half") {
                  notification_obj.description =
                    "Hi! " +
                    msg[0].emp_name +
                    " just requested a second half leave request on " +
                    moment(msg[0].leave_date).format("DD-MM-YYYY");
                } else if (msg[0].leave_type == "full") {
                  notification_obj.description =
                    "Hi! " +
                    msg[0].emp_name +
                    " just requested a full day leave request on " +
                    moment(msg[0].leave_date).format("DD-MM-YYYY");
                }
              }
              // const get_user = await find_user_by_id(all_hrs[j].user_id);

              all_hrs[j].sidebar_status.leaves = true;
              await all_hrs[j].save();
              let sidebar_status = {
                supports: all_hrs[j].sidebar_status.supports,
                my_supports: all_hrs[j].sidebar_status.my_supports,
                leaves: all_hrs[j].sidebar_status.leaves,
                my_leaves: all_hrs[j].sidebar_status.my_leaves,
                // announcement: all_hrs[j].sidebar_status.announcement,
                // feedback: all_hrs[j].sidebar_status.feedback,
              };
              notification_obj.sidebar_status = sidebar_status;

              io.to(all_hrs[j].socket_id).emit(
                "leave_request_receive",
                notification_obj
              );

              let pending_leaves = 0;
              if (
                all_hrs[j].role.title == "HR" ||
                all_hrs[j].role.title == "Admin" ||
                all_hrs[j].role.title == "All"
              ) {
                let query_obj = { status: "pending" };
                pending_leaves = await leave_request_search_count(query_obj);
              } else if (all_hrs[j].role.title == "Team Lead") {
                let team = await get_team_members_ids(all_hrs[j]._id);
                if (team.length > 0) {
                  let query_obj = {
                    status: "pending",
                    emp_obj_id: { $in: team },
                  };
                  pending_leaves = await leave_request_search_count(query_obj);
                }
              }

              io.to(all_hrs[j].socket_id).emit(
                "leave_request_pending_counts_receive",
                pending_leaves
              );
            }
          }
        }

        // let pending_leaves = 0;
        // const employee = await find_employee_by_id_without_populate(EMP_OBJ_ID);
        // if (employee) {
        //   if (
        //     employee.role.title == "HR" ||
        //     employee.role.title == "Admin" ||
        //     employee.role.title == "All"
        //   ) {
        //     let query_obj = { status: "pending" };
        //     pending_leaves = await leave_request_search_count(query_obj);
        //   } else if (employee.role.title == "Team Lead") {
        //     let team = await get_team_members_ids(employee._id);
        //     if (team.length > 0) {
        //       let query_obj = { status: "pending", emp_obj_id: { $in: team } };
        //       pending_leaves = await leave_request_search_count(query_obj);
        //     }
        //   }
        //   console.log("pending_leaves add: ", pending_leaves);
        //   io.to(employee.socket_id).emit(
        //     "leave_request_pending_counts_receive",
        //     pending_leaves
        //   );
        // }
      }
    });

    socket.on("leave_request_reply_sent", async (msg) => {
      const emp_details = await find_employee_by_id(msg.emp_obj_id);
      if (!emp_details) {
        return "Member not found";
      }

      const all_hrs = await get_all_active_hr();
      for (let x = 0; x < emp_details.leads.length; x++) {
        const get_lead = await find_employee_by_id_without_populate(
          emp_details.leads[x]._id
        );
        all_hrs.push(get_lead);
      }

      console.log(msg);
      // const leave_req_details = await find_leave_request_by_id(msg._id);

      // const get_user = await find_user_by_id(emp_details.user_id._id);
      if (emp_details.previllages.my_leaves.view) {
        let query_obj = {
          leave_request_id: msg._id,
          user_id: emp_details.user_id._id,
        };
        let get_notification_data = await get_notification_by_query_obj(
          query_obj
        );
        if (get_notification_data) {
          let notification_obj = {
            _id: get_notification_data._id,
            user_id: emp_details.user_id._id,
            leave_request_id: msg._id,
            title: "Leave Request",
            description:
              "Hi! " +
              msg.emp_name +
              ". Your leave request just got processed.",
            type: NOTIFICATION_TYPE.leave_request,
            createdAt: get_notification_data.createdAt,
          };
          emp_details.sidebar_status.my_leaves = true;
          await emp_details.save();
          let sidebar_status = {
            supports: emp_details.sidebar_status.supports,
            my_supports: emp_details.sidebar_status.my_supports,
            leaves: emp_details.sidebar_status.leaves,
            my_leaves: emp_details.sidebar_status.my_leaves,
            // feedback: emp_details.sidebar_status.feedback,
            // announcement: emp_details.sidebar_status.announcement,
          };
          notification_obj.sidebar_status = sidebar_status;
          io.to(emp_details.socket_id).emit(
            "leave_request_reply_receive",
            notification_obj
          );
        }

        if (msg.status == "approved") {
          for (let x = 0; x < emp_details.leads.length; x++) {
            let query_obj = {
              leave_request_id: msg._id,
              user_id: emp_details.leads[x].user_id,
            };
            let get_notification = await get_notification_by_query_obj(
              query_obj
            );
            if (get_notification) {
              let notification_obj = {
                _id: get_notification._id,
                user_id: emp_details.leads[x].user_id,
                leave_request_id: msg._id,
                title: "Leave Request",
                description:
                  "Hi! " +
                  msg.emp_name +
                  " will be on leave on " +
                  moment(msg.leave_date).format("DD-MM-YYYY") +
                  ". ",
                type: NOTIFICATION_TYPE.leave_request,
                createdAt: get_notification.createdAt,
              };

              const lead = await find_employee_by_id(emp_details.leads[x]._id);

              io.to(lead.socket_id).emit(
                "leave_request_reply_receive",
                notification_obj
              );
            }
          }
        }

        let pending_leaves = 0;

        for (let j = 0; j < all_hrs.length; j++) {
          if (
            all_hrs[j].role.title == "HR" ||
            all_hrs[j].role.title == "Admin" ||
            all_hrs[j].role.title == "All"
          ) {
            let query_obj = { status: "pending" };
            pending_leaves = await leave_request_search_count(query_obj);
          } else if (all_hrs[j].role.title == "Team Lead") {
            let team = await get_team_members_ids(all_hrs[j]._id);
            if (team.length > 0) {
              let query_obj = {
                status: "pending",
                emp_obj_id: { $in: team },
              };
              pending_leaves = await leave_request_search_count(query_obj);
            }
          }

          io.to(all_hrs[j].socket_id).emit(
            "leave_request_pending_counts_receive",
            pending_leaves
          );
        }

        // let pending_leaves = 0;
        // const employee = await find_employee_by_id_without_populate(EMP_OBJ_ID);
        // if (employee) {
        //   if (
        //     employee.role.title == "HR" ||
        //     employee.role.title == "Admin" ||
        //     employee.role.title == "All"
        //   ) {
        //     let query_obj = { status: "pending" };
        //     pending_leaves = await leave_request_search_count(query_obj);
        //   } else if (employee.role.title == "Team Lead") {
        //     let team = await get_team_members_ids(employee._id);
        //     if (team.length > 0) {
        //       let query_obj = { status: "pending", emp_obj_id: { $in: team } };
        //       pending_leaves = await leave_request_search_count(query_obj);
        //     }
        //   }
        //   console.log("pending_leaves reply: ", pending_leaves);
        //   io.to(employee.socket_id).emit(
        //     "leave_request_pending_counts_receive",
        //     pending_leaves
        //   );
        // }

        // socket.emit(
        //   "leave_request_reply_receive" + emp_details.user_id._id,
        //   notification_obj
        // );
        // io.emit('leave_request_receive');
      }
    });

    //************************************* support ticket event call ******************************************/

    socket.on("support_ticket_sent", async (msg) => {
      const role_details = await find_role_by_id(msg.support_type);
      if (!role_details) {
        return "Invalid Support Type";
      }
      let all_employees_role_based = [];
      if (role_details.title == "All") {
        all_employees_role_based =
          await get_active_employees_role_based_except_employee();
      } else {
        all_employees_role_based = await get_active_employees_role_based(
          role_details._id
        );
      }

      for (let j = 0; j < all_employees_role_based.length; j++) {
        if (all_employees_role_based[j].previllages.support.view) {
          let query_obj = {
            support_ticket_id: msg._id,
            user_id: all_employees_role_based[j].user_id,
          };
          let get_notification_data = await get_notification_by_query_obj(
            query_obj
          );

          if (get_notification_data) {
            let notification_obj = {
              _id: get_notification_data._id,
              user_id: all_employees_role_based[j].user_id,
              support_ticket_id: msg._id,
              title: "Support Ticket",
              description:
                "Hi! " + msg.emp_name + " just added a support ticket",
              createdAt: get_notification_data.createdAt,
              type: NOTIFICATION_TYPE.support_ticket,
            };
            // socket.emit("support_ticket_receive" + get_user._id, notification_obj);
            all_employees_role_based[j].sidebar_status.supports = true;
            await all_employees_role_based[j].save();
            let sidebar_status = {
              supports: all_employees_role_based[j].sidebar_status.supports,
              my_supports:
                all_employees_role_based[j].sidebar_status.my_supports,
              leaves: all_employees_role_based[j].sidebar_status.leaves,
              my_leaves: all_employees_role_based[j].sidebar_status.my_leaves,
              // feedback: all_employees_role_based[j].sidebar_status.feedback,
              // announcement: all_employees_role_based[j].sidebar_status.announcement,
            };
            notification_obj.sidebar_status = sidebar_status;

            io.to(String(all_employees_role_based[j].socket_id)).emit(
              "support_ticket_receive",
              notification_obj
            );
          }
        }
      }

      // io.emit('leave_request_receive');
    });

    socket.on("support_ticket_status_change", async (msg) => {
      const emp_details = await find_employee_by_id(msg.emp_obj_id);
      if (!emp_details) {
        return "Member not found";
      }

      // const get_user = await find_user_by_id(emp_details.user_id._id);
      if (emp_details.previllages.my_support.view) {
        let query_obj = {
          support_ticket_id: msg._id,
          user_id: emp_details.user_id._id,
        };
        let get_notification_data = await get_notification_by_query_obj(
          query_obj
        );
        if (get_notification_data) {
          let notification_obj = {
            _id: get_notification_data._id,
            user_id: emp_details.user_id._id,
            support_ticket_id: msg._id,
            title: "Support Ticket",
            type: NOTIFICATION_TYPE.support_ticket,
            createdAt: get_notification_data.createdAt,
          };
          if (msg.status == 0) {
            notification_obj.description =
              "Hi! " + msg.emp_name + ". Your support ticket is open";
          } else if (msg.status == 1) {
            notification_obj.description =
              "Hi! " + msg.emp_name + ". Your support ticket is closed";
          }
          // .broadcast
          // .to(emp_details.user_id._id)
          // socket.emit(
          //   "support_ticket_status_change_receive" + emp_details.user_id._id,
          //   notification_obj
          // );
          emp_details.sidebar_status.my_supports = true;
          await emp_details.save();
          let sidebar_status = {
            supports: emp_details.sidebar_status.supports,
            my_supports: emp_details.sidebar_status.my_supports,
            leaves: emp_details.sidebar_status.leaves,
            my_leaves: emp_details.sidebar_status.my_leaves,
            // feedback: emp_details.sidebar_status.feedback,
            // announcement: emp_details.sidebar_status.announcement,
          };
          notification_obj.sidebar_status = sidebar_status;
          io.to(emp_details.socket_id).emit(
            "support_ticket_status_change_receive",
            notification_obj
          );
        }
      }

      // io.emit('leave_request_receive');
    });

    //************************************* Message in Support Ticket ***********************************/
    socket.on("support_ticket_message_sent", async (msg) => {
      const role_details = await find_role_by_id(msg.support_type._id);
      if (!role_details) {
        return "This support no longer exists";
      }
      const emp_details = await find_employee_by_id_without_populate(
        msg.emp_obj_id
      );
      if (!emp_details) {
        return "Support ticket sender no longer exists";
      }
      let send_to = [];
      if (
        msg.messages[msg.messages.length - 1].user_id == emp_details.user_id
      ) {
        if (role_details.title == "All") {
          send_to = await get_active_employees_role_based_except_employee();
        } else {
          send_to = await get_active_employees_role_based(role_details._id);
        }
      } else {
        send_to.push(emp_details);
      }
      let sender_details = await find_employee_by_user_id_without_populate(
        msg.messages[msg.messages.length - 1].user_id
      );

      let message_obj = {
        _id: msg.messages[msg.messages.length - 1]._id,
        text: msg.messages[msg.messages.length - 1].text,
        images: msg.messages[msg.messages.length - 1].images,
        user_id: msg.messages[msg.messages.length - 1].user_id,
        date_time: msg.messages[msg.messages.length - 1].date_time,
      };
      message_obj.emp_name = "Unknown";
      message_obj.emp_image = "";
      if (sender_details) {
        message_obj.emp_name = sender_details.full_name;
        if (!_.isEmpty(sender_details.profile_pic)) {
          message_obj.emp_image = sender_details.profile_pic.large;
        }
      }

      let index = -1;
      index = _.findIndex(send_to, { user_id: sender_details.user_id });
      if (index >= 0) {
        send_to.splice(index, 1);
      }
      send_to.push(sender_details);

      let support_ticket_obj = { _id: msg._id };
      for (let j = 0; j < send_to.length; j++) {
        if (send_to[j].user_id != sender_details.user_id) {
          let reciever_obj = {
            message_id: msg.messages[msg.messages.length - 1]._id,
            receiver_id: send_to[j].user_id,
          };
          await add_message_to_unread(msg._id, reciever_obj);
        }

        io.to(send_to[j].socket_id).emit(
          "support_ticket_message_sent_receive",
          message_obj
        );
        let support_ticket = await find_support_ticket_by_id(msg._id);
        support_ticket_obj.message_receivers = support_ticket.message_receivers;

        // if (send_to[j]._id == msg.emp_obj_id) {
        //   send_to[j].sidebar_status.my_supports = true;
        //   await send_to[j].save();
        // } else {
        //   send_to[j].sidebar_status.supports = true;
        //   await send_to[j].save();
        // }

        if (send_to[j]._id != msg.emp_obj_id) {
          send_to[j].sidebar_status.supports = true;
          await send_to[j].save();
        }

        let sidebar_status = {
          supports: send_to[j].sidebar_status.supports,
          my_supports: send_to[j].sidebar_status.my_supports,
          leaves: send_to[j].sidebar_status.leaves,
          my_leaves: send_to[j].sidebar_status.my_leaves,
          // feedback: send_to[j].sidebar_status.feedback,
          // announcement: send_to[j].sidebar_status.announcement,
        };
        support_ticket_obj.sidebar_status = sidebar_status;
        io.to(send_to[j].socket_id).emit(
          "support_ticket_message_unread_count",
          support_ticket_obj
        );
      }

      // io.emit('leave_request_receive');
    });

    socket.on("support_ticket_message_delete", async (msg) => {
      const role_details = await find_role_by_id(msg.support_type._id);
      if (!role_details) {
        return "This support no longer exists";
      }
      const emp_details = await find_employee_by_id_without_populate(
        msg.emp_obj_id
      );
      if (!emp_details) {
        return "Support ticket sender no longer exists";
      }
      let send_to = [];
      if (msg.message.user_id == emp_details.user_id) {
        if (role_details.title == "All") {
          send_to = await get_active_employees_role_based_except_employee();
        } else {
          send_to = await get_active_employees_role_based(role_details._id);
        }
      } else {
        send_to.push(emp_details);
      }
      let sender_details = await find_employee_by_user_id(msg.message.user_id);
      let message_obj = {
        _id: msg.message._id,
        user_id: msg.message.user_id,
      };

      send_to.push(sender_details);
      for (let j = 0; j < send_to.length; j++) {
        io.to(send_to[j].socket_id).emit(
          "support_ticket_message_delete_receive",
          message_obj
        );
      }

      // io.emit('leave_request_receive');
    });

    //************************************* Announcement ******************************************/

    socket.on("announcement_sent", async (msg) => {
      const role_details = await find_role_by_id(msg.role._id);
      if (!role_details) {
        return "Invalid Announcement Type";
      }

      let all_employees_role_based = [];
      if (role_details.title == "All") {
        all_employees_role_based = await get_all_active_employees();
      } else {
        all_employees_role_based = await get_active_employees_role_based(
          role_details._id
        );
      }

      for (let j = 0; j < all_employees_role_based.length; j++) {
        if (all_employees_role_based[j].previllages.announcement.view) {
          let query_obj = {
            announcement_id: msg._id,
            user_id: all_employees_role_based[j].user_id,
          };
          let get_notification_data = await get_notification_by_query_obj(
            query_obj
          );
          if (get_notification_data) {
            let notification_obj = {
              _id: get_notification_data._id,
              user_id: all_employees_role_based[j].user_id,
              announcement_id: msg._id,
              title: "Announcement",
              description: "Hi! An announcement is just made",
              createdAt: get_notification_data.createdAt,
              type: NOTIFICATION_TYPE.announcement,
            };
            // socket.emit("announcement_receive" + get_user._id, notification_obj);
            all_employees_role_based[j].sidebar_status.announcement = true;
            await all_employees_role_based[j].save();
            let sidebar_status = {
              supports: all_employees_role_based[j].sidebar_status.supports,
              my_supports:
                all_employees_role_based[j].sidebar_status.my_supports,
              leaves: all_employees_role_based[j].sidebar_status.leaves,
              my_leaves: all_employees_role_based[j].sidebar_status.my_leaves,
              announcement:
                all_employees_role_based[j].sidebar_status.announcement,
              // feedback: all_employees_role_based[j].sidebar_status.feedback,
            };
            notification_obj.sidebar_status = sidebar_status;

            io.to(String(all_employees_role_based[j].socket_id)).emit(
              "announcement_receive",
              notification_obj
            );
          }
        }
      }

      // io.emit('leave_request_receive');
    });

    //************************************* Feedback ******************************************/

    socket.on("feedback_sent", async (msg) => {
      console.log("msg: ", msg);
      if (!_.isEmpty(msg)) {
        let get_sender = undefined;
        // let get_receiver = undefined;
        if (msg[0].send_to._id != null) {
          get_sender = await find_employee_by_id(msg[0].send_to._id);
        }
        // else {
        //   // get_receiver = await find_employee_by_id(msg[0].send_for._id);
        //   get_sender = await find_employee_by_id(msg[0].send_for._id);
        // }

        for (let j = 0; j < msg.length; j++) {
          if (get_sender != undefined && get_sender != null) {
            if (get_sender.previllages.feedback.view) {
              let query_obj = {
                feedback_id: msg[j]._id,
                user_id: get_sender.user_id._id,
              };
              let notification = await get_notification_by_query_obj(query_obj);
              if (notification) {
                let notification_obj = {
                  _id: notification._id,
                  user_id: get_sender.user_id._id,
                  feedback_id: msg[j]._id,
                  title: "Feedback",
                  description: "Hi! You received a new feedback to complete",
                  type: NOTIFICATION_TYPE.feedback,
                  createdAt: notification.createdAt,
                };

                // get_sender.sidebar_status.feedback = true;
                // await get_sender.save();
                // let sidebar_status = {
                //   supports: get_sender.sidebar_status.supports,
                //   my_supports: get_sender.sidebar_status.my_supports,
                //   leaves: get_sender.sidebar_status.leaves,
                //   my_leaves: get_sender.sidebar_status.my_leaves,
                //   announcement: get_sender.sidebar_status.announcement,
                //   feedback: get_sender.sidebar_status.feedback,
                // };
                // notification_obj.sidebar_status = sidebar_status;

                io.to(get_sender.socket_id).emit(
                  "feedback_receive",
                  notification_obj
                );
              }
            }
          }
          // else {
          //   if (get_receiver != undefined && get_receiver != null) {
          //     if (get_receiver.previllages.feedback.view) {
          //       let query_obj = {
          //         feedback_id: msg[j]._id,
          //         user_id: get_receiver.user_id._id,
          //       };
          //       let notification = await get_notification_by_query_obj(
          //         query_obj
          //       );
          //       if (notification) {
          //         let notification_obj = {
          //           _id: notification._id,
          //           user_id: get_receiver.user_id._id,
          //           feedback_id: msg[j]._id,
          //           title: "Feedback",
          //           description: "Hi! You received a new feedback to complete",
          //           type: NOTIFICATION_TYPE.feedback,
          //           createdAt: notification.createdAt,
          //         };

          //         get_receiver.sidebar_status.feedback = true;
          //         await get_receiver.save();
          //         let sidebar_status = {
          //           supports: get_receiver.sidebar_status.supports,
          //           my_supports: get_receiver.sidebar_status.my_supports,
          //           leaves: get_receiver.sidebar_status.leaves,
          //           my_leaves: get_receiver.sidebar_status.my_leaves,
          //           announcement: get_receiver.sidebar_status.announcement,
          //           feedback: get_receiver.sidebar_status.feedback,
          //         };
          //         notification_obj.sidebar_status = sidebar_status;

          //         io.to(get_receiver.socket_id).emit(
          //           "feedback_receive",
          //           notification_obj
          //         );
          //       }
          //     }
          //   }
          // }
        }
      }
    });

    //************************************* Lunch ******************************************/

    socket.on("lunch_added_sent", async (msg) => {
      const emp_details = await find_employee_by_id(msg.employee._id);
      if (!emp_details) {
        return "Member not found";
      }

      if (emp_details.previllages.lunch.view) {
        let query_obj = {
          lunch_id: msg._id,
          user_id: emp_details.user_id._id,
        };
        let get_notification = await get_notification_by_query_obj(query_obj);
        if (get_notification) {
          let notification_obj = {
            _id: get_notification._id,
            user_id: emp_details.user_id._id,
            lunch_id: msg._id,
            title: "Lunch Added",
            description:
              "Hi " +
              emp_details.full_name +
              "! Your lunch has been added for " +
              moment(msg.month, "M").format("MMMM") +
              " " +
              msg.year,
            createdAt: get_notification.createdAt,
            type: NOTIFICATION_TYPE.lunch,
          };
          // socket.emit("lunch_receive" + get_user._id, notification_obj);
          // emp_details.sidebar_status.lunch = true;
          // await emp_details.save();
          // let sidebar_status = {
          //   supports: emp_details.sidebar_status.supports,
          //   my_supports: emp_details.sidebar_status.my_supports,
          //   leaves: emp_details.sidebar_status.leaves,
          //   my_leaves: emp_details.sidebar_status.my_leaves,
          //   lunch: emp_details.sidebar_status.lunch,
          //   // feedback: emp_details.sidebar_status.feedback,
          // };
          // notification_obj.sidebar_status = sidebar_status;

          io.to(String(emp_details.socket_id)).emit(
            "lunch_added_receive",
            notification_obj
          );
        }
      }

      // io.emit('leave_request_receive');
    });

    socket.on("avail_lunch_sent", async (msg) => {
      // const emp_details = await find_employee_by_id(msg.employee._id);
      // if (!emp_details) {
      //   return "Member not found";
      // }
      console.log("msg: ", msg);
      const get_hrs = await get_all_active_hr();
      if (get_hrs.length > 0) {
        for (let x = 0; x < get_hrs.length; x++) {
          if (get_hrs[x].previllages.lunch.view) {
            console.log("get_hrs[x]: ", get_hrs[x]);
            if (msg.want_lunch) {
              let query_obj = {
                emp_obj_id: msg._id,
                user_id: get_hrs[x].user_id,
                title: "Lunch Continue",
              };
              let get_notification = await get_notification_by_query_obj(
                query_obj
              );
              if (get_notification) {
                let notification_obj = {
                  _id: get_notification._id,
                  user_id: get_hrs[x].user_id,
                  emp_obj_id: msg._id,
                  title: "Lunch Continue",
                  description:
                    "Hi! " + msg.full_name + " wants to avail lunch facility.",
                  createdAt: get_notification.createdAt,
                  type: NOTIFICATION_TYPE.lunch,
                };

                io.to(String(get_hrs[x].socket_id)).emit(
                  "avail_lunch_receive",
                  notification_obj
                );
              }
            } else if (msg.want_lunch == false) {
              let query_obj = {
                emp_obj_id: msg._id,
                user_id: get_hrs[x].user_id,
                title: "Lunch Discontinued",
              };
              let get_notification = await get_notification_by_query_obj(
                query_obj
              );
              if (get_notification) {
                let notification_obj = {
                  _id: get_notification._id,
                  user_id: get_hrs[x].user_id,
                  emp_obj_id: msg._id,
                  title: "Lunch Discontinued",
                  description:
                    "Hi! " + msg.full_name + " does not want to avail lunch.",
                  createdAt: get_notification.createdAt,
                  type: NOTIFICATION_TYPE.lunch,
                };

                io.to(String(get_hrs[x].socket_id)).emit(
                  "avail_lunch_receive",
                  notification_obj
                );
              }
            }
          }
        }
      }

      // io.emit('leave_request_receive');
    });

    //************************************* leave request event call ******************************************/

    socket.on("loan_request_sent", async (msg) => {
      if (!_.isEmpty(msg)) {
        // console.log("msg: ", msg);
        // const alls_hrs = await get_active_alls_hrs();
        const alls_hrs = await get_active_alls_hrs_and_admin();

        // const emp_details = await find_employee_by_id(msg[0].emp_obj_id);

        for (let j = 0; j < alls_hrs.length; j++) {
          if (alls_hrs[j].previllages.loans.view) {
            let query_obj = {
              loan_request_id: msg._id,
              user_id: alls_hrs[j].user_id,
            };
            let get_notification_data = await get_notification_by_query_obj(
              query_obj
            );
            if (get_notification_data) {
              let notification_obj = {
                _id: get_notification_data._id,
                user_id: alls_hrs[j].user_id,
                loan_request_id: msg._id,
                title: "Loan Request",
                description:
                  "Hi! " + msg.emp_name + " just requested for a loan",
                type: NOTIFICATION_TYPE.loan_request,
                createdAt: get_notification_data.createdAt,
              };

              // const get_user = await find_user_by_id(alls_hrs[j].user_id);
              alls_hrs[j].sidebar_status.loans = true;
              await alls_hrs[j].save();
              let sidebar_status = {
                supports: alls_hrs[j].sidebar_status.supports,
                my_supports: alls_hrs[j].sidebar_status.my_supports,
                leaves: alls_hrs[j].sidebar_status.leaves,
                my_leaves: alls_hrs[j].sidebar_status.my_leaves,
                loans: alls_hrs[j].sidebar_status.loans,
                my_loans: alls_hrs[j].sidebar_status.my_loans,
                // announcement: alls_hrs[j].sidebar_status.announcement,
                // feedback: alls_hrs[j].sidebar_status.feedback,
              };
              notification_obj.sidebar_status = sidebar_status;

              io.to(alls_hrs[j].socket_id).emit(
                "loan_request_receive",
                notification_obj
              );
            }
          }
        }
      }
    });

    socket.on("loan_request_reply_sent", async (msg) => {
      const emp_details = await find_employee_by_id(msg.emp_obj_id);
      if (!emp_details) {
        return "Member not found";
      }
      // console.log("msg: ", msg);
      // const leave_req_details = await find_loan_request_by_id(msg._id);

      // const get_user = await find_user_by_id(emp_details.user_id._id);
      if (emp_details.previllages.my_loans.view) {
        let query_obj = {
          loan_request_id: msg._id,
          user_id: emp_details.user_id._id,
        };
        let get_notification_data = await get_notification_by_query_obj(
          query_obj
        );
        if (get_notification_data) {
          let notification_obj = {
            _id: get_notification_data._id,
            user_id: emp_details.user_id._id,
            loan_request_id: msg._id,
            title: "Loan Request",
            description:
              "Hi! " + msg.emp_name + ". Your loan request just got processed.",
            type: NOTIFICATION_TYPE.loan_request,
            createdAt: get_notification_data.createdAt,
          };
          emp_details.sidebar_status.my_loans = true;
          await emp_details.save();
          let sidebar_status = {
            supports: emp_details.sidebar_status.supports,
            my_supports: emp_details.sidebar_status.my_supports,
            leaves: emp_details.sidebar_status.leaves,
            my_leaves: emp_details.sidebar_status.my_leaves,
            loans: emp_details.sidebar_status.loans,
            my_loans: emp_details.sidebar_status.my_loans,
            // feedback: emp_details.sidebar_status.feedback,
            // announcement: emp_details.sidebar_status.announcement,
          };
          notification_obj.sidebar_status = sidebar_status;
          io.to(emp_details.socket_id).emit(
            "loan_request_reply_receive",
            notification_obj
          );
        }

        // socket.emit(
        //   "loan_request_reply_receive" + emp_details.user_id._id,
        //   notification_obj
        // );
        // io.emit('loan_request_receive');
      }
    });

    socket.on("off_line", async (socket) => {
      let userProfile = await User.findOne({ socket_id: socket.id });
      if (userProfile) {
        userProfile.is_online = false;
        userProfile.socket_id = "";
        await userProfile.save();
      }
    });

    socket.on("disconnect", async (socket) => {
      let userProfile = await User.findOne({ socket_id: socket.id });
      if (userProfile) {
        userProfile.is_online = false;
        userProfile.socket_id = "";
        await userProfile.save();
      }
    });
  });
};

module.exports = { create_socket };
