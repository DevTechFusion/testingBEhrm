const { find_user, find_user_by_id } = require("../DAL/user");
const {
  add_leave_request,
  find_leave_request_by_id,
  pagination_leave_request,
  all_leave_requests_active,
  all_leave_requests_active_count,
  delete_leave_request_by_id,
  get_leave_request_search,
  leave_request_search_count,
  find_leave_request_by_emp_and_date,
  find_leave_requests_for_employee,
  search_leave_requests_by_query_obj,
  half_leave_requests_yearly,
  get_leave_stats,
  find_leaves_from_leave_request,
} = require("../DAL/leave_request");
const {
  find_employee_by_id,
  find_employee_by_user_id,
  get_all_active_hr,
  get_team_members_ids,
} = require("../DAL/employee");
const {
  get_employee_for_leave_report,
  get_employee_for_leave_report_count,
} = require("../DAL/employee-v1");

const {
  get_employee_leaves_for_dashboard_count,
} = require("../DAL/attendance");

const {
  add_notification,
  delete_leave_request_notifications,
} = require("../DAL/notification");
const { NOTIFY_BY_EMAIL_FROM_SES, SEND_EMAIL } = require("../utils/utils");
const { NOTIFICATION_TYPE } = require("../utils/constants");
const moment = require("moment");

const _addLeaveRequest = async (user_id, body, resp) => {
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  const all_hrs = await get_all_active_hr();

  let leave_dates_arr = [];
  let final_leaves_arr = [];
  let leave_type = body.leave_type;
  if (body.leave_date_to && body.leave_date_to != "") {
    let start_date = moment(body.leave_date_from, "DD-MM-YYYY").utc(true);
    let end_date = moment(body.leave_date_to, "DD-MM-YYYY").utc(true);
    while (start_date.isSameOrBefore(end_date)) {
      let week_day = moment(start_date).isoWeekday();
      if (leave_type == "range") {
        if (week_day != 6 && week_day != 7) {
          leave_dates_arr.push(start_date.format());
        }
      } else {
        leave_dates_arr.push(start_date.format());
      }
      start_date.add(+1, "days");
    }
  }

  if (leave_dates_arr.length <= 0) {
    resp.error = true;
    resp.error_message = "Check the date for weekend";
    return resp;
  }
  for (let j = 0; j < leave_dates_arr.length; j++) {
    const get_emp_leave_request = await find_leave_request_by_emp_and_date(
      emp_details._id,
      leave_dates_arr[j]
    );
    if (get_emp_leave_request) {
      resp.error = true;
      resp.error_message =
        "You have already added leave request for this date : " +
        moment(leave_dates_arr[j]).format("DD-MM-YYYY") +
        ". Exclude this date and try again";
      return resp;
    }
  }
  if (leave_type == "range") {
    leave_type = "full";
  }
  for (let i = 0; i < leave_dates_arr.length; i++) {
    let leave_request_obj = {
      emp_obj_id: emp_details._id,
      emp_name: emp_details.full_name,
      leave_type: leave_type,
      leave_reason: body.leave_reason,
      leave_date: leave_dates_arr[i],
      action_by: "employee",
    };

    const final_leave_request = await add_leave_request(leave_request_obj);
    final_leaves_arr.push(final_leave_request);
    for (let j = 0; j < all_hrs.length; j++) {
      if (all_hrs[j].previllages.leaves.view) {
        let notification_obj = {
          user_id: all_hrs[j].user_id,
          leave_request_id: final_leave_request._id,
          title: "Leave Request",
          description:
            "Hi! " + emp_details.full_name + " just requested a leave. ",
          type: NOTIFICATION_TYPE.leave_request,
        };
        await add_notification(notification_obj);
        NOTIFY_BY_EMAIL_FROM_SES(
          all_hrs[j].webmail_email,
          "Leave Request",
          notification_obj.description + leave_request_obj.leave_reason
        );
      }
    }
    for (let x = 0; x < emp_details.leads.length; x++) {
      let notification_obj_for_leads = {
        user_id: emp_details.leads[x].user_id,
        leave_request_id: final_leave_request._id,
        title: "Leave Request",
        description:
          "Hi! " +
          final_leave_request.emp_name +
          " requested a leave for " +
          moment(final_leave_request.leave_date).format("DD-MM-YYYY") +
          ". ",
        type: NOTIFICATION_TYPE.leave_request,
      };
      await add_notification(notification_obj_for_leads);

      await NOTIFY_BY_EMAIL_FROM_SES(
        emp_details.leads[x].webmail,
        "Leave Request",
        notification_obj_for_leads.description + leave_request_obj.leave_reason
      );
    }
  }

  resp.data = final_leaves_arr;
  return resp;
};
const addLeaveRequest = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addLeaveRequest(user_id, body, resp);
  return resp;
};

const _editLeaveRequest = async (user_id, leave_request_id, body, resp) => {
  const leave_request_detail = await find_leave_request_by_id(leave_request_id);
  if (!leave_request_detail) {
    resp.error = true;
    resp.error_message = "Invalid Leave Request ID";
    return resp;
  }
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  if (leave_request_detail.status != "pending") {
    resp.error = true;
    resp.error_message = "This leave request is already processed";
    return resp;
  }

  const body_leave_date = moment(body.leave_date_from, "DD-MM-YYYY")
    .utc(true)
    .format();

  if (
    body_leave_date == "Invalid date" ||
    body_leave_date == null ||
    body_leave_date == undefined
  ) {
    resp.error = true;
    resp.error_message =
      "This date : " +
      body.leave_date_from +
      " is not valid. Enter a valid date";
    return resp;
  }

  const date_1 = moment(body.leave_date_from, "DD-MM-YYYY").format(
    "YYYY-MM-DD"
  );
  const date_2 = moment(leave_request_detail.leave_date).format("YYYY-MM-DD");
  const check_dates = moment(date_1).isSame(date_2);

  if (!check_dates) {
    const get_emp_leave_request = await find_leave_request_by_emp_and_date(
      emp_details._id,
      body_leave_date
    );

    if (get_emp_leave_request) {
      resp.error = true;
      resp.error_message =
        "You have already added leave request for this date : " +
        moment(body_leave_date).format("DD-MM-YYYY") +
        ". Exclude this date and try again";
      return resp;
    }
  }

  leave_request_detail.leave_type = body.leave_type;
  leave_request_detail.leave_reason = body.leave_reason;
  leave_request_detail.leave_date = body_leave_date;

  await leave_request_detail.save();
  resp.data = leave_request_detail;
  return resp;
};
const editLeaveRequest = async (user_id, leave_request_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editLeaveRequest(user_id, leave_request_id, body, resp);
  return resp;
};

const _detailLeaveRequest = async (leave_request_id, resp) => {
  const leave_request = await find_leave_request_by_id(leave_request_id);
  if (!leave_request) {
    resp.error = true;
    resp.error_message = "Invalid Leave Request ID!";
    return resp;
  }
  resp.data = leave_request;
  return resp;
};

const detailLeaveRequest = async (leave_request_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailLeaveRequest(leave_request_id, resp);
  return resp;
};

const _deleteLeaveRequest = async (leave_request_id, resp) => {
  const get_leave_request = await find_leave_request_by_id(leave_request_id);
  if (!get_leave_request) {
    resp.error = true;
    resp.error_message = "Invalid Leave Request ID!";
    return resp;
  }
  if (get_leave_request.status != "pending") {
    resp.error = true;
    resp.error_message = "This leave request is already processed";
    return resp;
  }
  const deleted_leave_request = await delete_leave_request_by_id(
    leave_request_id
  );
  if (!deleted_leave_request) {
    resp.error = true;
    resp.error_message = "Invalid Leave Request ID!";
    return resp;
  } else {
    await delete_leave_request_notifications(deleted_leave_request._id);
  }
  return resp;
};

const deleteLeaveRequest = async (leave_request_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteLeaveRequest(leave_request_id, resp);
  return resp;
};

const _searchLeaveRequest = async (
  user_id,
  body,
  Limit,
  page,
  search,
  resp
) => {
  console.log("body: ", body);

  const emp_details = await find_employee_by_user_id(user_id);
  // if (!emp_details) {
  //   resp.error = true;
  //   resp.error_message = "Member not found";
  //   return resp;
  // }
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let full_day_leaves_yearly = 0;
  let half_day_leaves_yearly = 0;
  let total_pages = 0;
  let leave_request = [];

  if (emp_details) {
    let query_obj = { emp_obj_id: emp_details._id };
    if (body.status && body.status != "") {
      query_obj.status = body.status;
    }
    if (
      body.date_from &&
      body.date_to &&
      body.date_from != "" &&
      body.date_to != "" &&
      body.date_from != null &&
      body.date_to != null &&
      body.date_from != undefined &&
      body.date_to != undefined
    ) {
      query_obj.leave_date = {
        $gte: moment(body.date_from, "DD-MM-YYYY").utc(true),
        $lte: moment(body.date_to, "DD-MM-YYYY").utc(true),
      };
    }
    // else if (search && search != "") {
    //   query_obj.leave_date = moment(search, "DD-MM-YYYY").utc(true);
    //   // query_obj.leave_date = moment(search, "DD-MM-YYYY").set("hour", 5);
    // }

    leave_request = await get_leave_request_search(query_obj, limit, skip);
    total_pages = await leave_request_search_count(query_obj);

    let query_obj_search = { emp_obj_id: emp_details._id };
    const date = new Date();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    let year_from = year;
    let year_to = year;
    let date_from = "01-07";
    let date_to = "01-07";

    if (month < 7) {
      year_from = year - 1;
      date_from += "-" + year_from;
      date_to += "-" + year_to;
    } else {
      year_to += 1;
      date_from += "-" + year_from;
      date_to += "-" + year_to;
    }

    query_obj_search.leave_date = {
      $gte: moment(date_from, "DD-MM-YYYY").utc(true),
      $lt: moment(date_to, "DD-MM-YYYY").utc(true),
    };

    const leave_reqs_search = await search_leave_requests_by_query_obj(
      query_obj_search
    );

    for (let i = 0; i < leave_reqs_search.length; i++) {
      if (leave_reqs_search[i].status == "approved") {
        if (leave_reqs_search[i].leave_type == "full") {
          full_day_leaves_yearly += 1;
        } else {
          half_day_leaves_yearly += 1;
        }
      }
    }
  }

  resp.data = {
    full_day_leaves_yearly,
    half_day_leaves_yearly,
    leave_request,
    total_pages,
    load_more_url: `/leave_request/get_leave_request?page=${page}&limit=${limit}`,
  };

  console.log("resp.data: ", resp.data);

  return resp;
};

const searchLeaveRequest = async (user_id, body, limit, page, search) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchLeaveRequest(user_id, body, limit, page, search, resp);
  return resp;
};

const _processLeaveRequest = async (leave_req_id, user_id, body, resp) => {
  const leave_request_detail = await find_leave_request_by_id(leave_req_id);
  if (!leave_request_detail) {
    resp.error = true;
    resp.error_message = "Invalid Leave Request ID";
    return resp;
  }

  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  // if (emp_details._id == leave_request_detail.emp_obj_id) {
  //   resp.error = true;
  //   resp.error_message = "You cannot process your own leave request";
  //   return resp;
  // }

  if (leave_request_detail.status != "pending") {
    resp.error = true;
    resp.error_message = "This leave request is already processed";
    return resp;
  }
  const emp_details_to = await find_employee_by_id(
    leave_request_detail.emp_obj_id
  );
  if (!emp_details_to) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  leave_request_detail.status = body.status;
  if (body.status == "rejected") {
    leave_request_detail.rejection_reason = body.rejection_reason;

    if (emp_details_to.previllages.my_leaves.view) {
      let notification_obj = {
        user_id: emp_details_to.user_id._id,
        leave_request_id: leave_request_detail._id,
        title: "Leave Request",
        description:
          "Hi! " +
          leave_request_detail.emp_name +
          ". Your leave request was rejected",
        type: NOTIFICATION_TYPE.leave_request,
      };
      await add_notification(notification_obj);
    }
  } else if (body.status == "approved") {
    if (emp_details_to.previllages.my_leaves.view) {
      let notification_obj = {
        user_id: emp_details_to.user_id._id,
        leave_request_id: leave_request_detail._id,
        title: "Leave Request",
        description:
          "Hi! " +
          leave_request_detail.emp_name +
          ". Your leave request got approved",
        type: NOTIFICATION_TYPE.leave_request,
      };
      await add_notification(notification_obj);
      // console.log("emp_details_to.leads: ", emp_details_to.leads);
      for (let x = 0; x < emp_details_to.leads.length; x++) {
        let notification_obj_for_leads = {
          user_id: emp_details_to.leads[x].user_id,
          leave_request_id: leave_request_detail._id,
          title: "Leave Request",
          description:
            "Hi! " +
            leave_request_detail.emp_name +
            " will be on leave on " +
            moment(leave_request_detail.leave_date).format("DD-MM-YYYY") +
            ". ",
          type: NOTIFICATION_TYPE.leave_request,
        };
        await add_notification(notification_obj_for_leads);

        await NOTIFY_BY_EMAIL_FROM_SES(
          emp_details_to.leads[x].webmail,
          "Leave Request",
          notification_obj_for_leads.description +
            leave_request_detail.leave_reason
        );
      }
    }
  }
  await leave_request_detail.save();

  resp.data = leave_request_detail;
  return resp;
};
const processLeaveRequest = async (leave_req_id, user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _processLeaveRequest(leave_req_id, user_id, body, resp);
  return resp;
};

const _addLeaveRequestAdmin = async (user_id, body, resp) => {
  const admin_details = await find_user_by_id(user_id);
  if (!admin_details) {
    resp.error = true;
    resp.error_message = "Admin not found";
    return resp;
  }

  // if (admin_details.type != 0) {
  //   resp.error = true;
  //   resp.error_message = "You are not authorized";
  //   return resp;
  // }

  const emp_details = await find_employee_by_id(body.emp_obj_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  const all_hrs = await get_all_active_hr();

  let leave_dates_arr = [];
  let final_leaves_arr = [];
  let leave_type = body.leave_type;
  if (body.leave_date_to && body.leave_date_to != "") {
    let start_date = moment(body.leave_date_from, "DD-MM-YYYY").utc(true);
    let end_date = moment(body.leave_date_to, "DD-MM-YYYY").utc(true);
    while (start_date.isSameOrBefore(end_date)) {
      let week_day = moment(start_date).isoWeekday();
      if (leave_type == "range") {
        if (week_day != 6 && week_day != 7) {
          leave_dates_arr.push(start_date.format());
        }
      } else {
        leave_dates_arr.push(start_date.format());
      }
      start_date.add(+1, "days");
    }
  }
  if (leave_dates_arr.length <= 0) {
    resp.error = true;
    resp.error_message = "Check the date for weekend";
    return resp;
  }
  for (let j = 0; j < leave_dates_arr.length; j++) {
    const get_emp_leave_request = await find_leave_request_by_emp_and_date(
      emp_details._id,
      leave_dates_arr[j]
    );
    if (get_emp_leave_request) {
      resp.error = true;
      resp.error_message =
        "You have already added leave request for this date : " +
        moment(leave_dates_arr[j]).format("DD-MM-YYYY") +
        ". Exclude this date and try again";
      return resp;
    }
  }
  if (leave_type == "range") {
    leave_type = "full";
  }
  for (let i = 0; i < leave_dates_arr.length; i++) {
    let leave_request_obj = {
      emp_obj_id: emp_details._id,
      emp_name: emp_details.full_name,
      leave_type: leave_type,
      leave_reason: body.leave_reason,
      leave_date: leave_dates_arr[i],
      action_by: "admin",
    };

    const final_leave_request = await add_leave_request(leave_request_obj);
    final_leaves_arr.push(final_leave_request);
    for (let j = 0; j < all_hrs.length; j++) {
      if (all_hrs[j].previllages.leaves.view) {
        let notification_obj = {
          user_id: all_hrs[j].user_id,
          leave_request_id: final_leave_request._id,
          title: "Leave Request",
          description:
            "Hi! " + emp_details.full_name + " just requested a leave",
          type: NOTIFICATION_TYPE.leave_request,
        };
        await add_notification(notification_obj);
      }
    }
  }

  resp.data = final_leaves_arr;
  return resp;
};
const addLeaveRequestAdmin = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addLeaveRequestAdmin(user_id, body, resp);
  return resp;
};

const _editLeaveRequestAdmin = async (
  user_id,
  leave_request_id,
  body,
  resp
) => {
  const admin_details = await find_user_by_id(user_id);
  if (!admin_details) {
    resp.error = true;
    resp.error_message = "Admin not found";
    return resp;
  }

  // if (admin_details.type != 0) {
  //   resp.error = true;
  //   resp.error_message = "You are not authorized";
  //   return resp;
  // }
  const leave_request_detail = await find_leave_request_by_id(leave_request_id);
  if (!leave_request_detail) {
    resp.error = true;
    resp.error_message = "Invalid Leave Request ID";
    return resp;
  }
  const emp_details = await find_employee_by_id(body.emp_obj_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  // if (leave_request_detail.status != "pending") {
  //   resp.error = true;
  //   resp.error_message = "This leave request is already processed";
  //   return resp;
  // }

  const body_leave_date = moment(body.leave_date_from, "DD-MM-YYYY")
    .utc(true)
    .format();

  if (
    body_leave_date == "Invalid date" ||
    body_leave_date == null ||
    body_leave_date == undefined
  ) {
    resp.error = true;
    resp.error_message =
      "This date : " +
      body.leave_date_from +
      " is not valid. Enter a valid date";
    return resp;
  }

  const date_1 = moment(body.leave_date_from, "DD-MM-YYYY").format(
    "YYYY-MM-DD"
  );
  const date_2 = moment(leave_request_detail.leave_date).format("YYYY-MM-DD");
  const check_dates = moment(date_1).isSame(date_2);

  if (!check_dates) {
    const get_emp_leave_request = await find_leave_request_by_emp_and_date(
      emp_details._id,
      body_leave_date
    );

    if (get_emp_leave_request) {
      resp.error = true;
      resp.error_message =
        "A leave request is already added for this date : " +
        moment(body_leave_date).format("DD-MM-YYYY") +
        ". Exclude this date and try again";
      return resp;
    }
  }

  leave_request_detail.leave_type = body.leave_type;
  leave_request_detail.leave_reason = body.leave_reason;
  leave_request_detail.leave_date = body_leave_date;

  await leave_request_detail.save();
  resp.data = leave_request_detail;
  return resp;
};
const editLeaveRequestAdmin = async (user_id, leave_request_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editLeaveRequestAdmin(user_id, leave_request_id, body, resp);
  return resp;
};

const _deleteLeaveRequestAdmin = async (user_id, leave_request_id, resp) => {
  const admin_details = await find_user_by_id(user_id);
  if (!admin_details) {
    resp.error = true;
    resp.error_message = "Admin not found";
    return resp;
  }

  // if (admin_details.type != 0) {
  //   resp.error = true;
  //   resp.error_message = "You are not authorized";
  //   return resp;
  // }
  // const get_leave_request = await find_leave_request_by_id(leave_request_id);
  // if (!get_leave_request) {
  //   resp.error = true;
  //   resp.error_message = "Invalid Leave Request ID!";
  //   return resp;
  // }
  // if (get_leave_request.status != "pending") {
  //   resp.error = true;
  //   resp.error_message = "This leave request is already processed";
  //   return resp;
  // }
  const deleted_leave_request = await delete_leave_request_by_id(
    leave_request_id
  );
  if (!deleted_leave_request) {
    resp.error = true;
    resp.error_message = "Invalid Leave Request ID!";
    return resp;
  } else {
    await delete_leave_request_notifications(deleted_leave_request._id);
  }
  return resp;
};

const deleteLeaveRequestAdmin = async (user_id, leave_request_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteLeaveRequestAdmin(user_id, leave_request_id, resp);
  return resp;
};

const _processLeaveRequestAdmin = async (leave_req_id, user_id, body, resp) => {
  const admin_details = await find_user_by_id(user_id);
  if (!admin_details) {
    resp.error = true;
    resp.error_message = "User not found";
    return resp;
  }

  // if (admin_details.type != 0) {
  //   resp.error = true;
  //   resp.error_message = "You are not authorized";
  //   return resp;
  // }
  const leave_request_detail = await find_leave_request_by_id(leave_req_id);
  if (!leave_request_detail) {
    resp.error = true;
    resp.error_message = "Invalid Leave Request ID";
    return resp;
  }

  // if (leave_request_detail.status != "pending") {
  //   resp.error = true;
  //   resp.error_message = "This leave request is already processed";
  //   return resp;
  // }

  const emp_details = await find_employee_by_id(body.emp_obj_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  // if (emp_details._id == leave_request_detail.emp_obj_id) {
  //   resp.error = true;
  //   resp.error_message = "You cannot process your own leave request";
  //   return resp;
  // }

  const emp_details_to = await find_employee_by_id(
    leave_request_detail.emp_obj_id
  );
  if (!emp_details_to) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  leave_request_detail.status = body.status;
  if (body.status == "rejected") {
    leave_request_detail.rejection_reason = body.rejection_reason;
    if (emp_details_to.previllages.my_leaves.view) {
      let notification_obj = {
        user_id: emp_details_to.user_id._id,
        leave_request_id: leave_request_detail._id,
        title: "Leave Request",
        description:
          "Hi! " +
          leave_request_detail.emp_name +
          ". Your leave request was rejected",
        type: NOTIFICATION_TYPE.leave_request,
      };
      await add_notification(notification_obj);
    }
  } else {
    leave_request_detail.rejection_reason = "";

    if (emp_details_to.previllages.my_leaves.view) {
      let notification_obj = {
        user_id: emp_details_to.user_id._id,
        leave_request_id: leave_request_detail._id,
        title: "Leave Request",
        description:
          "Hi! " +
          leave_request_detail.emp_name +
          ". Your leave request got approved",
        type: NOTIFICATION_TYPE.leave_request,
      };
      await add_notification(notification_obj);
      console.log("emp_details_to.leads: ", emp_details_to.leads);
    }

    for (let x = 0; x < emp_details_to.leads.length; x++) {
      let notification_obj_for_leads = {
        user_id: emp_details_to.leads[x].user_id,
        leave_request_id: leave_request_detail._id,
        title: "Leave Request",
        description:
          "Hi! " +
          leave_request_detail.emp_name +
          " will be on leave on " +
          moment(leave_request_detail.leave_date).format("DD-MM-YYYY") +
          ". ",
        type: NOTIFICATION_TYPE.leave_request,
      };
      await add_notification(notification_obj_for_leads);

      NOTIFY_BY_EMAIL_FROM_SES(
        emp_details_to.leads[x].webmail,
        "Leave Request",
        notification_obj_for_leads.description +
          leave_request_detail.leave_reason
      );
    }
  }
  await leave_request_detail.save();

  resp.data = leave_request_detail;
  return resp;
};
const processLeaveRequestAdmin = async (leave_req_id, user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _processLeaveRequestAdmin(leave_req_id, user_id, body, resp);
  return resp;
};

const _searchLeaveRequestAdmin = async (body, Limit, page, search, resp) => {
  // const emp_details = await find_employee_by_user_id(user_id);
  // if (!emp_details) {
  //   resp.error = true;
  //   resp.error_message = "Member not found";
  //   return resp;
  // }
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let query_obj = { status: { $ne: "pending" } };
  if (body.emp_obj_id && body.emp_obj_id != "") {
    query_obj.emp_obj_id = body.emp_obj_id;
  }
  if (body.status && body.status != "") {
    query_obj.status = body.status;
  }
  if (
    body.date_from &&
    body.date_to &&
    body.date_from != "" &&
    body.date_to != "" &&
    body.date_from != null &&
    body.date_to != null &&
    body.date_from != undefined &&
    body.date_to != undefined
  ) {
    query_obj.leave_date = {
      $gte: moment(body.date_from, "DD-MM-YYYY").utc(true),
      $lte: moment(body.date_to, "DD-MM-YYYY").utc(true),
    };
  }
  // else if (search && search != "") {
  //   // query_obj.leave_date = moment(search, "DD-MM-YYYY").set("hour", 5);
  //   query_obj.leave_date = moment(search, "DD-MM-YYYY").utc(true);
  // }
  const leave_request = await get_leave_request_search(query_obj, limit, skip);
  const total_pages = await leave_request_search_count(query_obj);
  resp.data = {
    leave_request,
    total_pages,
    load_more_url: `/leave_request/get_leave_request?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchLeaveRequestAdmin = async (body, limit, page, search) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchLeaveRequestAdmin(body, limit, page, search, resp);
  return resp;
};

const _getTeamLeaveRequestsForLead = async (
  user_id,
  body,
  Limit,
  page,
  resp
) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let team_leaves = [];
  let team_leaves_count = 0;

  const lead = await find_employee_by_user_id(user_id);
  if (lead) {
    let team = await get_team_members_ids(lead._id);
    console.log("team: ", team);
    if (team.length > 0) {
      let query_obj = { status: { $ne: "pending" }, emp_obj_id: { $in: team } };

      if (body.status && body.status != "") {
        query_obj.status = body.status;
      }
      if (
        body.date_from &&
        body.date_to &&
        body.date_from != "" &&
        body.date_to != "" &&
        body.date_from != null &&
        body.date_to != null &&
        body.date_from != undefined &&
        body.date_to != undefined
      ) {
        query_obj.leave_date = {
          $gte: moment(body.date_from, "DD-MM-YYYY").utc(true),
          $lte: moment(body.date_to, "DD-MM-YYYY").utc(true),
        };
      }
      console.log("query: ", query_obj);
      team_leaves = await get_leave_request_search(query_obj, limit, skip);
      team_leaves_count = await leave_request_search_count(query_obj);
    }
  }

  const data = {
    team_leaves,
    team_leaves_count,
    load_more_url: `/employee/get_employees?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getTeamLeaveRequestsForLead = async (user_id, body, limit, page) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getTeamLeaveRequestsForLead(user_id, body, limit, page, resp);
  return resp;
};

const _getHalfLeaveRequestsYearly = async (user_id, resp) => {
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  const date = new Date();
  const year = date.getFullYear();
  // console.log("emp_details: ", emp_details);
  const half_leave_requests = await half_leave_requests_yearly(
    emp_details._id,
    year
  );
  const count = half_leave_requests.length;
  console.log("half_leave_requests: ", half_leave_requests);
  console.log("count: ", count);
  resp.data = { half_leave_requests, count };
  return resp;
};

const getHalfLeaveRequestsYearly = async (user_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getHalfLeaveRequestsYearly(user_id, resp);
  return resp;
};

const _searchAllLeaveRequestAdmin = async (body, Limit, page, search, resp) => {
  // const emp_details = await find_employee_by_user_id(user_id);
  // if (!emp_details) {
  //   resp.error = true;
  //   resp.error_message = "Member not found";
  //   return resp;
  // }
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let query_obj = {};
  if (body.emp_obj_id && body.emp_obj_id != "") {
    query_obj.emp_obj_id = body.emp_obj_id;
  }
  if (body.status && body.status != "") {
    query_obj.status = body.status;
  }
  if (
    body.date_from &&
    body.date_to &&
    body.date_from != "" &&
    body.date_to != "" &&
    body.date_from != null &&
    body.date_to != null &&
    body.date_from != undefined &&
    body.date_to != undefined
  ) {
    query_obj.leave_date = {
      $gte: moment(body.date_from, "DD-MM-YYYY").utc(true),
      $lte: moment(body.date_to, "DD-MM-YYYY").utc(true),
    };
  }
  // else if (search && search != "") {
  //   // query_obj.leave_date = moment(search, "DD-MM-YYYY").set("hour", 5);
  //   query_obj.leave_date = moment(search, "DD-MM-YYYY").utc(true);
  // }
  const leave_request = await get_leave_request_search(query_obj, limit, skip);
  const total_pages = await leave_request_search_count(query_obj);
  resp.data = {
    leave_request,
    total_pages,
    load_more_url: `/leave_request/get_all_leave_request?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchAllLeaveRequestAdmin = async (body, limit, page, search) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchAllLeaveRequestAdmin(body, limit, page, search, resp);
  return resp;
};

const _getAllEmployeeLeaveRequestStats = async (search, resp) => {
  // Get the current date
  const currentDate = moment();

  // Check if the current month is greater than or equal to 7th month (July)
  if (currentDate.month() > 6) {
    // Current year's July 1st to next year's June 30th
    var startDate = moment().month(6).date(1).startOf("day"); // July 1st of the current year
    var endDate = moment().add(1, "year").month(5).date(30).endOf("day"); // June 30th of the following year

    console.log("Start Date:", startDate.format("YYYY-MM-DD"));
    console.log("End Date:", endDate.format("YYYY-MM-DD"));
  } else {
    // Previous year's July 1st to current year's June 30th
    var startDate = moment()
      .subtract(1, "year")
      .month(6)
      .date(1)
      .startOf("day"); // July 1st of the previous year
    var endDate = moment().month(5).date(30).endOf("day"); // June 30th of the current year

    console.log("Start Date:", startDate.format("YYYY-MM-DD"));
    console.log("End Date:", endDate.format("YYYY-MM-DD"));
  }
  let query_obj = {};

  query_obj.leave_date = {
    $gte: new Date(startDate),
    $lte: new Date(endDate),
  };
  if (search !== "") {
    query_obj.emp_name = { $regex: new RegExp(search, "i") };
  }
  let leave_request = await get_leave_stats(query_obj);
  leave_request = leave_request.filter((l) => l.emp_status == true);
  resp.data = leave_request;

  return resp;
};

const getAllEmployeeLeaveRequestStats = async (search) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getAllEmployeeLeaveRequestStats(search, resp);
  return resp;
};

const _getAllEmployeeLeaveRequestStatsV1 = async (
  search,
  Limit,
  page,
  resp
) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  }

  let skip = (page - 1) * limit;

  //get employee details

  let employees = await get_employee_for_leave_report(search, limit, skip);

  let count = await get_employee_for_leave_report_count(search);

  let total_pages = Math.ceil(count / limit);

  console.log("emp_details: ", count);

  //fiscal year logic
  function getFiscalYear() {
    const currentDate = moment();
    let fiscalYearStart, fiscalYearEnd;

    if (currentDate.month() >= 6) {
      // If the current month is July or later
      fiscalYearStart = moment({
        year: currentDate.year(),
        month: 6,
        day: 1,
      }).format("YYYY-MM-DD");
      fiscalYearEnd = moment({
        year: currentDate.year() + 1,
        month: 5,
        day: 30,
      }).format("YYYY-MM-DD");
    } else {
      // If the current month is June or earlier
      fiscalYearStart = moment({
        year: currentDate.year() - 1,
        month: 6,
        day: 1,
      }).format("YYYY-MM-DD");
      fiscalYearEnd = moment({
        year: currentDate.year(),
        month: 5,
        day: 30,
      }).format("YYYY-MM-DD");
    }

    return { fiscalYearStart, fiscalYearEnd };
  }

  const { fiscalYearStart, fiscalYearEnd } = getFiscalYear();

  let all_employees = [];
  for (let i = 0; i < employees.length; i++) {
    //new logic

    // console.log("employe", employees[i]._id);
    let current_year_absent = await get_employee_leaves_for_dashboard_count(
      employees[i]._id,
      fiscalYearStart,
      fiscalYearEnd
    );

    // console.log("current_year_absent" + i +"=" , current_year_absent.length);

    let absent_count = 0;

    if (current_year_absent.length > 0) {
      current_year_absent.forEach((element) => {
        if (element.half_leave_type == 0) {
          absent_count += 1;
        } else if (
          element.half_leave_type == 1 ||
          element.half_leave_type == 2
        ) {
          absent_count += 0.5;
        }
      });
    }

    let emp_obj = {
      emp_obj_id: employees[i]._id,
      full_name: employees[i].full_name,
      leaves_count: absent_count,
      allowed_leaves: employees[i].allowed_leaves,
    };
    all_employees.push(emp_obj);
  }

  resp.data = {
    leaves_report: all_employees,
    count,
    total_pages: total_pages - 1,
  };

  return resp;
};

const getAllEmployeeLeaveRequestStatsV1 = async (search, limit, page) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getAllEmployeeLeaveRequestStatsV1(search, limit, page, resp);
  return resp;
};

const _getAllEmployeeLeaveRequestStatsV2 = async (body, Limit, page, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  }

  let skip = (page - 1) * limit;

  //validte date , body.date_from, body.date_to formate YYYY-MM-DD

  let date_from = body.date_from;
  let date_to = body.date_to;

  if (date_from && date_to) {
    let date_from = moment(body.date_from, "YYYY-MM-DD", true).utc(true);
    let date_to = moment(body.date_to, "YYYY-MM-DD", true).utc(true);
    if (!date_from.isValid() || !date_to.isValid()) {
      resp.error = true;
      resp.error_message =
        "Invalid date format - Formate YYYY-MM-DD is required";
      return resp;
    }
  }

  //get employee details

  let employees = await get_employee_for_leave_report(body.search, limit, skip);

  let count = await get_employee_for_leave_report_count(body.search);

  let total_pages = Math.ceil(count / limit);

  console.log("emp_details: ", count);

  // //fiscal year logic
  // function getFiscalYear() {
  //   const currentDate = moment();
  //   let fiscalYearStart, fiscalYearEnd;

  //   if (currentDate.month() >= 6) {
  //     // If the current month is July or later
  //     fiscalYearStart = moment({
  //       year: currentDate.year(),
  //       month: 6,
  //       day: 1,
  //     }).format("YYYY-MM-DD");
  //     fiscalYearEnd = moment({
  //       year: currentDate.year() + 1,
  //       month: 5,
  //       day: 30,
  //     }).format("YYYY-MM-DD");
  //   } else {
  //     // If the current month is June or earlier
  //     fiscalYearStart = moment({
  //       year: currentDate.year() - 1,
  //       month: 6,
  //       day: 1,
  //     }).format("YYYY-MM-DD");
  //     fiscalYearEnd = moment({
  //       year: currentDate.year(),
  //       month: 5,
  //       day: 30,
  //     }).format("YYYY-MM-DD");
  //   }

  //   return { fiscalYearStart, fiscalYearEnd };
  // }

  // const { fiscalYearStart, fiscalYearEnd } = getFiscalYear();

  let all_employees = [];
  for (let i = 0; i < employees.length; i++) {
    //new logic

    // // console.log("employe", employees[i]._id);
    // let current_year_absent = await get_employee_leaves_for_dashboard_count(
    //   employees[i]._id,
    //   fiscalYearStart,
    //   fiscalYearEnd
    // );

    // // console.log("current_year_absent" + i +"=" , current_year_absent.length);

    // let absent_count = 0;

    // if (current_year_absent.length > 0) {
    //   current_year_absent.forEach((element) => {
    //     if (element.half_leave_type == 0) {
    //       absent_count += 1;
    //     } else if (
    //       element.half_leave_type == 1 ||
    //       element.half_leave_type == 2
    //     ) {
    //       absent_count += 0.5;
    //     }
    //   });
    // }

    let current_year_absent = await find_leaves_from_leave_request(
      employees[i]._id,
      date_from,
      date_to
    );
    // console.log("current_year_absent", current_year_absent);
    let total_absent_yearly = 0;
    if (current_year_absent.length > 0) {
      current_year_absent.forEach((element) => {
        if (element.leave_type == "full") {
          total_absent_yearly += 1;
        } else if (
          element.leave_type == "first_half" ||
          element.leave_type == "second_half"
        ) {
          total_absent_yearly += 0.5;
        }
      });
    }

    let emp_obj = {
      emp_obj_id: employees[i]._id,
      full_name: employees[i].full_name,
      leaves_count: total_absent_yearly,
      allowed_leaves: employees[i].allowed_leaves,
    };
    all_employees.push(emp_obj);
  }

  resp.data = {
    leaves_report: all_employees,
    count,
    total_pages: total_pages - 1,
  };

  return resp;
};

const getAllEmployeeLeaveRequestStatsV2 = async (body, limit, page) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getAllEmployeeLeaveRequestStatsV2(body, limit, page, resp);
  return resp;
};

const _changeLeavePaymentStatus = async (leave_request_id, body, resp) => {
  const get_leave_request = await find_leave_request_by_id(leave_request_id);
  if (!get_leave_request) {
    resp.error = true;
    resp.error_message = "Invalid Leave Request ID!";
    return resp;
  }

  get_leave_request.leave_payment_status = body.leave_payment_status;
  let leave_request = await get_leave_request.save();

  resp.data = {
    leave_request: leave_request,
  };

  return resp;
};

const changeLeavePaymentStatus = async (user_id, leave_request_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _changeLeavePaymentStatus(leave_request_id, body, resp);
  return resp;
};

const _updateCountInYearlyLeaves = async (
  user_id,
  leave_request_id,
  body,
  resp
) => {
  let uncount_leave_action_by = {};

  const find_user = await find_employee_by_user_id(user_id);
  if (!find_user) {
    resp.error = true;
    resp.error_message = "Invalid User ID!";
    return resp;
  }

  uncount_leave_action_by = {
    emp_obj_id: find_user._id,
    user_id: user_id,
    emp_name: find_user.full_name ? find_user.full_name : "",
    designation: find_user.designation ? find_user.designation : "",
  };

  const get_leave_request = await find_leave_request_by_id(leave_request_id);
  if (!get_leave_request) {
    resp.error = true;
    resp.error_message = "Invalid Leave Request ID!";
    return resp;
  }

  get_leave_request.count_in_yearly_leaves = body.count_in_yearly_leaves;
  get_leave_request.uncount_leave_reason = body.uncount_leave_reason
    ? body.uncount_leave_reason
    : "";
  get_leave_request.uncount_leave_action_by = uncount_leave_action_by;

  let leave_request = await get_leave_request.save();

  resp.data = {
    leave_request: leave_request,
  };

  return resp;
};

const updateCountInYearlyLeaves = async (user_id, leave_request_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _updateCountInYearlyLeaves(
    user_id,
    leave_request_id,
    body,
    resp
  );
  return resp;
};

module.exports = {
  addLeaveRequest,
  addLeaveRequestAdmin,
  editLeaveRequest,
  editLeaveRequestAdmin,
  detailLeaveRequest,
  deleteLeaveRequest,
  deleteLeaveRequestAdmin,
  searchLeaveRequest,
  searchLeaveRequestAdmin,
  processLeaveRequest,
  processLeaveRequestAdmin,
  getTeamLeaveRequestsForLead,
  getHalfLeaveRequestsYearly,
  searchAllLeaveRequestAdmin,
  getAllEmployeeLeaveRequestStats,
  getAllEmployeeLeaveRequestStatsV1,
  getAllEmployeeLeaveRequestStatsV2,
  changeLeavePaymentStatus,
  updateCountInYearlyLeaves,
};
