const { find_user, find_user_by_id } = require("../DAL/user");
const {
  add_top_up,
  find_top_up_by_id,
  pagination_top_up,
  all_top_up_categories_active,
  all_top_up_categories_active_count,
  delete_top_up_by_id,
  get_top_up_search,
  top_up_search_count,
  find_top_up_by_name,
  top_up_search_by_query_obj,
  top_up_search_by_query_obj_count,
  get_top_up_by_query_obj,
  get_top_up_amount_by_query_obj,
} = require("../DAL/top_up");
const {
  find_employee_by_id,
  find_employee_by_user_id,
} = require("../DAL/employee");
const { find_vendor_by_id } = require("../DAL/vendor");
const { PREVILLAGES } = require("../utils/constants");
const moment = require("moment");
const _ = require("lodash");

const _addTopUp = async (user_id, body, resp) => {
  const added_employee_detail = await find_employee_by_user_id(user_id);
  if (!added_employee_detail) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  let added_by = {
    _id: added_employee_detail._id,
    name: added_employee_detail.full_name,
  };

  const transfer_by_detail = await find_employee_by_id(body.transfer_by);
  if (!transfer_by_detail) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  let transfer_by = {
    _id: transfer_by_detail._id,
    name: transfer_by_detail.full_name,
  };

  const transfer_to_detail = await find_employee_by_id(body.transfer_to);
  if (!transfer_to_detail) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  let transfer_to = {
    _id: transfer_to_detail._id,
    name: transfer_to_detail.full_name,
  };

  let top_up_obj = {
    title: body.title,
    amount: body.amount,
    payment_method: body.payment_method,
    date: moment(body.date, "DD-MM-YYYY").utc(true),
    attachment: body.attachment,
    notes: body.notes,
    cheque_number: body.cheque_number,
    transfer_by: transfer_by,
    transfer_to: transfer_to,
    added_by: added_by,
  };

  const final_top_up = await add_top_up(top_up_obj);
  if (final_top_up) {
    transfer_to_detail.total_balance += final_top_up.amount;
    await transfer_to_detail.save();
  }
  resp.data = final_top_up;
  return resp;
};
const addTopUp = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addTopUp(user_id, body, resp);
  return resp;
};

const _editTopUp = async (body, top_up_id, resp) => {
  const top_up_detail = await find_top_up_by_id(top_up_id);
  if (!top_up_detail) {
    resp.error = true;
    resp.error_message = "Invalid Top Up ID";
    return resp;
  }

  let transfer_by = top_up_detail.transfer_by;
  let transfer_to = top_up_detail.transfer_to;

  const transfer_to_old = await find_employee_by_id(transfer_to._id);
  if (!transfer_to_old) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  if (transfer_by._id != body.transfer_by) {
    const transfer_by_detail = await find_employee_by_id(body.transfer_by);
    if (!transfer_by_detail) {
      resp.error = true;
      resp.error_message = "Member not found";
      return resp;
    }
    transfer_by._id = transfer_by_detail._id;
    transfer_by.name = transfer_by_detail.full_name;
  }

  if (transfer_to._id != body.transfer_to) {
    const transfer_to_detail = await find_employee_by_id(body.transfer_to);
    if (!transfer_to_detail) {
      resp.error = true;
      resp.error_message = "Member not found";
      return resp;
    }

    transfer_to_old.total_balance -= top_up_detail.amount;
    await transfer_to_old.save();

    transfer_to_detail.total_balance += parseInt(body.amount);
    await transfer_to_detail.save();

    transfer_to._id = transfer_to_detail._id;
    transfer_to.name = transfer_to_detail.full_name;
  } else {
    if (top_up_detail.amount != body.amount) {
      transfer_to_old.total_balance -= top_up_detail.amount;
      await transfer_to_old.save();

      transfer_to_old.total_balance += parseInt(body.amount);
      await transfer_to_old.save();
    }
  }

  // let active_status = false;
  // if (body.active_status.toLowerCase() == "true") {
  //   active_status = true;
  // }

  if (body.payment_method.toLowerCase() != "cheque") {
    body.cheque_number = "";
  }

  top_up_detail.title = body.title;
  top_up_detail.amount = body.amount;
  top_up_detail.payment_method = body.payment_method;
  top_up_detail.date = moment(body.date, "DD-MM-YYYY").utc(true);
  top_up_detail.attachment = body.attachment;
  top_up_detail.notes = body.notes;
  top_up_detail.cheque_number = body.cheque_number;
  top_up_detail.transfer_by = transfer_by;
  top_up_detail.transfer_to = transfer_to;
  top_up_detail.active_status = body.active_status;

  await top_up_detail.save();
  resp.data = top_up_detail;
  return resp;
};
const editTopUp = async (body, top_up_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editTopUp(body, top_up_id, resp);
  return resp;
};

const _detailTopUp = async (top_up_id, resp) => {
  const top_up = await find_top_up_by_id(top_up_id);
  if (!top_up) {
    resp.error = true;
    resp.error_message = "Invalid Top Up ID!";
    return resp;
  }
  resp.data = top_up;
  return resp;
};

const detailTopUp = async (top_up_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailTopUp(top_up_id, resp);
  return resp;
};

const _detailTopUpForEdit = async (top_up_id, resp) => {
  const top_up = await find_top_up_by_id(top_up_id);
  if (!top_up) {
    resp.error = true;
    resp.error_message = "Invalid Top Up ID!";
    return resp;
  }
  resp.data = top_up;
  return resp;
};

const detailTopUpForEdit = async (top_up_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailTopUpForEdit(top_up_id, resp);
  return resp;
};

const _deleteTopUp = async (top_up_id, resp) => {
  const deleted_top_up = await delete_top_up_by_id(top_up_id);
  if (!deleted_top_up) {
    resp.error = true;
    resp.error_message = "Invalid Top Up  ID!";
    return resp;
  }
  const transfer_to_detail = await find_employee_by_id(
    deleted_top_up.transfer_to._id
  );
  if (transfer_to_detail) {
    transfer_to_detail.total_balance -= deleted_top_up.amount;
    await transfer_to_detail.save();
  }
  return resp;
};

const deleteTopUp = async (top_up_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteTopUp(top_up_id, resp);
  return resp;
};

const _searchTopUp = async (user_id, Limit, page, body, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let query_obj = {};
  if (
    body.date_from &&
    body.date_to &&
    body.date_from != "" &&
    body.date_to != "" &&
    body.date_from != null &&
    body.date_to != null &&
    body.date_from != undefined &&
    body.date_to != undefined
  ) {
    query_obj.date = {
      $gte: moment(body.date_from, "DD-MM-YYYY").utc(true).toDate(),
      $lte: moment(body.date_to, "DD-MM-YYYY").utc(true).toDate(),
    };
  }
  if (body.added_by && body.added_by != "") {
    query_obj["added_by.name"] = { $regex: new RegExp(body.added_by, "i") };
  }

  if (body.transfer_by && body.transfer_by != "") {
    query_obj["transfer_by.name"] = {
      $regex: new RegExp(body.transfer_by, "i"),
    };
  }

  const top_up = await get_top_up_search(limit, skip, query_obj);
  const total_pages = await top_up_search_count(query_obj);

  let top_up_balance = 0;

  console.log("query_obj:==============", query_obj);

  const top_up_amount = await get_top_up_amount_by_query_obj(query_obj);

  top_up_balance = top_up_amount;

  // if (!_.isEmpty(query_obj)) {
  //   const filtered_top_ups = await top_up_search_by_query_obj(query_obj);
  //   for (let i = 0; i < filtered_top_ups.length; i++) {
  //     top_up_balance += filtered_top_ups[i].amount;
  //   }
  // } else {
  //   for (let i = 0; i < top_up.length; i++) {
  //     top_up_balance += top_up[i].amount;
  //   }
  // }

  resp.data = {
    top_up,
    total_pages,
    top_up_balance,
    load_more_url: `/top_up/get_top_up?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchTopUp = async (user_id, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchTopUp(user_id, limit, page, body, resp);
  return resp;
};

const _maintainTopUp = async (user_id, resp) => {
  const emp = await find_employee_by_user_id(user_id);
  if (!emp) {
    resp.error = true;
    resp.error_message = "Member not found!";
    return resp;
  }

  let query_obj = { "transfer_to._id": emp._id };

  const top_up = await get_top_up_by_query_obj(query_obj);

  let top_up_balance = 0;
  for (let i = 0; i < top_up.length; i++) {
    top_up_balance += top_up[i].amount;
  }

  console.log("top_up_balance: ", top_up_balance);
  console.log("old emp.total_balance: ", emp.total_balance);
  emp.total_balance += top_up_balance;
  await emp.save();

  console.log("new emp.total_balance: ", emp.total_balance);

  return resp;
};

const maintainTopUp = async (user_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _maintainTopUp(user_id, resp);
  return resp;
};

module.exports = {
  addTopUp,
  editTopUp,
  detailTopUp,
  detailTopUpForEdit,
  deleteTopUp,
  searchTopUp,
  maintainTopUp,
};
