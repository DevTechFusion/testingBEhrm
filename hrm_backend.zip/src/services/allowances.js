const {
  add_allowance,
  update_allowance,
  get_allowance_by_id,
  list_allowances,
  delete_allowance,
} = require("../DAL/allowances");

const _addAllowance = async (body, resp) => {
  const allowance = await add_allowance(body);

  resp.data = {
    allowance: allowance,
  };
  return resp;
};

const addAllowance = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addAllowance(body, resp);
  return resp;
};

const _updateAllowance = async (id, body, resp) => {
  const find_allowance = await get_allowance_by_id(id);
  if (!find_allowance) {
    resp.error = true;
    resp.error_message = "Allowance not found";
    return resp;
  }

  const allowance = await update_allowance(id, body);
  if (!allowance) {
    resp.error = true;
    resp.error_message = "Allowance not updated";
    return resp;
  }

  resp.data = {
    allowance: allowance,
  };
  return resp;
};

const updateAllowance = async (id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _updateAllowance(id, body, resp);
  return resp;
};

const _getAllowanceById = async (id, resp) => {
  const find_allowance = await get_allowance_by_id(id);
  if (!find_allowance) {
    resp.error = true;
    resp.error_message = "Allowance not found";
    return resp;
  }

  resp.data = {
    allowance: find_allowance,
  };
  return resp;
};

const getAllowanceById = async (id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getAllowanceById(id, resp);
  return resp;
};

const _listAllowances = async (type, resp) => {
  let query_obj = {};

  if (type) {
    query_obj = {
      allowance_type: type,
      status: true,
    };
  }

  const allowances = await list_allowances(query_obj);

  resp.data = {
    allowances: allowances,
  };
  return resp;
};

const listAllowances = async (type) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _listAllowances(type, resp);
  return resp;
};

const _deleteAllowance = async (id, resp) => {
  const allowance = await delete_allowance(id);
  if (!allowance) {
    resp.error = true;
    resp.error_message = "Allowance not deleted";
    return resp;
  }

  resp.data = {};
  return resp;
};

const deleteAllowance = async (id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteAllowance(id, resp);
  return resp;
};

module.exports = {
  addAllowance,
  updateAllowance,
  getAllowanceById,
  listAllowances,
  deleteAllowance,
};
