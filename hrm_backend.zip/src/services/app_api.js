const { v1: uuidv1 } = require("uuid");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { ALL_FILE_PATH } = require("../utils/constants");
const {
  UPLOAD_S3_IMAGE,
  UPLOAD_AND_RESIZE_FILE,
  UPLOAD_AUDIO_FILE,
  NOTIFY_BY_EMAIL_FROM_SES,
  UPLOAD_ANY_SINGLE_FILE_ON_S3,
  UPLOAD_FILE_on_S3_with_CONTENT_TYPE,
} = require("../utils/utils");
const {
  add_to_session,
  get_session_by_user_id,
  delete_from_session,
} = require("../DAL/session");
const {
  find_user,
  find_user_by_id,
  checking_email_exist,
  get_all_user,
} = require("../DAL/user");
const { detail_admin, find_admin_by_user_id } = require("../DAL/admin");
const {
  find_employee_by_user_id,
  find_employee_by_id,
  find_employee_by_email,
  get_all_employees,
} = require("../DAL/employee");
const { v1: uuidv4 } = require("uuid");
const { getAudioDurationInSeconds } = require("get-audio-duration");
const axios = require("axios");
const fs = require("fs");
const path = require("path");
const { endPoint } = require("../utils/api_url");
const { invokeApi } = require("../libs/invoke_api");

const _loginUser = async (body, resp) => {
  const user = await find_user(body);
  if (!user) {
    resp.error = true;
    resp.error_message = "Invalid Email Address!";
    return resp;
  }
  // if (user.type !== body.type) {
  //   resp.error = true;
  //   resp.error_message = "Invalid Type!";
  //   return resp;
  // }
  const employee = await find_employee_by_email(body.email);
  // if (!employee) {
  //   resp.error = true;
  //   resp.error_message = "Invalid Email Address!";
  //   return resp;
  // }
  if (employee) {
    if (!employee.active_status) {
      resp.error = true;
      resp.error_message = "You are inactive";
      return resp;
    }
  }

  const isValidPassword = await bcrypt.compare(body.password, user.password);

  if (!isValidPassword) {
    resp.error = true;
    resp.error_message = "Invalid Email or Password";
    return resp;
  }

  // Logging in Employee in DONE
  // let headers = {
  //   Accept: "application/json",
  //   "Content-Type": "application/json",
  // };
  // let queryParams = {};
  // let postData = {
  //   email: body.email,
  //   password: body.password,
  //   type: 2,
  //   device_token: "",
  // };

  // let response = await invokeApi({
  //   url: endPoint.customerLogin,
  //   method: "POST",
  //   headers,
  //   queryParams,
  //   postData,
  // });
  //
  // if (response.code != 200) {
  //   resp.error = true;
  //   resp.error_message = response.message;
  //   return resp;
  // }
  // let token = response.token;
  // const decoded = jwt.verify(response.token, process.env.JWT_SECRET);
  // let login_token = decoded.login_token;
  //

  //generating token
  // const access = "auth";
  // const json_token = uuidv1();
  // const token = jwt
  //   .sign({ login_token: json_token, access }, process.env.JWT_SECRET)
  //   .toString();

  // const add_session = await add_to_session(login_token, response.customer.user_id);

  //generating token
  const access = "auth";
  const json_token = uuidv1();
  const token = jwt
    .sign({ login_token: json_token, access }, process.env.JWT_SECRET)
    .toString();

  const add_session = await add_to_session(json_token, user._id);

  if (!add_session) {
    resp.error = true;
    resp.error_message = "Login Failed";
    return resp;
  }
  let detail;
  let previllages = {
    support: {
      sidebar: false,
      add: false,
      alter: false,
      delete: false,
      view: false,
    },
    announcement: {
      sidebar: false,
      add: false,
      alter: false,
      delete: false,
      view: false,
    },
    attendance: {
      sidebar: false,
      add: false,
      alter: false,
      delete: false,
      view: false,
    },
    department: {
      sidebar: false,
      add: false,
      alter: false,
      delete: false,
      view: false,
    },
    employee: {
      sidebar: false,
      add: false,
      alter: false,
      delete: false,
      view: false,
    },
    asset: {
      sidebar: false,
      add: false,
      alter: false,
      delete: false,
      view: false,
    },
    vendor: {
      sidebar: false,
      add: false,
      alter: false,
      delete: false,
      view: false,
    },
    brand: {
      sidebar: false,
      add: false,
      alter: false,
      delete: false,
      view: false,
    },
    company: {
      sidebar: false,
      add: false,
      alter: false,
      delete: false,
      view: false,
    },
    category: {
      sidebar: false,
      add: false,
      alter: false,
      delete: false,
      view: false,
    },
    leaves: {
      sidebar: false,
      add: false,
      alter: false,
      delete: false,
      view: false,
    },
    role: {
      sidebar: false,
      add: false,
      alter: false,
      delete: false,
      view: false,
    },
    my_leaves: {
      sidebar: false,
      add: false,
      alter: false,
      delete: false,
      view: false,
    },
    my_support: {
      sidebar: false,
      add: false,
      alter: false,
      delete: false,
      view: false,
    },
  };

  detail = await find_employee_by_user_id(user._id);

  if (detail) {
    previllages = detail.previllages;
  }
  resp.data = {
    token: token,
    admin: detail,
    type: user.type,
    previllages: previllages,
  };

  return resp;
};

const loginUser = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _loginUser(body, resp);
  return resp;
};

const _changePassword = async (body, user_id, token, resp) => {
  if (body.new_password !== body.confirm_password) {
    resp.error = true;
    resp.error_message = "New password and confirm password are not matched";
    return resp;
  }

  let user = await find_user_by_id(user_id);
  if (!user) {
    resp.error = true;
    resp.error_message = "Something Wrong";
    return resp;
  }
  const isValidPassword = await bcrypt.compare(
    body.old_password,
    user.password
  );

  if (!isValidPassword) {
    resp.error = true;
    resp.error_message = "Old Password Is Incorrect";
    return resp;
  }

  const salt = await bcrypt.genSalt(10);
  user.password = await bcrypt.hash(body.new_password, salt);

  // Updating password in DONE
  // let headers = {
  //   Accept: "application/json",
  //   "Content-Type": "application/json",
  //   "x-sh-auth": token,
  // };
  // let queryParams = {};

  // let postData = {
  //   old_password: body.old_password,
  //   new_password: body.new_password,
  //   confirm_password: body.confirm_password,
  // };

  // let response = await invokeApi({
  //   url: endPoint.changePassword,
  //   method: "PUT",
  //   headers,
  //   queryParams,
  //   postData,
  // });
  // if (response.code != 200) {
  //   resp.error = true;
  //   resp.error_message = response.message;
  //   return resp;
  // }
  user = await user.save();
  return resp;
};

const changePassword = async (body, user_id, token) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _changePassword(body, user_id, token, resp);
  return resp;
};

const _changeEmail = async (body, user_id, resp) => {
  let user = await find_user_by_id(user_id);
  if (!user) {
    resp.error = true;
    resp.error_message = "Something Went Wrong";
    return resp;
  }

  if (body.email !== user.email) {
    let check_user_email = await find_user(body);
    if (check_user_email) {
      resp.error = true;
      resp.error_message = "User With This Email Already Exist";
      return resp;
    }
  }

  user.email = body.email;
  user = await user.save();
  return resp;
};

const changeEmail = async (body, user_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _changeEmail(body, user_id, resp);
  return resp;
};

const _logoutUser = async (user_id, resp) => {
  const session = await get_session_by_user_id(user_id);
  if (!session) {
    resp.error = true;
    resp.error_message = "Something Wrong";
    return resp;
  }
  const delete_session = await delete_from_session(session._id);
  if (!delete_session) {
    resp.error = true;
    resp.error_message = "Something Wrong";
    return resp;
  }
  return resp;
};

const logoutUser = async (user_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _logoutUser(user_id, resp);
  return resp;
};

/********************** Validate Email Address**********************/
const _validateEmailAddress = async (body, resp) => {
  // find user by email
  const user = await checking_email_exist(body.email);
  if (!user) {
    resp.error = true;
    resp.error_message = "Invalid Email Address";
    return resp;
  }
  // generate code
  const code =
    Math.floor(Math.random() * (9 * Math.pow(10, 6 - 1))) + Math.pow(10, 6 - 1);
  user.verification_code = code;
  await user.save();

  // console.log("Verification Code saved: ", code);
  // console.log("user: ", user);

  let subject = `Email Verification Code`;
  let email_body = `Hi, Your Email verification code is ${code}`;
  await NOTIFY_BY_EMAIL_FROM_SES(user.email, subject, email_body);
  return resp;
};

const validateEmailAddress = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _validateEmailAddress(body, resp);
  return resp;
};

//*************** Validate Code*******************/
const _codeValidation = async (body, resp) => {
  // find user by email
  const user = await checking_email_exist(body.email);
  if (!user) {
    resp.error = true;
    resp.error_message = "Invalid Email Address";
    return resp;
  }

  if (user.verification_code == body.verification_code) {
    user.verification_code = "";
    user.verification_status = true;
    await user.save();
    return resp;
  } else {
    resp.error = true;
    resp.error_message = "Invalid code or code is expire";
    return resp;
  }
};

const codeValidation = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _codeValidation(body, resp);
  return resp;
};

//****************Reset Password ********************/
const _resetPassword = async (body, resp) => {
  // find user by email
  const user = await checking_email_exist(body.email);
  if (!user) {
    resp.error = true;
    resp.error_message = "Invalid Email Address";
    return resp;
  }

  if (body.password !== body.confirm_password) {
    resp.error = true;
    resp.error_message = "New password and confirm password are not matched";
    return resp;
  }
  if (user.verification_status !== true) {
    resp.error = true;
    resp.error_message = "Something get wrong";
    return resp;
  }

  const salt = await bcrypt.genSalt(10);
  user.password = await bcrypt.hash(body.password, salt);
  user.verification_status = false;
  await user.save();
  return resp;
};

const resetPassword = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _resetPassword(body, resp);
  return resp;
};

const _uplaodImageS3 = async (files, resp) => {
  if (
    files == null ||
    files.image == null ||
    files.image == undefined ||
    files.image == " "
  ) {
    resp.error = true;
    resp.error_message = "please Upload Image";
    return resp;
  }
  let dir = "images/";
  let image_name = uuidv4() + ".jpeg";
  image_path = dir.concat(image_name);

  const upload_image_response = await UPLOAD_S3_IMAGE(
    image_name,
    dir,
    files.image.data
  );
  if (upload_image_response.status == false) {
    resp.error = true;
    resp.error_message = "Something get wrong";
    return resp;
  }

  resp.data = {
    path: image_path,
  };
  return resp;
};

const uplaodImageS3 = async (files) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _uplaodImageS3(files, resp);
  return resp;
};

const _uplaodImage = async (files, resp) => {
  if (
    files == null ||
    files.image == null ||
    files.image == undefined ||
    files.image == " "
  ) {
    resp.error = true;
    resp.error_message = "please Upload Image";
    return resp;
  }
  let dir = "./src/utils/images/";
  let image_name = uuidv4() + ".jpeg";
  image_path = dir.concat(image_name);

  const upload_image_response = await UPLOAD_AND_RESIZE_FILE(
    files.image.data,
    dir,
    { width: 200 }
  );
  if (upload_image_response == false) {
    resp.error = true;
    resp.error_message = "Something get wrong";
    return resp;
  }

  resp.data = {
    path: image_path,
  };
  return resp;
};

const uplaodImage = async (files) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _uplaodImage(files, resp);
  return resp;
};

const _uplaodAudio = async (files, resp) => {
  if (
    files == null ||
    files.audio == null ||
    files.audio == undefined ||
    files.audio == " "
  ) {
    resp.error = true;
    resp.error_message = "please Upload audio";
    return resp;
  }
  // move file to audio folder in utils
  const response = await UPLOAD_AUDIO_FILE(files, resp);
  if (response.error) {
    return response;
  }
  // calculate duration of audio file
  await getAudioDurationInSeconds("./src/utils/audio/" + response).then(
    (duration_in_sec) => {
      let duration_in_hours = Math.floor(duration_in_sec / 3600); // get hours
      let duration_in_minutes = Math.floor(
        (duration_in_sec - duration_in_hours * 3600) / 60
      );
      let duration_in_seconds =
        duration_in_sec - duration_in_hours * 3600 - duration_in_minutes * 60; //  get seconds
    }
  );
  // delete file now
  await fs.unlink("./src/utils/audio/" + response, function (err) {
    if (err) throw err;
    // if no error, file has been deleted successfully
  });
  resp.data = { path: response };
  return resp;
};

const uplaodAudio = async (files) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _uplaodAudio(files, resp);
  return resp;
};

const _loginCustomer = async (resp) => {
  const user = await get_all_user();
  for (let i = 0; i < user.length; i++) {
    let user_object = {
      user_id: user[i]._id,
      email: user[i].email,
      password: user[i].password,
      first_name: "",
      last_name: "",
      contact_number: "",
      country_code: "",
      gender: "",
      device_token: "",
    };
    const employee = await find_employee_by_email(user[i].email);
    if (employee) {
      if (employee.first_name == "") {
        user_object.first_name = employee.full_name;
      } else {
        user_object.first_name = employee.first_name;
      }

      if (employee.last_name == "") {
        user_object.last_name = employee.full_name;
      } else {
        user_object.last_name = employee.last_name;
      }
      let phone_number = employee.contact_number.split(" ");
      if (phone_number.length > 1) {
        user_object.contact_number = phone_number[1];
        user_object.country_code = phone_number[0];
      } else {
        user_object.contact_number = phone_number[0];
        user_object.country_code = "+92";
      }
      if (employee.gender == "") {
        user_object.gender = "other";
      } else {
        user_object.gender = employee.gender.toLowerCase();
      }

      let headers = {
        Accept: "application/json",
        "Content-Type": "application/json",
      };
      let queryParams = {};
      let postData = {
        user_id: user_object.user_id,
        email: user_object.email,
        password: user_object.password,
        first_name: user_object.first_name,
        last_name: user_object.last_name,
        contact_number: user_object.contact_number,
        country_code: user_object.country_code,
        gender: user_object.gender,
        device_token: user_object.device_token,
      };
      let response = await invokeApi({
        url: endPoint.addCustomers,
        method: "POST",
        headers,
        queryParams,
        postData,
      });
    }
  }
  return resp;
};

const loginCustomer = async () => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _loginCustomer(resp);
  return resp;
};

const _uploadAnySingleFileOnS3 = async (files, resp) => {
  if (
    files == null ||
    files == undefined ||
    files.file == null ||
    files.file == undefined ||
    files.file == " " ||
    files.file == ""
  ) {
    resp.error = true;
    resp.error_message = "Please upload file";
    return resp;
  }

  let file_extension = path.extname(files.file.name);

  const return_path = await UPLOAD_ANY_SINGLE_FILE_ON_S3(
    files.file,
    ALL_FILE_PATH,
    file_extension
  );

  // console.log(files.file.data);
  // const return_path = await UPLOAD_FILE_on_S3_with_CONTENT_TYPE(
  //   files.file.data,
  //   ALL_FILE_PATH,
  //   file_extension,
  //   "application/pdf"
  // );

  resp.data = { path: return_path };
  return resp;
};

const uploadAnySingleFileOnS3 = async (files) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _uploadAnySingleFileOnS3(files, resp);
  return resp;
};

//**********************************{udate user previllages } */
const _updateUserPrevillages = async (resp) => {
  let all_employee = await get_all_employees();

  console.log("all_employee", all_employee);

  let new_obj = {
    general_settings: {
      sidebar: false,
      alter: false,
      view: false,
    },
    upcomming_birthdays: {
      sidebar: false,
      view: false,
    },
    upcomming_anniversary: {
      sidebar: false,
      view: false,
    },
  };

  let new_employee = []

  for (let i = 0; i < all_employee.length; i++) {
    let employee = all_employee[i];

    let all_previllages = {
      ...employee.previllages,
      ...new_obj,
    };
    employee.previllages = all_previllages;
    // console.log("employee", employee);
    // new_employee.push(employee);
    await employee.save();
  }

  resp.data = new_employee;

  return resp;
};

const updateUserPrevillages = async () => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _updateUserPrevillages(resp);
  return resp;
};

module.exports = {
  loginUser,
  changePassword,
  logoutUser,
  validateEmailAddress,
  codeValidation,
  resetPassword,
  changeEmail,
  uplaodImageS3,
  uplaodImage,
  uplaodAudio,
  loginCustomer,
  uploadAnySingleFileOnS3,
  updateUserPrevillages,
};
