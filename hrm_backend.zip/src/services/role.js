const { Role } = require("../models/role");
const { find_user, find_user_by_id } = require("../DAL/user");
const {
  add_role,
  find_role_by_id,
  pagination_role,
  all_roles_active,
  all_roles_active_count,
  delete_role_by_id,
  get_role_search,
  role_search_count,
  find_role_by_name,
  get_default_role,
} = require("../DAL/role");
const {
  update_role_title_in_employee,
  update_role_in_employee,
} = require("../DAL/employee");
const {
  MAX_ORDER,
  CHANGE_DEL_ORDER,
  ORDER_CHANGE_TO_LOWER,
  ORDER_CHANGE_TO_UPPER,
} = require("../utils/utils");
const { update_role_in_support_ticket } = require("../DAL/support_ticket");
const { update_role_in_announcement } = require("../DAL/announcement");

const _addRole = async (body, resp) => {
  const role_detail = await find_role_by_name(body.title);
  if (role_detail) {
    resp.error = true;
    resp.error_message = "Role with this title already exists";
    return resp;
  }
  const latest_order = await MAX_ORDER(Role);
  let role_obj = {
    title: body.title,
    order: latest_order + 1,
  };

  const final_role = await add_role(role_obj);
  resp.data = final_role;
  return resp;
};
const addRole = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addRole(body, resp);
  return resp;
};

const _editRole = async (body, role_id, resp) => {
  const role_detail = await find_role_by_id(role_id);
  if (!role_detail) {
    resp.error = true;
    resp.error_message = "Invalid Role ID";
    return resp;
  }

  if (body.order != role_detail.order) {
    const max_order = await MAX_ORDER(Role);
    if (body.order > max_order) {
      resp.error = true;
      resp.error_message =
        "Invalid Order. Order must be less than or equal to " + max_order;
      return resp;
    }
    let current_order = body.order;
    if (body.order < role_detail.order) {
      await ORDER_CHANGE_TO_LOWER(role_id, body.order, role_detail.order, Role);
    } else if (body.order > role_detail.order) {
      await ORDER_CHANGE_TO_UPPER(role_id, body.order, role_detail.order, Role);
    }
  }

  const old_title = role_detail.title;

  role_detail.title = body.title;
  role_detail.order = body.order;
  role_detail.active_status = body.active_status;

  if (old_title != body.title) {
    await update_role_title_in_employee(role_id, body.title);
    await update_role_in_support_ticket(role_id, body.title);
    await update_role_in_announcement(role_id, body.title);
  }

  await role_detail.save();
  resp.data = role_detail;
  return resp;
};
const editRole = async (body, role_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editRole(body, role_id, resp);
  return resp;
};

const _getRole = async (resp) => {
  const role = await all_roles_active();
  // const total_pages = await all_roles_active_count();
  const data = {
    role: role,
  };
  resp.data = data;
  return resp;
};

const getRole = async () => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getRole(resp);
  return resp;
};
const _detailRole = async (role_id, resp) => {
  const role = await find_role_by_id(role_id);
  if (!role) {
    resp.error = true;
    resp.error_message = "Invalid Role ID!";
    return resp;
  }
  resp.data = role;
  return resp;
};

const detailRole = async (role_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailRole(role_id, resp);
  return resp;
};

const _deleteRole = async (role_id, resp) => {
  const role = await find_role_by_id(role_id);
  if (!role) {
    resp.error = true;
    resp.error_message = "Invalid Role ID!";
    return resp;
  }
  if (role.is_default) {
    resp.error = true;
    resp.error_message = "Can't delete default role";
    return resp;
  } else {
    const default_role = await get_default_role();
    if (!default_role) {
      resp.error = true;
      resp.error_message = "Couldn't find default role";
      return resp;
    }
    const deleted_role = await delete_role_by_id(role_id);
    if (!deleted_role) {
      resp.error = true;
      resp.error_message = "Invalid Role ID!";
      return resp;
    }
    await CHANGE_DEL_ORDER(role_id, deleted_role.order, Role);

    await update_role_in_employee(
      role_id,
      default_role._id,
      default_role.title
    );
  }
  return resp;
};

const deleteRole = async (role_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteRole(role_id, resp);
  return resp;
};

const _searchRole = async (Limit, page, search, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;
  const role = await get_role_search(limit, skip, search);
  const total_pages = await role_search_count(search);
  resp.data = {
    role: role,
    total_pages: total_pages,
    load_more_url: `/role/get_role?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchRole = async (limit, page, search) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchRole(limit, page, search, resp);
  return resp;
};
module.exports = {
  addRole,
  editRole,
  getRole,
  detailRole,
  deleteRole,
  searchRole,
};
