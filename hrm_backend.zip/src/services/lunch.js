const {
  add_lunch,
  find_lunch_by_id,
  pagination_lunch,
  delete_lunch_by_id,
  get_lunch_search,
  lunch_search_count,
  find_lunch_for_emp_month_year,
  lunch_search_by_query_obj,
  lunch_search_by_query_obj_count,
} = require("../DAL/lunch");
const {
  find_employee_by_id,
  find_employee_by_user_id,
  get_all_active_hr,
  find_employee_for_lunch,
} = require("../DAL/employee");
const {
  add_notification,
  delete_lunch_notifications,
} = require("../DAL/notification");
const { UPLOAD_IMAGE } = require("../utils/utils");
const { NOTIFICATION_TYPE } = require("../utils/constants");
const moment = require("moment");
const _ = require("lodash");

const _addLunch = async (user_id, body, resp) => {
  [year, month] = body.date.split("-");
  const get_lunch = await find_lunch_for_emp_month_year(
    body.employee,
    month,
    year
  );

  console.log("month: ", month);
  console.log("year: ", year);
  if (get_lunch) {
    resp.error = true;
    resp.error_message = "Lunch for this month already added for this member";
    return resp;
  }

  const employee_detail = await find_employee_by_id(body.employee);
  if (!employee_detail) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  let employee = {
    _id: employee_detail._id,
    name: employee_detail.full_name,
  };

  let lunch_obj = {
    month,
    year,
    employee,
    amount: body.amount,
    paid_status: body.paid_status,
    deadline: moment("10-" + month + "-" + year, "DD-MM-YYYY").utc(true),
  };

  // console.log(moment(lunch_obj.month, "M").format("MMMM"));
  const final_lunch = await add_lunch(lunch_obj);
  if (employee_detail.previllages.lunch.view) {
    let notification_obj = {
      user_id: employee_detail.user_id._id,
      lunch_id: final_lunch._id,
      title: "Lunch Added",
      description:
        "Hi " +
        employee_detail.full_name +
        "! Your lunch has been added for " +
        moment(final_lunch.month, "M").format("MMMM") +
        " " +
        final_lunch.year,
      type: NOTIFICATION_TYPE.lunch,
    };
    await add_notification(notification_obj);
  }

  resp.data = final_lunch;
  return resp;
};
const addLunch = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addLunch(user_id, body, resp);
  return resp;
};

const _editLunch = async (body, lunch_id, resp) => {
  const lunch_detail = await find_lunch_by_id(lunch_id);
  if (!lunch_detail) {
    resp.error = true;
    resp.error_message = "Invalid Lunch ID";
    return resp;
  }

  let month = moment().month() + 1;
  let year = moment().year();

  // console.log("month: ", month);
  // console.log("lunch_detail.active_status: ",lunch_detail.active_status);
  // console.log("body.active_status: ",body.active_status);

  if (lunch_detail.active_status != body.active_status) {
    if (lunch_detail.month != month || lunch_detail.year != year) {
      resp.error = true;
      resp.error_message =
        "Lunch can only be marked as active or inactive for current month";
      return resp;
    }
  }

  lunch_detail.amount = body.amount;
  lunch_detail.paid_status = body.paid_status;
  lunch_detail.active_status = body.active_status;

  await lunch_detail.save();
  resp.data = lunch_detail;
  return resp;
};
const editLunch = async (body, lunch_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editLunch(body, lunch_id, resp);
  return resp;
};

const _detailLunch = async (lunch_id, resp) => {
  const lunch = await find_lunch_by_id(lunch_id);
  if (!lunch) {
    resp.error = true;
    resp.error_message = "Invalid Lunch ID!";
    return resp;
  }
  resp.data = lunch;
  return resp;
};

const detailLunch = async (lunch_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailLunch(lunch_id, resp);
  return resp;
};

const _deleteLunch = async (lunch_id, resp) => {
  const deleted_lunch = await delete_lunch_by_id(lunch_id);
  if (!deleted_lunch) {
    resp.error = true;
    resp.error_message = "Invalid Lunch  ID!";
    return resp;
  }
  await delete_lunch_notifications(deleted_lunch._id);

  return resp;
};

const deleteLunch = async (lunch_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteLunch(lunch_id, resp);
  return resp;
};

const _searchLunch = async (user_id, Limit, page, body, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  const emp_details = await find_employee_by_user_id(user_id);
  const date = new Date();
  let month_from = date.getMonth() + 1;
  let year_from = date.getFullYear();
  let month_to = date.getMonth() + 1;
  let year_to = date.getFullYear();

  let query_obj = { year: year_from, month: month_from };

  if (!_.isEmpty(emp_details)) {
    if (
      emp_details.role.title != "HR" &&
      emp_details.role.title != "Admin" &&
      emp_details.role.title != "All"
    ) {
      query_obj["employee._id"] = emp_details._id;
    }
  }

  if (
    body.date_from &&
    body.date_to &&
    body.date_from != "" &&
    body.date_to != "" &&
    body.date_from != null &&
    body.date_to != null &&
    body.date_from != undefined &&
    body.date_to != undefined
  ) {
    [year_from, month_from] = body.date_from.split("-");
    [year_to, month_to] = body.date_to.split("-");
    query_obj.month = {
      $gte: month_from,
      $lte: month_to,
    };
    query_obj.year = {
      $gte: year_from,
      $lte: year_to,
    };
  }
  if (body.search && body.search != "") {
    query_obj["employee._id"] = body.search;
  }


  const lunch = await get_lunch_search(limit, skip, query_obj);
  const total_pages = await lunch_search_count(query_obj);

  const updated_lunch = await Promise.all(
    lunch.map(async (item) => {
      const emp = await find_employee_for_lunch(item.employee._id);
      if (emp) {
        item.employee.employee_id = emp.employee_id;
      }
      return item;
    })
  );

  resp.data = {
    lunch: updated_lunch,
    total_pages,
    load_more_url: `/lunch/get_lunch?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchLunch = async (user_id, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchLunch(user_id, limit, page, body, resp);
  return resp;
};

const _continueLunch = async (user_id, body, resp) => {
  console.log("body: ", body);
  const get_emp = await find_employee_by_user_id(user_id);
  if (!get_emp) {
    resp.error = true;
    resp.error_message = "Invalid User ID";
    return resp;
  }
  // console.log("get_emp: ", get_emp);
  // let month = moment().month() + 1;
  // let year = moment().year();
  // const lunch_detail = await find_lunch_for_emp_month_year(
  //   get_emp._id,
  //   month,
  //   year
  // );
  // if (!lunch_detail) {
  //   resp.error = true;
  //   resp.error_message = "Lunch not found";
  //   return resp;
  // }

  // console.log("month: ", month);
  // console.log("lunch_detail.active_status: ",lunch_detail.active_status);
  // console.log("body.active_status: ",body.active_status);

  // if (lunch_detail.active_status != body.active_status) {
  //   if (lunch_detail.month != month || lunch_detail.year != year) {
  //     resp.error = true;
  //     resp.error_message =
  //       "Lunch can only be marked as active or inactive for current month";
  //     return resp;
  //   }
  // }

  const get_hrs = await get_all_active_hr();
  if (body.want_lunch != null) {
    if (body.want_lunch) {
      get_emp.want_lunch = true;
      for (let x = 0; x < get_hrs.length; x++) {
        if (get_hrs[x].previllages.lunch.view) {
          let notification_obj = {
            user_id: get_hrs[x].user_id,
            emp_obj_id: get_emp._id,
            title: "Lunch Continue",
            description:
              "Hi! " + get_emp.full_name + " wants to avail lunch facility.",
            type: NOTIFICATION_TYPE.lunch,
          };
          await add_notification(notification_obj);
        }
      }
    } else {
      get_emp.want_lunch = false;

      for (let x = 0; x < get_hrs.length; x++) {
        if (get_hrs[x].previllages.lunch.view) {
          let notification_obj = {
            user_id: get_hrs[x].user_id,
            emp_obj_id: get_emp._id,
            title: "Lunch Discontinued",
            description:
              "Hi! " + get_emp.full_name + " does not want to avail lunch.",
            type: NOTIFICATION_TYPE.lunch,
          };
          await add_notification(notification_obj);
        }
      }
    }
    get_emp.want_lunch = body.want_lunch;
  }

  await get_emp.save();
  resp.data = get_emp;
  return resp;
};

const continueLunch = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _continueLunch(user_id, body, resp);
  return resp;
};

module.exports = {
  addLunch,
  editLunch,
  detailLunch,
  deleteLunch,
  searchLunch,
  continueLunch,
};
