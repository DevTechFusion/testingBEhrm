const { find_user, find_user_by_id } = require("../DAL/user");
const {
  add_company_asset,
  find_company_asset_by_id,
  find_company_asset_by_device_id,
  pagination_company_asset,
  all_company_asset_count,
  delete_company_asset_by_id,
  get_company_asset_search,
  company_asset_search_count,
  find_company_asset_by_name,
  get_all_company_assets,
  assign_company_asset_to_employee,
  unassign_company_asset_to_employee,
  add_company_asset_repair_history,
  edit_company_asset_repair_history,
  delete_company_asset_repair_history,
  get_all_free_active_company_assets,
  get_all_free_active_company_assets_count,
  find_total_cost_of_company_assets,
  company_asset_search_by_query_obj,
  get_company_asset_search_v1,
  get_company_asset_search_v2,
  company_asset_search_count_v2,
  get_amount_of_company_assets,
} = require("../DAL/company_asset");
const {
  find_employee_by_id,
  add_company_asset_to_employee,
  delete_company_asset_from_employee,
} = require("../DAL/employee");
const {
  find_asset_category_by_id,
  find_asset_category_by_id_for_assignable_status,
  get_asset_categories_for_assignable_status,
  get_asset_category_search,
  all_asset_categories_active,
} = require("../DAL/asset_category");
const { find_company_by_id } = require("../DAL/company");
const { find_vendor_by_id, all_vendors_active } = require("../DAL/vendor");
const { find_brand_by_id, all_brands_active } = require("../DAL/brand");
const { UPLOAD_IMAGE_on_S3, UPLOAD_S3_IMAGE } = require("../utils/utils");
const {
  IMAGE_EXTENSIONS,
  ASSET_IMAGE_SIZES,
  ASSET_FILE_PATH,
} = require("../utils/constants");

const path = require("path");
const moment = require("moment");
const _ = require("lodash");

const ObjectId = require("mongodb").ObjectID;

const _addCompanyAsset = async (body, files, resp) => {
  if (body.device_id != "") {
    const asset_detail = await find_company_asset_by_device_id(body.device_id);
    if (asset_detail) {
      resp.error = true;
      resp.error_message = "Asset with same Device ID already exists";
      return resp;
    }
  }

  let images = {};
  let warranty_card_images = {};
  let receipt_images = {};

  // Uploading image for Asset
  if (files) {
    if (files.image) {
      let file_extension = path.extname(files.image.name);
      let file_extension_status = IMAGE_EXTENSIONS.some(
        (extension) => file_extension === extension
      );
      if (file_extension_status == false) {
        resp.error = true;
        resp.error_message =
          "Following  image type is not allowed. The allowed image types are " +
          IMAGE_EXTENSIONS;
        return resp;
      }
      let image = await UPLOAD_IMAGE_on_S3(
        files.image,
        ASSET_IMAGE_SIZES,
        ASSET_FILE_PATH
      );
      if (image) {
        images = image;
      }
    }
  }

  // Uploading image for Warranty Card
  if (files) {
    if (files.warranty_card_image) {
      let file_extension = path.extname(files.warranty_card_image.name);
      let file_extension_status = IMAGE_EXTENSIONS.some(
        (extension) => file_extension === extension
      );
      if (file_extension_status == false) {
        resp.error = true;
        resp.error_message =
          "Following  image type is not allowed. The allowed image types are " +
          IMAGE_EXTENSIONS;
        return resp;
      }
      let warranty_images = await UPLOAD_IMAGE_on_S3(
        files.warranty_card_image,
        ASSET_IMAGE_SIZES,
        ASSET_FILE_PATH
      );
      if (warranty_images) {
        warranty_card_images = warranty_images;
      }
    }
  }

  // Uploading image for Receipt
  if (files) {
    if (files.receipt_image) {
      let file_extension = path.extname(files.receipt_image.name);
      let file_extension_status = IMAGE_EXTENSIONS.some(
        (extension) => file_extension === extension
      );
      if (file_extension_status == false) {
        resp.error = true;
        resp.error_message =
          "Following  image type is not allowed. The allowed image types are " +
          IMAGE_EXTENSIONS;
        return resp;
      }
      let receipt_image = await UPLOAD_IMAGE_on_S3(
        files.receipt_image,
        ASSET_IMAGE_SIZES,
        ASSET_FILE_PATH
      );
      if (receipt_image) {
        receipt_images = receipt_image;
      }
    }
  }

  const get_brand = await find_brand_by_id(body.brand);
  if (!get_brand) {
    resp.error = true;
    resp.error_message = "This brand does not exist. Try again";
    return resp;
  }
  let brand = { _id: get_brand._id, title: get_brand.title };

  const get_asset_category = await find_asset_category_by_id(
    body.asset_category
  );
  if (!get_asset_category) {
    resp.error = true;
    resp.error_message = "This asset category does not exist. Try again";
    return resp;
  }
  let asset_category = {
    _id: get_asset_category._id,
    title: get_asset_category.title,
  };

  const get_vendor = await find_vendor_by_id(body.vendor);
  if (!get_vendor) {
    resp.error = true;
    resp.error_message = "This vendor does not exist. Try again";
    return resp;
  }
  let vendor = { _id: get_vendor._id, name: get_vendor.name };

  let company_asset_obj = {
    title: body.title,
    device_id: body.device_id,
    details: body.details,
    image: images,
    purchase_date: body.purchase_date,
    price: body.price,
    quantity: body.quantity,
    warranty_expire_date: body.warranty_expire_date,
    warranty_card_image: warranty_card_images,
    receipt_image: receipt_images,
    vendor: vendor,
    brand: brand,
    asset_category: asset_category,
    link: body.link,
    // assigned_employee: {},
  };

  const final_company_asset = await add_company_asset(company_asset_obj);
  resp.data = final_company_asset;
  return resp;
};
const addCompanyAsset = async (body, files) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addCompanyAsset(body, files, resp);
  return resp;
};

const _editCompanyAsset = async (body, company_asset_id, files, resp) => {
  const company_asset_detail = await find_company_asset_by_id(company_asset_id);
  if (!company_asset_detail) {
    resp.error = true;
    resp.error_message = "Invalid Company Asset";
    return resp;
  }

  const old_device_id = company_asset_detail.device_id;

  if (old_device_id != body.device_id) {
    if (body.device_id != "") {
      const asset_detail = await find_company_asset_by_device_id(
        body.device_id
      );
      if (asset_detail) {
        resp.error = true;
        resp.error_message = "Asset with same Device ID already exists";
        return resp;
      }
    }
  }

  let images = {};
  let warranty_card_images = {};
  let receipt_images = {};

  // Uploading image for Asset
  if (files) {
    if (files.image) {
      let file_extension = path.extname(files.image.name);
      let file_extension_status = IMAGE_EXTENSIONS.some(
        (extension) => file_extension === extension
      );
      if (file_extension_status == false) {
        resp.error = true;
        resp.error_message =
          "Following  image type is not allowed. The allowed image types are " +
          IMAGE_EXTENSIONS;
        return resp;
      }
      let image = await UPLOAD_IMAGE_on_S3(
        files.image,
        ASSET_IMAGE_SIZES,
        ASSET_FILE_PATH
      );
      if (image) {
        images = image;
      }
    } else {
      images = company_asset_detail.image;
    }
  } else {
    images = company_asset_detail.image;
  }

  // Uploading image for Warranty Card
  if (files) {
    if (files.warranty_card_image) {
      let file_extension = path.extname(files.warranty_card_image.name);
      let file_extension_status = IMAGE_EXTENSIONS.some(
        (extension) => file_extension === extension
      );
      if (file_extension_status == false) {
        resp.error = true;
        resp.error_message =
          "Following  image type is not allowed. The allowed image types are " +
          IMAGE_EXTENSIONS;
        return resp;
      }
      let warranty_images = await UPLOAD_IMAGE_on_S3(
        files.warranty_card_image,
        ASSET_IMAGE_SIZES,
        ASSET_FILE_PATH
      );
      if (warranty_images) {
        warranty_card_images = warranty_images;
      }
    } else {
      warranty_card_images = company_asset_detail.warranty_card_image;
    }
  } else {
    warranty_card_images = company_asset_detail.warranty_card_image;
  }

  if (files) {
    if (files.receipt_image) {
      let file_extension = path.extname(files.receipt_image.name);
      let file_extension_status = IMAGE_EXTENSIONS.some(
        (extension) => file_extension === extension
      );
      if (file_extension_status == false) {
        resp.error = true;
        resp.error_message =
          "Following  image type is not allowed. The allowed image types are " +
          IMAGE_EXTENSIONS;
        return resp;
      }
      let receipt_image = await UPLOAD_IMAGE_on_S3(
        files.receipt_image,
        ASSET_IMAGE_SIZES,
        ASSET_FILE_PATH
      );
      if (receipt_image) {
        receipt_images = receipt_image;
      }
    } else {
      receipt_images = company_asset_detail.receipt_image;
    }
  } else {
    receipt_images = company_asset_detail.receipt_image;
  }

  let old_title = company_asset_detail.title;

  const get_brand = await find_brand_by_id(body.brand);
  if (!get_brand) {
    resp.error = true;
    resp.error_message = "This brand does not exist. Try again";
    return resp;
  }
  let brand = { _id: get_brand._id, title: get_brand.title };

  const get_asset_category = await find_asset_category_by_id(
    body.asset_category
  );
  if (!get_asset_category) {
    resp.error = true;
    resp.error_message = "This asset category does not exist. Try again";
    return resp;
  }
  let asset_category = {
    _id: get_asset_category._id,
    title: get_asset_category.title,
  };

  const get_vendor = await find_vendor_by_id(body.vendor);
  if (!get_vendor) {
    resp.error = true;
    resp.error_message = "This vendor does not exist. Try again";
    return resp;
  }
  let vendor = { _id: get_vendor._id, name: get_vendor.name };

  company_asset_detail.title = body.title;
  company_asset_detail.device_id = body.device_id;
  company_asset_detail.details = body.details;
  company_asset_detail.image = images;
  company_asset_detail.price = body.price;
  company_asset_detail.quantity = body.quantity;
  company_asset_detail.active_status = body.active_status;
  // company_asset_detail.assigned_status = body.assigned_status;
  company_asset_detail.purchase_date = body.purchase_date;
  company_asset_detail.warranty_expire_date = body.warranty_expire_date;
  company_asset_detail.warranty_card_image = warranty_card_images;
  company_asset_detail.receipt_image = receipt_images;
  company_asset_detail.vendor = vendor;
  company_asset_detail.brand = brand;
  company_asset_detail.asset_category = asset_category;
  company_asset_detail.link = body.link;

  if (old_title != body.title) {
  }

  if (body.active_status == "false") {
    const current_date = moment().format("DD/MM/YYYY");
    let unassign_obj = {
      returned_date: current_date,
    };
    await unassign_company_asset_to_employee(company_asset_id, unassign_obj);
  }
  await company_asset_detail.save();
  resp.data = company_asset_detail;
  return resp;
};
const editCompanyAsset = async (body, company_asset_id, files) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editCompanyAsset(body, company_asset_id, files, resp);
  return resp;
};

const _detailCompanyAsset = async (company_asset_id, resp) => {
  const company_asset = await find_company_asset_by_id(company_asset_id);
  if (!company_asset) {
    resp.error = true;
    resp.error_message = "Invalid Company Asset ID!";
    return resp;
  }
  let assigned_employee_images = {};
  if (company_asset.assigned_history.length > 0) {
    for (let i = 0; i < company_asset.assigned_history.length; i++) {
      if (company_asset.assigned_history[i].emp_assigned_status) {
        const get_emp = await find_employee_by_id(
          company_asset.assigned_history[i].emp_obj_id
        );
        if (get_emp) {
          assigned_employee_images = get_emp.profile_pic;
        }
      }
    }
  }
  let assignable_status = false;
  const asset_category_details =
    await find_asset_category_by_id_for_assignable_status(
      company_asset.asset_category._id
    );
  if (asset_category_details) {
    assignable_status = asset_category_details.assignable_status;
  }
  let company_asset_obj = {
    _id: company_asset._id,
    title: company_asset.title,
    device_id: company_asset.device_id,
    details: company_asset.details,
    price: company_asset.price,
    quantity: company_asset.quantity,
    active_status: company_asset.active_status,
    assigned_status: company_asset.assigned_status,
    assignable_status: assignable_status,
    purchase_date: company_asset.purchase_date,
    warranty_expire_date: company_asset.warranty_expire_date,
    vendor: company_asset.vendor,
    brand: company_asset.brand,
    asset_category: company_asset.asset_category,
    assigned_history: company_asset.assigned_history,
    repair_history: company_asset.repair_history,
    assigned_employee_images: assigned_employee_images,
    image: company_asset.image,
    warranty_card_image: company_asset.warranty_card_image,
    receipt_image: company_asset.receipt_image,
    link: company_asset.link,
    createdAt: company_asset.createdAt,
    updatedAt: company_asset.updatedAt,
  };
  resp.data = company_asset_obj;
  return resp;
};

const detailCompanyAsset = async (company_asset_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailCompanyAsset(company_asset_id, resp);
  return resp;
};

const _deleteCompanyAsset = async (company_asset_id, resp) => {
  const company_asset = await find_company_asset_by_id(company_asset_id);
  if (!company_asset) {
    resp.error = true;
    resp.error_message = "Invalid CompanyAsset ID!";
    return resp;
  }
  let emp_object_id = undefined;
  let asset_obj = {
    _id: company_asset_id,
    title: company_asset.title,
  };
  for (let i = 0; i < company_asset.assigned_history.length; i++) {
    if (company_asset.assigned_history[i].emp_assigned_status) {
      emp_object_id = company_asset.assigned_history[i].emp_obj_id;
    }
  }
  await delete_company_asset_by_id(company_asset_id);
  if (emp_object_id != undefined) {
    await delete_company_asset_from_employee(emp_object_id, asset_obj);
  }
  return resp;
};

const deleteCompanyAsset = async (company_asset_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteCompanyAsset(company_asset_id, resp);
  return resp;
};

const _searchCompanyAsset = async (body, Limit, page, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let date_filter_check = false;
  if (
    body.date_from &&
    body.date_to &&
    body.date_from != "" &&
    body.date_to != "" &&
    body.date_from != null &&
    body.date_to != null &&
    body.date_from != undefined &&
    body.date_to != undefined
  ) {
    date_filter_check = true;
  }

  let query_obj = {};

  console.log("body.assigned_status:=============1 ", body.assigned_status);
  //body.assigned_status is boolean check if it is true or false and then add it to query_obj
  if (body.assigned_status != undefined) {
    query_obj["assigned_status"] = body.assigned_status;
  }
  //body.brand is brand id check if it is not empty and then add it to query_obj

  if (body.brand && body.brand != "") {
    query_obj["brand._id"] = body.brand;
  }

  //body.vendor is vendor id check if it is not empty and then add it to query_obj
  if (body.vendor && body.vendor != "") {
    query_obj["vendor._id"] = body.vendor;
  }

  //body.asset_category is asset_category id check if it is not empty and then add it to query_obj
  if (body.asset_category && body.asset_category != "") {
    query_obj["asset_category._id"] = body.asset_category;
  }

  // if (body.asset_category && body.asset_category != "") {
  //   query_obj["asset_category.title"] = {
  //     $regex: new RegExp(body.asset_category, "i"),
  //   };
  // }

  if (body.search && body.search != "") {
    query_obj.$or = [
      { title: { $regex: new RegExp(body.search, "i") } },
      {
        $and: [
          { "assigned_history.emp_assigned_status": true },
          { "assigned_history.name": { $regex: new RegExp(body.search, "i") } },
        ],
      },
    ];
  }

  const company_asset = await get_company_asset_search(query_obj, skip, limit);
  let total_pages = await company_asset_search_count(query_obj);
  // console.log("company_asset: ", company_asset);
  const all_asset_categories =
    await get_asset_categories_for_assignable_status();
  let company_asset_final_arr = [];
  let total_cost = 0;

  for (let i = 0; i < company_asset.length; i++) {
    let category_assignable_status = false;
    let asset_category_id = company_asset[i].asset_category._id.toString();

    category_assignable_status = all_asset_categories.find(
      (category) => category._id.toString() === asset_category_id.toString()
    ).assignable_status;

    // "message": "Cannot read properties of undefined (reading 'assignable_status')"

    if (category_assignable_status == undefined) {
      category_assignable_status = false;
    }

    let company_asset_obj = {
      _id: company_asset[i]._id,
      title: company_asset[i].title,
      device_id: company_asset[i].device_id,
      details: company_asset[i].details,
      image: company_asset[i].image,
      purchase_date: company_asset[i].purchase_date,
      price: company_asset[i].price,
      quantity: company_asset[i].quantity,
      active_status: company_asset[i].active_status,
      assigned_status: company_asset[i].assigned_status,
      warranty_expire_date: company_asset[i].warranty_expire_date,
      warranty_card_image: company_asset[i].warranty_card_image,
      receipt_image: company_asset[i].receipt_image,
      vendor: company_asset[i].vendor,
      brand: company_asset[i].brand,
      asset_category: company_asset[i].asset_category,
      category_assignable_status: category_assignable_status,
      assigned_history: company_asset[i].assigned_history,
      repair_history: company_asset[i].repair_history,
      link: company_asset[i].link,
      createdAt: company_asset[i].createdAt,
      updatedAt: company_asset[i].updatedAt,
    };

    if (date_filter_check) {
      let date_from = moment(body.date_from, "DD-MM-YYYY");
      let date_to = moment(body.date_to, "DD-MM-YYYY");
      let purchase_date = moment(company_asset[i].purchase_date, "DD-MM-YYYY");
      if (purchase_date >= date_from && purchase_date <= date_to) {
        company_asset_final_arr.push(company_asset_obj);
      }
    } else {
      company_asset_final_arr.push(company_asset_obj);
    }
  }

  //total cost of all assets
  total_cost = company_asset_final_arr.reduce((acc, curr) => {
    return acc + curr.price;
  }, 0);

  // if (!_.isEmpty(query_obj) || date_filter_check) {
  //   const filtered_assets = await company_asset_search_by_query_obj(query_obj);
  //   for (let x = 0; x < filtered_assets.length; x++) {
  //     if (date_filter_check) {
  //       let date_from = moment(body.date_from, "DD-MM-YYYY");
  //       let date_to = moment(body.date_to, "DD-MM-YYYY");
  //       let purchase_date = moment(
  //         filtered_assets[x].purchase_date,
  //         "DD-MM-YYYY"
  //       );
  //       if (purchase_date >= date_from && purchase_date <= date_to) {
  //         total_cost += filtered_assets[x].price;
  //       }
  //     } else {
  //       total_cost += filtered_assets[x].price;
  //     }
  //   }
  // } else {
  //   total_cost = company_asset_final_arr.reduce((acc, curr) => {
  //     return acc + curr.price;
  //   }, 0);
  // }

  resp.data = {
    company_asset: company_asset_final_arr,
    total_cost,
    total_pages,
    load_more_url: `/company_asset/get_company_asset?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchCompanyAsset = async (body, limit, page) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchCompanyAsset(body, limit, page, resp);
  return resp;
};
//************************{v1 of search company assets}**********************/

const _searchCompanyAssetV1 = async (body, Limit, page, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let date_filter_check = false;
  if (
    body.date_from &&
    body.date_to &&
    body.date_from != "" &&
    body.date_to != "" &&
    body.date_from != null &&
    body.date_to != null &&
    body.date_from != undefined &&
    body.date_to != undefined
  ) {
    date_filter_check = true;
  }

  let query_obj = {};

  console.log("body.assigned_status:=============1 ", body.assigned_status);
  //body.assigned_status is boolean check if it is true or false and then add it to query_obj
  if (body.assigned_status != undefined) {
    query_obj["assigned_status"] = body.assigned_status;
  }
  //body.brand is brand id check if it is not empty and then add it to query_obj

  if (body.brand && body.brand != "") {
    query_obj["brand._id"] = body.brand;
  }

  //body.vendor is vendor id check if it is not empty and then add it to query_obj
  if (body.vendor && body.vendor != "") {
    query_obj["vendor._id"] = body.vendor;
  }

  //body.asset_category is asset_category id check if it is not empty and then add it to query_obj
  if (body.asset_category && body.asset_category != "") {
    query_obj["asset_category._id"] = body.asset_category;
  }

  if (body.search && body.search != "") {
    query_obj.$or = [
      { title: { $regex: new RegExp(body.search, "i") } },
      {
        $and: [
          { "assigned_history.emp_assigned_status": true },
          { "assigned_history.name": { $regex: new RegExp(body.search, "i") } },
        ],
      },
    ];
  }

  // const company_asset = await get_company_asset_search(query_obj, skip, limit);
  const company_asset = await get_company_asset_search_v1(query_obj);

  // let total_pages = await company_asset_search_count(query_obj);
  // console.log("company_asset: ", company_asset);
  const all_asset_categories =
    await get_asset_categories_for_assignable_status();
  let company_asset_arr = [];
  let company_asset_final_arr = [];
  let total_cost = 0;

  console.log("company_asset: ", company_asset);

  //exchage the place of the code

  if (date_filter_check) {
    for (let i = 0; i < company_asset.length; i++) {
      let date_from = moment(body.date_from, "DD-MM-YYYY");
      let date_to = moment(body.date_to, "DD-MM-YYYY");
      let purchase_date = moment(company_asset[i].purchase_date, "DD-MM-YYYY");
      if (purchase_date >= date_from && purchase_date <= date_to) {
        company_asset_arr.push(company_asset[i]);
      }
    }
  } else {
    company_asset_arr = company_asset;
  }

  console.log("company_asset_arr: ", company_asset_arr);

  for (let i = 0; i < company_asset_arr.length; i++) {
    let category_assignable_status = false;
    let asset_category_id = company_asset_arr[i].asset_category._id.toString();

    category_assignable_status = all_asset_categories.find(
      (category) => category._id.toString() === asset_category_id.toString()
    ).assignable_status;

    let company_asset_obj = {
      _id: company_asset_arr[i]._id,
      title: company_asset_arr[i].title,
      device_id: company_asset_arr[i].device_id,
      details: company_asset_arr[i].details,
      image: company_asset_arr[i].image,
      purchase_date: company_asset_arr[i].purchase_date,
      price: company_asset_arr[i].price,
      quantity: company_asset_arr[i].quantity,
      active_status: company_asset_arr[i].active_status,
      assigned_status: company_asset_arr[i].assigned_status,
      warranty_expire_date: company_asset_arr[i].warranty_expire_date,
      warranty_card_image: company_asset_arr[i].warranty_card_image,
      receipt_image: company_asset_arr[i].receipt_image,
      vendor: company_asset_arr[i].vendor,
      brand: company_asset_arr[i].brand,
      asset_category: company_asset_arr[i].asset_category,
      category_assignable_status: category_assignable_status,
      assigned_history: company_asset_arr[i].assigned_history,
      repair_history: company_asset_arr[i].repair_history,
      link: company_asset_arr[i].link,
      createdAt: company_asset_arr[i].createdAt,
      updatedAt: company_asset_arr[i].updatedAt,
    };

    company_asset_final_arr.push(company_asset_obj);
  }

  //total cost of all assets
  total_cost = company_asset_final_arr.reduce((acc, curr) => {
    return acc + curr.price;
  }, 0);

  let count = company_asset_final_arr.length;
  total_pages = Math.ceil(company_asset_final_arr.length / limit);

  let start = skip;
  let end = skip + limit;
  // Ensure end doesn't exceed the length
  if (end > company_asset_final_arr.length) {
    end = company_asset_final_arr.length;
  }

  company_asset_final_arr = company_asset_final_arr.slice(start, end);

  resp.data = {
    company_asset: company_asset_final_arr,
    total_cost,
    count: count,
    total_pages: total_pages,
    load_more_url: `/company_asset/get_company_asset?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchCompanyAssetV1 = async (body, limit, page) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchCompanyAssetV1(body, limit, page, resp);
  return resp;
};

//************************{v2 of search company assets}**********************/

const _searchCompanyAssetV2 = async (body, Limit, page, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let date_filter_check = false;
  if (
    body.date_from &&
    body.date_to &&
    body.date_from != "" &&
    body.date_to != "" &&
    body.date_from != null &&
    body.date_to != null &&
    body.date_from != undefined &&
    body.date_to != undefined
  ) {
    date_filter_check = true;
  }

  let query_obj = {};

  console.log("body.assigned_status:=============1 ", body.assigned_status);
  //body.assigned_status is boolean check if it is true or false and then add it to query_obj
  if (body.assigned_status != undefined) {
    query_obj["assigned_status"] = body.assigned_status;
  }
  //body.brand is brand id check if it is not empty and then add it to query_obj

  if (body.brand && body.brand != "") {
    query_obj["brand._id"] = ObjectId(body.brand);
  }

  //body.vendor is vendor id check if it is not empty and then add it to query_obj
  if (body.vendor && body.vendor != "") {
    query_obj["vendor._id"] = ObjectId(body.vendor);
  }

  //body.asset_category is asset_category id check if it is not empty and then add it to query_obj
  if (body.asset_category && body.asset_category != "") {
    query_obj["asset_category._id"] = ObjectId(body.asset_category);
  }

  if (body.search && body.search != "") {
    query_obj.$or = [
      { title: { $regex: new RegExp(body.search, "i") } },
      {
        $and: [
          { "assigned_history.emp_assigned_status": true },
          { "assigned_history.name": { $regex: new RegExp(body.search, "i") } },
        ],
      },
    ];
  }

  let new_date_from = "";
  let new_date_to = "";

  if (date_filter_check) {
    new_date_from = moment(body.date_from, "DD/MM/YYYY").format("YYYY-MM-DD");
    new_date_to = moment(body.date_to, "DD/MM/YYYY").format("YYYY-MM-DD");
  }

  var company_asset_arr = [];
  var company_asset_final_arr = [];

  // const company_asset = await get_company_asset_search(query_obj, skip, limit);
  company_asset_arr = await get_company_asset_search_v2(
    query_obj,
    new_date_from,
    new_date_to,
    skip,
    limit
  );

  let count_of_assets = await company_asset_search_count_v2(
    query_obj,
    new_date_from,
    new_date_to
  );
  console.log("count_of_assets===========", count_of_assets);
  const all_asset_categories =
    await get_asset_categories_for_assignable_status();

  const total_price = await get_amount_of_company_assets(
    query_obj,
    new_date_from,
    new_date_to
  );

  console.log("total_price: ", total_price);

  for (let i = 0; i < company_asset_arr.length; i++) {
    let category_assignable_status = false;
    let asset_category_id = company_asset_arr[i].asset_category._id.toString();

    // category_assignable_status = all_asset_categories.find(
    //   (category) => category._id.toString() === asset_category_id.toString()
    // ).assignable_status;
    // let matching_categories = all_asset_categories.filter(
    //   (category) => category._id.toString() === asset_category_id.toString()
    // );

    // // let category_assignable_status;
    // if (matching_categories.length > 0) {
    //   category_assignable_status = matching_categories[0].assignable_status;
    // }

    for (let category of all_asset_categories) {
      if (category._id.toString() === asset_category_id.toString()) {
        category_assignable_status = category.assignable_status;
        break;
      }
    }

    let company_asset_obj = {
      _id: company_asset_arr[i]._id,
      title: company_asset_arr[i].title,
      device_id: company_asset_arr[i].device_id,
      details: company_asset_arr[i].details,
      image: company_asset_arr[i].image,
      purchase_date: company_asset_arr[i].purchase_date,
      price: company_asset_arr[i].price,
      quantity: company_asset_arr[i].quantity,
      active_status: company_asset_arr[i].active_status,
      assigned_status: company_asset_arr[i].assigned_status,
      warranty_expire_date: company_asset_arr[i].warranty_expire_date,
      warranty_card_image: company_asset_arr[i].warranty_card_image,
      receipt_image: company_asset_arr[i].receipt_image,
      vendor: company_asset_arr[i].vendor,
      brand: company_asset_arr[i].brand,
      asset_category: company_asset_arr[i].asset_category,
      category_assignable_status: category_assignable_status,
      assigned_history: company_asset_arr[i].assigned_history,
      // repair_history: company_asset_arr[i].repair_history,
      link: company_asset_arr[i].link,
      createdAt: company_asset_arr[i].createdAt,
      updatedAt: company_asset_arr[i].updatedAt,
    };

    company_asset_final_arr.push(company_asset_obj);
  }

  total_pages = Math.ceil(count_of_assets / limit);

  resp.data = {
    total_price: total_price,
    company_asset: company_asset_final_arr,
    count: count_of_assets,
    total_pages: total_pages - 1,
    load_more_url: `/company_asset/get_company_asset?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchCompanyAssetV2 = async (body, limit, page) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchCompanyAssetV2(body, limit, page, resp);
  return resp;
};

const _assignCompanyAsset = async (asset_id, body, resp) => {
  const asset_detail = await find_company_asset_by_id(asset_id);
  if (!asset_detail) {
    resp.error = true;
    resp.error_message = "Asset with this ID Does Not Exist";
    return resp;
  }
  let emp_object_id = undefined;
  for (let i = 0; i < asset_detail.assigned_history.length; i++) {
    if (asset_detail.assigned_history[i].emp_assigned_status) {
      emp_object_id = asset_detail.assigned_history[i].emp_obj_id;
    }
  }
  let asset_obj = {
    _id: asset_id,
    title: asset_detail.title,
  };
  if (body.assigned_employee.emp_assigned_status) {
    if (asset_detail.assigned_status) {
      resp.error = true;
      resp.error_message = "This Asset is already Assigned";
      return resp;
    }
    await assign_company_asset_to_employee(asset_id, body.assigned_employee);
    await add_company_asset_to_employee(
      body.assigned_employee.emp_obj_id,
      asset_obj
    );
  }
  if (!body.assigned_employee.emp_assigned_status) {
    if (!asset_detail.assigned_status) {
      resp.error = true;
      resp.error_message = "This Asset is already Not Assigned";
      return resp;
    }
    await unassign_company_asset_to_employee(asset_id, body.assigned_employee);
    if (emp_object_id != undefined) {
      await delete_company_asset_from_employee(emp_object_id, asset_obj);
    }
  }
  // resp.data = final_obj;
  return resp;
};
const assignCompanyAsset = async (asset_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _assignCompanyAsset(asset_id, body, resp);
  return resp;
};

const _addRepairHistoryCompanyAsset = async (asset_id, body, resp) => {
  const asset_detail = await find_company_asset_by_id(asset_id);
  if (!asset_detail) {
    resp.error = true;
    resp.error_message = "Asset with this ID Does Not Exist";
    return resp;
  }

  await add_company_asset_repair_history(asset_id, body.repair_details);

  return resp;
};
const addRepairHistoryCompanyAsset = async (asset_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addRepairHistoryCompanyAsset(asset_id, body, resp);
  return resp;
};

const _editRepairHistoryCompanyAsset = async (asset_id, body, resp) => {
  const asset_detail = await find_company_asset_by_id(asset_id);
  if (!asset_detail) {
    resp.error = true;
    resp.error_message = "Asset with this ID Does Not Exist";
    return resp;
  }

  await edit_company_asset_repair_history(asset_id, body.repair_details);

  return resp;
};

const editRepairHistoryCompanyAsset = async (asset_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editRepairHistoryCompanyAsset(asset_id, body, resp);
  return resp;
};

const _deleteRepairHistoryCompanyAsset = async (asset_id, body, resp) => {
  const asset_detail = await find_company_asset_by_id(asset_id);
  if (!asset_detail) {
    resp.error = true;
    resp.error_message = "Asset with this ID Does Not Exist";
    return resp;
  }

  await delete_company_asset_repair_history(asset_id, body._id);

  return resp;
};

const deleteRepairHistoryCompanyAsset = async (asset_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteRepairHistoryCompanyAsset(asset_id, body, resp);
  return resp;
};

const _getAllFreeActiveCompanyAssets = async (resp) => {
  const company_asset = await get_all_free_active_company_assets();
  const total_pages = await get_all_free_active_company_assets_count();
  const data = {
    company_asset: company_asset,
    total_pages: total_pages,
  };
  resp.data = data;
  return resp;
};

const getAllFreeActiveCompanyAssets = async () => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getAllFreeActiveCompanyAssets(resp);
  return resp;
};

const _getDataForCompanyAssetList = async (resp) => {
  const category_list = await all_asset_categories_active();

  const vendor_list = await all_vendors_active();

  const brand_list = await all_brands_active();

  console.log("category_list: ", category_list);
  console.log("vendor_list: ", vendor_list);
  console.log("brand_list: ", brand_list);

  resp.data = {
    category_list: category_list,
    vendor_list: vendor_list,
    brand_list: brand_list,
  };
  return resp;
};

const getDataForCompanyAssetList = async () => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getDataForCompanyAssetList(resp);
  return resp;
};

module.exports = {
  addCompanyAsset,
  editCompanyAsset,
  detailCompanyAsset,
  deleteCompanyAsset,
  searchCompanyAsset,
  searchCompanyAssetV1,
  searchCompanyAssetV2,
  assignCompanyAsset,
  addRepairHistoryCompanyAsset,
  editRepairHistoryCompanyAsset,
  deleteRepairHistoryCompanyAsset,
  getAllFreeActiveCompanyAssets,
  getDataForCompanyAssetList,
};
