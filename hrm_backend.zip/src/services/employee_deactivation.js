const {
  find_user,
  find_user_by_id,
  add_user,
  delete_user_by_id,
} = require("../DAL/user");
const {
  mark_employee_inactive,
  delete_company_asset_from_employee,
  find_employee_by_id,
} = require("../DAL/employee");
const { unassign_company_asset_to_employee } = require("../DAL/company_asset");
const {
  add_employee_deactivation,
  find_employee_deactivation_by_id,
  total_deactivated_employee,
  latest_deactivated_employee,
  pagination_employee_deactivation,
  delete_employee_deactivation_by_id,
  get_employee_search,
  employee_search_count,
  find_employee_deactivation_by_employee_id,
} = require("../DAL/employee_deactivation");
const {
  add_to_session,
  delete_from_session_by_user_id,
} = require("../DAL/session");
const {
  update_employee_deactivation_lead_in_department,
  update_employee_deactivation_in_department_members,
} = require("../DAL/department");

const moment = require("moment");

const _addEmployeeDeactivation = async (body, resp) => {
  const get_employee_deactivation =
    await find_employee_deactivation_by_employee_id(body.employee._id);
  if (get_employee_deactivation) {
    resp.error = true;
    resp.error_message = "Member Already Deactivated";
    return resp;
  }
  const get_employee_details = await find_employee_by_id(body.employee._id);
  if (!get_employee_details) {
    resp.error = true;
    resp.error_message = "Member Not Found";
    return resp;
  }
  let employee_deactivation_obj = {
    employee: body.employee,
    leaving_reason: body.leaving_reason,
    leaving_reason_detail: body.leaving_reason_detail,
    hr_comments: body.hr_comments,
    clearance_status: body.clearance_status,
  };
  // add employee_deactivation

  const final_employee_deactivation = await add_employee_deactivation(
    employee_deactivation_obj
  );

  if (final_employee_deactivation) {
    await mark_employee_inactive(body.employee._id);
  }

  if (final_employee_deactivation.clearance_status) {
    if (get_employee_details.company_assets.length > 0) {
      let company_assets = get_employee_details.company_assets;
      for (let j = 0; j < company_assets.length; j++) {
        const current_date = moment().format("DD/MM/YYYY");
        let unassign_obj = {
          returned_date: current_date,
        };
        await unassign_company_asset_to_employee(
          company_assets[j]._id,
          unassign_obj
        );
        let asset_obj = {
          _id: company_assets[j]._id,
          title: company_assets[j].title,
        };

        await delete_company_asset_from_employee(
          get_employee_details._id,
          asset_obj
        );
      }
    }
  }

  resp.data = final_employee_deactivation;
  return resp;
};
const addEmployeeDeactivation = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addEmployeeDeactivation(body, resp);
  return resp;
};

const _editEmployeeDeactivation = async (
  body,
  user_id,
  employee_deactivation_id,
  resp
) => {
  const employee_deactivation_detail = await find_employee_deactivation_by_id(
    employee_deactivation_id
  );
  if (!employee_deactivation_detail) {
    resp.error = true;
    resp.error_message = "Invalid Member Deactivation ID";
    return resp;
  }

  employee_deactivation_detail.employee = body.employee;
  employee_deactivation_detail.leaving_reason = body.leaving_reason;
  employee_deactivation_detail.leaving_reason_detail =
    body.leaving_reason_detail;
  employee_deactivation_detail.hr_comments = body.hr_comments;
  employee_deactivation_detail.clearance_status = body.clearance_status;

  if (employee_deactivation_detail.clearance_status) {
    if (employee.company_assets.length > 0) {
      let company_assets = employee.company_assets;
      for (let j = 0; j < company_assets.length; j++) {
        const current_date = moment().format("DD/MM/YYYY");
        let unassign_obj = {
          returned_date: current_date,
        };
        await unassign_company_asset_to_employee(
          company_assets[j]._id,
          unassign_obj
        );
        let asset_obj = {
          _id: company_assets[j]._id,
          title: company_assets[j].title,
        };
        await delete_company_asset_from_employee(employee._id, asset_obj);
      }
    }
  }

  await employee_deactivation_detail.save();
  resp.data = employee_deactivation_detail;
  return resp;
};
const editEmployeeDeactivation = async (
  body,
  user_id,
  employee_deactivation_id
) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editEmployeeDeactivation(
    body,
    user_id,
    employee_deactivation_id,
    resp
  );
  return resp;
};

const _getEmployeeDeactivations = async (search, Limit, page, resp) => {
  // pagination
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;
  const employee_deactivation = await pagination_employee_deactivation(
    search,
    skip,
    limit
  );
  // count all employee_deactivation
  const total_pages = await employee_search_count(search);
  const data = {
    employee_deactivation: employee_deactivation,
    total_pages: total_pages,
    load_more_url: `/employee_deactivation/get_employee_deactivations?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getEmployeeDeactivations = async (search, limit, page) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getEmployeeDeactivations(search, limit, page, resp);
  return resp;
};
const _detailEmployeeDeactivation = async (emp_id, resp) => {
  const employee_deactivation = await find_employee_deactivation_by_employee_id(
    emp_id
  );
  if (!employee_deactivation) {
    resp.error = true;
    resp.error_message = "Invalid Member Deactivation ID!";
    return resp;
  }
  resp.data = employee_deactivation;
  return resp;
};

const detailEmployeeDeactivation = async (emp_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailEmployeeDeactivation(emp_id, resp);
  return resp;
};

const _detailEmployeeDeactivationByID = async (
  employee_deactivation_id,
  resp
) => {
  const employee_deactivation = await find_employee_deactivation_by_id(
    employee_deactivation_id
  );
  if (!employee_deactivation) {
    resp.error = true;
    resp.error_message = "Invalid Member Deactivation ID!";
    return resp;
  }
  resp.data = employee_deactivation;
  return resp;
};

const detailEmployeeDeactivationByID = async (employee_deactivation_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailEmployeeDeactivationByID(employee_deactivation_id, resp);
  return resp;
};

const _deleteEmployeeDeactivation = async (employee_deactivation_id, resp) => {
  // find by id
  const employee_deactivation = await find_employee_deactivation_by_id(
    employee_deactivation_id
  );
  if (!employee_deactivation) {
    resp.error = true;
    resp.error_message = "Invalid Member Deactivation ID!";
    return resp;
  }
  // delete employee_deactivation
  const deleted_employee_deactivation =
    await delete_employee_deactivation_by_id(employee_deactivation._id);
  return resp;
};

const deleteEmployeeDeactivation = async (employee_deactivation_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteEmployeeDeactivation(employee_deactivation_id, resp);
  return resp;
};

module.exports = {
  addEmployeeDeactivation,
  editEmployeeDeactivation,
  getEmployeeDeactivations,
  detailEmployeeDeactivation,
  detailEmployeeDeactivationByID,
  deleteEmployeeDeactivation,
};
