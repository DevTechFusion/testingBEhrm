const { find_user, find_user_by_id } = require("../DAL/user");
const {
  add_asset_category,
  find_asset_category_by_id,
  pagination_asset_category,
  all_asset_categories_active,
  all_asset_categories_active_count,
  delete_asset_category_by_id,
  get_asset_category_search,
  asset_category_search_count,
  find_asset_category_by_name,
} = require("../DAL/asset_category");
const {
  update_vendor_in_company_assets,
  update_asset_category_in_company_assets,
} = require("../DAL/company_asset");

const _addAssetCategory = async (body, resp) => {
  const asset_category_detail = await find_asset_category_by_name(body.title);
  if (asset_category_detail) {
    resp.error = true;
    resp.error_message = "Asset Category already exists";
    return resp;
  }
  let asset_category_obj = {
    title: body.title,
    description: body.description,
    assignable_status: body.assignable_status,
  };

  const final_asset_category = await add_asset_category(asset_category_obj);
  resp.data = final_asset_category;
  return resp;
};
const addAssetCategory = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addAssetCategory(body, resp);
  return resp;
};

const _editAssetCategory = async (body, asset_category_id, resp) => {
  const asset_category_detail = await find_asset_category_by_id(
    asset_category_id
  );
  if (!asset_category_detail) {
    resp.error = true;
    resp.error_message = "Invalid Asset Category";
    return resp;
  }
  const old_title = asset_category_detail.title;

  asset_category_detail.title = body.title;
  asset_category_detail.description = body.description;
  asset_category_detail.active_status = body.active_status;
  asset_category_detail.assignable_status = body.assignable_status;

  if (old_title != body.title) {
    await update_asset_category_in_company_assets(
      asset_category_id,
      body.title
    );
  }

  await asset_category_detail.save();
  resp.data = asset_category_detail;
  return resp;
};
const editAssetCategory = async (body, asset_category_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editAssetCategory(body, asset_category_id, resp);
  return resp;
};

const _getAssetCategory = async (resp) => {
  const asset_category = await all_asset_categories_active();
  // const total_pages = await all_asset_categories_active_count();
  const data = {
    asset_category: asset_category,
  };
  resp.data = data;
  return resp;
};

const getAssetCategory = async () => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getAssetCategory(resp);
  return resp;
};
const _detailAssetCategory = async (asset_category_id, resp) => {
  const asset_category = await find_asset_category_by_id(asset_category_id);
  if (!asset_category) {
    resp.error = true;
    resp.error_message = "Invalid AssetCategory ID!";
    return resp;
  }
  resp.data = asset_category;
  return resp;
};

const detailAssetCategory = async (asset_category_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailAssetCategory(asset_category_id, resp);
  return resp;
};

const _deleteAssetCategory = async (asset_category_id, resp) => {
  const deleted_asset_category = await delete_asset_category_by_id(
    asset_category_id
  );
  if (!deleted_asset_category) {
    resp.error = true;
    resp.error_message = "Invalid Asset Category ID!";
    return resp;
  }
  return resp;
};

const deleteAssetCategory = async (asset_category_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteAssetCategory(asset_category_id, resp);
  return resp;
};

const _searchAssetCategory = async (Limit, page, search, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;
  const asset_category = await get_asset_category_search(limit, skip, search);
  const total_pages = await asset_category_search_count(search);
  resp.data = {
    asset_category: asset_category,
    total_pages: total_pages,
    load_more_url: `/asset_category/get_asset_category?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchAssetCategory = async (limit, page, search) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchAssetCategory(limit, page, search, resp);
  return resp;
};
module.exports = {
  addAssetCategory,
  editAssetCategory,
  getAssetCategory,
  detailAssetCategory,
  deleteAssetCategory,
  searchAssetCategory,
};
