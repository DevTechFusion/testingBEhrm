const { find_user, find_user_by_id } = require("../DAL/user");
const { find_topup_amount_by_query_obj } = require("../DAL/top_up");
const {
  add_expense,
  find_expense_by_id,
  pagination_expense,
  all_expense_categories_active,
  all_expense_categories_active_count,
  delete_expense_by_id,
  get_expense_search,
  expense_search_count,
  find_expense_by_name,
  expense_search_by_query_obj,
  expense_search_by_query_obj_count,
  get_expense_tax,
} = require("../DAL/expense");
const {
  find_employee_by_id,
  find_employee_by_user_id,
} = require("../DAL/employee");
const { find_vendor_by_id } = require("../DAL/vendor");
const { find_expense_category_by_id } = require("../DAL/expense_category");
const { UPLOAD_IMAGE } = require("../utils/utils");
const { PREVILLAGES } = require("../utils/constants");
const moment = require("moment");
const _ = require("lodash");

const _addExpense = async (user_id, body, resp) => {
  const added_employee_detail = await find_employee_by_user_id(user_id);
  if (!added_employee_detail) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  let added_by = {
    _id: added_employee_detail._id,
    name: added_employee_detail.full_name,
  };
  let expense_category = {};
  let vendor = {};
  let employee = {};
  const category_detail = await find_expense_category_by_id(
    body.expense_category
  );
  if (!category_detail) {
    resp.error = true;
    resp.error_message = "Category not found";
    return resp;
  } else {
    expense_category._id = category_detail._id;
    expense_category.title = category_detail.title;
  }
  const vendor_detail = await find_vendor_by_id(body.vendor);
  if (!vendor_detail) {
    resp.error = true;
    resp.error_message = "Vendor not found";
    return resp;
  } else {
    vendor._id = vendor_detail._id;
    vendor.name = vendor_detail.name;
  }
  if (body.employee && body.employee != null && body.employee != undefined) {
    const employee_detail = await find_employee_by_id(body.employee);
    if (!employee_detail) {
      resp.error = true;
      resp.error_message = "Member not found";
      return resp;
    } else {
      employee._id = employee_detail._id;
      employee.name = employee_detail.full_name;
    }
  }
  let expense_obj = {
    title: body.title,
    amount: body.amount,
    payment_method: body.payment_method,
    date: moment(body.date, "DD-MM-YYYY").utc(true),
    attachment: body.attachment,
    notes: body.notes,
    vendor: vendor,
    employee: employee,
    tax_type: body.tax_type,
    tax_amount: body.tax_amount,
    link: body.link,
    other_link: body.other_link,
    expense_category: expense_category,
    added_by: added_by,
  };

  const final_expense = await add_expense(expense_obj);
  if (final_expense) {
    added_employee_detail.total_balance -= final_expense.amount;
    await added_employee_detail.save();
  }
  resp.data = final_expense;
  return resp;
};
const addExpense = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addExpense(user_id, body, resp);
  return resp;
};

const _editExpense = async (body, expense_id, resp) => {
  const expense_detail = await find_expense_by_id(expense_id);
  if (!expense_detail) {
    resp.error = true;
    resp.error_message = "Invalid Expense ID";
    return resp;
  }

  let expense_category = expense_detail.expense_category;
  let vendor = expense_detail.vendor;
  let employee = expense_detail.employee;
  if (expense_category._id != body.expense_category) {
    const category_detail = await find_expense_category_by_id(
      body.expense_category
    );
    if (!category_detail) {
      resp.error = true;
      resp.error_message = "Category not found";
      return resp;
    } else {
      expense_category._id = category_detail._id;
      expense_category.title = category_detail.title;
    }
  }
  if (vendor._id != body.vendor) {
    const vendor_detail = await find_vendor_by_id(body.vendor);
    if (!vendor_detail) {
      resp.error = true;
      resp.error_message = "Vendor not found";
      return resp;
    } else {
      vendor._id = vendor_detail._id;
      vendor.name = vendor_detail.name;
    }
  }
  if (employee._id != body.employee) {
    if (body.employee && body.employee != null && body.employee != undefined) {
      const employee_detail = await find_employee_by_id(body.employee);
      if (!employee_detail) {
        resp.error = true;
        resp.error_message = "Member not found";
        return resp;
      } else {
        employee._id = employee_detail._id;
        employee.name = employee_detail.full_name;
      }
    }
  }

  if (expense_detail.amount != body.amount) {
    const added_by_detail = await find_employee_by_id(
      expense_detail.added_by._id
    );
    if (!added_by_detail) {
      resp.error = true;
      resp.error_message = "Member not found";
      return resp;
    }

    added_by_detail.total_balance += expense_detail.amount;
    added_by_detail.total_balance -= body.amount;
    await added_by_detail.save();
  }

  // let active_status = false;
  // if (body.active_status.toLowerCase() == "true") {
  //   active_status = true;
  // }

  expense_detail.title = body.title;
  expense_detail.amount = body.amount;
  expense_detail.payment_method = body.payment_method;
  expense_detail.date = moment(body.date, "DD-MM-YYYY").utc(true);
  expense_detail.attachment = body.attachment;
  expense_detail.notes = body.notes;
  expense_detail.vendor = vendor;
  expense_detail.employee = employee;
  expense_detail.tax_type = body.tax_type;
  expense_detail.tax_amount = body.tax_amount;
  expense_detail.expense_category = expense_category;
  expense_detail.link = body.link;
  expense_detail.other_link = body.other_link;
  expense_detail.active_status = body.active_status;

  await expense_detail.save();
  resp.data = expense_detail;
  return resp;
};
const editExpense = async (body, expense_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editExpense(body, expense_id, resp);
  return resp;
};

const _detailExpense = async (expense_id, resp) => {
  const expense = await find_expense_by_id(expense_id);
  if (!expense) {
    resp.error = true;
    resp.error_message = "Invalid Expense  ID!";
    return resp;
  }
  resp.data = expense;
  return resp;
};

const detailExpense = async (expense_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailExpense(expense_id, resp);
  return resp;
};

const _deleteExpense = async (expense_id, resp) => {
  const deleted_expense = await delete_expense_by_id(expense_id);
  if (!deleted_expense) {
    resp.error = true;
    resp.error_message = "Invalid Expense  ID!";
    return resp;
  }
  const added_by_detail = await find_employee_by_id(
    deleted_expense.added_by._id
  );
  if (added_by_detail) {
    added_by_detail.total_balance += deleted_expense.amount;
    await added_by_detail.save();
  }
  return resp;
};

const deleteExpense = async (expense_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteExpense(expense_id, resp);
  return resp;
};

const _searchExpense = async (user_id, Limit, page, body, resp) => {
  // let available_balance = 0;
  // const employee_detail = await find_employee_by_user_id(user_id);
  // if (employee_detail) {
  //   available_balance = employee_detail.total_balance;
  // }

  let query_for_topup = {};
  if (
    body.date_from &&
    body.date_to &&
    body.date_from != "" &&
    body.date_to != "" &&
    body.date_from != null &&
    body.date_to != null &&
    body.date_from != undefined &&
    body.date_to != undefined
  ) {
    query_for_topup.date = {
      $gte: moment(body.date_from, "DD-MM-YYYY").utc(true).toDate(),
      $lte: moment(body.date_to, "DD-MM-YYYY").utc(true).toDate(),
    };
  }

  const total_topup_amount = await find_topup_amount_by_query_obj(
    query_for_topup
  );

  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let query_obj = {};
  if (
    body.date_from &&
    body.date_to &&
    body.date_from != "" &&
    body.date_to != "" &&
    body.date_from != null &&
    body.date_to != null &&
    body.date_from != undefined &&
    body.date_to != undefined
  ) {
    query_obj.date = {
      $gte: moment(body.date_from, "DD-MM-YYYY").utc(true).toDate(),
      $lte: moment(body.date_to, "DD-MM-YYYY").utc(true).toDate(),
    };
  }
  if (body.search && body.search != "") {
    query_obj.$or = [
      { title: { $regex: new RegExp(body.search, "i") } },
      { "added_by.name": { $regex: new RegExp(body.search, "i") } },
    ];
  }
  if (body.payment_method && body.payment_method != "") {
    query_obj.payment_method = { $regex: new RegExp(body.payment_method, "i") };
  }
  if (body.expense_category && body.expense_category != "") {
    query_obj["expense_category.title"] = {
      $regex: new RegExp(body.expense_category, "i"),
    };
  }
  if (body.tax_type) {
    query_obj.tax_type = body.tax_type;
  }

  const expense = await get_expense_search(limit, skip, query_obj);
  const total_pages = await expense_search_count(query_obj);

  const { total_expense, total_tax } = await get_expense_tax(query_obj);

  let tax_amount = total_tax;

  // if (!_.isEmpty(query_obj)) {
  //   const filtered_expenses = await expense_search_by_query_obj(query_obj);
  //   for (let i = 0; i < filtered_expenses.length; i++) {
  //     total_expense += filtered_expenses[i].amount;
  //     tax_amount += filtered_expenses[i].tax_amount;
  //   }
  // } else {
  //   for (let i = 0; i < expense.length; i++) {
  //     total_expense += expense[i].amount;
  //     tax_amount += expense[i].tax_amount;
  //   }
  // }
  let available_balance = total_topup_amount - total_expense;
  resp.data = {
    expense,
    total_pages,
    available_balance,
    total_expense,
    tax_amount,
    load_more_url: `/expense/get_expense?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchExpense = async (user_id, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchExpense(user_id, limit, page, body, resp);
  return resp;
};

const _maintainExpense = async (user_id, resp) => {
  const emp = await find_employee_by_user_id(user_id);
  if (!emp) {
    resp.error = true;
    resp.error_message = "Member not found!";
    return resp;
  }

  let query_obj = { "added_by._id": emp._id };

  const expense = await expense_search_by_query_obj(query_obj);

  let expense_balance = 0;
  for (let i = 0; i < expense.length; i++) {
    expense_balance += expense[i].amount;
  }

  console.log("expense_balance: ", expense_balance);
  console.log("old emp.total_balance: ", emp.total_balance);
  emp.total_balance -= expense_balance;
  await emp.save();

  console.log("new emp.total_balance: ", emp.total_balance);

  return resp;
};

const maintainExpense = async (user_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _maintainExpense(user_id, resp);
  return resp;
};

module.exports = {
  addExpense,
  editExpense,
  detailExpense,
  deleteExpense,
  searchExpense,
  maintainExpense,
};
