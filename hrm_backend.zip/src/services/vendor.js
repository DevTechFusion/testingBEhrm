const { find_user, find_user_by_id } = require("../DAL/user");
const {
  add_vendor,
  find_vendor_by_id,
  pagination_vendor,
  all_vendors_active,
  all_vendors_active_count,
  delete_vendor_by_id,
  get_vendor_search,
  vendor_search_count,
  find_vendor_by_email,
} = require("../DAL/vendor");
const {
  update_vendor_in_company_assets,
  update_vendor_in_company_asset_repair_history,
} = require("../DAL/company_asset");
const { update_vendor_in_expense } = require("../DAL/expense");
const { UPLOAD_IMAGE_on_S3 } = require("../utils/utils");
const {
  IMAGE_EXTENSIONS,
  VENDOR_IMAGE_SIZES,
  VENDOR_FILE_PATH,
} = require("../utils/constants.js");
const path = require("path");

const _addVendor = async (body, files, resp) => {
  if (body.email != "") {
    const user = await find_vendor_by_email(body.email);
    if (user) {
      resp.error = true;
      resp.error_message = "Email Already Exists";
      return resp;
    }
  }

  let images = {};
  if (files) {
    let file_extension = path.extname(files.image.name);
    let file_extension_status = IMAGE_EXTENSIONS.some(
      (extension) => file_extension === extension
    );
    if (file_extension_status == false) {
      resp.error = true;
      resp.error_message =
        "Following  image type is not allowed. The allowed image types are " +
        IMAGE_EXTENSIONS;
      return resp;
    }
    let image = await UPLOAD_IMAGE_on_S3(
      files.image,
      VENDOR_IMAGE_SIZES,
      VENDOR_FILE_PATH
    );

    if (image) {
      images = image;
    }
  }
  let vendor_obj = {
    name: body.name,
    email: body.email,
    contact_number: body.contact_number,
    address: body.address,
    image: images,
  };

  const final_vendor = await add_vendor(vendor_obj);
  resp.data = final_vendor;
  return resp;
};
const addVendor = async (body, files) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addVendor(body, files, resp);
  return resp;
};

const _editVendor = async (body, vendor_id, files, resp) => {
  const vendor_detail = await find_vendor_by_id(vendor_id);
  if (!vendor_detail) {
    resp.error = true;
    resp.error_message = "Invalid Vendor";
    return resp;
  }

  if (vendor_detail.email != body.email) {
    if (body.email != "") {
      const check_email = await find_vendor_by_email(body.email);
      if (check_email) {
        resp.error = true;
        resp.error_message = "Vendor with this email already exist";
        return resp;
      }
    }
  }

  let images = {};

  if (files) {
    let file_extension = path.extname(files.image.name);
    let file_extension_status = IMAGE_EXTENSIONS.some(
      (extension) => file_extension === extension
    );
    if (file_extension_status == false) {
      resp.error = true;
      resp.error_message =
        "Following  image type is not allowed. The allowed image types are " +
        IMAGE_EXTENSIONS;
      return resp;
    }
    let image = await UPLOAD_IMAGE_on_S3(
      files.image,
      VENDOR_IMAGE_SIZES,
      VENDOR_FILE_PATH
    );

    if (image) {
      images = image;
    }
  } else {
    images = vendor_detail.image;
  }

  const old_name = vendor_detail.name;

  vendor_detail.name = body.name;
  vendor_detail.email = body.email;
  vendor_detail.contact_number = body.contact_number;
  vendor_detail.active_status = body.active_status;
  vendor_detail.address = body.address;
  vendor_detail.image = images;

  if (old_name != body.name) {
    await update_vendor_in_company_assets(vendor_id, body.name);
    await update_vendor_in_company_asset_repair_history(vendor_id, body.name);
    await update_vendor_in_expense(vendor_id, body.name);
  }

  await vendor_detail.save();
  resp.data = vendor_detail;
  return resp;
};
const editVendor = async (body, vendor_id, files) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editVendor(body, vendor_id, files, resp);
  return resp;
};

const _getAllActiveVendors = async (resp) => {
  const vendor = await all_vendors_active();
  // const total_pages = await all_vendors_active_count();
  const data = {
    vendor: vendor,
  };
  resp.data = data;
  return resp;
};

const getAllActiveVendors = async () => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getAllActiveVendors(resp);
  return resp;
};
const _detailVendor = async (vendor_id, resp) => {
  const vendor = await find_vendor_by_id(vendor_id);
  if (!vendor) {
    resp.error = true;
    resp.error_message = "Invalid Vendor ID!";
    return resp;
  }
  resp.data = vendor;
  return resp;
};

const detailVendor = async (vendor_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailVendor(vendor_id, resp);
  return resp;
};

const _deleteVendor = async (vendor_id, resp) => {
  const deleted_vendor = await delete_vendor_by_id(vendor_id);
  if (!deleted_vendor) {
    resp.error = true;
    resp.error_message = "Invalid Vendor ID!";
    return resp;
  }
  return resp;
};

const deleteVendor = async (vendor_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteVendor(vendor_id, resp);
  return resp;
};

const _searchVendor = async (search, Limit, page, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;
  const vendor = await get_vendor_search(limit, skip, search);
  const total_pages = await vendor_search_count(search);
  resp.data = {
    vendor: vendor,
    total_pages: total_pages,
    load_more_url: `/vendor/get_vendor?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchVendor = async (search, limit, page) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchVendor(search, limit, page, resp);
  return resp;
};
module.exports = {
  addVendor,
  editVendor,
  getAllActiveVendors,
  detailVendor,
  deleteVendor,
  searchVendor,
};
