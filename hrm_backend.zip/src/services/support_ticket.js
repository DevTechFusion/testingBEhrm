const { find_user, find_user_by_id } = require("../DAL/user");
const {
  add_support_ticket,
  find_support_ticket_by_id,
  pagination_support_ticket,
  all_support_tickets_active,
  all_support_tickets_active_count,
  delete_support_ticket_by_id,
  get_support_ticket_search,
  support_ticket_search_count,
  find_support_ticket_by_emp_and_date,
  find_support_tickets_for_employee,
  search_support_tickets_by_query_obj,
  find_support_ticket_by_id_with_populate,
} = require("../DAL/support_ticket");
const {
  find_employee_by_id,
  find_employee_by_user_id,
  get_active_employees_role_based,
  get_active_employees_role_based_except_employee,
  get_all_active_employees,
} = require("../DAL/employee");
const {
  add_notification,
  delete_support_ticket_notifications,
} = require("../DAL/notification");
const { NOTIFICATION_TYPE } = require("../utils/constants");
const { find_role_by_id } = require("../DAL/role");
const { UPLOAD_IMAGE } = require("../utils/utils");
const moment = require("moment");
const _ = require("lodash");

const _addSupportTicket = async (user_id, body, resp) => {
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  const role_details = await find_role_by_id(body.support_type);
  if (!role_details) {
    resp.error = true;
    resp.error_message = "Invalid Support Type";
    return resp;
  }
  let all_employees_role_based = [];
  if (role_details.title == "All") {
    all_employees_role_based =
      await get_active_employees_role_based_except_employee();
  } else {
    all_employees_role_based = await get_active_employees_role_based(
      role_details._id
    );
  }

  let support_type = { _id: role_details._id, title: role_details.title };

  let support_ticket_obj = {
    emp_obj_id: emp_details._id,
    emp_name: emp_details.full_name,
    title: body.title,
    description: body.description,
    priority: body.priority,
    support_type: support_type,
    image: body.image,
  };
  const final_support_ticket = await add_support_ticket(support_ticket_obj);
  for (let j = 0; j < all_employees_role_based.length; j++) {
    if (all_employees_role_based[j].previllages.support.view) {
      let notification_obj = {
        user_id: all_employees_role_based[j].user_id,
        support_ticket_id: final_support_ticket._id,
        title: "Support Ticket",
        description:
          "Hi! " + emp_details.full_name + " just posted a support ticket",
        type: NOTIFICATION_TYPE.support_ticket,
      };
      await add_notification(notification_obj);
    }
  }

  resp.data = final_support_ticket;
  return resp;
};
const addSupportTicket = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addSupportTicket(user_id, body, resp);
  return resp;
};

const _editSupportTicket = async (user_id, support_ticket_id, body, resp) => {
  const support_ticket_detail = await find_support_ticket_by_id(
    support_ticket_id
  );
  if (!support_ticket_detail) {
    resp.error = true;
    resp.error_message = "Invalid Support Ticket ID";
    return resp;
  }
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  const old_support_type = support_ticket_detail.support_type._id;
  let support_type = support_ticket_detail.support_type;

  let all_employees_role_based = [];

  if (old_support_type != body.support_type) {
    const role_details = await find_role_by_id(body.support_type);
    if (!role_details) {
      resp.error = true;
      resp.error_message = "Invalid Support Type";
      return resp;
    }
    if (role_details.title == "All") {
      all_employees_role_based =
        await get_active_employees_role_based_except_employee();
    } else {
      all_employees_role_based = await get_active_employees_role_based(
        role_details._id
      );
    }
    support_type._id = role_details._id;
    support_type.title = role_details.title;
  }

  support_ticket_detail.title = body.title;
  support_ticket_detail.description = body.description;
  support_ticket_detail.priority = body.priority;
  support_ticket_detail.support_type = support_type;
  support_ticket_detail.image = body.image;

  await support_ticket_detail.save();

  if (old_support_type != body.support_type) {
    for (let j = 0; j < all_employees_role_based.length; j++) {
      if (all_employees_role_based[j].previllages.support.view) {
        let notification_obj = {
          user_id: all_employees_role_based[j].user_id,
          support_ticket_id: support_ticket_detail._id,
          title: "Support Ticket",
          description: "Hi! A support ticket is just added",
          type: NOTIFICATION_TYPE.support_ticket,
        };
        await add_notification(notification_obj);
      }
    }
  }

  resp.data = support_ticket_detail;
  return resp;
};
const editSupportTicket = async (user_id, support_ticket_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editSupportTicket(user_id, support_ticket_id, body, resp);
  return resp;
};

const _detailSupportTicket = async (support_ticket_id, resp) => {
  const support_ticket = await find_support_ticket_by_id_with_populate(
    support_ticket_id
  );
  if (!support_ticket) {
    resp.error = true;
    resp.error_message = "Invalid Support Ticket ID!";
    return resp;
  }

  let final_support_ticket_obj = {
    _id: support_ticket._id,
    emp_obj_id: support_ticket.emp_obj_id,
    emp_name: support_ticket.emp_name,
    title: support_ticket.title,
    description: support_ticket.description,
    priority: support_ticket.priority,
    support_type: support_ticket.support_type,
    status: support_ticket.status,
    image: support_ticket.image,
    message_receivers: support_ticket.message_receivers,
    createdAt: support_ticket.createdAt,
    updatedAt: support_ticket.updatedAt,
  };
  let message_arr = [];
  for (let i = 0; i < support_ticket.messages.length; i++) {
    let emp_details = await find_employee_by_user_id(
      support_ticket.messages[i].user_id
    );
    let message_obj = {
      _id: support_ticket.messages[i]._id,
      text: support_ticket.messages[i].text,
      images: support_ticket.messages[i].images,
      user_id: support_ticket.messages[i].user_id,
      date_time: support_ticket.messages[i].date_time,
    };
    message_obj.emp_name = "Unknown";
    message_obj.emp_image = "";
    if (emp_details) {
      message_obj.emp_name = emp_details.full_name;
      if (!_.isEmpty(emp_details.profile_pic)) {
        message_obj.emp_image = emp_details.profile_pic.large;
      }
    }
    message_arr.push(message_obj);
  }

  final_support_ticket_obj.messages = message_arr;
  resp.data = final_support_ticket_obj;
  return resp;
};

const detailSupportTicket = async (support_ticket_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailSupportTicket(support_ticket_id, resp);
  return resp;
};

const _deleteSupportTicket = async (support_ticket_id, resp) => {
  const deleted_support_ticket = await delete_support_ticket_by_id(
    support_ticket_id
  );
  if (!deleted_support_ticket) {
    resp.error = true;
    resp.error_message = "Invalid Support Ticket ID!";
    return resp;
  } else {
    await delete_support_ticket_notifications(deleted_support_ticket._id);
  }
  return resp;
};

const deleteSupportTicket = async (support_ticket_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteSupportTicket(support_ticket_id, resp);
  return resp;
};

const _searchSupportTicket = async (
  user_id,
  body,
  Limit,
  page,
  search,
  resp
) => {
  const emp_details = await find_employee_by_user_id(user_id);
  // if (!emp_details) {
  //   resp.error = true;
  //   resp.error_message = "Member not found";
  //   return resp;
  // }
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let open_tickets_count = 0;
  let close_tickets_count = 0;
  let all_tickets_count = 0;
  let total_pages = 0;
  let support_ticket = [];

  if (emp_details) {
    let query_obj = { emp_obj_id: emp_details._id };
    const search_support_ticket = await search_support_tickets_by_query_obj(
      query_obj
    );
    if (
      body.status &&
      body.status != "" &&
      (body.status == 0 || body.status == 1)
    ) {
      query_obj.status = body.status;
    }

    if (search && search != "") {
      query_obj.title = { $regex: new RegExp(search, "i") };
    }

    support_ticket = await get_support_ticket_search(query_obj, limit, skip);
    total_pages = await support_ticket_search_count(query_obj);

    open_tickets_count = 0;
    close_tickets_count = 0;
    all_tickets_count = search_support_ticket.length;

    for (let i = 0; i < search_support_ticket.length; i++) {
      if (search_support_ticket[i].status == 0) {
        open_tickets_count++;
      } else if (search_support_ticket[i].status == 1) {
        close_tickets_count++;
      }
    }
  }

  resp.data = {
    open_tickets_count,
    close_tickets_count,
    all_tickets_count,
    support_ticket,
    total_pages,
    load_more_url: `/support_ticket/get_support_ticket?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchSupportTicket = async (user_id, body, limit, page, search) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchSupportTicket(user_id, body, limit, page, search, resp);
  return resp;
};

const _processSupportTicket = async (
  support_ticket_id,
  user_id,
  body,
  resp
) => {
  const support_ticket_detail = await find_support_ticket_by_id(
    support_ticket_id
  );
  if (!support_ticket_detail) {
    resp.error = true;
    resp.error_message = "Invalid Support Ticket ID";
    return resp;
  }

  const user_details = await find_employee_by_user_id(user_id);
  if (!user_details) {
    resp.error = true;
    resp.error_message = "User not found";
    return resp;
  }

  const emp_details = await find_employee_by_id(
    support_ticket_detail.emp_obj_id
  );
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  support_ticket_detail.status = body.status;
  await support_ticket_detail.save();
  if (support_ticket_detail.status == 0) {
    if (emp_details.previllages.my_support.view) {
      let notification_obj = {
        user_id: emp_details.user_id._id,
        support_ticket_id: support_ticket_detail._id,
        title: "Support Ticket",
        description:
          "Hi! " + emp_details.full_name + ". Your support ticket is open now",
        type: NOTIFICATION_TYPE.support_ticket,
      };
      await add_notification(notification_obj);
    }
  } else if (support_ticket_detail.status == 1) {
    if (emp_details.previllages.my_support.view) {
      let notification_obj = {
        user_id: emp_details.user_id._id,
        support_ticket_id: support_ticket_detail._id,
        title: "Support Ticket",
        description:
          "Hi! " +
          emp_details.full_name +
          ". Your support ticket is closed now",
        type: NOTIFICATION_TYPE.support_ticket,
      };
      await add_notification(notification_obj);
    }
  }
  resp.data = support_ticket_detail;
  return resp;
};
const processSupportTicket = async (support_ticket_id, user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _processSupportTicket(support_ticket_id, user_id, body, resp);
  return resp;
};

const _addSupportTicketAdmin = async (user_id, body, resp) => {
  const admin_details = await find_user_by_id(user_id);
  if (!admin_details) {
    resp.error = true;
    resp.error_message = "Admin not found";
    return resp;
  }

  const emp_details = await find_employee_by_id(body.emp_obj_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  const role_details = await find_role_by_id(body.support_type);
  if (!role_details) {
    resp.error = true;
    resp.error_message = "Invalid Support Type";
    return resp;
  }
  let all_employees_role_based = [];
  if (role_details.title == "All") {
    all_employees_role_based =
      await get_active_employees_role_based_except_employee();
  } else {
    all_employees_role_based = await get_active_employees_role_based(
      role_details._id
    );
  }
  let support_type = { _id: role_details._id, title: role_details.title };

  let support_ticket_obj = {
    emp_obj_id: emp_details._id,
    emp_name: emp_details.full_name,
    title: body.title,
    description: body.description,
    priority: body.priority,
    support_type: support_type,
    image: body.image,
  };
  const final_support_ticket = await add_support_ticket(support_ticket_obj);
  for (let j = 0; j < all_employees_role_based.length; j++) {
    if (all_employees_role_based[j].previllages.support.view) {
      let notification_obj = {
        user_id: all_employees_role_based[j].user_id,
        support_ticket_id: final_support_ticket._id,
        title: "Support Ticket",
        description:
          "Hi! Here is a ticket on behalf of " + emp_details.full_name + ".",
        type: NOTIFICATION_TYPE.support_ticket,
      };
      await add_notification(notification_obj);
    }
  }
  resp.data = final_support_ticket;
  return resp;
};
const addSupportTicketAdmin = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addSupportTicketAdmin(user_id, body, resp);
  return resp;
};

const _editSupportTicketAdmin = async (
  user_id,
  support_ticket_id,
  body,
  resp
) => {
  const admin_details = await find_user_by_id(user_id);
  if (!admin_details) {
    resp.error = true;
    resp.error_message = "Admin not found";
    return resp;
  }

  const support_ticket_detail = await find_support_ticket_by_id(
    support_ticket_id
  );
  if (!support_ticket_detail) {
    resp.error = true;
    resp.error_message = "Invalid Support Ticket ID";
    return resp;
  }
  const emp_details = await find_employee_by_id(body.emp_obj_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  // if (support_ticket_detail.status != "pending") {
  //   resp.error = true;
  //   resp.error_message = "This leave request is already processed";
  //   return resp;
  // }

  let old_support_type = support_ticket_detail.support_type._id;
  let support_type = support_ticket_detail.support_type;
  let all_employees_role_based = [];

  if (support_type != body.support_type) {
    const role_details = await find_role_by_id(body.support_type);
    if (!role_details) {
      resp.error = true;
      resp.error_message = "Invalid Support Type";
      return resp;
    }
    if (role_details.title == "All") {
      all_employees_role_based =
        await get_active_employees_role_based_except_employee();
    } else {
      all_employees_role_based = await get_active_employees_role_based(
        role_details._id
      );
    }
    support_type._id = role_details._id;
    support_type.title = role_details.title;
  }

  support_ticket_detail.title = body.title;
  support_ticket_detail.description = body.description;
  support_ticket_detail.priority = body.priority;
  support_ticket_detail.support_type = support_type;
  support_ticket_detail.image = body.image;

  await support_ticket_detail.save();

  if (old_support_type != body.support_type) {
    for (let j = 0; j < all_employees_role_based.length; j++) {
      if (all_employees_role_based[j].previllages.support.view) {
        let notification_obj = {
          user_id: all_employees_role_based[j].user_id,
          support_ticket_id: support_ticket_detail._id,
          title: "Support Ticket",
          description: "Hi! A support ticket is just added",
          type: NOTIFICATION_TYPE.support_ticket,
        };
        await add_notification(notification_obj);
      }
    }
  }

  resp.data = support_ticket_detail;
  return resp;
};
const editSupportTicketAdmin = async (user_id, support_ticket_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editSupportTicketAdmin(user_id, support_ticket_id, body, resp);
  return resp;
};

const _deleteSupportTicketAdmin = async (user_id, support_ticket_id, resp) => {
  const admin_details = await find_user_by_id(user_id);
  if (!admin_details) {
    resp.error = true;
    resp.error_message = "Admin not found";
    return resp;
  }

  // const get_support_ticket = await find_support_ticket_by_id(support_ticket_id);
  // if (!get_support_ticket) {
  //   resp.error = true;
  //   resp.error_message = "Invalid Support Ticket ID!";
  //   return resp;
  // }
  // if (get_support_ticket.status != "pending") {
  //   resp.error = true;
  //   resp.error_message = "This leave request is already processed";
  //   return resp;
  // }
  const deleted_support_ticket = await delete_support_ticket_by_id(
    support_ticket_id
  );
  if (!deleted_support_ticket) {
    resp.error = true;
    resp.error_message = "Invalid Support Ticket ID!";
    return resp;
  } else {
    await delete_support_ticket_notifications(deleted_support_ticket._id);
  }
  return resp;
};

const deleteSupportTicketAdmin = async (user_id, support_ticket_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteSupportTicketAdmin(user_id, support_ticket_id, resp);
  return resp;
};

const _searchSupportTicketAdmin = async (
  user_id,
  body,
  Limit,
  page,
  search,
  resp
) => {
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let query_obj = {};
  if (search && search != "") {
    query_obj = {
      $or: [
        { title: { $regex: new RegExp(search, "i") } },
        { emp_name: { $regex: new RegExp(search, "i") } },
      ],
    };
  }

  if (!!emp_details) {
    if (emp_details.role.title == "All") {
      query_obj["support_type.title"] = { $in: ["All", "Admin", "HR"] };
    } else if (emp_details.role.title == "Admin") {
      query_obj["support_type.title"] = { $in: ["Admin"] };
    } else if (emp_details.role.title == "HR") {
      query_obj["support_type.title"] = { $in: ["HR"] };
    }
  }
  // if (emp_details) {
  //   query_obj["support_type.title"] = { $in: [emp_details.role.title, "All"] };
  // }

  const all_support_tickets = await search_support_tickets_by_query_obj(
    query_obj
  );

  if (
    body.status &&
    body.status != "" &&
    (body.status == 0 || body.status == 1)
  ) {
    query_obj.status = body.status;
  }

  const support_ticket = await get_support_ticket_search(
    query_obj,
    limit,
    skip
  );

  let open_tickets_count = 0;
  let close_tickets_count = 0;
  let all_tickets_count = all_support_tickets.length;

  for (let i = 0; i < all_support_tickets.length; i++) {
    if (all_support_tickets[i].status == 0) {
      open_tickets_count++;
    } else if (all_support_tickets[i].status == 1) {
      close_tickets_count++;
    }
  }

  const total_pages = await support_ticket_search_count(query_obj);
  console.log("query_obj", query_obj);
  console.log("all_tickets_count", all_tickets_count);
  console.log("open_tickets_count", open_tickets_count);
  console.log("total_pages", total_pages);

  resp.data = {
    all_tickets_count,
    open_tickets_count,
    close_tickets_count,
    support_ticket: support_ticket,
    total_pages: total_pages,
    load_more_url: `/support_ticket/get_support_ticket?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchSupportTicketAdmin = async (user_id, body, limit, page, search) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchSupportTicketAdmin(
    user_id,
    body,
    limit,
    page,
    search,
    resp
  );
  return resp;
};

const _addMessageSupportTicket = async (
  support_ticket_id,
  user_id,
  body,
  resp
) => {
  const support_ticket_details = await find_support_ticket_by_id(
    support_ticket_id
  );
  if (!support_ticket_details) {
    resp.error = true;
    resp.error_message = "Support ticket not found";
    return resp;
  }
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  let message_obj = {
    text: body.text,
    images: body.images,
    user_id: emp_details.user_id._id,
    date_time: moment().utc(true).format(),
  };
  support_ticket_details.messages.push(message_obj);

  await support_ticket_details.save();

  resp.data = support_ticket_details;
  return resp;
};
const addMessageSupportTicket = async (support_ticket_id, user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addMessageSupportTicket(support_ticket_id, user_id, body, resp);
  return resp;
};

const _deleteMessageSupportTicket = async (
  support_ticket_id,
  user_id,
  body,
  resp
) => {
  const support_ticket_details = await find_support_ticket_by_id(
    support_ticket_id
  );
  if (!support_ticket_details) {
    resp.error = true;
    resp.error_message = "Support ticket not found";
    return resp;
  }
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  let message_arr = support_ticket_details.messages;

  // let index = _.findIndex(message_arr, { _id: body.message_id });
  let index = -1;
  for (let i = 0; i < message_arr.length; i++) {
    if (
      message_arr[i]._id == body.message_id &&
      message_arr[i].user_id.toString() == user_id.toString()
    ) {
      index = i;
    }
  }

  let deleted_msg = {};
  if (index >= 0) {
    deleted_msg = support_ticket_details.messages[index];
    support_ticket_details.messages.splice(index, 1);
    await support_ticket_details.save();
  } else {
    resp.error = true;
    resp.error_message = "Could not delete the requested text";
    return resp;
  }

  let new_messages = [];
  for (let j = 0; j < support_ticket_details.message_receivers.length; j++) {
    if (
      support_ticket_details.message_receivers[j].message_id.toString() !=
      body.message_id
    ) {
      new_messages.push(support_ticket_details.message_receivers[j]);
    }
  }

  let resp_obj = {
    _id: support_ticket_details._id,
    emp_obj_id: support_ticket_details.emp_obj_id,
    emp_name: support_ticket_details.emp_name,
    title: support_ticket_details.title,
    description: support_ticket_details.description,
    priority: support_ticket_details.priority,
    support_type: support_ticket_details.support_type,
    status: support_ticket_details.status,
    image: support_ticket_details.image,
    message: deleted_msg,
    message_receivers: new_messages,
    createdAt: support_ticket_details.createdAt,
    updatedAt: support_ticket_details.updatedAt,
  };
  resp.data = resp_obj;
  support_ticket_details.message_receivers = new_messages;
  support_ticket_details.save();
  return resp;
};
const deleteMessageSupportTicket = async (support_ticket_id, user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteMessageSupportTicket(
    support_ticket_id,
    user_id,
    body,
    resp
  );
  return resp;
};

const _editMessageSupportTicket = async (
  support_ticket_id,
  user_id,
  body,
  resp
) => {
  const support_ticket_details = await find_support_ticket_by_id(
    support_ticket_id
  );
  if (!support_ticket_details) {
    resp.error = true;
    resp.error_message = "Support ticket not found";
    return resp;
  }
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  let message_arr = support_ticket_details.messages;
  for (let i = 0; i < message_arr.length; i++) {
    if (
      message_arr[i]._id == body.message_id &&
      message_arr[i].user_id.toString() == user_id.toString()
    ) {
      support_ticket_details.messages[i].text = body.text;
      support_ticket_details.messages[i].images = body.images;
    }
  }

  await support_ticket_details.save();

  resp.data = support_ticket_details;
  return resp;
};
const editMessageSupportTicket = async (support_ticket_id, user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editMessageSupportTicket(
    support_ticket_id,
    user_id,
    body,
    resp
  );
  return resp;
};

const _removeUnreadMessageCountSupportTicket = async (
  user_id,
  support_ticket_id,
  resp
) => {
  const support_ticket = await find_support_ticket_by_id_with_populate(
    support_ticket_id
  );
  if (!support_ticket) {
    resp.error = true;
    resp.error_message = "Invalid Support Ticket ID!";
    return resp;
  }

  let new_receivers = [];
  for (let j = 0; j < support_ticket.message_receivers.length; j++) {
    if (
      support_ticket.message_receivers[j].receiver_id.toString() !=
      user_id.toString()
    ) {
      new_receivers.push(support_ticket.message_receivers[j]);
    }
  }
  support_ticket.message_receivers = new_receivers;
  support_ticket.save();
  // resp.data = final_support_ticket_obj;
  return resp;
};

const removeUnreadMessageCountSupportTicket = async (
  user_id,
  support_ticket_id
) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _removeUnreadMessageCountSupportTicket(
    user_id,
    support_ticket_id,
    resp
  );
  return resp;
};

module.exports = {
  addSupportTicket,
  addSupportTicketAdmin,
  editSupportTicket,
  editSupportTicketAdmin,
  detailSupportTicket,
  deleteSupportTicket,
  deleteSupportTicketAdmin,
  searchSupportTicket,
  searchSupportTicketAdmin,
  processSupportTicket,
  addMessageSupportTicket,
  deleteMessageSupportTicket,
  editMessageSupportTicket,
  removeUnreadMessageCountSupportTicket,
};
