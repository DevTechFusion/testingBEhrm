const {
  add_payroll,
  find_payroll_by_id,
  pagination_payroll,
  delete_payroll_by_id,
  get_payroll_search,
  payroll_search_count,
  find_payroll_for_emp_month_year,
  find_payroll_for_month_year,
  payroll_search_by_query_obj,
  payroll_search_by_query_obj_count,
  delete_payroll_by_month_year,
  get_total_salary_by_month,
  get_payroll_search_v1,
  payroll_search_count_v1,
  get_total_salary_by_month_v1,
  delete_payroll_records_v1,
  find_payroll_ids_by_month_year,
} = require("../DAL/payroll");
const { pay_fine_on_payroll } = require("../DAL/attendance");
const {
  find_employee_by_id,
  find_employee_by_user_id,
  get_all_active_hr,
} = require("../DAL/employee");
const {
  add_notification,
  delete_payroll_notifications,
} = require("../DAL/notification");
const {
  get_general_allowance,
  get_other_allowance,
} = require("../DAL/allowances");
const {
  GENERATE_PAYSLIP_PDF,
  SEND_PAYSLIP_TO_EMAIL_FROM_SES,
  CREATE_PAYSLIP_PDF,
  UPLOAD_FILE_on_S3_with_CONTENT_TYPE,
  UPLOAD_ANY_SINGLE_FILE_ON_S3,
  SEND_EMAIL_BY_ML_MS,
  NOTIFY_BY_EMAIL_FROM_SES,
  SEND_EMAIL_BY_SES,
} = require("../utils/utils");
const { NOTIFICATION_TYPE } = require("../utils/constants");
const moment = require("moment");
const _ = require("lodash");
const fs = require("fs");

const { generatePayslip } = require("../utils/generate_payroll_pdf_v1");

const html_file = fs.readFileSync("./payslip.html", { encoding: "utf-8" });
// console.log(html_file);

const _addPayroll = async (body, resp) => {
  let payroll = body.payroll;
  if (payroll.length == 0) {
    resp.error = true;
    resp.error_message = "Please generate payroll first";
    return resp;
  }

  let payroll_ids = [];
  let month = payroll[0].month;
  let year = payroll[0].year;
  let month_name = moment(month, "MM").format("MMMM");

  const check_exist = await find_payroll_for_month_year(month, year);
  if (check_exist) {
    resp.error = true;
    resp.error_message =
      "Payroll for this month already added. Please delete the existing payroll for this month to add again";
    return resp;
  }
  let final_payroll = [];
  for (let i = 0; i < payroll.length; i++) {
    const saved_payroll = await add_payroll(payroll[i]);
    if (saved_payroll) {
      await pay_fine_on_payroll(saved_payroll.emp_obj_id, month, year);
    }
    payroll_ids.push(saved_payroll._id);
    final_payroll.push(saved_payroll);
  }

  resp.data = final_payroll;

  send_payrolls_to_employees(payroll_ids, month_name, year, body.is_send_email);

  return resp;
};
const addPayroll = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addPayroll(body, resp);
  return resp;
};

const _editPayroll = async (body, payroll_id, resp) => {
  const payroll_detail = await find_payroll_by_id(payroll_id);
  if (!payroll_detail) {
    resp.error = true;
    resp.error_message = "Invalid Payroll ID";
    return resp;
  }

  // let month = moment().month() + 1;
  // let year = moment().year();

  // console.log("month: ", month);
  // console.log("payroll_detail.active_status: ",payroll_detail.active_status);
  // console.log("body.active_status: ",body.active_status);

  // if (payroll_detail.active_status != body.active_status) {
  //   if (payroll_detail.month != month || payroll_detail.year != year) {
  //     resp.error = true;
  //     resp.error_message =
  //       "Payroll can only be marked as active or inactive for current month";
  //     return resp;
  //   }
  // }

  payroll_detail.emp_obj_id = body.emp_obj_id;
  payroll_detail.emp_name = body.emp_name;
  payroll_detail.month = body.month;
  payroll_detail.year = body.year;
  payroll_detail.basic_salary = body.basic_salary;
  payroll_detail.conveyance_allowance = body.conveyance_allowance
    ? body.conveyance_allowance
    : 0;
  // payroll_detail.education_allowance = body.education_allowance;
  payroll_detail.medical_allowance = body.medical_allowance
    ? body.medical_allowance
    : 0;
  // payroll_detail.rent_allowance = body.rent_allowance;
  payroll_detail.food_allowance = body.food_allowance ? body.food_allowance : 0;
  payroll_detail.other_payment = body.other_payment ? body.other_payment : 0;
  payroll_detail.commission = body.commission ? body.commission : 0;
  payroll_detail.overtime = body.overtime ? body.overtime : 0;
  payroll_detail.loan = body.loan ? body.loan : 0;
  payroll_detail.monthly_tax = body.monthly_tax;
  payroll_detail.tax_file = body.tax_file;
  payroll_detail.net_salary = body.net_salary;
  payroll_detail.loan_deduction = body.loan_deduction ? body.loan_deduction : 0;
  payroll_detail.lunch_deduction = body.lunch_deduction
    ? body.lunch_deduction
    : 0;
  payroll_detail.fine_deduction = body.fine_deduction ? body.fine_deduction : 0;
  payroll_detail.other_deduction = body.other_deduction
    ? body.other_deduction
    : 0;
  payroll_detail.active_status = body.active_status;
  payroll_detail.other_deduction_label = body.other_deduction_label
    ? body.other_deduction_label
    : "";
  payroll_detail.other_payment_label = body.other_payment_label
    ? body.other_payment_label
    : "";
  payroll_detail.gross_salary = body.gross_salary;
  payroll_detail.other_allowances = body.other_allowances
    ? body.other_allowances
    : [];
  payroll_detail.other_deductions = body.other_deductions
    ? body.other_deductions
    : [];

  payroll_detail.general_allowances = body.general_allowances
    ? body.general_allowances
    : [];

  payroll_detail.total_allowances = body.total_allowances;
  payroll_detail.total_deductions = body.total_deductions;
  payroll_detail.gross_earnings = body.gross_earnings;
  payroll_detail.is_included_general_allowances =
    body.is_included_general_allowances;

  await payroll_detail.save();
  resp.data = payroll_detail;

  //generate payslip pdf and send email

  let payroll_ids = [];
  payroll_ids.push(payroll_id);

  let month_name = moment(body.month, "MM").format("MMMM");
  let year = body.year;

  send_payrolls_to_employees(payroll_ids, month_name, year, body.is_send_email);

  return resp;
};
const editPayroll = async (body, payroll_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editPayroll(body, payroll_id, resp);
  return resp;
};

const _detailPayroll = async (payroll_id, resp) => {
  //general_allowance  other_allowance

  const general_allowance = await get_general_allowance();
  const other_allowance = await get_other_allowance();

  const payroll = await find_payroll_by_id(payroll_id);
  if (!payroll) {
    resp.error = true;
    resp.error_message = "Invalid Payroll ID!";
    return resp;
  }
  let final_payroll = {
    emp_obj_id: payroll.emp_obj_id,
    emp_name: payroll.emp_name,
    month: payroll.month,
    year: payroll.year,
    basic_salary: payroll.basic_salary,
    conveyance_allowance: payroll.conveyance_allowance
      ? payroll.conveyance_allowance
      : 0,
    // education_allowance: payroll.education_allowance,
    medical_allowance: payroll.medical_allowance
      ? payroll.medical_allowance
      : 0,
    rent_allowance: payroll.rent_allowance ? payroll.rent_allowance : 0,
    food_allowance: payroll.food_allowance ? payroll.food_allowance : 0,
    other_payment: payroll.other_payment ? payroll.other_payment : 0,
    commission: payroll.commission ? payroll.commission : 0,
    overtime: payroll.overtime ? payroll.overtime : 0,
    loan: payroll.loan ? payroll.loan : 0,
    monthly_tax: payroll.monthly_tax,
    tax_file: payroll.tax_file,
    net_salary: payroll.net_salary,
    loan_deduction: payroll.loan_deduction ? payroll.loan_deduction : 0,
    lunch_deduction: payroll.lunch_deduction,
    fine_deduction: payroll.fine_deduction,
    other_deduction: payroll.other_deduction ? payroll.other_deduction : 0,
    other_deduction_label: payroll.other_deduction_label
      ? payroll.other_deduction_label
      : "",
    other_payment_label: payroll.other_payment_label
      ? payroll.other_payment_label
      : "",
    gross_salary: payroll.gross_salary,
    gross_earnings: payroll.gross_earnings,
    is_included_general_allowances: payroll.is_included_general_allowances,
    total_allowances: payroll.total_allowances ? payroll.total_allowances : 0,
    total_deductions: payroll.total_deductions ? payroll.total_deductions : 0,
    other_allowances: payroll.other_allowances ? payroll.other_allowances : [],
    other_deductions: payroll.other_deductions ? payroll.other_deductions : [],
    general_allowances: payroll.general_allowances
      ? payroll.general_allowances
      : [],
    active_status: payroll.active_status,
    date: payroll.date,
    pay_slip: payroll.pay_slip,
    createdAt: payroll.createdAt,
    updatedAt: payroll.updatedAt,
  };
  const emp_details = await find_employee_by_id(payroll.emp_obj_id);
  if (emp_details) {
    final_payroll.designation = emp_details.designation;
    final_payroll.bank_account = emp_details.bank_account;
    final_payroll.emp_id = emp_details.employee_id;
  }
  resp.data = {
    payroll: final_payroll,
    general_allowance: general_allowance,
    other_allowance: other_allowance,
  };
  return resp;
};

const detailPayroll = async (payroll_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailPayroll(payroll_id, resp);
  return resp;
};

const _deletePayroll = async (body, resp) => {
  // const deleted_payroll = await delete_payroll_by_month_year(
  //   body.month,
  //   body.year
  // );

  const deleted_payroll = await delete_payroll_records_v1(body);

  // console.log("deleted_payroll: ", deleted_payroll);
  if (deleted_payroll.deletedCount <= 0) {
    resp.error = true;
    resp.error_message = "No records found for this month";
    return resp;
  }
  // const deleted_payroll = await delete_payroll_by_id(payroll_id);
  // if (!deleted_payroll) {
  //   resp.error = true;
  //   resp.error_message = "Invalid Payroll  ID!";
  //   return resp;
  // }
  // await delete_payroll_notifications(deleted_payroll._id);

  return resp;
};

const deletePayroll = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deletePayroll(body, resp);
  return resp;
};

const _searchPayroll = async (user_id, Limit, page, body, resp) => {
  const emp_details = await find_employee_by_user_id(user_id);
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let date = new Date();
  let month = date.getMonth();
  let year = date.getFullYear();

  let query_obj = { month: month, year: year };
  let total_salary = 0;
  let final_payrolls_list = [];
  let total_pages = [];
  let payroll = 0;

  if (emp_details) {
    if (emp_details.role.title != "HR" && emp_details.role.title != "All") {
      // console.log("Employee");
      query_obj = {
        emp_obj_id: emp_details._id,
      };
      const currentMonthNumber = moment().format("M");
      if (currentMonthNumber >= 7) {
        query_obj["$or"] = [
          { $and: [{ month: { $gte: 7 } }, { year: parseInt(body.year) }] },
          { $and: [{ month: { $lte: 6 } }, { year: parseInt(body.year) + 1 }] },
        ];
      } else {
        query_obj["$or"] = [
          { $and: [{ month: { $gte: 7 } }, { year: parseInt(body.year) - 1 }] },
          { $and: [{ month: { $lte: 6 } }, { year: parseInt(body.year) }] },
        ];
      }
      // console.log("query_obj: ", query_obj);
      final_payrolls_list = await get_payroll_search(12, 0, query_obj);

      final_payrolls_list = final_payrolls_list.map((final_payroll) => {
        return {
          ...final_payroll,
          designation: emp_details.designation,
          bank_account: emp_details.bank_account,
          emp_id: emp_details.employee_id,
        };
      });

      // console.log("final_payrolls_list: ", final_payrolls_list);
    } else {
      if (
        body.month &&
        body.year &&
        body.month != "" &&
        body.year != "" &&
        body.month != null &&
        body.year != null &&
        body.month != undefined &&
        body.year != undefined
      ) {
        query_obj.month = body.month;
        query_obj.year = body.year;
      }
      const get_total_salary = await get_total_salary_by_month(
        query_obj.month,
        query_obj.year
      );
      // console.log("get_total_salary: ", get_total_salary);
      if (get_total_salary.length > 0) {
        total_salary = get_total_salary[0].totalNetSalary;
      }
      if (body.search && body.search != "") {
        query_obj.emp_name = { $regex: new RegExp(body.search, "i") };
      }
      final_payrolls_list = await get_payroll_search(limit, skip, query_obj);
      total_pages = await payroll_search_count(query_obj);

      for (let i = 0; i < final_payrolls_list.length; i++) {
        // let final_payroll = {
        //   _id: payroll[i]._id,
        //   emp_obj_id: payroll[i].emp_obj_id,
        //   emp_name: payroll[i].emp_name,
        //   month: payroll[i].month,
        //   year: payroll[i].year,
        //   basic_salary: payroll[i].basic_salary,
        //   conveyance_allowance: payroll[i].conveyance_allowance,
        //   // education_allowance: payroll[i].education_allowance,
        //   medical_allowance: payroll[i].medical_allowance,
        //   rent_allowance: payroll[i].rent_allowance,
        //   food_allowance: payroll[i].food_allowance,
        //   other_payment: payroll[i].other_payment,
        //   commission: payroll[i].commission,
        //   overtime: payroll[i].overtime,
        //   loan: payroll[i].loan,
        //   monthly_tax: payroll[i].monthly_tax,
        //   tax_file: payroll[i].tax_file,
        //   net_salary: payroll[i].net_salary,
        //   loan_deduction: payroll[i].loan_deduction,
        //   lunch_deduction: payroll[i].lunch_deduction,
        //   fine_deduction: payroll[i].fine_deduction,
        //   other_deduction: payroll[i].other_deduction,
        //   active_status: payroll[i].active_status,
        //   date: payroll[i].date,
        //   createdAt: payroll[i].createdAt,
        //   updatedAt: payroll[i].updatedAt,
        // };
        const emp_details = await find_employee_by_id(
          final_payrolls_list[i].emp_obj_id
        );
        if (emp_details) {
          final_payrolls_list[i].designation = emp_details.designation;
          final_payrolls_list[i].bank_account = emp_details.bank_account;
          final_payrolls_list[i].emp_id = emp_details.employee_id;
        }
        // final_payrolls_list.push(final_payroll);
      }
    }

    final_payrolls_list.sort((a, b) => a.emp_name.localeCompare(b.emp_name));
    // console.log("final_payrolls_list: ", final_payrolls_list);
  }

  resp.data = {
    payroll: final_payrolls_list,
    total_pages,
    total_salary,
    load_more_url: `/payroll/get_payroll?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchPayroll = async (user_id, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchPayroll(user_id, limit, page, body, resp);
  return resp;
};

const _searchPayrollV1 = async (user_id, Limit, page, body, resp) => {
  // const emp_details = await find_employee_by_user_id(user_id);
  const emp_details = await find_employee_by_user_id(user_id);

  console.log("emp_details: ", emp_details);

  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let total_salary = 0;
  let final_payrolls_list = [];
  let total_pages = 0;
  let payroll = 0;
  let query_obj = {};

  if (emp_details) {
    if (
      emp_details.role.title != "HR" &&
      emp_details.role.title != "All" &&
      emp_details.role.title != "Admin"
    ) {
      query_obj = {
        emp_obj_id: emp_details._id,
      };

      final_payrolls_list = await get_payroll_search_v1(
        limit,
        skip,
        body,
        query_obj
      );

      // const count_payroll = await payroll_search_count_v1(body, query_obj);
      // total_pages = count_payroll;

      final_payrolls_list = final_payrolls_list.map((final_payroll) => {
        return {
          ...final_payroll,
          designation: emp_details.designation,
          bank_account: emp_details.bank_account,
          emp_id: emp_details.employee_id,
        };
      });
    } else {
      if (body.search && body.search != "") {
        query_obj.emp_name = { $regex: new RegExp(body.search.trim(), "i") };
      }

      const get_total_salary = await get_total_salary_by_month_v1(
        body,
        query_obj
      );

      total_salary = get_total_salary;

      final_payrolls_list = await get_payroll_search_v1(
        limit,
        skip,
        body,
        query_obj
      );

      for (let i = 0; i < final_payrolls_list.length; i++) {
        const emp_details = await find_employee_by_id(
          final_payrolls_list[i].emp_obj_id
        );
        if (emp_details) {
          final_payrolls_list[i].designation = emp_details.designation;
          final_payrolls_list[i].bank_account = emp_details.bank_account;
          final_payrolls_list[i].emp_id = emp_details.employee_id;
        }
      }
    }
  }

  total_pages = await payroll_search_count_v1(body, query_obj);

  resp.data = {
    payroll: final_payrolls_list,
    total_pages,
    total_salary,
    load_more_url: `/payroll/get_payroll?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchPayrollV1 = async (user_id, limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchPayrollV1(user_id, limit, page, body, resp);
  return resp;
};

const _emailPayslip = async (user_id, body, resp) => {
  console.log("Inside email payroll request");
  console.log("body.employees: ", body.employees);
  if (body.employees.length > 0) {
    // console.log("inside if");
    let month = body.employees[0].month;
    let year = body.employees[0].year;
    let month_name = moment(month, "MM").format("MMMM");
    let month_year = month_name + " " + year;
    // console.log("month_name: ", month_name);
    // console.log("month_year: ", month_year);
    for (let i = 0; i < body.employees.length; i++) {
      // console.log("iteration============ ", i);
      const payroll = await find_payroll_for_emp_month_year(
        body.employees[i]._id,
        month,
        year
      );
      // console.log("payroll: ", payroll);
      if (payroll) {
        let final_payroll = {
          _id: payroll._id,
          emp_obj_id: payroll.emp_obj_id,
          emp_name: payroll.emp_name,
          month: payroll.month,
          year: payroll.year,
          basic_salary: payroll.basic_salary,
          conveyance_allowance: payroll.conveyance_allowance,
          // education_allowance: payroll.education_allowance,
          medical_allowance: payroll.medical_allowance,
          rent_allowance: payroll.rent_allowance,
          food_allowance: payroll.food_allowance,
          other_payment: payroll.other_payment,
          commission: payroll.commission,
          overtime: payroll.overtime,
          loan: payroll.loan,
          monthly_tax: payroll.monthly_tax,
          tax_file: payroll.tax_file,
          net_salary: payroll.net_salary,
          loan_deduction: payroll.loan_deduction,
          lunch_deduction: payroll.lunch_deduction,
          fine_deduction: payroll.fine_deduction,
          other_deduction: payroll.other_deduction,
          active_status: payroll.active_status,
          date: payroll.date,
          createdAt: payroll.createdAt,
          updatedAt: payroll.updatedAt,
          webmail_email: body.employees[i].webmail_email,
          designation: body.employees[i].designation,
          emp_id: body.employees[i].employee_id,
          bank_account: body.employees[i].bank_account,
        };
        // const payslip = await GENERATE_PAYSLIP_PDF(html_file, final_payroll);
        let totalEarning =
          final_payroll.basic_salary +
          final_payroll.conveyance_allowance +
          final_payroll.medical_allowance +
          final_payroll.rent_allowance +
          final_payroll.food_allowance +
          final_payroll.other_payment +
          final_payroll.commission +
          final_payroll.overtime +
          final_payroll.loan;
        // final_payroll.education_allowance
        let totalDeduction =
          final_payroll.monthly_tax +
          final_payroll.loan_deduction +
          final_payroll.lunch_deduction +
          final_payroll.fine_deduction;

        let html_body = html_file;
        html_body = html_body.replace(/emp_id/g, final_payroll.emp_id);
        html_body = html_body.replace(
          /designation/g,
          final_payroll.designation
        );
        html_body = html_body.replace(/emp_name/g, final_payroll.emp_name);
        html_body = html_body.replace(
          /basic_salary/g,
          final_payroll.basic_salary
        );
        html_body = html_body.replace(
          /conveyance_allowance/g,
          final_payroll.conveyance_allowance
        );
        // html_body = html_body.replace(
        //   /education_allowance/g,
        //   final_payroll.education_allowance
        // );
        html_body = html_body.replace(
          /medical_allowance/g,
          final_payroll.medical_allowance
        );
        html_body = html_body.replace(
          /rent_allowance/g,
          final_payroll.rent_allowance
        );
        html_body = html_body.replace(
          /food_allowance/g,
          final_payroll.food_allowance
        );
        html_body = html_body.replace(
          /other_payment/g,
          final_payroll.other_payment
        );
        html_body = html_body.replace(/commission/g, final_payroll.commission);
        html_body = html_body.replace(/overtime/g, final_payroll.overtime);
        html_body = html_body.replace(/loan/g, final_payroll.loan);
        html_body = html_body.replace(
          /monthly_tax/g,
          final_payroll.monthly_tax
        );
        html_body = html_body.replace(/net_salary/g, final_payroll.net_salary);
        html_body = html_body.replace(
          /loan_deduction/g,
          final_payroll.loan_deduction
        );
        html_body = html_body.replace(
          /lunch_deduction/g,
          final_payroll.lunch_deduction
        );
        html_body = html_body.replace(
          /fine_deduction/g,
          final_payroll.fine_deduction
        );
        html_body = html_body.replace(
          /bank_account/g,
          final_payroll.bank_account
        );
        html_body = html_body.replace(/totalEarning/g, totalEarning);
        html_body = html_body.replace(/totalDeduction/g, totalDeduction);
        html_body = html_body.replace(/monthYear/g, month_year);

        // console.log(html_body);

        // const payslip = await GENERATE_PAYSLIP_PDF(html_file, final_payroll);
        // console.log("payslip: ", payslip);
        // const payslip = await CREATE_PAYSLIP_PDF(html_body);
        // console.log("received payslip: ", payslip);
        // const upload_slip = await UPLOAD_FILE_on_S3_with_CONTENT_TYPE(
        //   payslip,
        //   `payslips/`,
        //   ".pdf",
        //   "application/pdf"
        // );
        // console.log("upload_slip: ", upload_slip);
        // await SEND_PAYSLIP_TO_EMAIL_FROM_SES(
        //   body.employees[i].webmail_email,
        //   `Payslip ${month_name} ${year}`,
        //   payslip
        // );
      }
    }
  } else {
    resp.error = true;
    resp.error_message = "Select members for sending payslip";
    return resp;
  }

  // console.log("month: ", month);
  // console.log("payroll_detail.active_status: ",payroll_detail.active_status);
  // console.log("body.active_status: ",body.active_status);

  // await payroll_detail.save();
  // resp.data = payroll_detail;
  return resp;
};

const emailPayslip = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _emailPayslip(user_id, body, resp);
  return resp;
};

const send_payrolls_to_employees = async (
  payroll_ids,
  month_name,
  year,
  is_send_email
) => {
  console.log("payroll_ids: ", payroll_ids);
  for (let i = 0; i < payroll_ids.length; i++) {
    let employee;
    const find_payroll = await find_payroll_by_id(payroll_ids[i]);
    if (find_payroll) {
      employee = await find_employee_by_id(find_payroll.emp_obj_id);
    }

    let pay_date = moment(find_payroll.createdAt).format("D - MMMM - YYYY");
    let payroll_object = {};

    if (find_payroll && employee) {
      payroll_object = {
        _id: find_payroll._id,
        emp_obj_id: find_payroll.emp_obj_id,
        emp_name: find_payroll.emp_name,
        month: find_payroll.month,
        year: find_payroll.year,
        pay_date: pay_date,
        basic_salary: find_payroll.basic_salary,
        conveyance_allowance: find_payroll.conveyance_allowance
          ? find_payroll.conveyance_allowance
          : 0,
        medical_allowance: find_payroll.medical_allowance
          ? find_payroll.medical_allowance
          : 0,
        // rent_allowance: find_payroll.rent_allowance,
        food_allowance: find_payroll.food_allowance
          ? find_payroll.food_allowance
          : 0,
        other_payment: find_payroll.other_payment
          ? find_payroll.other_payment
          : 0,
        commission: find_payroll.commission ? find_payroll.commission : 0,
        overtime: find_payroll.overtime ? find_payroll.overtime : 0,
        loan: find_payroll.loan ? find_payroll.loan : 0,
        monthly_tax: find_payroll.monthly_tax,
        // tax_file: find_payroll.tax_file,
        net_salary: find_payroll.net_salary,
        loan_deduction: find_payroll.loan_deduction
          ? find_payroll.loan_deduction
          : 0,
        lunch_deduction: find_payroll.lunch_deduction
          ? find_payroll.lunch_deduction
          : 0,
        fine_deduction: find_payroll.fine_deduction
          ? find_payroll.fine_deduction
          : 0,
        other_deduction: find_payroll.other_deduction
          ? find_payroll.other_deduction
          : 0,
        other_deduction_label: find_payroll.other_deduction_label
          ? find_payroll.other_deduction_label
          : "",
        other_payment_label: find_payroll.other_payment_label
          ? find_payroll.other_payment_label
          : "",
        gross_salary: find_payroll.gross_salary,
        general_allowances: find_payroll.general_allowances
          ? find_payroll.general_allowances
          : [],
        other_allowances: find_payroll.other_allowances
          ? find_payroll.other_allowances
          : [],
        other_deductions: find_payroll.other_deductions
          ? find_payroll.other_deductions
          : [],
        active_status: find_payroll.active_status,
        total_allowances: find_payroll.total_allowances
          ? find_payroll.total_allowances
          : 0,
        total_deductions: find_payroll.total_deductions
          ? find_payroll.total_deductions
          : 0,
        date: find_payroll.date,
        createdAt: find_payroll.createdAt,
        updatedAt: find_payroll.updatedAt,
        webmail_email: employee.webmail_email,
        designation: employee.designation ? employee.designation : "N/A",
        emp_id: employee.employee_id ? employee.employee_id : "N/A",
        bank_account: employee.bank_account ? employee.bank_account : "N/A",
      };

      console.log("payroll_object:====================", payroll_object);
      //generate payslip return aws 3 path
      const pay_slip = await generatePayslip(payroll_object);

      console.log("pay_slip:====================", pay_slip);

      var file_to_upload = fs.readFileSync(pay_slip);

      console.log(
        "file_to_upload ; buffer:====================",
        file_to_upload
      );

      let s3_path = await UPLOAD_FILE_on_S3_with_CONTENT_TYPE(
        file_to_upload,
        `payslips/`,
        ".pdf",
        "application/pdf"
      );

      console.log("s3_path:====================", s3_path);

      try {
        fs.unlinkSync(pay_slip);
        console.log("File deleted successfully!");
      } catch (err) {
        console.error("Error deleting file:", err);
      }

      if (s3_path) {
        //save path in payroll

        find_payroll.pay_slip = s3_path;
        await find_payroll.save();
      }

      var base_url = "";
      if (process.env.NODE_ENV === "dev") {
        base_url =
          "https://metalogix-support-portal-dev-app-bucket.s3.amazonaws.com/";
      } else if (process.env.NODE_ENV === "prod") {
        base_url =
          "https://metalogix-support-portal-app-bucket.s3.amazonaws.com/";
      }

      var s3_url_of_payslip = base_url + s3_path;

      var attachment_array = []; //array of strings

      attachment_array.push(s3_url_of_payslip);

      if (find_payroll.tax_file && find_payroll.tax_file != "") {
        let s3_url_of_tax_file = base_url + find_payroll.tax_file;
        attachment_array.push(s3_url_of_tax_file);
      }

      if (is_send_email && employee.webmail_email) {
        //send email to employee pay slip have aws 3 link
        // SEND_EMAIL_BY_ML_MS(
        //   employee.webmail_email,
        //   `Payslip ${month_name} ${year}`,
        //   "Please find attached payslip for the month of " +
        //     month_name +
        //     " " +
        //     year,
        //   attachment_array
        // );

        try {
          await SEND_EMAIL_BY_SES(
            employee.webmail_email,
            `Payslip ${month_name} ${year}`,
            "Please find attached payslip for the month of " +
              month_name +
              " " +
              year,
            attachment_array
          );
        } catch (err) {
          console.log("Error in sending email: ", err.message);
        }
      }
    }
  }
};

const update_payrolls = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  console.log("body:=========", body);

  const find_payroll_ids = await find_payroll_ids_by_month_year(
    body.month,
    body.year
  );

  let payroll_ids = [];

  if (find_payroll_ids.length > 0) {
    for (let i = 0; i < find_payroll_ids.length; i++) {
      payroll_ids.push(find_payroll_ids[i]._id);
    }
  }

  console.log("payroll_ids: ", payroll_ids);
  for (let i = 0; i < payroll_ids.length; i++) {
    let employee;
    const find_payroll = await find_payroll_by_id(payroll_ids[i]);
    if (find_payroll) {
      employee = await find_employee_by_id(find_payroll.emp_obj_id);
    }

    let pay_date = moment(find_payroll.createdAt).format("D - MMMM - YYYY");
    let payroll_object = {};

    if (find_payroll && employee) {
      payroll_object = {
        _id: find_payroll._id,
        emp_obj_id: find_payroll.emp_obj_id,
        emp_name: find_payroll.emp_name,
        month: body.set_month,
        year: find_payroll.year,
        pay_date: pay_date,
        basic_salary: find_payroll.basic_salary,
        conveyance_allowance: find_payroll.conveyance_allowance
          ? find_payroll.conveyance_allowance
          : 0,
        medical_allowance: find_payroll.medical_allowance
          ? find_payroll.medical_allowance
          : 0,
        // rent_allowance: find_payroll.rent_allowance,
        food_allowance: find_payroll.food_allowance
          ? find_payroll.food_allowance
          : 0,
        other_payment: find_payroll.other_payment
          ? find_payroll.other_payment
          : 0,
        commission: find_payroll.commission ? find_payroll.commission : 0,
        overtime: find_payroll.overtime ? find_payroll.overtime : 0,
        loan: find_payroll.loan ? find_payroll.loan : 0,
        monthly_tax: find_payroll.monthly_tax,
        // tax_file: find_payroll.tax_file,
        net_salary: find_payroll.net_salary,
        loan_deduction: find_payroll.loan_deduction
          ? find_payroll.loan_deduction
          : 0,
        lunch_deduction: find_payroll.lunch_deduction
          ? find_payroll.lunch_deduction
          : 0,
        fine_deduction: find_payroll.fine_deduction
          ? find_payroll.fine_deduction
          : 0,
        other_deduction: find_payroll.other_deduction
          ? find_payroll.other_deduction
          : 0,
        other_deduction_label: find_payroll.other_deduction_label
          ? find_payroll.other_deduction_label
          : "",
        other_payment_label: find_payroll.other_payment_label
          ? find_payroll.other_payment_label
          : "",
        gross_salary: find_payroll.gross_salary,
        general_allowances: find_payroll.general_allowances
          ? find_payroll.general_allowances
          : [],
        other_allowances: find_payroll.other_allowances
          ? find_payroll.other_allowances
          : [],
        other_deductions: find_payroll.other_deductions
          ? find_payroll.other_deductions
          : [],
        active_status: find_payroll.active_status,
        total_allowances: find_payroll.total_allowances
          ? find_payroll.total_allowances
          : 0,
        total_deductions: find_payroll.total_deductions
          ? find_payroll.total_deductions
          : 0,
        date: find_payroll.date,
        createdAt: find_payroll.createdAt,
        updatedAt: find_payroll.updatedAt,
        webmail_email: employee.webmail_email,
        designation: employee.designation ? employee.designation : "N/A",
        emp_id: employee.employee_id ? employee.employee_id : "N/A",
        bank_account: employee.bank_account ? employee.bank_account : "N/A",
      };

      console.log("payroll_object:====================", payroll_object);
      //generate payslip return aws 3 path
      const pay_slip = await generatePayslip(payroll_object);

      // console.log("pay_slip:====================", pay_slip);

      var file_to_upload = fs.readFileSync(pay_slip);

      console.log(
        "file_to_upload ; buffer:====================",
        file_to_upload
      );

      let s3_path = await UPLOAD_FILE_on_S3_with_CONTENT_TYPE(
        file_to_upload,
        `payslips/`,
        ".pdf",
        "application/pdf"
      );

      console.log("s3_path:====================", s3_path);

      try {
        fs.unlinkSync(pay_slip);
        console.log("File deleted successfully!");
      } catch (err) {
        console.error("Error deleting file:", err);
      }

      if (s3_path) {
        //save path in payroll

        find_payroll.pay_slip = s3_path;
      }

      find_payroll.month = body.set_month;
      await find_payroll.save();
    }
  }

  return resp;
};

const _sendPayslipAgain = async (body, resp) => {
  console.log(body);

  const find_payroll = await find_payroll_by_id(body.payroll_id);
  if (!find_payroll) {
    resp.error = true;
    resp.error_message = "Payroll not found";
    return resp;
  }

  if (!find_payroll.pay_slip) {
    resp.error = true;
    resp.error_message = "Payslip not Found Generate Payslip First";
    return resp;
  }

  let month_name = moment(find_payroll.month, "MM").format("MMMM");
  let year = find_payroll.year;

  let employee = await find_employee_by_id(find_payroll.emp_obj_id);

  var base_url = "";
  if (process.env.NODE_ENV === "dev") {
    base_url =
      "https://metalogix-support-portal-dev-app-bucket.s3.amazonaws.com/";
  } else if (process.env.NODE_ENV === "prod") {
    base_url = "https://metalogix-support-portal-app-bucket.s3.amazonaws.com/";
  }

  var s3_url_of_payslip = base_url + find_payroll.pay_slip;

  var attachment_array = []; //array of strings

  attachment_array.push(s3_url_of_payslip);

  if (find_payroll.tax_file && find_payroll.tax_file != "") {
    let s3_url_of_tax_file = base_url + find_payroll.tax_file;
    attachment_array.push(s3_url_of_tax_file);
  }

  if (employee.webmail_email) {
    try {
      SEND_EMAIL_BY_SES(
        employee.webmail_email,
        `Payslip ${month_name} ${year}`,
        "Please find attached payslip for the month of " +
          month_name +
          " " +
          year,
        attachment_array
      );
    } catch (err) {
      console.log("Error in sending email: ", err.message);
    }
  }

  return resp;
};

const sendPayslipAgain = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _sendPayslipAgain(body, resp);
  return resp;
};

module.exports = {
  addPayroll,
  editPayroll,
  detailPayroll,
  deletePayroll,
  searchPayroll,
  emailPayslip,
  searchPayrollV1,
  sendPayslipAgain,
  update_payrolls,
};
