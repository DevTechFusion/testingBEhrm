const { LoanRequest } = require("../models/loan_request");
const { get_website_gernal_setting } = require("../DAL/website_setting");
const { find_user, find_user_by_id } = require("../DAL/user");
const {
  add_loan_request,
  find_loan_request_by_id,
  pagination_loan_request,
  all_loan_requests_active,
  all_loan_requests_active_count,
  delete_loan_request_by_id,
  get_loan_request_search,
  loan_request_search_count,
  find_loan_request_by_emp_and_date,
  find_loan_requests_for_employee,
  search_loan_requests_by_query_obj,
  find_loan_request_by_id_user,
  search_loan_requests,
  search_loan_requests_admin,
  pending_paid_installment_counts,
  update_installment_status,
  loan_request_details,
  find_installment_by_installment_id,
  find_all_loan_requests,
  get_approved_pending_loan,
  get_pending_installments,
  rollout_installment_status,
  update_installment_objects,
  pending_installments_for_admin,
  count_pending_installments,
  update_loan_returned_date,
  find_installment_by_installment_id_and_update,
  sum_of_amount_paid_amount_pending_amount,
} = require("../DAL/loan_request");
const {
  find_employee_by_id,
  find_employee_by_user_id,
  get_all_active_hr,
  get_active_alls,
  get_active_alls_hrs,
  get_team_members_ids,
  get_active_alls_hrs_and_admin,
  get_employee_name_and_salary,
  find_employee_by_user_id_without_populate,
} = require("../DAL/employee");

const { ObjectId } = require("mongodb");

const {
  add_notification,
  delete_loan_request_notifications,
} = require("../DAL/notification");
const {
  NOTIFY_BY_EMAIL_FROM_SES,
  SEND_EMAIL,
  SEND_EMAIL_BY_ML_MS,
} = require("../utils/utils");
const { NOTIFICATION_TYPE } = require("../utils/constants");
const moment = require("moment");
const _ = require("lodash");
const mongoose = require("mongoose");
const { validate } = require("joi/lib/types/lazy");

const _addLoanRequest = async (user_id, body, resp) => {
  console.log("body: ", body);
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  // let alls_hrs = await get_active_alls_hrs();
  let alls_hrs = await get_active_alls_hrs_and_admin();
  let installments = [];
  // let today = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY").utc(true);
  // convert date string to moment date from installments array
  for (let i = 0; i < body.installments.length; i++) {
    const installment_date = moment(
      body.installments[i].due_date,
      "DD-MM-YYYY"
    ).utc(true);

    if (
      installment_date == "Invalid date" ||
      installment_date == null ||
      installment_date == undefined
    ) {
      resp.error = true;
      resp.error_message =
        "This date : " +
        body.installments[i].due_date +
        " is not valid. Enter a valid date";
      return resp;
    }

    // if (installment_date.isSameOrBefore(today)) {
    //   resp.error = true;
    //   resp.error_message =
    //     "This date : " +
    //     body.installments[i].due_date +
    //     " is not valid. Due date must be greater than today's date";
    //   return resp;
    // }

    const installment_obj = {
      due_date: installment_date.format(),
      amount: body.installments[i].amount,
    };
    installments.push(installment_obj);
  }

  let loan_request_obj = {
    emp_obj_id: emp_details._id,
    emp_name: emp_details.full_name,
    amount: body.amount,
    description: body.description,
    loan_type: body.loan_type,
    installments: installments,
  };

  const final_loan_request = await add_loan_request(loan_request_obj);
  for (let j = 0; j < alls_hrs.length; j++) {
    if (alls_hrs[j].previllages.loans.view) {
      let notification_obj = {
        user_id: alls_hrs[j].user_id,
        loan_request_id: final_loan_request._id,
        title: "Loan Request",
        description:
          "Hi! " + emp_details.full_name + " just requested for a loan.",
        type: NOTIFICATION_TYPE.loan_request,
      };
      await add_notification(notification_obj);
      SEND_EMAIL_BY_ML_MS(
        alls_hrs[j].webmail_email,
        "Loan Request",
        notification_obj.description
      );
    }
  }

  resp.data = final_loan_request;
  return resp;
};
const addLoanRequest = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addLoanRequest(user_id, body, resp);
  return resp;
};

//************************{add loan request v1} ********************************/
const _addLoanRequestV1 = async (user_id, body, resp) => {
  console.log("body: ", body);
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  //find user have loan approved and pending

  const check_loan = await get_approved_pending_loan(emp_details._id);

  if (check_loan) {
    resp.error = true;
    resp.error_message = "You have Already Requested for Loan ";
    return resp;
  }

  // let alls_hrs = await get_active_alls_hrs();
  let alls_hrs = await get_active_alls_hrs_and_admin();

  //installment in advance salary case for one month
  let installments = [];
  let one_month_after_date;

  if (body.loan_type == "advance_salary") {
    //current date with moment

    let current_date = moment(moment().format("YYYY-MM-DD"), "YYYY-MM-DD").utc(
      true
    );

    //one month after date of current date
    one_month_after_date = moment(current_date).add(1, "months");

    //installment object in advance salary case
    let installment_obj = {
      due_date: one_month_after_date.format(),
      amount: body.amount,
    };

    installments.push(installment_obj);
  }

  let loan_request_obj = {
    emp_obj_id: emp_details._id,
    emp_name: emp_details.full_name,
    amount: body.amount,
    description: body.description,
    loan_type: body.loan_type,
    pending_amount: body.amount,
    installment_start_from: body.installment_start_from
      ? body.installment_start_from
      : one_month_after_date,
    no_of_installments: body.no_of_installments ? body.no_of_installments : 1,
    installments: body.installments ? body.installments : installments,
    paid_installments_count: 0,
    pending_installments_count: body.no_of_installments
      ? body.no_of_installments
      : 1,
  };

  const final_loan_request = await add_loan_request(loan_request_obj);
  for (let j = 0; j < alls_hrs.length; j++) {
    if (alls_hrs[j].previllages.loans.view) {
      let notification_obj = {
        user_id: alls_hrs[j].user_id,
        loan_request_id: final_loan_request._id,
        title: "Loan Request",
        description:
          "Hi! " + emp_details.full_name + " just requested for a loan.",
        type: NOTIFICATION_TYPE.loan_request,
      };
      await add_notification(notification_obj);
      SEND_EMAIL_BY_ML_MS(
        alls_hrs[j].webmail_email,
        "Loan Request",
        notification_obj.description
      );
    }
  }

  resp.data = final_loan_request;
  return resp;
};
const addLoanRequestV1 = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addLoanRequestV1(user_id, body, resp);
  return resp;
};

const _editLoanRequest = async (user_id, loan_request_id, body, resp) => {
  const loan_request_detail = await find_loan_request_by_id(loan_request_id);
  if (!loan_request_detail) {
    resp.error = true;
    resp.error_message = "Invalid Loan Request ID";
    return resp;
  }
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  if (loan_request_detail.emp_obj_id.toString() != emp_details._id.toString()) {
    resp.error = true;
    resp.error_message = "You can not edit this loan request";
    return resp;
  }
  if (loan_request_detail.status != "pending") {
    resp.error = true;
    resp.error_message = "This loan request is already processed";
    return resp;
  }
  // console.log("body: ", body);
  let installments = [];
  let today = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY").utc(true);
  // convert date string to moment date from installments array
  for (let i = 0; i < body.installments.length; i++) {
    const installment_date = moment(
      body.installments[i].due_date,
      "DD-MM-YYYY"
    ).utc(true);

    if (
      installment_date == "Invalid date" ||
      installment_date == null ||
      installment_date == undefined
    ) {
      resp.error = true;
      resp.error_message =
        "This date : " +
        body.installments[i].due_date +
        " is not valid. Enter a valid date";
      return resp;
    }

    // if (installment_date.isSameOrBefore(today)) {
    //   resp.error = true;
    //   resp.error_message =
    //     "This date : " +
    //     body.installments[i].due_date +
    //     " is not valid. Due date must be greater than today's date";
    //   return resp;
    // }

    const installment_obj = {
      due_date: installment_date.format(),
      amount: body.installments[i].amount,
    };
    installments.push(installment_obj);
  }

  loan_request_detail.amount = body.amount;
  loan_request_detail.description = body.description;
  loan_request_detail.loan_type = body.loan_type;
  loan_request_detail.installments = installments;

  await loan_request_detail.save();
  resp.data = loan_request_detail;
  return resp;
};
const editLoanRequest = async (user_id, loan_request_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editLoanRequest(user_id, loan_request_id, body, resp);
  return resp;
};

//************************{edit loan request v1} ********************************/
const _editLoanRequestV1 = async (user_id, loan_request_id, body, resp) => {
  const loan_request_detail = await find_loan_request_by_id(loan_request_id);
  if (!loan_request_detail) {
    resp.error = true;
    resp.error_message = "Invalid Loan Request ID";
    return resp;
  }
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  if (loan_request_detail.emp_obj_id.toString() != emp_details._id.toString()) {
    resp.error = true;
    resp.error_message = "You can not edit this loan request";
    return resp;
  }
  if (loan_request_detail.status != "pending") {
    resp.error = true;
    resp.error_message = "This loan request is already processed";
    return resp;
  }

  //installment in advance salary case for one month after date
  let installments = [];
  let one_month_after_date;

  if (body.loan_type == "advance_salary") {
    //current date with moment

    let current_date = moment(moment().format("YYYY-MM-DD"), "YYYY-MM-DD").utc(
      true
    );

    //one month after date of current date
    one_month_after_date = moment(current_date).add(1, "months");

    console.log("current_date: ", current_date);
    console.log("one_month_after: ", one_month_after_date);

    //installment object in advance salary case
    let installment_obj = {
      due_date: one_month_after_date.format(),
      amount: body.amount,
    };

    installments.push(installment_obj);
  }

  loan_request_detail.amount = body.amount;
  loan_request_detail.description = body.description;
  loan_request_detail.loan_type = body.loan_type;
  loan_request_detail.pending_amount = body.amount;
  loan_request_detail.installment_start_from = body.installment_start_from
    ? body.installment_start_from
    : one_month_after_date;
  loan_request_detail.no_of_installments = body.no_of_installments
    ? body.no_of_installments
    : 1;
  loan_request_detail.installments = body.installments
    ? body.installments
    : installments;
  loan_request_detail.paid_installments_count = 0;
  loan_request_detail.pending_installments_count = body.no_of_installments
    ? body.no_of_installments
    : 1;

  await loan_request_detail.save();
  resp.data = loan_request_detail;
  return resp;
};
const editLoanRequestV1 = async (user_id, loan_request_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editLoanRequestV1(user_id, loan_request_id, body, resp);
  return resp;
};

const _detailLoanRequest = async (loan_request_id, resp) => {
  const loan_request = await loan_request_details(loan_request_id);

  console.log("loan_request : ", loan_request[0].emp_obj_id);

  const employee_data = await get_employee_name_and_salary(
    loan_request[0].emp_obj_id
  );

  console.log("employee_data : ", employee_data);

  if (loan_request.length > 0) {
    resp.data.loan_request = loan_request[0];
    resp.data.employee_data = employee_data;
    return resp;
  } else {
    resp.error = true;
    resp.error_message = "Invalid Loan Request ID!";
    return resp;
  }
};

const detailLoanRequest = async (loan_request_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailLoanRequest(loan_request_id, resp);
  return resp;
};

const _deleteLoanRequest = async (user_id, loan_request_id, resp) => {
  const get_loan_request = await find_loan_request_by_id(loan_request_id);
  if (!get_loan_request) {
    resp.error = true;
    resp.error_message = "Invalid Loan Request ID!";
    return resp;
  }
  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }
  if (get_loan_request.emp_obj_id.toString() != emp_details._id.toString()) {
    resp.error = true;
    resp.error_message = "You can not delete this loan request";
    return resp;
  }
  if (get_loan_request.status != "pending") {
    resp.error = true;
    resp.error_message = "This loan request is already processed";
    return resp;
  }
  const deleted_loan_request = await delete_loan_request_by_id(loan_request_id);
  if (!deleted_loan_request) {
    resp.error = true;
    resp.error_message = "Invalid Loan Request ID!";
    return resp;
  } else {
    await delete_loan_request_notifications(deleted_loan_request._id);
  }
  return resp;
};

const deleteLoanRequest = async (user_id, loan_request_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteLoanRequest(user_id, loan_request_id, resp);
  return resp;
};

const _searchLoanRequest = async (user_id, body, Limit, page, resp) => {
  // console.log("body: ", body);

  const emp_details = await find_employee_by_user_id(user_id);
  // if (!emp_details) {
  //   resp.error = true;
  //   resp.error_message = "Member not found";
  //   return resp;
  // }
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let total_pages = 0;
  let loan_request = [];
  let gernal_settings = {};

  if (emp_details) {
    let query_obj = { emp_obj_id: emp_details._id };
    // if (body.status && body.status != "") {
    //   query_obj.status = body.status;
    // }
    // if (
    //   body.date_from &&
    //   body.date_to &&
    //   body.date_from != "" &&
    //   body.date_to != "" &&
    //   body.date_from != null &&
    //   body.date_to != null &&
    //   body.date_from != undefined &&
    //   body.date_to != undefined
    // ) {
    //   query_obj.loan_request_date = {
    //     $gte: moment(body.date_from, "DD-MM-YYYY").utc(true),
    //     $lte: moment(body.date_to, "DD-MM-YYYY").utc(true),
    //   };
    // }

    //tab base serach  all , active , returned

    //all have all loan request

    //active have approved and pending loan request

    //returned have returned loan request

    if (body.tab && body.tab != "") {
      if (body.tab == "all") {
      } else if (body.tab == "active") {
        query_obj.status = { $in: ["approved", "pending"] };
      } else if (body.tab == "returned") {
        query_obj.status = "returned";
      }
    }

    if (body.search && body.search.trim() != "") {
      if (/^\d+$/.test(body.search)) {
        query_obj.amount = parseInt(body.search);
      } else {
        query_obj.loan_type = { $regex: new RegExp(body.search, "i") };
      }
    }
    console.log("query_obj: ", query_obj);
    loan_request = await search_loan_requests(query_obj, limit, skip);
    total_pages = await loan_request_search_count(query_obj);

    //gernal settings

    gernal_settings = await get_website_gernal_setting();
  }

  resp.data = {
    loan_request,
    gernal_settings,
    total_pages,
    load_more_url: `/loan_request/get_loan_request?page=${page}&limit=${limit}`,
  };

  // console.log("resp.data: ", resp.data);

  return resp;
};

const searchLoanRequest = async (user_id, body, limit, page) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchLoanRequest(user_id, body, limit, page, resp);
  return resp;
};

const _processLoanRequest = async (loan_req_id, user_id, body, resp) => {
  const loan_request_detail = await find_loan_request_by_id(loan_req_id);
  if (!loan_request_detail) {
    resp.error = true;
    resp.error_message = "Invalid Loan Request ID";
    return resp;
  }

  const emp_details = await find_employee_by_user_id(user_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  // if (emp_details._id == loan_request_detail.emp_obj_id) {
  //   resp.error = true;
  //   resp.error_message = "You cannot process your own loan_request";
  //   return resp;
  // }

  // if (
  //   loan_request_detail.status != "pending" &&
  //   loan_request_detail.status != ""
  // ) {
  //   resp.error = true;
  //   resp.error_message = "This loan request is already processed";
  //   return resp;
  // }

  const emp_details_to = await find_employee_by_id(
    loan_request_detail.emp_obj_id
  );
  if (!emp_details_to) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  loan_request_detail.status = body.status;

  if (body.status == "rejected") {
    loan_request_detail.rejection_reason = body.rejection_reason;

    if (emp_details.previllages.my_loans.view) {
      let notification_obj = {
        user_id: emp_details_to.user_id._id,
        loan_request_id: loan_request_detail._id,
        title: "Loan Request",
        description:
          "Hi! " +
          emp_details_to.full_name +
          ". Your loan request was rejected",
        type: NOTIFICATION_TYPE.loan_request,
      };
      await add_notification(notification_obj);
      SEND_EMAIL_BY_ML_MS(
        emp_details_to.webmail_email,
        "Loan Request Rejected",
        notification_obj.description + body.rejection_reason
      );
    }
  } else if (body.status == "approved") {
    let release_date = moment(body.release_date, "DD-MM-YYYY").utc(true);
    loan_request_detail.payment_method = body.payment_method;
    loan_request_detail.release_date = moment(body.release_date, "DD-MM-YYYY")
      .utc(true)
      .format();

    for (let i = 0; i < loan_request_detail.installments.length; i++) {
      const installment = loan_request_detail.installments[i];
      if (moment(installment.due_date).isBefore(release_date)) {
        resp.error = true;
        resp.error_message =
          "Release date must be less than due date of every installment";
        return resp;
      }
    }

    if (emp_details.previllages.my_loans.view) {
      let notification_obj = {
        user_id: emp_details_to.user_id._id,
        loan_request_id: loan_request_detail._id,
        title: "Loan Request",
        description:
          "Hi! " +
          emp_details_to.full_name +
          ". Your loan request got approved",
        type: NOTIFICATION_TYPE.loan_request,
      };
      await add_notification(notification_obj);
      SEND_EMAIL_BY_ML_MS(
        emp_details_to.webmail_email,
        "Loan Request Approved",
        notification_obj.description
      );
    }
  }
  await loan_request_detail.save();
  let final_loan_request_resp = loan_request_detail;
  const final_loan_request = await loan_request_details(loan_req_id);
  if (final_loan_request.length > 0) {
    final_loan_request_resp = final_loan_request[0];
  }

  resp.data = final_loan_request_resp;
  return resp;
};
const processLoanRequest = async (loan_req_id, user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _processLoanRequest(loan_req_id, user_id, body, resp);
  return resp;
};

const _addLoanRequestAdmin = async (user_id, body, resp) => {
  const admin_details = await find_user_by_id(user_id);
  if (!admin_details) {
    resp.error = true;
    resp.error_message = "Admin not found";
    return resp;
  }

  const emp_details = await find_employee_by_id(body.emp_obj_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  let alls_hrs = await get_active_alls_hrs_and_admin();
  // let all_hrs = await get_all_active_hr();
  let installments = [];
  let installments_html = "";
  // let today = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY").utc(true);
  // convert date string to moment date from installments array
  for (let i = 0; i < body.installments.length; i++) {
    const installment_date = moment(
      body.installments[i].due_date,
      "DD-MM-YYYY"
    ).utc(true);

    if (
      installment_date == "Invalid date" ||
      installment_date == null ||
      installment_date == undefined
    ) {
      resp.error = true;
      resp.error_message =
        "This date : " +
        body.installments[i].due_date +
        " is not valid. Enter a valid date";
      return resp;
    }

    const installment_obj = {
      due_date: installment_date.format(),
      amount: body.installments[i].amount,
      // status: "pending",
    };
    installments_html += `<tr>
    <td>${i + 1}</td>
    <td>${body.installments[i].amount}</td>
    <td>${installment_date.format("DD-MM-YYYY")}</td>
</tr>`;
    // if (body.installments[i].status == "paid") {
    //   installment_obj.status = "paid";
    //   installment_obj.payment_method = body.installments[i].payment_method;
    //   installment_obj.payment_date = moment(
    //     body.installments[i].payment_date,
    //     "DD-MM-YYYY"
    //   )
    //     .utc(true)
    //     .format();
    // }
    installments.push(installment_obj);
  }

  let loan_request_obj = {
    emp_obj_id: emp_details._id,
    emp_name: emp_details.full_name,
    amount: body.amount,
    description: body.description,
    loan_type: body.loan_type,
    installments: installments,
    status: body.status,
    payment_method: body.payment_method,
  };
  if (
    body.release_date &&
    body.release_date != "" &&
    body.release_date != null &&
    body.release_date != undefined
  ) {
    loan_request_obj.release_date = moment(body.release_date, "DD-MM-YYYY")
      .utc(true)
      .format();
  }

  const final_loan_request = await add_loan_request(loan_request_obj);
  for (let j = 0; j < alls_hrs.length; j++) {
    if (alls_hrs[j].previllages.loans.view) {
      let notification_obj = {
        user_id: alls_hrs[j].user_id,
        loan_request_id: final_loan_request._id,
        title: "Loan Request",
        description:
          "Hi! " +
          admin_details.full_name +
          " has just requested for a loan on behalf of " +
          emp_details.full_name,
        type: NOTIFICATION_TYPE.loan_request,
      };
      await add_notification(notification_obj);
      let email_body = `<!DOCTYPE html>
      <html lang="en">
      
      <head>
          <meta charset="UTF-8">
          <title>Email Template</title>
      </head>
      
      <body>
          <div>
              <b>Loan Request Added by ${emp_details.full_name}</b>
              <p>Description:  ${body.description}.</p>
             
              <p><b>Loan Type</b>: ${body.loan_type}</p>    
               <p><b>Total Amount</b>: ${body.amount} </p>
               <p><b>Loan Apply Date</b>: ${moment(
                 body.release_date,
                 "DD-MM-YYYY"
               )
                 .utc(true)
                 .format("DD-MM-YYYY")}</p>
            
              
              <p>Here is the installment plan.</p>
      
              <table border="1">
                  <thead>
                      <tr>
                          <th>#</th>
                          <th>Installment Amount</th>
                          <th>Installment Date</th>
                      </tr>
                  </thead>
                  <tbody>
                     ${installments_html}
                  </tbody>
              </table>
          </div>
      </body>
      
      </html>
      `;
      await NOTIFY_BY_EMAIL_FROM_SES(
        alls_hrs[j].webmail_email,
        "Loan Request",
        email_body
      );
    }
  }

  resp.data = final_loan_request;
  return resp;
};
const addLoanRequestAdmin = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addLoanRequestAdmin(user_id, body, resp);
  return resp;
};

//****************************{add loan request admin v1 } ******************************/
const _addLoanRequestAdminV1 = async (user_id, body, resp) => {
  const admin_details = await find_user_by_id(user_id);
  if (!admin_details) {
    resp.error = true;
    resp.error_message = "Admin not found";
    return resp;
  }
  const find_admin = await find_employee_by_user_id_without_populate(user_id);

  const emp_details = await find_employee_by_id(body.emp_obj_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  let alls_hrs = await get_active_alls_hrs_and_admin();

  //installment in advance salary case for one month
  let installments = [];
  let one_month_after_date;

  if (body.loan_type == "advance_salary") {
    //current date with moment

    let current_date = moment(moment().format("YYYY-MM-DD"), "YYYY-MM-DD").utc(
      true
    );

    //one month after date of current date
    one_month_after_date = moment(current_date).add(1, "months");

    //installment object in advance salary case
    let installment_obj = {
      due_date: one_month_after_date.format(),
      amount: body.amount,
    };

    installments.push(installment_obj);
  }

  let installments_check = body.installments ? body.installments : installments;

  //ggerate html for installments
  let installments_html = "";
  for (let i = 0; i < installments_check.length; i++) {
    installments_html += `<tr>
  <td>${i + 1}</td>
  <td>${installments_check[i].amount}</td>
  <td>${installments_check[i].due_date}</td>
</tr>`;
  }

  // //gernate html for installments
  //   for (let i = 0; i < body.installments.length; i++) {
  //     installments_html += `<tr>
  //     <td>${i + 1}</td>
  //     <td>${body.installments[i].amount}</td>
  //     <td>${installment_date.format("DD-MM-YYYY")}</td>
  // </tr>`;
  //   }

  let loan_request_obj = {
    emp_obj_id: emp_details._id,
    emp_name: emp_details.full_name,
    amount: body.amount,
    description: body.description,
    loan_type: body.loan_type,
    status: body.status,
    payment_method: body.payment_method,
    pending_amount: body.amount,
    installment_start_from: body.installment_start_from
      ? body.installment_start_from
      : one_month_after_date,
    no_of_installments: body.no_of_installments ? body.no_of_installments : 1,
    installments: body.installments ? body.installments : installments,
    paid_installments_count: 0,
    pending_installments_count: body.no_of_installments
      ? body.no_of_installments
      : 1,
  };

  if (
    body.release_date &&
    body.release_date != "" &&
    body.release_date != null &&
    body.release_date != undefined
  ) {
    loan_request_obj.release_date = moment(body.release_date)
      .utc(true)
      .format();
  }

  console.log("above final_loan_request ");

  const final_loan_request = await add_loan_request(loan_request_obj);
  for (let j = 0; j < alls_hrs.length; j++) {
    if (alls_hrs[j].previllages.loans.view) {
      let notification_obj = {
        user_id: alls_hrs[j].user_id,
        loan_request_id: final_loan_request._id,
        title: "Loan Request",
        description:
          "Hi! " +
          find_admin.full_name +
          " has just requested for a loan on behalf of " +
          emp_details.full_name,
        type: NOTIFICATION_TYPE.loan_request,
      };

      await add_notification(notification_obj);
      let email_body = `<!DOCTYPE html>
      <html lang="en">
      
      <head>
          <meta charset="UTF-8">
          <title>Email Template</title>
      </head>
      
      <body>
          <div>
              <b>Loan Request Added by ${emp_details.full_name}</b>
              <p>Description:  ${body.description}.</p>
             
              <p><b>Loan Type</b>: ${body.loan_type}</p>    
               <p><b>Total Amount</b>: ${body.amount} </p>
               <p><b>Loan Apply Date</b>: ${moment(
                 body.release_date,
                 "DD-MM-YYYY"
               )
                 .utc(true)
                 .format("DD-MM-YYYY")}</p>
            
              
              <p>Here is the installment plan.</p>
      
              <table border="1">
                  <thead>
                      <tr>
                          <th>#</th>
                          <th>Installment Amount</th>
                          <th>Installment Date</th>
                      </tr>
                  </thead>
                  <tbody>
                     ${installments_html}
                  </tbody>
              </table>
          </div>
      </body>
      
      </html>
      `;
      NOTIFY_BY_EMAIL_FROM_SES(
        alls_hrs[j].webmail_email,
        "Loan Request",
        email_body
      );
    }
  }

  resp.data = final_loan_request;
  return resp;
};
const addLoanRequestAdminV1 = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addLoanRequestAdminV1(user_id, body, resp);
  return resp;
};

const _editLoanRequestAdmin = async (user_id, loan_request_id, body, resp) => {
  const admin_details = await find_user_by_id(user_id);
  if (!admin_details) {
    resp.error = true;
    resp.error_message = "Admin not found";
    return resp;
  }

  const loan_request_detail = await find_loan_request_by_id(loan_request_id);
  if (!loan_request_detail) {
    resp.error = true;
    resp.error_message = "Invalid Loan Request ID";
    return resp;
  }

  if (loan_request_detail.status == "returned") {
    resp.error = true;
    resp.error_message = "This loan is already paid back";
    return resp;
  }

  for (let i = 0; i < loan_request_detail.installments.length; i++) {
    const installment = loan_request_detail.installments[i];
    if (installment.status == "paid") {
      resp.error = true;
      resp.error_message = "This loan is being paid back. You cannot edit it";
      return resp;
    }
  }

  // if (loan_request_detail.paid_installments_count > 0) {
  //   resp.error = true;
  //   resp.error_message = "This loan is being paid back. You cannot edit it";
  //   return resp;
  // }

  const emp_details = await find_employee_by_id(loan_request_detail.emp_obj_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  let installments = [];
  for (let i = 0; i < body.installments.length; i++) {
    const installment_date = moment(
      body.installments[i].due_date,
      "DD-MM-YYYY"
    ).utc(true);

    if (
      installment_date == "Invalid date" ||
      installment_date == null ||
      installment_date == undefined
    ) {
      resp.error = true;
      resp.error_message =
        "This date : " +
        body.installments[i].due_date +
        " is not valid. Enter a valid date";
      return resp;
    }

    const installment_obj = {
      due_date: installment_date.format(),
      amount: body.installments[i].amount,
      // status: "pending",
    };
    // if (body.installments[i].status == "paid") {
    //   installment_obj.status = "paid";
    //   installment_obj.payment_method = body.installments[i].payment_method;
    //   installment_obj.payment_date = moment(
    //     body.installments[i].payment_date,
    //     "DD-MM-YYYY"
    //   )
    //     .utc(true)
    //     .format();
    // }
    installments.push(installment_obj);
  }

  let release_date = null;
  if (
    body.release_date &&
    body.release_date != "" &&
    body.release_date != null &&
    body.release_date != undefined
  ) {
    release_date = moment(body.release_date, "DD-MM-YYYY").utc(true).format();
  }

  loan_request_detail.amount = body.amount;
  loan_request_detail.description = body.description;
  loan_request_detail.loan_type = body.loan_type;
  loan_request_detail.installments = installments;
  loan_request_detail.status = body.status;
  loan_request_detail.payment_method = body.payment_method;
  loan_request_detail.release_date = release_date;

  await loan_request_detail.save();
  resp.data = loan_request_detail;
  return resp;
};
const editLoanRequestAdmin = async (user_id, loan_request_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editLoanRequestAdmin(user_id, loan_request_id, body, resp);
  return resp;
};

//************************{edit loan request admin v1} ********************************/

const _editLoanRequestAdminV1 = async (
  user_id,
  loan_request_id,
  body,
  resp
) => {
  const admin_details = await find_user_by_id(user_id);
  if (!admin_details) {
    resp.error = true;
    resp.error_message = "Admin not found";
    return resp;
  }

  const loan_request_detail = await find_loan_request_by_id(loan_request_id);
  if (!loan_request_detail) {
    resp.error = true;
    resp.error_message = "Invalid Loan Request ID";
    return resp;
  }

  if (loan_request_detail.status == "returned") {
    resp.error = true;
    resp.error_message = "This loan is already paid back";
    return resp;
  } else if (loan_request_detail.status == "rejected") {
    resp.error = true;
    resp.error_message = "This loan is already rejected";
    return resp;
  }

  const emp_details = await find_employee_by_id(loan_request_detail.emp_obj_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  let installments = [];
  let one_month_after_date;

  if (body.loan_type == "advance_salary") {
    //current date with moment

    let current_date = moment(moment().format("YYYY-MM-DD"), "YYYY-MM-DD").utc(
      true
    );

    //one month after date of current date
    one_month_after_date = moment(current_date).add(1, "months");

    //installment object in advance salary case
    let installment_obj = {
      due_date: one_month_after_date.format(),
      amount: body.amount,
    };

    installments.push(installment_obj);
  }

  let release_date = null;
  if (
    body.release_date &&
    body.release_date != "" &&
    body.release_date != null &&
    body.release_date != undefined
  ) {
    release_date = moment(body.release_date).utc(true).format();
  }

  loan_request_detail.amount = body.amount;
  loan_request_detail.description = body.description;
  loan_request_detail.loan_type = body.loan_type;
  loan_request_detail.pending_amount = body.amount;
  loan_request_detail.installment_start_from = body.installment_start_from
    ? body.installment_start_from
    : one_month_after_date;
  loan_request_detail.no_of_installments = body.no_of_installments
    ? body.no_of_installments
    : 1;
  loan_request_detail.installments = body.installments
    ? body.installments
    : installments;
  loan_request_detail.paid_installments_count = 0;
  loan_request_detail.pending_installments_count = body.no_of_installments
    ? body.no_of_installments
    : 1;
  loan_request_detail.status = body.status;
  loan_request_detail.payment_method = body.payment_method;
  loan_request_detail.release_date = release_date;

  await loan_request_detail.save();
  resp.data = loan_request_detail;
  return resp;
};
const editLoanRequestAdminV1 = async (user_id, loan_request_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editLoanRequestAdminV1(user_id, loan_request_id, body, resp);
  return resp;
};

const _deleteLoanRequestAdmin = async (user_id, loan_request_id, resp) => {
  const admin_details = await find_user_by_id(user_id);
  if (!admin_details) {
    resp.error = true;
    resp.error_message = "Admin not found";
    return resp;
  }

  // if (admin_details.type != 0) {
  //   resp.error = true;
  //   resp.error_message = "You are not authorized";
  //   return resp;
  // }
  // const get_loan_request = await find_loan_request_by_id(loan_request_id);
  // if (!get_loan_request) {
  //   resp.error = true;
  //   resp.error_message = "Invalid LoanRequest ID!";
  //   return resp;
  // }
  // if (get_loan_request.status != "pending") {
  //   resp.error = true;
  //   resp.error_message = "This loan_request is already processed";
  //   return resp;
  // }
  const deleted_loan_request = await delete_loan_request_by_id(loan_request_id);
  if (!deleted_loan_request) {
    resp.error = true;
    resp.error_message = "Invalid LoanRequest ID!";
    return resp;
  } else {
    await delete_loan_request_notifications(deleted_loan_request._id);
  }
  return resp;
};

const deleteLoanRequestAdmin = async (user_id, loan_request_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteLoanRequestAdmin(user_id, loan_request_id, resp);
  return resp;
};

const _updateInstallmentStatus = async (loan_req_id, user_id, body, resp) => {
  const loan_request_detail = await find_loan_request_by_id(loan_req_id);
  if (!loan_request_detail) {
    resp.error = true;
    resp.error_message = "Invalid Loan Request ID";
    return resp;
  }

  if (loan_request_detail.status == "pending") {
    resp.error = true;
    resp.error_message = "This loan request has not been approved yet";
    return resp;
  }

  if (loan_request_detail.status == "rejected") {
    resp.error = true;
    resp.error_message = "This loan request has been rejected";
    return resp;
  }

  if (loan_request_detail.status == "returned") {
    resp.error = true;
    resp.error_message = "This loan is already paid back";
    return resp;
  }

  //Return message if installment is already rolled out

  let is_rolledout_object = loan_request_detail.installments.filter(
    (installment) => installment._id == body.installment_id
  );
  if (is_rolledout_object[0].status == "rollout") {
    resp.error = true;
    resp.error_message = "This installment is already rolled out";
    return resp;
  }

  //Return message if installment is already paid
  const pending_index = _.findIndex(loan_request_detail.installments, {
    status: "pending",
  });

  if (pending_index == -1) {
    resp.error = true;
    resp.error_message = "No pending installments";
    return resp;
  }

  if (body.status == "paid") {
    await update_installment_status(
      loan_request_detail._id,
      body.installment_id,
      body.status,
      body.payment_date,
      body.payment_method
    );

    const installment_by_id = await find_installment_by_installment_id(
      loan_req_id,
      body.installment_id
    );

    console.log("installment_by_id: ", installment_by_id);

    let amonut_paid = installment_by_id.installments[0].amount;

    loan_request_detail.pending_amount =
      loan_request_detail.pending_amount - amonut_paid;
    loan_request_detail.paid_amount =
      loan_request_detail.paid_amount + amonut_paid;

    loan_request_detail.paid_installments_count =
      loan_request_detail.paid_installments_count + 1;
    loan_request_detail.pending_installments_count =
      loan_request_detail.pending_installments_count - 1;

    if (loan_request_detail.pending_amount < 0) {
      loan_request_detail.pending_amount = 0;
    }
    await loan_request_detail.save();
  }

  //add installment_by_id.instalments.ammount to paid_amount and subtract from pending_amount

  // const ObjectId = mongoose.Types.ObjectId;
  // console.log("body: ", body);
  // console.log("installment_id type 1: ", typeof body.installment_id);
  // let installment_id = new ObjectId(body.installment_id);
  // console.log("installment_id: ", installment_id);
  // console.log("installment_id type 2: ", typeof installment_id);

  // console.log("loan_req: ", loan_request_detail);

  // const index = _.findIndex(loan_request_detail.installments, {
  //   "installments._id": installment_id,
  // });

  // if (index == -1) {
  //   resp.error = true;
  //   resp.error_message = "Installment not found";
  //   return resp;
  // }

  // loan_request_detail.installments[index].payment_method = body.payment_method;
  // loan_request_detail.installments[index].status = body.status;
  // loan_request_detail.installments[index].payment_date = moment(
  //   body.payment_date,
  //   "DD-MM-YYYY"
  // )
  //   .utc(true)
  //   .format();

  // loan_request_detail.save();

  const saved_loan = await find_loan_request_by_id(loan_req_id);
  if (!saved_loan) {
    resp.error = true;
    resp.error_message = "Could not save loan request";
    return resp;
  }

  const index = _.findIndex(saved_loan.installments, { status: "pending" });

  if (index == -1) {
    saved_loan.status = "returned";
    saved_loan.returned_date = moment().format("YYYY-MM-DD");

    saved_loan.save();
  }

  const emp_details = await find_employee_by_id(loan_request_detail.emp_obj_id);
  if (!emp_details) {
    resp.error = true;
    resp.error_message = "Member not found";
    return resp;
  }

  if (body.status == "paid") {
    if (emp_details.previllages.my_loans.view) {
      let notification_obj = {
        user_id: emp_details.user_id._id,
        loan_request_id: loan_request_detail._id,
        title: "Loan Request",
        description:
          "Hi! " +
          emp_details.full_name +
          ". Thanks for paying back your installments. Visit your application to check details.",
        type: NOTIFICATION_TYPE.loan_request,
      };
      await add_notification(notification_obj);
      SEND_EMAIL_BY_ML_MS(
        emp_details.webmail_email,
        "Installment Paid",
        notification_obj.description
      );
    }
  }

  resp.data = saved_loan;
  return resp;
};
const updateInstallmentStatus = async (loan_req_id, user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _updateInstallmentStatus(loan_req_id, user_id, body, resp);
  return resp;
};

const _searchLoanRequestAdmin = async (user_id, body, Limit, page, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  // sum of loan total amount paid and pending amount

  const loan_statas = await sum_of_amount_paid_amount_pending_amount();
  //   loan_statas: Array [ {…} ]
  // ​​​
  // 0: Object { total_amount: 1493350, total_paid_amount: 865857, total_pending_amount: 628611, … }

  //loan_statas is an array of object
  //total_amount: 1493350
  //total_paid_amount: 865857
  //total_pending_amount: 628611

  // make variables

  let total_amount = loan_statas[0].total_amount;
  let total_paid_amount = loan_statas[0].total_paid_amount;
  let total_pending_amount = loan_statas[0].total_pending_amount;

  // let total_pages = 0;
  let total_pending_installments = 0;
  let total_paid_installments = 0;
  // let loan_request = [];
  // let gernal_settings = {};

  let date_from;
  let date_to;

  if (body.date_from && body.date_to) {
    date_from = moment(body.date_from, "YYYY-MM-DD", true);
    date_to = moment(body.date_to, "YYYY-MM-DD", true);

    //check if date is valid else return error not query not other just return error

    if (!date_from.isValid() || !date_to.isValid()) {
      return { error: true, message: "Invalid date format" };
    }
  }

  let query_obj = {};

  if (date_from && date_to && body.status == "returned") {
    query_obj.returned_date = {
      $gte: date_from.toDate(),
      $lte: date_to.toDate(),
    };
  }

  if (date_from && date_to && body.status != "returned") {
    query_obj.application_date = {
      $gte: date_from.toDate(),
      $lte: date_to.toDate(),
    };
  }

  if (body.loan_type && body.loan_type != "") {
    query_obj.loan_type = { $regex: new RegExp(body.loan_type, "i") };
  }
  if (body.status && body.status != "") {
    // query_obj.status = { $regex: new RegExp(body.status, "i") };
    if (body.status == "all") {
      // query_obj.status = { $nin: [returned""] };
    } else if (body.status == "active") {
      query_obj.status = { $in: ["pending", "approved"] };
    } else {
      query_obj.status = { $regex: new RegExp(body.status, "i") };
    }
  }
  if (body.emp_name && body.emp_name != "") {
    query_obj.emp_name = { $regex: new RegExp(body.emp_name, "i") };
  }

  let [total_pages, gernal_settings, loan_request] = await Promise.all([
    loan_request_search_count(query_obj),
    get_website_gernal_setting(),
    search_loan_requests_admin(query_obj, limit, skip),
    // pending_paid_installment_counts(query_obj)
  ]);

  // if (counts.length > 0) {
  //   total_pages = counts[0].total_documents;
  //   total_pending_installments = counts[0].total_pending_installments;
  //   total_paid_installments = counts[0].total_paid_installments;
  // }

  resp.data = {
    total_amount: total_amount,
    total_paid_amount: total_paid_amount,
    total_pending_amount: total_pending_amount,
    loan_request: loan_request ? loan_request : [],
    gernal_settings: gernal_settings ? gernal_settings : {},
    total_pages: total_pages,
    total_pending_installments: 0,
    total_paid_installments: 0,
    load_more_url: `/loan_request/get_loan_request?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchLoanRequestAdmin = async (user_id, body, limit, page) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchLoanRequestAdmin(user_id, body, limit, page, resp);
  return resp;
};

const _getTeamLoanRequestsForLead = async (
  user_id,
  body,
  Limit,
  page,
  resp
) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let team_loan_requests = [];
  let team_loan_requests_count = 0;

  const lead = await find_employee_by_user_id(user_id);
  if (lead) {
    let team = await get_team_members_ids(lead._id);
    console.log("team: ", team);
    if (team.length > 0) {
      let query_obj = { emp_obj_id: { $in: team } };
      if (body.status && body.status != "") {
        query_obj.status = body.status;
      }
      if (
        body.date_from &&
        body.date_to &&
        body.date_from != "" &&
        body.date_to != "" &&
        body.date_from != null &&
        body.date_to != null &&
        body.date_from != undefined &&
        body.date_to != undefined
      ) {
        query_obj.loan_request_date = {
          $gte: moment(body.date_from, "DD-MM-YYYY").utc(true),
          $lte: moment(body.date_to, "DD-MM-YYYY").utc(true),
        };
      }
      console.log("query: ", query_obj);
      team_loan_requests = await get_loan_request_search(
        query_obj,
        limit,
        skip
      );
      team_loan_requests_count = await loan_request_search_count(query_obj);
    }
  }

  const data = {
    team_loan_requests,
    team_loan_requests_count,
    load_more_url: `/employee/get_employees?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getTeamLoanRequestsForLead = async (user_id, body, limit, page) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getTeamLoanRequestsForLead(user_id, body, limit, page, resp);
  return resp;
};

const manage_old_loan_requests = async () => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  let all_loan_requests = await find_all_loan_requests();
  for (let i = 0; i < all_loan_requests.length; i++) {
    const loan_request = all_loan_requests[i];
    let pending_installments = 0;
    let paid_installments = 0;
    let paid_amount = 0;
    let pending_amount = 0;
    let rollout_installments_count = 0;
    for (let j = 0; j < loan_request.installments.length; j++) {
      const installment = loan_request.installments[j];
      if (installment.status == "pending") {
        pending_installments++;
        pending_amount += installment.amount;
      } else if (installment.status == "paid") {
        paid_installments++;
        paid_amount += installment.amount;
      } else if (installment.status == "rollout") {
        rollout_installments_count++;
      }
    }
    loan_request.pending_installments_count = pending_installments;
    loan_request.paid_installments_count = paid_installments;
    loan_request.pending_amount = pending_amount;
    loan_request.paid_amount = paid_amount;
    loan_request.rollout_installments_count = rollout_installments_count;
    loan_request.no_of_installments = loan_request.installments.length;
    loan_request.installment_start_from = moment(
      loan_request.installments[0].due_date
    );
    await loan_request.save();
  }

  return resp;
};

//**************************{rollout installment status} *********************************/
const _rolloutInstallmentStatus = async (loan_req_id, user_id, body, resp) => {
  if (body.status != "rollout") {
    resp.error = true;
    resp.error_message = "Invalid status";
    return resp;
  }

  const loan_request_detail = await find_loan_request_by_id(loan_req_id);
  if (!loan_request_detail) {
    resp.error = true;
    resp.error_message = "Invalid Loan Request ID";
    return resp;
  }

  console.log("loan_request_detail: ", loan_request_detail);

  if (
    loan_request_detail.status == "pending" ||
    loan_request_detail.status == "rejected" ||
    loan_request_detail.status == "returned"
  ) {
    resp.error = true;
    resp.error_message =
      "You cannot rollout installment status Your status is not approved";
    return resp;
  }

  //check if installment is already rolled out
  const check_rollout_installment = loan_request_detail.installments.filter(
    (installment) => installment._id == body.installment_id
  );

  if (check_rollout_installment[0].status == "rollout") {
    resp.error = true;
    resp.error_message = "This installment is already rolled out";
    return resp;
  }

  if (check_rollout_installment[0].status == "paid") {
    resp.error = true;
    resp.error_message = "This installment is already paid";
    return resp;
  }

  //if pending installment is one user can not roll out installment status

  const pendingInstallments = loan_request_detail.installments.filter(
    (installment) => installment.status == "pending"
  );

  console.log("pendingInstallments: ", pendingInstallments);
  //lenth of pending installments
  console.log("pendingInstallments.length: ", pendingInstallments.length);

  if (pendingInstallments.length == 1) {
    resp.error = true;
    resp.error_message = "This is the last installment. You cannot rollout";
    return resp;
  }

  //get installment by installment _id from pendingInstallments
  const current_installment = pendingInstallments.find(
    (installment) => installment._id == body.installment_id
  );

  if (!current_installment) {
    resp.error = true;
    resp.error_message = "Invalid Installment ID";
    return resp;
  }

  let rolled_out_amount = current_installment.amount;

  console.log("current_installment: ", current_installment);

  //rollout installment status
  const rolled_out_installment = await rollout_installment_status(
    loan_req_id,
    body.installment_id
  );
  console.log("rolled_out_installment: ", rolled_out_installment);
  if (!rolled_out_installment) {
    resp.error = true;
    resp.error_message = "Could not rollout installment status";
    return resp;
  }

  let new_pendingInstallments = pendingInstallments.filter(
    (installment) =>
      installment._id.toString() != body.installment_id.toString()
  );
  console.log("new_pendingInstallments: ", new_pendingInstallments);

  //count ammount from pending installments
  let pending_amount = 0;
  // for (let i = 0; i < new_pendingInstallments.length; i++) {
  //   pending_amount += new_pendingInstallments[i].amount;
  // }

  pending_amount = new_pendingInstallments.reduce(
    (acc, installment) => acc + installment.amount,
    0
  );

  console.log("pending_amount: ", pending_amount);

  let total_pending_amount = pending_amount + rolled_out_amount;
  console.log("total_pending_amount: ", total_pending_amount);

  let one_installment_amount = Math.ceil(
    total_pending_amount / new_pendingInstallments.length
  );
  console.log("one_installment_amount: ", one_installment_amount);

  const updated_installments = await update_installment_objects(
    loan_req_id,
    one_installment_amount
  );

  if (!updated_installments) {
    resp.error = true;
    resp.error_message = "Could not update installment status";
    return resp;
  }

  // const saved_loan = await find_loan_request_by_id(loan_req_id);
  // if (!saved_loan) {
  //   resp.error = true;
  //   resp.error_message = "Could not save loan request";
  //   return resp;
  // }

  // const index = _.findIndex(saved_loan.installments, { status: "pending" });

  // if (index == -1) {
  //   saved_loan.status = "returned";
  //   saved_loan.save();
  // }

  // const emp_details = await find_employee_by_id(loan_request_detail.emp_obj_id);
  // if (!emp_details) {
  //   resp.error = true;
  //   resp.error_message = "Member not found";
  //   return resp;
  // }

  // if (body.status == "paid") {
  //   if (emp_details.previllages.my_loans.view) {
  //     let notification_obj = {
  //       user_id: emp_details.user_id._id,
  //       loan_request_id: loan_request_detail._id,
  //       title: "Loan Request",
  //       description:
  //         "Hi! " +
  //         emp_details.full_name +
  //         ". Thanks for paying back your installments. Visit your application to check details.",
  //       type: NOTIFICATION_TYPE.loan_request,
  //     };
  //     await add_notification(notification_obj);
  //     SEND_EMAIL_BY_ML_MS(
  //       emp_details.webmail_email,
  //       "Installment Paid",
  //       notification_obj.description
  //     );
  //   }
  // }

  resp.data = updated_installments;
  return resp;
};
const rolloutInstallmentStatus = async (loan_req_id, user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _rolloutInstallmentStatus(loan_req_id, user_id, body, resp);
  return resp;
};

//********************************{pending_loan_request_admin}*****************************/
const _pendingInstallmentsForAdmin = async (
  user_id,
  body,
  Limit,
  page,
  resp
) => {
  //pagination variables
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  //find user

  // const emp_details = await find_employee_by_user_id(user_id);
  // if (!emp_details) {
  //   resp.error = true;
  //   resp.error_message = "Member not found";
  //   return resp;
  // }

  console.log("body=============", body.emp_name);

  let query_obj = {};

  console.log("query_obj", query_obj);

  if (body.status != "") {
    query_obj = { "installments.status": body.status };
  }

  query_obj.status = "approved";

  if (body.emp_name) {
    query_obj.emp_name = new RegExp(body.emp_name, "i");
  }

  if (body.loan_type) {
    query_obj.loan_type = new RegExp(body.loan_type, "i");
  }

  // if (
  //   body.date_from &&
  //   body.date_to &&
  //   body.date_from != "" &&
  //   body.date_to != "" &&
  //   body.date_from != null &&
  //   body.date_to != null &&
  //   body.date_from != undefined &&
  //   body.date_to != undefined
  // ) {
  //   query_obj = {
  //     ...query_obj,
  //     "installments.due_date": {
  //       $gte: new Date(body.date_from),
  //       $lte: new Date(body.date_to),
  //     },
  //   };
  // }

  const pending_installments = await pending_installments_for_admin(
    query_obj,
    limit,
    skip,
    body
  );

  const total_pending_installments = await count_pending_installments(
    query_obj,
    body
  );

  let total_count = 0;
  if (total_pending_installments.length > 0) {
    total_count = total_pending_installments[0].installments;
  }

  let total_pages = Math.ceil(total_count / limit);

  if (total_pending_installments.length == 0) {
    total_count = 0;
    total_pages = 0;
  }

  // console.log("end of function");

  resp.data = {
    loan_request: pending_installments,
    total_count: total_count,
    total_pages: total_pages,
  };
  return resp;
};

const pendingInstallmentsForAdmin = async (user_id, body, limit, page) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _pendingInstallmentsForAdmin(user_id, body, limit, page, resp);
  return resp;
};

//********************************{update loan returned date}*****************************/
//for api use for update the returned date of loan which loan installments are paid
const _updateLoanReturnedDate = async (resp) => {
  const loans = await update_loan_returned_date();

  console.log("loan.length: ", loans.length);

  if (loans.length > 0) {
    //iterate over all loans and get payment date of indx 0 installment and update the returned date of loan
    for (let i = 0; i < loans.length; i++) {
      const loan = loans[i];
      const installment = loan.installments[0];
      await LoanRequest.updateOne(
        { _id: loan._id },
        { returned_date: installment.payment_date }
      );
    }
  }
  resp.data = {
    // loan: loans,
  };
  return resp;
};

const updateLoanReturnedDate = async () => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _updateLoanReturnedDate(resp);
  return resp;
};

//********************************{update loan returned date}*****************************/
//admin can update the installment date of loan
const _updateLoanInstallmentDate = async (body, resp) => {
  const installment = await find_installment_by_installment_id(
    body.loan_id,
    body.installment_id
  );

  console.log("installment: ", installment);

  if (!installment) {
    resp.error = true;
    resp.error_message = "Installment not found";
    return resp;
  }

  if (installment.installments[0].status != "pending") {
    resp.error = true;
    resp.error_message = "you can't chage date of this installment";
    return resp;
  }

  const updated_installment =
    await find_installment_by_installment_id_and_update(
      body.loan_id,
      body.installment_id,
      body.date
    );

  resp.data = {};
  return resp;
};

const updateLoanInstallmentDate = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _updateLoanInstallmentDate(body, resp);
  return resp;
};

module.exports = {
  addLoanRequest,
  addLoanRequestAdmin,
  editLoanRequest,
  editLoanRequestAdmin,
  detailLoanRequest,
  deleteLoanRequest,
  deleteLoanRequestAdmin,
  searchLoanRequest,
  searchLoanRequestAdmin,
  processLoanRequest,
  updateInstallmentStatus,
  getTeamLoanRequestsForLead,
  addLoanRequestV1,
  editLoanRequestV1,
  manage_old_loan_requests,
  addLoanRequestAdminV1,
  editLoanRequestAdminV1,
  rolloutInstallmentStatus,
  pendingInstallmentsForAdmin,
  updateLoanReturnedDate,
  updateLoanInstallmentDate,
};
