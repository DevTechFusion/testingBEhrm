const { find_user, find_user_by_id } = require("../DAL/user");
const {
  Add_department,
  find_department_by_id,
  pagination_department,
  all_department_count,
  delete_department_by_id,
  get_department_search,
  get_all_departments,
  department_search_count,
  find_department_by_name,
  get_all_active_departments,
} = require("../DAL/department");

const {
  delete_department_from_employees,
  update_department_name_in_employees,
} = require("../DAL/employee");

const { find_company_by_id } = require("../DAL/company");

const _addDepartment = async (body, resp) => {
  const department = await find_department_by_name(body);
  if (department) {
    resp.error = true;
    resp.error_message =
      "Department with same Title already exists in this company";
    return resp;
  }

  // body.active_status = true;
  // let members = [];
  // if (body.members.length > 0) {
  //   members = JSON.parse(body.members);
  // }
  let department_obj = {
    title: body.title,
    description: body.description,
    previllages: body.previllages,
    lead: [],
    members: [],
    company: body.company,
  };

  const final_department = await Add_department(department_obj);
  resp.data = final_department;
  return resp;
};
const addDepartment = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addDepartment(body, resp);
  return resp;
};

const _editDepartment = async (body, department_id, resp) => {
  const department_detail = await find_department_by_id(department_id);
  if (!department_detail) {
    resp.error = true;
    resp.error_message = "Invalid Department";
    return resp;
  }

  const old_title = department_detail.title;

  if (old_title !== body.title) {
    const get_department_for_title = await find_department_by_name(body);
    if (get_department_for_title) {
      resp.error = true;
      resp.error_message =
        "Department with same Title already exists in this company";
      return resp;
    } else {
      await update_department_name_in_employees(department_id, body.title);
    }
  }

  department_detail.title = body.title;
  department_detail.description = body.description;
  department_detail.active_status = body.active_status;
  department_detail.previllages = body.previllages;
  department_detail.lead = body.lead;
  department_detail.members = body.members;
  department_detail.company = body.company;
  await department_detail.save();
  resp.data = department_detail;
  return resp;
};
const editDepartment = async (body, department_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editDepartment(body, department_id, resp);
  return resp;
};

const _getDepartments = async (search, Limit, page, resp) => {
  // pagination
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;
  const departments = await pagination_department(skip, limit, search);
  const total_pages = await department_search_count(search);
  const data = {
    department: departments,
    total_pages: total_pages,
    load_more_url: `/department/get_departments?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getDepartments = async (search, limit, page) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getDepartments(search, limit, page, resp);
  return resp;
};
const _detailDepartment = async (department_id, resp) => {
  const department = await find_department_by_id(department_id);
  if (!department) {
    resp.error = true;
    resp.error_message = "Invalid Department ID!";
    return resp;
  }
  resp.data = department;
  return resp;
};

const detailDepartment = async (department_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailDepartment(department_id, resp);
  return resp;
};

const _deleteDepartment = async (department_id, resp) => {
  const department = await find_department_by_id(department_id);
  if (!department) {
    resp.error = true;
    resp.error_message = "Invalid Department ID!";
    return resp;
  }
  await delete_department_by_id(department_id);
  await delete_department_from_employees(department_id);
  return resp;
};

const deleteDepartment = async (department_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteDepartment(department_id, resp);
  return resp;
};

const _getAllActiveDepartments = async (resp) => {
  const department = await get_all_active_departments();
  resp.data = {
    department,
  };

  return resp;
};

const getAllActiveDepartments = async () => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getAllActiveDepartments(resp);
  return resp;
};

module.exports = {
  addDepartment,
  editDepartment,
  getDepartments,
  detailDepartment,
  deleteDepartment,
  getAllActiveDepartments,
};
