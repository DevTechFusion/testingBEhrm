const bcrypt = require("bcrypt");
var FormData = require("form-data");
const axios = require("axios");
const fs = require("fs");

const {
  find_user,
  find_user_by_id,
  signup_user,
  delete_user_by_id,
  checking_email_exist,
} = require("../DAL/user");
const {
  add_employee,
  find_employee_by_id,
  pagination_employee,
  all_employee_count,
  delete_employee_by_id,
  get_employee_search,
  employee_search_count,
  find_employee_by_user_id,
  find_employee_by_employee_id,
  employees_for_department,
  get_all_employees,
  get_all_employees_count,
  get_all_active_employees,
  get_all_active_employees_count,
  delete_employee_from_leads,
  checking_webmail_exist,
  update_webmail_in_lead,
  find_employee_by_bank_account,
  add_lead_to_member,
  remove_member_from_team,
  team_members_search,
  team_members_search_count,
  team_members_search_v1,
  team_members_search_count_v1,
  get_team_members_by_user_id,
  get_leads_with_their_teams,
  get_leads_with_their_teams_count,
  update_employee_in_lead,
  update_employee_in_tech_lead,
  get_members_for_lead_for_feedback,
  get_team_members_ids,
  get_employee_search_with_query_obj,
  get_member_list_for_my_team,
  get_all_active_employees_for_loan,
  get_all_active_employees_for_birthday_anniversary,
  get_member_for_birthday,
  get_member_for_anniversary,
  count_member_for_birthday,
  count_member_for_anniversary,
  get_employee_search_v1,
  get_active_inactive_and_total_employees,
  get_active_employees_for_increments,
  employee_next_increment,
  employee_next_increment_count,
  get_all_active_employees_for_payroll,
  get_all_active_employees_for_payroll_v2,
  get_all_active_employees_for_payroll_sort_employee_id,
  find_employee_allowance_by_id,
  team_members_of_lead_tech_lead,
} = require("../DAL/employee");

const {
  find_employee_by_id_for_popup,
  find_employee_by_id_for_settings,
} = require("../DAL/employee-v1");

const { get_website_gernal_setting } = require("../DAL/website_setting");
const {
  add_to_session,
  delete_from_session_by_user_id,
} = require("../DAL/session");
const {
  update_employee_lead_in_department,
  update_employee_in_department_members,
  add_employee_to_department,
  delete_employee_from_department,
  delete_employee_from_department_lead,
  find_department_by_id,
} = require("../DAL/department");
const { find_company_by_id } = require("../DAL/company");
const {
  find_attendance_for_payroll,
  update_employee_in_attendance,
  add_employee_to_attendance,
  delete_employee_attendance,
  get_employee_attendance_by_query_obj,
  find_attendance_by_emp_id_month_year,
  get_employee_leaves_for_dashboard_count,
} = require("../DAL/attendance");
const {
  update_employee_info_and_action_info_of_increment_history,
} = require("../DAL/increment_history");
const { get_absent_count_yearly } = require("../DAL/dashboard");
const {
  find_company_asset_by_id,
  assign_company_asset_to_employee,
  unassign_company_asset_to_employee,
  update_employee_company_assets,
  get_company_assets_for_employee,
} = require("../DAL/company_asset");
const {
  update_employee_leave_requests,
  leave_request_search_count,
  find_leaves_from_leave_request,
  update_uncount_leave_action_by,
} = require("../DAL/leave_request");
const { update_employee_support_tickets } = require("../DAL/support_ticket");
const { find_role_by_id } = require("../DAL/role");
const {
  delete_employee_deactivation_by_employee_id,
} = require("../DAL/employee_deactivation");
const {
  update_employee_in_expense,
  update_added_by_in_expense,
} = require("../DAL/expense");
const {
  update_transfer_by_in_top_up,
  update_added_by_in_top_up,
  update_transfer_to_in_top_up,
} = require("../DAL/top_up");

const {
  find_lunch_for_payroll,
  update_employee_in_lunch,
  find_lunch_for_emp_month_year,
} = require("../DAL/lunch");
const { update_employee_loan_requests } = require("../DAL/loan_request");

const jwt = require("jsonwebtoken");
const { UPLOAD_IMAGE_on_S3 } = require("../utils/utils");
const {
  IMAGE_EXTENSIONS,
  EMPLOYEE_IMAGE_SIZES,
  EMPLOYEE_FILE_PATH,
} = require("../utils/constants.js");
const { SERVICE_ICON_SIZE } = require("../utils/constants");
const { v1: uuidv1 } = require("uuid");
const { v1: uuidv4 } = require("uuid");
const path = require("path");
const _ = require("lodash");
const moment = require("moment");
const { invokeApi } = require("../libs/invoke_api");
const { endPoint } = require("../utils/api_url");

const {
  get_general_allowance,
  get_other_allowance,
} = require("../DAL/allowances");

const {
  update_action_info_in_feedback_improvement,
  update_team_member_info_in_feedback_improvement,
} = require("../DAL/feedback_improvement");

const _addEmployee = async (body, files, resp) => {
  const user = await find_user(body);
  if (user) {
    resp.error = true;
    resp.error_message = "Email Already Exists";
    return resp;
  }
  const employee = await find_employee_by_employee_id(
    parseInt(body.employee_id)
  );
  if (employee) {
    resp.error = true;
    resp.error_message = "Member with same ID Already Exists";
    return resp;
  }

  const check_webmail = await checking_webmail_exist(body.webmail_email);
  if (check_webmail) {
    resp.error = true;
    resp.error_message = "This webmail already exists";
    return resp;
  }

  const check_bank_account = await find_employee_by_bank_account(
    body.bank_account
  );
  if (check_bank_account) {
    resp.error = true;
    resp.error_message = "Member with this bank account number already exists";
    return resp;
  }

  let employee_user;
  let previllages = {};
  let company_assets = [];
  let leads_arr = [];

  let leads = JSON.parse(body.leads);

  if (body.previllages) {
    previllages = JSON.parse(body.previllages);
  }
  if (body.company_assets) {
    company_assets = JSON.parse(body.company_assets);
  }

  const get_department = await find_department_by_id(body.department);
  if (!get_department) {
    resp.error = true;
    resp.error_message = "This department does not exist. Try again";
    return resp;
  }
  let department = { _id: get_department._id, title: get_department.title };

  const get_company = await find_company_by_id(body.company);
  if (!get_company) {
    resp.error = true;
    resp.error_message = "This comapny does not exist. Try again";
    return resp;
  }
  let company = { _id: get_company._id, title: get_company.title };

  for (let i = 0; i < company_assets.length; i++) {
    const get_company_asset = await find_company_asset_by_id(
      company_assets[i]._id
    );
    if (!get_company_asset) {
      resp.error = true;
      resp.error_message = "One of the Assets does not exist. Try again";
      return resp;
    }
  }

  console.log("leads: ", leads);

  for (let i = 0; i < leads.length; i++) {
    const get_lead = await find_employee_by_id(leads[i]);
    if (!get_lead) {
      resp.error = true;
      resp.error_message = "One of the Leads does not exist. Try again";
      return resp;
    }
    leads_arr.push({
      _id: get_lead._id,
      user_id: get_lead.user_id._id,
      name: get_lead.full_name,
      webmail: get_lead.webmail_email,
    });
  }

  const get_tech_lead = await find_employee_by_id(body.tech_lead);
  if (!get_tech_lead) {
    resp.error = true;
    resp.error_message = "Technical Lead does not exist anymore. Try again";
    return resp;
  }

  let tech_lead = {
    _id: get_tech_lead._id,
    user_id: get_tech_lead.user_id._id,
    name: get_tech_lead.full_name,
    webmail: get_tech_lead.webmail_email,
  };

  const get_role = await find_role_by_id(body.role);
  if (!get_role) {
    resp.error = true;
    resp.error_message = "This role does not exist. Try again";
    return resp;
  }
  let role = { _id: get_role._id, title: get_role.title };

  let images = {};
  if (files) {
    let file_extension = path.extname(files.image.name);
    let file_extension_status = IMAGE_EXTENSIONS.some(
      (extension) => file_extension === extension
    );
    if (file_extension_status == false) {
      resp.error = true;
      resp.error_message =
        "Following  image type is not allowed. The allowed image types are " +
        IMAGE_EXTENSIONS;
      return resp;
    }
    let image = await UPLOAD_IMAGE_on_S3(
      files.image,
      EMPLOYEE_IMAGE_SIZES,
      EMPLOYEE_FILE_PATH
    );
    //
    if (image) {
      images = image;
      //
    }
  }

  let full_name = body.first_name + " " + body.last_name;
  body.type = 1;
  let employee_obj = {
    first_name: body.first_name,
    last_name: body.last_name,
    full_name: full_name,
    email: body.email,
    skype_email: body.skype_email,
    webmail_email: body.webmail_email,
    webmail_password: body.webmail_password,
    date_of_birth: body.date_of_birth,
    date_of_joining: body.date_of_joining,
    date_of_confirmation: body.date_of_confirmation,
    date_of_contract: body.date_of_contract,
    date_of_increment: body.date_of_increment,
    designation: body.designation,
    contact_number: body.contact_number,
    address: body.address,
    gender: body.gender,
    cnic: body.cnic,
    profile_pic: images,
    employee_id: parseInt(body.employee_id),
    active_status: body.active_status,
    previllages: previllages,
    department: department,
    company: company,
    company_assets: company_assets,
    role: role,
    documents_url: body.documents_url,
    basic_salary: parseInt(body.basic_salary),
    bank_account: body.bank_account,
    blood_group: body.blood_group,
    allowed_leaves: body.allowed_leaves,
    tech_lead: tech_lead,
  };
  if (leads_arr.length > 0) {
    employee_obj.leads = leads_arr;
  }

  // Signing up employee in DONE and using those credentials here
  // let headers = {
  //   Accept: "application/json",
  //   "Content-Type": "application/json",
  // };
  // let queryParams = {};
  // let phone_number = body.contact_number.split(" ");

  // let postData = {
  //   email: body.email,
  //   password: body.password,
  //   first_name: body.first_name,
  //   last_name: body.last_name,
  //   country_code: phone_number[0],
  //   contact_number: phone_number[1],
  //   gender: body.gender.toLowerCase(),
  //   device_token: "",
  // };

  // let response = await invokeApi({
  //   url: endPoint.customerSignUp,
  //   method: "POST",
  //   headers,
  //   queryParams,
  //   postData,
  // });
  //
  // if (response.code != 200) {
  //   resp.error = true;
  //   resp.error_message = response.message;
  //   return resp;
  // }
  // body._id = response.customer.user_id;
  employee_user = await signup_user(body);
  if (!employee_user) {
    resp.error = true;
    resp.error_message = "Something Went Wrong";
    return resp;
  }
  let employee_user_obj = {
    _id: employee_user._id,
    email: employee_user.email,
  };
  employee_obj.user_id = employee_user_obj;

  // add employee
  const final_employee = await add_employee(employee_obj);
  //generating token'
  // const decoded = jwt.verify(response.token, process.env.JWT_SECRET);
  // let login_token = decoded.login_token;
  //

  const access = "auth";
  const json_token = uuidv1();
  const token = jwt
    .sign({ login_token: json_token, access }, process.env.JWT_SECRET)
    .toString();
  const add_session = await add_to_session(json_token, employee_user._id);
  if (!add_session) {
    resp.error = true;
    resp.error_message = "Could not add session";
    return resp;
  }

  // add employee to department
  const add_to_department = await add_employee_to_department(
    final_employee._id,
    full_name,
    department._id
  );
  if (!add_to_department) {
    resp.error = true;
    resp.error_message = "Could not add employee to department";
    return resp;
  }
  // Assign company assets
  for (let j = 0; j < company_assets.length; j++) {
    const current_date = moment().format("DD/MM/YYYY");
    let employee_obj = {
      emp_obj_id: final_employee._id,
      name: final_employee.full_name,
      emp_assigned_status: true,
      assigned_date: current_date,
    };

    await assign_company_asset_to_employee(company_assets[j]._id, employee_obj);
  }

  // employee_obj.token = response.token;
  employee_obj.token = token;
  resp.data = employee_obj;
  return resp;
};
const addEmployee = async (body, files) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addEmployee(body, files, resp);
  return resp;
};

const _editEmployee = async (
  user_id,
  body,
  employee_id,
  files,
  token,
  resp
) => {
  const employee_detail = await find_employee_by_id(employee_id);
  if (!employee_detail) {
    resp.error = true;
    resp.error_message = "Invalid Member";
    return resp;
  }

  let images = {};
  let newImageUrl = "";
  if (files) {
    let file_extension = path.extname(files.image.name);
    let file_extension_status = IMAGE_EXTENSIONS.some(
      (extension) => file_extension === extension
    );
    if (file_extension_status == false) {
      resp.error = true;
      resp.error_message =
        "Following  image type is not allowed. The allowed image types are " +
        IMAGE_EXTENSIONS;
      return resp;
    }
    let image = await UPLOAD_IMAGE_on_S3(
      files.image,
      EMPLOYEE_IMAGE_SIZES,
      EMPLOYEE_FILE_PATH
    );
    if (image) {
      images = image;
    }

    // Changing image in DONE
    // const formData = new FormData();
    // formData.append("image", Buffer.from(files.image.data), {
    //   filename: files.image.name,
    // });
    // let headers = formData.getHeaders();
    // headers["x-sh-auth"] = token;
    // await axios({
    //   method: "post",
    //   url: endPoint.uploadS3,
    //   data: formData,
    //   headers: headers,
    // })
    //   .then((res) => {
    //     //
    //     if (res.data.code === 200) {
    //       newImageUrl = res.data.path;
    //
    //     }
    //   })
    //   .catch((error) => {
    //     console.error(error, "error");
    //   });
  } else {
    images = employee_detail.profile_pic;
  }

  if (body.bank_account != employee_detail.bank_account) {
    const check_bank_account = await find_employee_by_bank_account(
      body.bank_account
    );
    if (check_bank_account) {
      resp.error = true;
      resp.error_message =
        "Member with this bank account number already exists";
      return resp;
    }
  }

  const get_department = await find_department_by_id(body.department);
  if (!get_department) {
    resp.error = true;
    resp.error_message = "This department does not exist. Try again";
    return resp;
  }

  let department = { _id: get_department._id, title: get_department.title };
  let body_employee_id = parseInt(body.employee_id);
  const old_department = employee_detail.department;
  const old_emp_id = employee_detail.employee_id;
  const old_name = employee_detail.full_name;
  const old_email = employee_detail.email;
  const old_role_id = employee_detail.role._id;
  const old_designation = employee_detail.designation;
  const new_designation = body.designation;
  const new_name = body.first_name + " " + body.last_name;
  const employee_id_new = employee_detail._id;
  const update_user_id = employee_detail.user_id._id;

  console.log("update_user_id:=======", update_user_id);
  let leads_arr = [];
  let leads = JSON.parse(body.leads);

  console.log("leads: ", leads);

  for (let i = 0; i < leads.length; i++) {
    const get_lead = await find_employee_by_id(leads[i]);
    if (!get_lead) {
      resp.error = true;
      resp.error_message = "One of the Leads does not exist. Try again";
      return resp;
    }
    leads_arr.push({
      _id: get_lead._id,
      user_id: get_lead.user_id._id,
      name: get_lead.full_name,
      webmail: get_lead.webmail_email,
    });
  }
  const get_tech_lead = await find_employee_by_id(body.tech_lead);
  if (!get_tech_lead) {
    resp.error = true;
    resp.error_message = "Technical Lead does not exist anymore. Try again";
    return resp;
  }

  let tech_lead = {
    _id: get_tech_lead._id,
    user_id: get_tech_lead.user_id._id,
    name: get_tech_lead.full_name,
    webmail: get_tech_lead.webmail_email,
  };

  const get_company = await find_company_by_id(body.company);
  if (!get_company) {
    resp.error = true;
    resp.error_message = "This comapny does not exist. Try again";
    return resp;
  }
  let company = { _id: get_company._id, title: get_company.title };

  let role = employee_detail.role;
  if (old_role_id !== body.role) {
    const get_role = await find_role_by_id(body.role);
    if (!get_role) {
      resp.error = true;
      resp.error_message = "This role does not exist. Try again";
      return resp;
    }
    role._id = get_role._id;
    role.title = get_role.title;
  }

  if (old_emp_id !== body_employee_id) {
    const emp_by_emp_id = await find_employee_by_employee_id(body_employee_id);
    if (emp_by_emp_id) {
      resp.error = true;
      resp.error_message = "Member with this ID already exists";
      return resp;
    }
  }

  if (old_name !== new_name || old_emp_id !== body_employee_id) {
    await update_employee_lead_in_department(employee_id, new_name);
    await update_employee_leave_requests(employee_id, new_name);
    await update_employee_support_tickets(employee_id, new_name);
    await update_employee_company_assets(employee_id, new_name);
    await update_employee_in_department_members(employee_id, new_name);
    await update_employee_in_expense(employee_id, new_name);
    await update_added_by_in_expense(employee_id, new_name);
    await update_transfer_by_in_top_up(employee_id, new_name);
    await update_added_by_in_top_up(employee_id, new_name);
    await update_transfer_to_in_top_up(employee_id, new_name);
    await update_employee_in_lunch(employee_id, new_name);
    await update_employee_in_lead(employee_id, new_name);
    await update_employee_in_tech_lead(employee_id, new_name);
    await update_employee_loan_requests(employee_id, new_name);
    await update_employee_in_attendance(
      employee_id,
      new_name,
      body_employee_id
    );
  }

  if (old_name !== new_name || old_designation !== new_designation) {
    update_action_info_in_feedback_improvement(
      employee_id_new,
      new_name,
      new_designation
    );
    update_team_member_info_in_feedback_improvement(
      employee_id_new,
      new_name,
      new_designation
    );

    update_uncount_leave_action_by(employee_id_new, new_name, new_designation);

    update_employee_info_and_action_info_of_increment_history(
      employee_id_new,
      update_user_id,
      new_name,
      new_designation
    );
  }

  if (!_.isEmpty(old_department._id) || !_.isEmpty(department)) {
    if (!_.isEmpty(old_department._id) && !_.isEmpty(department)) {
      if (old_department._id.toString() != department._id.toString()) {
        await add_employee_to_department(employee_id, new_name, department._id);
        await delete_employee_from_department(
          employee_id,
          employee_detail.full_name,
          old_department._id
        );
        await delete_employee_from_department_lead(
          employee_id,
          employee_detail.full_name,
          old_department._id
        );
      }
    } else if (_.isEmpty(old_department._id) && !_.isEmpty(department)) {
      await add_employee_to_department(employee_id, new_name, department._id);
    }
  }

  if (old_email !== body.email) {
    let user = await checking_email_exist(old_email);
    if (!user) {
      resp.error = true;
      resp.error_message = "User does not exist with this email";
      return resp;
    }

    if (body.email !== user.email) {
      let user_new_email = await find_user(body);
      if (user_new_email) {
        resp.error = true;
        resp.error_message = "User With This Email Already Exist";
        return resp;
      }
    }

    user.email = body.email;
    employee_detail.email = body.email;
    user = await user.save();
  }

  if (body.webmail_email != employee_detail.webmail_email) {
    const check_webmail = await checking_webmail_exist(body.webmail_email);
    if (check_webmail) {
      resp.error = true;
      resp.error_message = "This webmail already exists";
      return resp;
    }

    await update_webmail_in_lead(
      employee_detail.webmail_email,
      body.webmail_email
    );
  }

  employee_detail.first_name = body.first_name;
  employee_detail.last_name = body.last_name;
  employee_detail.full_name = new_name;
  employee_detail.skype_email = body.skype_email;
  employee_detail.webmail_email = body.webmail_email;
  employee_detail.webmail_password = body.webmail_password;
  employee_detail.date_of_birth = body.date_of_birth;
  employee_detail.date_of_joining = body.date_of_joining;
  employee_detail.date_of_confirmation = body.date_of_confirmation;
  employee_detail.date_of_contract = body.date_of_contract;
  employee_detail.date_of_increment = body.date_of_increment;
  employee_detail.next_date_of_increment = body.next_date_of_increment;
  employee_detail.designation = body.designation;
  employee_detail.contact_number = body.contact_number;
  employee_detail.address = body.address;
  employee_detail.gender = body.gender;
  employee_detail.cnic = body.cnic;
  employee_detail.profile_pic = images;
  employee_detail.employee_id = body_employee_id;
  employee_detail.active_status = body.active_status;
  employee_detail.previllages = JSON.parse(body.previllages);
  employee_detail.department = department;
  employee_detail.company = company;
  employee_detail.leads = leads_arr;
  employee_detail.tech_lead = tech_lead;
  employee_detail.documents_url = body.documents_url;
  employee_detail.role.role = role;
  employee_detail.basic_salary = parseInt(body.basic_salary);
  employee_detail.bank_account = body.bank_account;
  employee_detail.blood_group = body.blood_group;
  employee_detail.allowed_leaves = body.allowed_leaves;

  if (!employee_detail.active_status) {
    await delete_from_session_by_user_id(employee_detail.user_id._id);
    await delete_employee_from_leads(employee_id);
  } else {
    await delete_employee_deactivation_by_employee_id(employee_id);
  }

  if (body.password && body.password != "") {
    let get_user_for_password = await find_user(body);
    if (!get_user_for_password) {
      resp.error = true;
      resp.error_message = "User does not exist with this email";
      return resp;
    }

    const salt = await bcrypt.genSalt(10);
    get_user_for_password.password = await bcrypt.hash(body.password, salt);
    let user_saved = await get_user_for_password.save();
    if (!user_saved) {
      resp.error = true;
      resp.error_message = "Could not save the user";
      return resp;
    }

    // Updating Password in DONE
    // let headers = {
    //   Accept: "application/json",
    //   "Content-Type": "application/json",
    //   "x-sh-auth": token,
    // };
    // let queryParams = {};
    // let postData = {
    //   user_id: get_user_for_password._id,
    //   new_password: body.password,
    // };
    // let response = await invokeApi({
    //   url: endPoint.editPortalCustomerPassword,
    //   method: "PUT",
    //   headers,
    //   queryParams,
    //   postData,
    // });
    // if (response.code != 200) {
    //   resp.error = true;
    //   resp.error_message = response.message;
    //   return resp;
    // }
  }

  // Updating Contact in DONE
  // let headers = {
  //   Accept: "application/json",
  //   "Content-Type": "application/json",
  //   "x-sh-auth": token,
  // };
  // let queryParams = {};
  // let phone_number = employee_detail.contact_number.split(" ");
  // let postData = {
  //   first_name: employee_detail.first_name,
  //   last_name: employee_detail.last_name,
  //   contact_number: phone_number[1],
  //   country_code: phone_number[0],
  //   gender: employee_detail.gender.toLowerCase(),
  // };
  // if (newImageUrl != "") {
  //   postData.image = newImageUrl;
  // }
  // let response = await invokeApi({
  //   url: endPoint.editCustomer + user_id,
  //   method: "PUT",
  //   headers,
  //   queryParams,
  //   postData,
  // });
  // if (response.code != 200) {
  //   resp.error = true;
  //   resp.error_message = response.message;
  //   return resp;
  // }

  await employee_detail.save();
  resp.data = employee_detail;
  return resp;
};

const editEmployee = async (user_id, body, employee_id, files, token) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editEmployee(user_id, body, employee_id, files, token, resp);
  return resp;
};

const _editEmployeeForSettings = async (
  user_id,
  body,
  employee_id,
  files,
  resp
) => {
  const employee_detail = await find_employee_by_id(employee_id);
  console.log("employee_detail:=============" + employee_detail);
  if (!employee_detail) {
    resp.error = true;
    resp.error_message = "Invalid Member";
    return resp;
  }

  let images = {};
  let newImageUrl = "";
  if (files) {
    let file_extension = path.extname(files.image.name);
    let file_extension_status = IMAGE_EXTENSIONS.some(
      (extension) => file_extension === extension
    );
    if (file_extension_status == false) {
      resp.error = true;
      resp.error_message =
        "Following  image type is not allowed. The allowed image types are " +
        IMAGE_EXTENSIONS;
      return resp;
    }
    let image = await UPLOAD_IMAGE_on_S3(
      files.image,
      EMPLOYEE_IMAGE_SIZES,
      EMPLOYEE_FILE_PATH
    );
    if (image) {
      images = image;
    }
  } else {
    images = employee_detail.profile_pic;
  }

  const new_name = body.first_name + " " + body.last_name;

  console.log(employee_id);

  let body_employee_id = parseInt(body.employee_id);
  const old_emp_id = employee_detail.employee_id;
  const old_name = employee_detail.full_name;
  const old_designation = employee_detail.designation;
  const new_designation = body.designation;
  let employee_id_new = employee_detail._id;
  const update_user_id = employee_detail.user_id._id;

  if (old_emp_id !== body_employee_id) {
    const emp_by_emp_id = await find_employee_by_employee_id(body_employee_id);
    if (emp_by_emp_id) {
      resp.error = true;
      resp.error_message = "Member with this ID already exists";
      return resp;
    }
  }

  if (old_name !== new_name || old_emp_id !== body_employee_id) {
    await update_employee_lead_in_department(employee_id, new_name);
    await update_employee_leave_requests(employee_id, new_name);
    await update_employee_support_tickets(employee_id, new_name);
    await update_employee_company_assets(employee_id, new_name);
    await update_employee_in_department_members(employee_id, new_name);
    await update_employee_in_expense(employee_id, new_name);
    await update_added_by_in_expense(employee_id, new_name);
    await update_transfer_by_in_top_up(employee_id, new_name);
    await update_added_by_in_top_up(employee_id, new_name);
    await update_transfer_to_in_top_up(employee_id, new_name);
    await update_employee_in_lunch(employee_id, new_name);
    await update_employee_in_lead(employee_id, new_name);
    await update_employee_in_tech_lead(employee_id, new_name);
    await update_employee_loan_requests(employee_id, new_name);
    await update_employee_in_attendance(
      employee_id,
      new_name,
      body_employee_id
    );
  }

  if (old_name !== new_name || old_designation !== new_designation) {
    update_action_info_in_feedback_improvement(
      employee_id_new,
      new_name,
      old_designation
    );
    update_team_member_info_in_feedback_improvement(
      employee_id_new,
      new_name,
      old_designation
    );

    update_uncount_leave_action_by(employee_id_new, new_name, old_designation);

    update_employee_info_and_action_info_of_increment_history(
      employee_id_new,
      update_user_id,
      new_name,
      old_designation
    );
  }

  employee_detail.first_name = body.first_name;
  employee_detail.last_name = body.last_name;
  employee_detail.contact_number = body.contact_number;
  employee_detail.address = body.address;
  employee_detail.full_name = new_name;
  employee_detail.profile_pic = images;

  await employee_detail.save();
  resp.data = employee_detail;
  return resp;
};

const editEmployeeForSettings = async (user_id, body, employee_id, files) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editEmployeeForSettings(
    user_id,
    body,
    employee_id,
    files,
    resp
  );
  return resp;
};

const _getEmployees = async (active_status, search, Limit, page, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let query_obj = {};
  const search_by_query_obj = await get_employee_search_with_query_obj(
    query_obj
  );
  if (/^\d+$/.test(search)) {
    query_obj.employee_id = parseInt(search);
  } else {
    query_obj.$or = [
      { full_name: { $regex: new RegExp(search, "i") } },
      { email: { $regex: new RegExp(search, "i") } },
    ];
  }
  if (!_.isEmpty(active_status)) {
    if (active_status == "active") {
      query_obj.active_status = true;
    } else if (active_status == "inactive") {
      query_obj.active_status = false;
    }
  }

  let total_employees = search_by_query_obj.length;
  let active_employees = 0;
  let inactive_employees = 0;
  for (let i = 0; i < search_by_query_obj.length; i++) {
    if (search_by_query_obj[i].active_status) {
      active_employees += 1;
    } else {
      inactive_employees += 1;
    }
  }

  const employees = await get_employee_search(query_obj, skip, limit);
  const total_pages = await employee_search_count(query_obj);

  // let query_obj_search = {};
  const date = new Date();
  // let month = date.getMonth() + 1;
  let year = date.getFullYear();
  // let year_from = year;
  // let year_to = year;

  // if (month < 7) {
  //   year_from -= 1;
  // } else {
  //   year_to += 1;
  // }
  // query_obj_search.month = {
  //   $gte: 2,
  //   $lt: 7,
  // };
  // query_obj_search.year = {
  //   $gte: year_from,
  //   $lte: year_to,
  // };
  let all_employees = [];
  for (let i = 0; i < employees.length; i++) {
    let absent_count = 0;
    let absent_query = { emp_obj_id: employees[i]._id };
    const absents_data_yearly = await get_absent_count_yearly(absent_query);

    absent_count = absents_data_yearly;

    // console.log("absents_data_yearly: ", absents_data_yearly);
    // query_obj_search.emp_obj_id = employees[i]._id;
    // const emp_details = await get_employee_attendance_by_query_obj(
    //   query_obj_search
    // );
    // for (let j = 0; j < emp_details.length; j++) {
    //   if (emp_details[j].month < 7 && emp_details[j].year == year) {
    //     absent_count += emp_details[j].total_absents;
    //   } else if (
    //     emp_details[j].month >= 7 &&
    //     emp_details[j].year == year_from
    //   ) {
    //     absent_count += emp_details[j].total_absents;
    //   }
    // }
    let emp_obj = {
      _id: employees[i]._id,
      full_name: employees[i].full_name,
      email: employees[i].email,
      skype_email: employees[i].skype_email,
      webmail_email: employees[i].webmail_email,
      webmail_password: employees[i].webmail_password,
      date_of_birth: employees[i].date_of_birth,
      date_of_joining: employees[i].date_of_joining,
      date_of_confirmation: employees[i].date_of_confirmation,
      date_of_increment: employees[i].date_of_increment,
      date_of_contract: employees[i].date_of_contract,
      designation: employees[i].designation,
      contact_number: employees[i].contact_number,
      address: employees[i].address,
      gender: employees[i].gender,
      cnic: employees[i].cnic,
      profile_pic: employees[i].profile_pic,
      employee_id: employees[i].employee_id,
      active_status: employees[i].active_status,
      previllages: employees[i].previllages,
      department: employees[i].department,
      company: employees[i].company,
      company_assets: employees[i].company_assets,
      role: employees[i].role,
      documents_url: employees[i].documents_url,
      basic_salary: employees[i].basic_salary,
      bank_account: employees[i].bank_account,
      absents: absent_count,
      leads: employees[i].leads,
      tech_lead: employees[i].tech_lead,
      blood_group: employees[i].blood_group,
      allowed_leaves: employees[i].allowed_leaves,
    };
    all_employees.push(emp_obj);
  }
  const data = {
    employee: all_employees,
    total_pages,
    total_employees,
    active_employees,
    inactive_employees,
    load_more_url: `/employee/get_employees?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getEmployees = async (active_status, search, limit, page) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getEmployees(active_status, search, limit, page, resp);
  return resp;
};

const _getEmployeesV1 = async (active_status, search, Limit, page, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let query_obj = {};

  if (/^\d+$/.test(search)) {
    query_obj.employee_id = parseInt(search);
  } else {
    query_obj.$or = [
      { full_name: { $regex: new RegExp(search, "i") } },
      { email: { $regex: new RegExp(search, "i") } },
    ];
  }
  if (!_.isEmpty(active_status)) {
    if (active_status == "active") {
      query_obj.active_status = true;
    } else if (active_status == "inactive") {
      query_obj.active_status = false;
    }
  }

  // let total_employees = search_by_query_obj.length;
  // let active_employees = 0;
  // let inactive_employees = 0;

  //fiscal year for absent count

  function getFiscalYear() {
    const currentDate = moment();
    let fiscalYearStart, fiscalYearEnd;

    if (currentDate.month() >= 6) {
      // If the current month is July or later
      fiscalYearStart = moment({
        year: currentDate.year(),
        month: 6,
        day: 1,
      }).format("YYYY-MM-DD");
      fiscalYearEnd = moment({
        year: currentDate.year() + 1,
        month: 5,
        day: 30,
      }).format("YYYY-MM-DD");
    } else {
      // If the current month is June or earlier
      fiscalYearStart = moment({
        year: currentDate.year() - 1,
        month: 6,
        day: 1,
      }).format("YYYY-MM-DD");
      fiscalYearEnd = moment({
        year: currentDate.year(),
        month: 5,
        day: 30,
      }).format("YYYY-MM-DD");
    }

    return { fiscalYearStart, fiscalYearEnd };
  }

  const { fiscalYearStart, fiscalYearEnd } = getFiscalYear();

  const employees = await get_employee_search_v1(query_obj, skip, limit);
  const total_pages = await employee_search_count(query_obj);

  // // let query_obj_search = {};
  // const date = new Date();
  // // let month = date.getMonth() + 1;
  // let year = date.getFullYear();

  let all_employees = [];
  for (let i = 0; i < employees.length; i++) {
    let absent_count = 0;
    // let absent_query = { emp_obj_id: employees[i]._id };
    // const absents_data_yearly = await get_absent_count_yearly(absent_query);

    //new logic
    let current_year_absent = await get_employee_leaves_for_dashboard_count(
      employees[i]._id,
      fiscalYearStart,
      fiscalYearEnd
    );

    if (current_year_absent.length > 0) {
      current_year_absent.forEach((element) => {
        if (element.half_leave_type == 0) {
          absent_count += 1;
        } else if (
          element.half_leave_type == 1 ||
          element.half_leave_type == 2
        ) {
          absent_count += 0.5;
        }
      });
    }

    // console.log("current_year_absent", current_year_absent);
    // console.log("total_absent_yearly", total_absent_yearly);

    // absent_count = absents_data_yearly;

    let emp_obj = {
      _id: employees[i]._id,
      full_name: employees[i].full_name,
      email: employees[i].email,
      // skype_email: employees[i].skype_email,
      // webmail_email: employees[i].webmail_email,
      // webmail_password: employees[i].webmail_password,
      // date_of_birth: employees[i].date_of_birth,
      // date_of_joining: employees[i].date_of_joining,
      // date_of_confirmation: employees[i].date_of_confirmation,
      // date_of_increment: employees[i].date_of_increment,
      // date_of_contract: employees[i].date_of_contract,
      // designation: employees[i].designation,
      // contact_number: employees[i].contact_number,
      // address: employees[i].address,
      // gender: employees[i].gender,
      // cnic: employees[i].cnic,
      // profile_pic: employees[i].profile_pic,
      employee_id: employees[i].employee_id,
      active_status: employees[i].active_status,
      // previllages: employees[i].previllages,
      department: employees[i].department,
      // company: employees[i].company,
      // company_assets: employees[i].company_assets,
      role: employees[i].role,
      documents_url: employees[i].documents_url,
      // basic_salary: employees[i].basic_salary,
      // bank_account: employees[i].bank_account,
      absents: absent_count,
      // leads: employees[i].leads,
      // tech_lead: employees[i].tech_lead,
      blood_group: employees[i].blood_group,
      allowed_leaves: employees[i].allowed_leaves,
    };
    all_employees.push(emp_obj);
  }

  const { active, inactive, total } =
    await get_active_inactive_and_total_employees();
  const data = {
    employee: all_employees,
    total_pages,
    total_employees: total,
    active_employees: active,
    inactive_employees: inactive,
    load_more_url: `/employee/get_employees?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getEmployeesV1 = async (active_status, search, limit, page) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getEmployeesV1(active_status, search, limit, page, resp);
  return resp;
};

const _getEmployeesV2 = async (active_status, search, Limit, page, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let query_obj = {};

  if (/^\d+$/.test(search)) {
    query_obj.employee_id = parseInt(search);
  } else {
    query_obj.$or = [
      { full_name: { $regex: new RegExp(search, "i") } },
      { email: { $regex: new RegExp(search, "i") } },
    ];
  }
  if (!_.isEmpty(active_status)) {
    if (active_status == "active") {
      query_obj.active_status = true;
    } else if (active_status == "inactive") {
      query_obj.active_status = false;
    }
  }

  // let total_employees = search_by_query_obj.length;
  // let active_employees = 0;
  // let inactive_employees = 0;

  //fiscal year for absent count

  function getFiscalYear() {
    const currentDate = moment();
    let fiscalYearStart, fiscalYearEnd;

    if (currentDate.month() >= 6) {
      // If the current month is July or later
      fiscalYearStart = moment({
        year: currentDate.year(),
        month: 6,
        day: 1,
      }).format("YYYY-MM-DD");
      fiscalYearEnd = moment({
        year: currentDate.year() + 1,
        month: 5,
        day: 30,
      }).format("YYYY-MM-DD");
    } else {
      // If the current month is June or earlier
      fiscalYearStart = moment({
        year: currentDate.year() - 1,
        month: 6,
        day: 1,
      }).format("YYYY-MM-DD");
      fiscalYearEnd = moment({
        year: currentDate.year(),
        month: 5,
        day: 30,
      }).format("YYYY-MM-DD");
    }

    return { fiscalYearStart, fiscalYearEnd };
  }

  const { fiscalYearStart, fiscalYearEnd } = getFiscalYear();

  const employees = await get_employee_search_v1(query_obj, skip, limit);
  const total_pages = await employee_search_count(query_obj);

  // // let query_obj_search = {};
  // const date = new Date();
  // // let month = date.getMonth() + 1;
  // let year = date.getFullYear();

  let all_employees = [];
  for (let i = 0; i < employees.length; i++) {
    let total_absent_yearly = 0;
    // let absent_query = { emp_obj_id: employees[i]._id };
    // const absents_data_yearly = await get_absent_count_yearly(absent_query);

    let current_year_absent = await find_leaves_from_leave_request(
      employees[i]._id,
      fiscalYearStart,
      fiscalYearEnd
    );
    if (current_year_absent.length > 0) {
      current_year_absent.forEach((element) => {
        if (element.leave_type == "full") {
          total_absent_yearly += 1;
        } else if (
          element.leave_type == "first_half" ||
          element.leave_type == "second_half"
        ) {
          total_absent_yearly += 0.5;
        }
      });
    }

    // absent_count = absents_data_yearly;

    let emp_obj = {
      _id: employees[i]._id,
      full_name: employees[i].full_name,
      email: employees[i].email,
      // skype_email: employees[i].skype_email,
      // webmail_email: employees[i].webmail_email,
      // webmail_password: employees[i].webmail_password,
      // date_of_birth: employees[i].date_of_birth,
      // date_of_joining: employees[i].date_of_joining,
      // date_of_confirmation: employees[i].date_of_confirmation,
      // date_of_increment: employees[i].date_of_increment,
      // date_of_contract: employees[i].date_of_contract,
      // designation: employees[i].designation,
      // contact_number: employees[i].contact_number,
      // address: employees[i].address,
      // gender: employees[i].gender,
      // cnic: employees[i].cnic,
      // profile_pic: employees[i].profile_pic,
      employee_id: employees[i].employee_id,
      active_status: employees[i].active_status,
      // previllages: employees[i].previllages,
      department: employees[i].department,
      // company: employees[i].company,
      // company_assets: employees[i].company_assets,
      role: employees[i].role,
      documents_url: employees[i].documents_url,
      // basic_salary: employees[i].basic_salary,
      // bank_account: employees[i].bank_account,
      absents: total_absent_yearly,
      // leads: employees[i].leads,
      // tech_lead: employees[i].tech_lead,
      blood_group: employees[i].blood_group,
      allowed_leaves: employees[i].allowed_leaves,
    };
    all_employees.push(emp_obj);
  }

  const { active, inactive, total } =
    await get_active_inactive_and_total_employees();
  const data = {
    employee: all_employees,
    total_pages,
    total_employees: total,
    active_employees: active,
    inactive_employees: inactive,
    load_more_url: `/employee/get_employees?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getEmployeesV2 = async (active_status, search, limit, page) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getEmployeesV2(active_status, search, limit, page, resp);
  return resp;
};

const _getAllEmployees = async (resp) => {
  const employee = await get_all_employees();
  const data = {
    employee: employee,
  };
  resp.data = data;
  return resp;
};

const getAllEmployees = async () => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getAllEmployees(resp);
  return resp;
};

const _getAllActiveEmployees = async (resp) => {
  const employee = await get_all_active_employees();
  const data = {
    employee: employee,
  };
  resp.data = data;
  return resp;
};

const getAllActiveEmployees = async () => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getAllActiveEmployees(resp);
  return resp;
};

//******************************{get active employee for loan } ****************************/

const _getAllActiveEmployeesForLoan = async (search_text, resp) => {
  let query_obj = {};

  //   if search_text pass number test then parse int and search by employee id

  if (/^\d+$/.test(search_text)) {
    query_obj.employee_id = parseInt(search_text);
  } else {
    query_obj.$or = [
      { full_name: { $regex: new RegExp(search_text, "i") } },
      { email: { $regex: new RegExp(search_text, "i") } },
    ];
  }

  const employee = await get_all_active_employees_for_loan(query_obj);
  const data = {
    employee: employee,
  };
  resp.data = data;
  return resp;
};

const getAllActiveEmployeesForLoan = async (search_text) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getAllActiveEmployeesForLoan(search_text, resp);
  return resp;
};

//******************************{get active employee with search} ****************************/

const _getAllActiveEmployeesWithSearch = async (search_text, resp) => {
  let query_obj = {};

  //   if search_text pass number test then parse int and search by employee id

  if (/^\d+$/.test(search_text)) {
    query_obj.employee_id = parseInt(search_text);
  } else if (search_text) {
    query_obj.$or = [
      { full_name: { $regex: new RegExp(search_text.trim(), "i") } },
      { email: { $regex: new RegExp(search_text.trim(), "i") } },
    ];
  }

  const employee = await get_all_active_employees_for_payroll_sort_employee_id(
    query_obj
  );
  const data = {
    employee: employee,
  };
  resp.data = data;
  return resp;
};

const getAllActiveEmployeesWithSearch = async (search_text) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getAllActiveEmployeesWithSearch(search_text, resp);
  return resp;
};

const _getEmployeesForDepartment = async (resp) => {
  const employee = await employees_for_department();
  const data = {
    employee: employee,
  };
  resp.data = data;
  return resp;
};

const getEmployeesForDepartment = async () => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getEmployeesForDepartment(resp);
  return resp;
};

const _detailEmployee = async (user_id, resp) => {
  const employee = await find_employee_by_user_id(user_id);
  if (!employee) {
    resp.error = true;
    resp.error_message = "Invalid Member ID!";
    return resp;
  }
  resp.data = employee;
  return resp;
};

const detailEmployee = async (user_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailEmployee(user_id, resp);
  return resp;
};

const _detailEmployeeByID = async (employee_id, resp) => {
  const employee = await find_employee_by_id(employee_id);
  if (!employee) {
    resp.error = true;
    resp.error_message = "Invalid Member ID!";
    return resp;
  }
  // console.log("employee: ", employee);

  let final_employee = {
    _id: employee._id,
    full_name: employee.full_name,
    user_id: employee.user_id,
    first_name: employee.first_name,
    last_name: employee.last_name,
    email: employee.email,
    skype_email: employee.skype_email,
    webmail_email: employee.webmail_email,
    webmail_password: employee.webmail_password,
    date_of_birth: employee.date_of_birth,
    date_of_joining: employee.date_of_joining,
    date_of_confirmation: employee.date_of_confirmation,
    date_of_increment: employee.date_of_increment,
    next_date_of_increment: employee.next_date_of_increment,
    date_of_contract: employee.date_of_contract,
    designation: employee.designation,
    contact_number: employee.contact_number,
    address: employee.address,
    gender: employee.gender,
    cnic: employee.cnic,
    profile_pic: employee.profile_pic,
    employee_id: employee.employee_id,
    active_status: employee.active_status,
    previllages: employee.previllages,
    leads: employee.leads,
    tech_lead: employee.tech_lead,
    department: employee.department,
    company: employee.company,
    company_assets: employee.company_assets,
    role: employee.role,
    documents_url: employee.documents_url,
    socket_id: employee.socket_id,
    is_online: employee.is_online,
    sidebar_status: employee.sidebar_status,
    total_balance: employee.total_balance,
    basic_salary: employee.basic_salary,
    bank_account: employee.bank_account,
    want_lunch: employee.want_lunch,
    blood_group: employee.blood_group,
    allowed_leaves: employee.allowed_leaves,
    createdAt: employee.createdAt,
    updatedAt: employee.updatedAt,
  };

  let leaves_count = 0;

  if (
    employee.role.title == "HR" ||
    employee.role.title == "Admin" ||
    employee.role.title == "All"
  ) {
    let query_obj = { status: "pending" };
    leaves_count = await leave_request_search_count(query_obj);
  } else if (employee.role.title == "Team Lead") {
    let team = await get_team_members_ids(employee._id);
    if (team.length > 0) {
      let query_obj = { status: "pending", emp_obj_id: { $in: team } };
      leaves_count = await leave_request_search_count(query_obj);
    }
  }

  // console.log("leaves_count: ", leaves_count);

  final_employee.pending_leaves = leaves_count;

  // console.log("final_employee: ", final_employee);

  let general_settings = await get_website_gernal_setting();

  resp.data = {
    employee: final_employee,
    general_settings: general_settings,
  };

  return resp;
};

const detailEmployeeByID = async (employee_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailEmployeeByID(employee_id, resp);
  return resp;
};

//***************************{}**************************/
const _detailEmployeeByIDForSettings = async (employee_id, resp) => {
  const employee = await find_employee_by_id_for_settings(employee_id);
  if (!employee) {
    resp.error = true;
    resp.error_message = "Invalid Member ID!";
    return resp;
  }
  console.log("employee:=====================", employee);
  resp.data = {
    employee: employee,
  };

  return resp;
};

const detailEmployeeByIDForSettings = async (employee_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailEmployeeByIDForSettings(employee_id, resp);
  return resp;
};

//***************************{}**************************/
const _detailEmployeeByIDForPopup = async (employee_id, resp) => {
  const employee = await find_employee_by_id_for_popup(employee_id);
  if (!employee) {
    resp.error = true;
    resp.error_message = "Invalid Member ID!";
    return resp;
  }
  console.log("employee:=====================", employee);
  resp.data = {
    employee: employee,
  };

  return resp;
};

const detailEmployeeByIDForPopup = async (employee_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailEmployeeByIDForPopup(employee_id, resp);
  return resp;
};

const _deleteEmployee = async (emp_id, token, resp) => {
  // find by id
  const employee = await find_employee_by_id(emp_id);
  if (!employee) {
    resp.error = true;
    resp.error_message = "Invalid Member ID!";
    return resp;
  }

  // Deleting Employee from DONE
  // let headers = {
  //   Accept: "application/json",
  //   "Content-Type": "application/json",
  //   "x-sh-auth": token,
  // };
  // let queryParams = {};
  // let postData = {};
  // let response = await invokeApi({
  //   url: endPoint.deleteCustomer + employee.user_id._id,
  //   method: "DELETE",
  //   headers,
  //   queryParams,
  //   postData,
  // });
  //
  // if (response.code != 200) {
  //   resp.error = true;
  //   resp.error_message = response.message;
  //   return resp;
  // }
  //
  //
  if (employee.company_assets.length > 0) {
    let company_assets = employee.company_assets;
    for (let j = 0; j < company_assets.length; j++) {
      const current_date = moment().format("DD/MM/YYYY");
      let unassign_obj = {
        returned_date: current_date,
      };
      await unassign_company_asset_to_employee(
        company_assets[j]._id,
        unassign_obj
      );
    }
  }

  // employee from user model
  const deleted_user = await delete_user_by_id(employee.user_id._id);
  // delete employee
  const deleted_employee = await delete_employee_by_id(employee._id);
  // delete employee from session
  const delete_employee_session = await delete_from_session_by_user_id(
    employee.user_id._id
  );
  // delete employee from department
  const delete_employee_department = await delete_employee_from_department(
    employee._id,
    employee.full_name,
    employee.department._id
  );

  //  delete employee from attendance
  const delete_employee_from_attendance = await delete_employee_attendance(
    employee._id
  );
  // delete employee from leads
  await delete_employee_from_leads(employee._id);

  return resp;
};

const deleteEmployee = async (emp_id, token) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteEmployee(emp_id, token, resp);
  return resp;
};

const _updateSidebarStatusForEmployee = async (user_id, body, resp) => {
  const employee = await find_employee_by_user_id(user_id);
  if (!employee) {
    resp.error = true;
    resp.error_message = "Invalid Member ID!";
    return resp;
  }
  employee.sidebar_status = body.sidebar_status;
  employee.save();
  resp.data = employee;
  return resp;
};

const updateSidebarStatusForEmployee = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _updateSidebarStatusForEmployee(user_id, body, resp);
  return resp;
};

const _getEmployeesForPayroll = async (body, resp) => {
  const employees = await get_all_active_employees();

  let all_employees = [];
  for (let i = 0; i < employees.length; i++) {
    let fine = 0;
    let lunch_deduction = 0;
    const get_fine = await find_attendance_by_emp_id_month_year(
      employees[i].employee_id,
      body.month,
      body.year
    );

    if (get_fine) {
      fine = get_fine.fine;
    }
    // console.log("body.month: ", parseInt(body.month));
    // console.log("body.month + 1: ", parseInt(body.month) + 1);
    // const get_lunch = await find_lunch_for_emp_month_year(
    //   employees[i]._id,
    //   parseInt(body.month) + 1,
    //   body.year
    // );
    lunch_month = parseInt(body.month) + 1;
    lunch_year = parseInt(body.year);
    if (parseInt(body.month) == 12) {
      lunch_year = lunch_year + 1;
      lunch_month = 1;
    }
    console.log(lunch_month, "=================lunch month");
    console.log(lunch_year, "=================lunch year");
    const get_lunch = await find_lunch_for_emp_month_year(
      employees[i]._id,
      lunch_month,
      lunch_year
    );
    // console.log("get_lunch: ", get_lunch);

    if (get_lunch) {
      lunch_deduction = get_lunch.amount;
    }

    let emp_obj = {
      _id: employees[i]._id,
      full_name: employees[i].full_name,
      date_of_joining: employees[i].date_of_joining,
      date_of_confirmation: employees[i].date_of_confirmation,
      date_of_increment: employees[i].date_of_increment,
      date_of_contract: employees[i].date_of_contract,
      designation: employees[i].designation,
      address: employees[i].address,
      gender: employees[i].gender,
      cnic: employees[i].cnic,
      profile_pic: employees[i].profile_pic,
      employee_id: employees[i].employee_id,
      active_status: employees[i].active_status,
      department: employees[i].department,
      role: employees[i].role,
      basic_salary: employees[i].basic_salary,
      bank_account: employees[i].bank_account,
      fine,
      lunch_deduction,
    };
    all_employees.push(emp_obj);
  }

  resp.data = all_employees;
  return resp;
};

const getEmployeesForPayroll = async (body) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getEmployeesForPayroll(body, resp);
  return resp;
};

const _getEmployeesForPayrollV1 = async (body, resp) => {
  // const employees = await get_all_active_employees();
  const employees = await get_all_active_employees_for_payroll();

  let all_employees = [];
  for (let i = 0; i < employees.length; i++) {
    let fine = 0;
    let lunch_deduction = 0;
    const get_fine = await find_attendance_by_emp_id_month_year(
      employees[i].employee_id,
      body.month,
      body.year
    );

    if (get_fine) {
      fine = get_fine.fine;
    }
    lunch_month = parseInt(body.month) + 1;
    lunch_year = parseInt(body.year);
    if (parseInt(body.month) == 12) {
      lunch_year = lunch_year + 1;
      lunch_month = 1;
    }
    console.log(lunch_month, "=================lunch month");
    console.log(lunch_year, "=================lunch year");
    const get_lunch = await find_lunch_for_emp_month_year(
      employees[i]._id,
      lunch_month,
      lunch_year
    );
    // console.log("get_lunch: ", get_lunch);

    if (get_lunch) {
      lunch_deduction = get_lunch.amount;
    }

    let emp_obj = {
      _id: employees[i]._id,
      full_name: employees[i].full_name,
      // date_of_joining: employees[i].date_of_joining,
      // date_of_confirmation: employees[i].date_of_confirmation,
      // date_of_increment: employees[i].date_of_increment,
      // date_of_contract: employees[i].date_of_contract,
      // designation: employees[i].designation,
      // address: employees[i].address,
      // gender: employees[i].gender,
      // cnic: employees[i].cnic,
      // profile_pic: employees[i].profile_pic,
      // employee_id: employees[i].employee_id,
      // active_status: employees[i].active_status,
      // department: employees[i].department,
      // role: employees[i].role,
      basic_salary: employees[i].basic_salary,
      // bank_account: employees[i].bank_account,
      food_allowance: employees[i].food_allowance
        ? employees[i].food_allowance
        : 0,
      medical_allowance: employees[i].medical_allowance
        ? employees[i].medical_allowance
        : 0,
      conveyance_allowance: employees[i].conveyance_allowance
        ? employees[i].conveyance_allowance
        : 0,
      fine,
      lunch_deduction,
      employee_id: employees[i].employee_id,
    };
    all_employees.push(emp_obj);
  }

  resp.data = all_employees;
  return resp;
};

const getEmployeesForPayrollV1 = async (body) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getEmployeesForPayrollV1(body, resp);
  return resp;
};

//*************{getEmployeesForPayrollV2 with general allowance}***************/

const _getEmployeesForPayrollV2 = async (body, resp) => {
  const general_allowance = await get_general_allowance();
  const other_allowance = await get_other_allowance();

  const employees = await get_all_active_employees_for_payroll_v2();

  let lunch_month = parseInt(body.month) + 1;
  let lunch_year = parseInt(body.year);
  if (parseInt(body.month) == 12) {
    lunch_year = lunch_year + 1;
    lunch_month = 1;
  }

  console.log("employees: length", employees.length);

  let all_employees = [];
  for (let i = 0; i < employees.length; i++) {
    let fine = 0;
    let lunch_deduction = false;

    // find fine
    const get_fine = await find_attendance_for_payroll(
      employees[i].employee_id,
      body.month,
      body.year
    );
    if (get_fine) {
      fine = get_fine.fine;
    }

    //find lunch deduction
    const get_lunch = await find_lunch_for_payroll(
      employees[i]._id,
      lunch_month,
      lunch_year
    );
    if (get_lunch) {
      lunch_deduction = true;
    }

    let emp_obj = {
      _id: employees[i]._id,
      employee_id: employees[i].employee_id,
      full_name: employees[i].full_name,
      basic_salary: employees[i].basic_salary,
      fine,
      lunch_deduction,
    };
    all_employees.push(emp_obj);
  }

  resp.data = {
    general_allowance: general_allowance,
    other_allowance: other_allowance,
    all_employees: all_employees,
  };
  return resp;
};

const getEmployeesForPayrollV2 = async (body) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getEmployeesForPayrollV2(body, resp);
  return resp;
};

const _addMemberToTeam = async (user_id, body, resp) => {
  // console.log("body: ", body);

  const lead = await find_employee_by_user_id(user_id);
  if (!lead) {
    resp.error = true;
    resp.error_message = "Invalid user ID";
    return resp;
  }

  for (let i = 0; i < body.team_members.length; i++) {
    const get_member = await find_employee_by_id(
      body.team_members[i].emp_obj_id
    );
    if (get_member) {
      if (
        !get_member.leads.some(
          (lead) => lead.user_id.toString() == user_id.toString()
        )
      ) {
        let lead_obj = {
          _id: lead._id,
          user_id: lead.user_id._id,
          name: lead.full_name,
          webmail: lead.webmail_email,
        };
        await add_lead_to_member(get_member._id, lead_obj);
      }
    }
  }

  // resp.data = employee_obj;
  return resp;
};
const addMemberToTeam = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addMemberToTeam(user_id, body, resp);
  return resp;
};

const _searchTeamMembers = async (user_id, search, Limit, page, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;
  const team_members = await team_members_search(user_id, search, skip, limit);
  const total_pages = await team_members_search_count(user_id, search);

  // let all_team_members = [];
  // for (let i = 0; i < team_members.length; i++) {
  //   let emp_obj = {
  //     _id: team_members[i]._id,
  //     full_name: team_members[i].full_name,
  //     email: team_members[i].email,
  //     skype_email: team_members[i].skype_email,
  //     webmail_email: team_members[i].webmail_email,
  //     date_of_joining: team_members[i].date_of_joining,
  //     date_of_confirmation: team_members[i].date_of_confirmation,
  //     date_of_increment: team_members[i].date_of_increment,
  //     date_of_contract: team_members[i].date_of_contract,
  //     designation: team_members[i].designation,
  //     contact_number: team_members[i].contact_number,
  //     address: team_members[i].address,
  //     gender: team_members[i].gender,
  //     profile_pic: team_members[i].profile_pic,
  //     employee_id: team_members[i].employee_id,
  //     active_status: team_members[i].active_status,
  //     department: team_members[i].department,
  //   };
  //   all_team_members.push(emp_obj);
  // }
  const data = {
    // team_members: all_team_members,
    team_members: team_members,
    total_pages: total_pages,
    load_more_url: `/employee/get_team_members?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const searchTeamMembers = async (user_id, search, limit, page) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _searchTeamMembers(user_id, search, limit, page, resp);
  return resp;
};

//*****************************{search team members v1}*************************/
const _searchTeamMembersV1 = async (user_id, search, Limit, page, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;
  const team_members = await team_members_search_v1(
    user_id,
    search,
    skip,
    limit
  );
  const total_count = await team_members_search_count_v1(user_id, search);

  let total_pages = Math.ceil(total_count / limit);

  const data = {
    // team_members: all_team_members,
    team_members: team_members,
    count: total_count,
    total_pages: total_pages - 1,
    load_more_url: `/employee/get_team_members?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const searchTeamMembersV1 = async (user_id, search, limit, page) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _searchTeamMembersV1(user_id, search, limit, page, resp);
  return resp;
};

const _removeMemberFromTeam = async (user_id, member_id, resp) => {
  const lead = await find_employee_by_user_id(user_id);
  if (!lead) {
    resp.error = true;
    resp.error_message = "Invalid user ID";
    return resp;
  }

  const get_member = await find_employee_by_id(member_id);
  if (get_member) {
    await remove_member_from_team(get_member._id, user_id);
  }

  // for (let i = 0; i < body.team_members.length; i++) {
  //   const get_member = await find_employee_by_id(
  //     body.team_members[i].emp_obj_id
  //   );
  //   if (get_member) {
  //     await remove_member_from_team(get_member._id, user_id);
  //   }
  // }

  // resp.data = employee_obj;
  return resp;
};

const removeMemberFromTeam = async (user_id, member_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _removeMemberFromTeam(user_id, member_id, resp);
  return resp;
};

const _getAllTeamMembers = async (user_id, resp) => {
  const team_members = await get_team_members_by_user_id(user_id);
  const data = {
    team_members: team_members ? team_members : [],
  };
  resp.data = data;
  return resp;
};

const getAllTeamMembers = async (user_id) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getAllTeamMembers(user_id, resp);
  return resp;
};

const _getLeadsAndTheirTeams = async (user_id, search, Limit, page, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let leads_teams = [];
  let total_pages = 0;
  const get_employee = await find_employee_by_user_id(user_id);
  // console.log("get_employee: ", get_employee);
  if (get_employee) {
    if (
      get_employee.role.title == "All" ||
      get_employee.role.title == "HR" ||
      get_employee.role.title == "Admin"
    ) {
      leads_teams = await get_leads_with_their_teams(search, skip, limit);
      leads_teams_count = await get_leads_with_their_teams_count(search);
      console.log("leads_teams: ", leads_teams);
      console.log("total_pages: ", leads_teams_count);
      if (leads_teams_count.length > 0) {
        total_pages = leads_teams_count[0].count;
      }
    }
  }

  // const team_members = await team_members_search(user_id, search, skip, limit);
  // const total_pages = await team_members_search_count(user_id, search);

  // let all_team_members = [];
  // for (let i = 0; i < team_members.length; i++) {
  //   let emp_obj = {
  //     _id: team_members[i]._id,
  //     full_name: team_members[i].full_name,
  //     email: team_members[i].email,
  //     skype_email: team_members[i].skype_email,
  //     webmail_email: team_members[i].webmail_email,
  //     date_of_joining: team_members[i].date_of_joining,
  //     date_of_confirmation: team_members[i].date_of_confirmation,
  //     date_of_increment: team_members[i].date_of_increment,
  //     date_of_contract: team_members[i].date_of_contract,
  //     designation: team_members[i].designation,
  //     contact_number: team_members[i].contact_number,
  //     address: team_members[i].address,
  //     gender: team_members[i].gender,
  //     profile_pic: team_members[i].profile_pic,
  //     employee_id: team_members[i].employee_id,
  //     active_status: team_members[i].active_status,
  //     department: team_members[i].department,
  //   };
  //   all_team_members.push(emp_obj);
  // }
  const data = {
    leads_teams,
    total_pages,
    load_more_url: `/employee/get_team_members?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getLeadsAndTheirTeams = async (user_id, search, limit, page) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getLeadsAndTheirTeams(user_id, search, limit, page, resp);
  return resp;
};

const _getMembersLeadsForEachOther = async (body, resp) => {
  let employees = [];
  const get_emp = await find_employee_by_id(body.emp_obj_id);
  if (get_emp) {
    if (body.selection_type == "get_members") {
      employees = await get_members_for_lead_for_feedback(get_emp._id);
    } else if (body.selection_type == "get_leads") {
      if (!_.isEmpty(get_emp.tech_lead)) {
        employees.push({
          _id: get_emp.tech_lead._id,
          full_name: get_emp.tech_lead.name,
        });
      }
      // for (let i = 0; i < get_emp.leads.length; i++) {
      //   const element = get_emp.leads[i];
      //   employees.push({ _id: element._id, full_name: element.name });
      // }
    }
  }
  const data = {
    members_leads: employees,
  };
  resp.data = data;
  return resp;
};

const getMembersLeadsForEachOther = async (body) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getMembersLeadsForEachOther(body, resp);
  return resp;
};

const _updateTechLeadForTeamMember = async (body, resp) => {
  const get_tech_lead = await find_employee_by_id(body.tech_lead_id);
  if (!get_tech_lead) {
    resp.error = true;
    resp.error_message = "Invalid Lead ID!";
    return resp;
  }
  const get_member = await find_employee_by_id(body.team_member_id);
  if (!get_member) {
    resp.error = true;
    resp.error_message = "Invalid Member ID!";
    return resp;
  }

  let tech_lead = {
    _id: get_tech_lead._id,
    user_id: get_tech_lead.user_id._id,
    name: get_tech_lead.full_name,
    webmail: get_tech_lead.webmail_email,
  };

  get_member.tech_lead = tech_lead;
  get_member.save();

  const data = {
    get_member,
  };
  resp.data = data;
  return resp;
};

const updateTechLeadForTeamMember = async (body) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _updateTechLeadForTeamMember(body, resp);
  return resp;
};

//********************************{get member list for my team }**************************//
const _getMemberListForMyTeam = async (user_id, resp) => {
  const team_members = await get_member_list_for_my_team(user_id);

  resp.data = {
    member_list: team_members,
  };
  return resp;
};

const getMemberListForMyTeam = async (user_id) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getMemberListForMyTeam(user_id, resp);
  return resp;
};

//********************************{get member list for my team }**************************//
const _getMemberBirthdayAnniversary = async (body, resp) => {
  //check formate of date with moment
  if (body.start_date && body.end_date) {
    let date_from = moment(body.start_date, "DD-MM-YYYY", true).isValid();
    let date_to = moment(body.end_date, "DD-MM-YYYY", true).isValid();
    if (!date_from || !date_to) {
      resp.error = true;
      resp.error_message = "Invalid Date Formate!";
      return resp;
    }
  }

  if (body.type == "birthday") {
    let birthday_employees = [];
    const all_employees =
      await get_all_active_employees_for_birthday_anniversary();

    // console.log("all_employees", all_employees);

    let start_date;
    let birthday_end_date;
    if (body.start_date && body.end_date) {
      start_date = moment(body.start_date, "DD-MM-YYYY");
      birthday_end_date = moment(body.end_date, "DD-MM-YYYY");

      console.log("start_date: ", start_date);
      console.log("birthday_end_date: ", birthday_end_date);
    }

    if (!body.start_date && !body.end_date) {
      start_date = moment();
      birthday_end_date = moment().add(30, "days");
    }

    // console.log("start_date: ", start_date);
    // console.log("birthday_end_date: ", birthday_end_date);

    for (let i = 0; i < all_employees.length; i++) {
      let [day, month, year] = all_employees[i].date_of_birth.split("-");
      let temp_birth_date = day + "-" + month + "-" + moment().format("YYYY");
      // console.log("temp_birth_date: ", temp_birth_date);
      let birth_date = moment(temp_birth_date, "DD-MM-YYYY");

      let check = birth_date.isBetween(
        start_date,
        birthday_end_date,
        null,
        "[]"
      );
      if (check) {
        birthday_employees.push(all_employees[i]);
      }
    }

    birthday_employees.sort(function (a, b) {
      a_date_of_birth = a.date_of_birth
        .split("-")
        .slice(0, 2)
        .reverse()
        .join("");
      b_date_of_birth = b.date_of_birth
        .split("-")
        .slice(0, 2)
        .reverse()
        .join("");
      return a_date_of_birth > b_date_of_birth
        ? 1
        : a_date_of_birth < b_date_of_birth
        ? -1
        : 0;
    });

    resp.data = {
      member_list: birthday_employees,
    };
  } else if (body.type == "anniversary") {
    let anniversary_employees = [];
    const all_employees =
      await get_all_active_employees_for_birthday_anniversary();

    let start_date;
    let anniversary_end_date;
    if (body.start_date && body.end_date) {
      start_date = moment(body.start_date, "DD-MM-YYYY");
      anniversary_end_date = moment(body.end_date, "DD-MM-YYYY");
    }

    if (!body.start_date && !body.end_date) {
      start_date = moment();
      anniversary_end_date = moment().add(30, "days");
    }

    for (let i = 0; i < all_employees.length; i++) {
      let [day, month, year] = all_employees[i].date_of_joining.split("-");
      let temp_anniversary_date =
        day + "-" + month + "-" + moment().format("YYYY");
      let anniversary_date = moment(temp_anniversary_date, "DD-MM-YYYY");

      let check = anniversary_date.isBetween(
        start_date,
        anniversary_end_date,
        null,
        "[]"
      );

      if (check) {
        anniversary_employees.push(all_employees[i]);
      }
    }

    anniversary_employees.sort(function (a, b) {
      a_date_of_joining = a.date_of_joining
        .split("-")
        .slice(0, 2)
        .reverse()
        .join("");
      b_date_of_joining = b.date_of_joining
        .split("-")
        .slice(0, 2)
        .reverse()
        .join("");
      return a_date_of_joining > b_date_of_joining
        ? 1
        : a_date_of_joining < b_date_of_joining
        ? -1
        : 0;
    });

    resp.data = {
      member_list: anniversary_employees,
    };
  }

  return resp;
};

const getMemberBirthdayAnniversary = async (body) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getMemberBirthdayAnniversary(body, resp);
  return resp;
};

const _getMemberBirthdayAnniversaryV1 = async (body, Limit, page, resp) => {
  //check formate of date with moment

  if (!body.month) {
    resp.error = true;
    resp.error_message = "Invalid Month!";
    return resp;
  }

  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let total_pages = 0;
  let total_count = 0;

  if (body.type == "birthday") {
    const members = await get_member_for_birthday(body.month, skip, limit);

    total_count = await count_member_for_birthday(body.month);
    console.log("total_count:============", total_count);

    //if array not empty then get count
    if (total_count.length > 0) {
      total_count = total_count[0].count;
      total_pages = Math.ceil(total_count / limit);
    }

    //if total count array is empty then set 0
    if (total_count.length == 0) {
      total_count = 0;
    }

    resp.data = {
      member_list: members,
      count: total_count,
      total_pages: total_pages,
    };
  } else if (body.type == "anniversary") {
    const members = await get_member_for_anniversary(body.month, skip, limit);

    total_count = await count_member_for_anniversary(body.month);

    //if array not empty then get count
    if (total_count.length > 0) {
      total_count = total_count[0].count;
      total_pages = Math.ceil(total_count / limit);
    }

    //if total count array is empty then set 0
    if (total_count.length == 0) {
      total_count = 0;
    }

    resp.data = {
      member_list: members,
      count: total_count,
      total_pages: total_pages,
    };
  }

  return resp;
};

const getMemberBirthdayAnniversaryV1 = async (body, limit, page) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getMemberBirthdayAnniversaryV1(body, limit, page, resp);
  return resp;
};

//********************************{get increment for employee}**************************//
const _getIncrementForEmployee = async (body, Limit, page, resp) => {
  //page and Limit
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  }

  let skip = (page - 1) * limit;

  //check formate of date with moment body.date_from body.date_to

  if (!body.date_from && !body.date_to) {
    resp.error = true;
    resp.error_message = "Date From and Date To Required!";
    return resp;
  }

  if (body.date_from && body.date_to) {
    let date_from = moment(body.date_from, "YYYY-MM-DD", true).isValid();
    let date_to = moment(body.date_to, "YYYY-MM-DD", true).isValid();
    if (!date_from || !date_to) {
      resp.error = true;
      resp.error_message = "Invalid Date Formate!";
      return resp;
    }
  }

  let date_from = moment(body.date_from, "YYYY-MM-DD");
  let date_to = moment(body.date_to, "YYYY-MM-DD");

  const increment_employees = await employee_next_increment(
    date_from,
    date_to,
    skip,
    limit
  );

  const count = await employee_next_increment_count(date_from, date_to);

  let total_pages = Math.ceil(count / limit);

  resp.data = {
    increment_employees: increment_employees,
    count: count,
    total_pages: total_pages - 1,
  };
  return resp;
};

const getIncrementForEmployee = async (body, limit, page) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getIncrementForEmployee(body, limit, page, resp);
  return resp;
};

//********************************{update employee allowance}**************************//
const _updateEmployeeAllowance = async (employee_id, body, resp) => {
  const find_employee = await find_employee_by_id(employee_id);

  if (!find_employee) {
    resp.error = true;
    resp.error_message = "Employee not found!";
    return resp;
  }

  find_employee.food_allowance = body.food_allowance;
  find_employee.medical_allowance = body.medical_allowance;
  find_employee.conveyance_allowance = body.conveyance_allowance;

  await find_employee.save();

  return resp;
};

const updateEmployeeAllowance = async (employee_id, body) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _updateEmployeeAllowance(employee_id, body, resp);
  return resp;
};

//********************************{update employee allowance}**************************//
const _getEmployeeAllowance = async (employee_id, resp) => {
  const find_allowance = await find_employee_allowance_by_id(employee_id);

  resp.data = {
    allowance: find_allowance,
  };

  return resp;
};

const getEmployeeAllowance = async (employee_id) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getEmployeeAllowance(employee_id, resp);
  return resp;
};

//*****************************{search team members v1}*************************/
const _searchTeamMembersForLeadTechLead = async (
  user_id,
  search,
  filter_by,
  resp
) => {
  const user = await find_employee_by_user_id(user_id);

  let query_object = {
    active_status: true,
  };

  // Check the user's role
  if (
    user.role.title == "All" ||
    user.role.title == "HR" ||
    user.role.title == "Admin"
  ) {
    if (user.role.title == "All" && filter_by == "Team") {
      query_object = {
        ...query_object,
        $or: [{ "leads.user_id": user_id }, { "tech_lead.user_id": user_id }],
      };

      if (!!search) {
        query_object.$and = [
          {
            $or: [
              { full_name: { $regex: search, $options: "i" } },
              { email: { $regex: search, $options: "i" } },
            ],
          },
        ];
      }
    } else {
      query_object = {
        ...query_object,
      };
      if (!!search) {
        query_object.$and = [
          {
            $or: [
              { full_name: { $regex: search, $options: "i" } },
              { email: { $regex: search, $options: "i" } },
            ],
          },
        ];
      }
    }
  } else if (user.role.title == "Lead" || user.role.title == "Team Lead") {
    query_object = {
      ...query_object,
      $or: [{ "leads.user_id": user_id }, { "tech_lead.user_id": user_id }],
    };

    if (!!search) {
      query_object.$and = [
        {
          $or: [
            { full_name: { $regex: search, $options: "i" } },
            { email: { $regex: search, $options: "i" } },
          ],
        },
      ];
    }
  }

  const team_members = await team_members_of_lead_tech_lead(query_object);

  const data = {
    team_members: team_members,
  };
  resp.data = data;
  return resp;
};

const searchTeamMembersForLeadTechLead = async (user_id, search, filter_by) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _searchTeamMembersForLeadTechLead(
    user_id,
    search,
    filter_by,
    resp
  );
  return resp;
};

//*****************************{search team members v1}*************************/
const _searchTeamMembersForLeadTechLeadForFeedbackImprovement = async (
  user_id,
  search,
  filter_by,
  resp
) => {
  const user = await find_employee_by_user_id(user_id);

  let query_object = {
    active_status: true,
  };

  // Check the user's role
  if (
    user.role.title == "All" ||
    user.role.title == "HR" ||
    user.role.title == "Admin"
  ) {
    if (user.role.title == "All" && filter_by == "Team") {
      query_object = {
        ...query_object,
        $or: [{ "leads.user_id": user_id }, { "tech_lead.user_id": user_id }],
      };

      if (!!search) {
        query_object.$and = [
          {
            $or: [
              { full_name: { $regex: search, $options: "i" } },
              { email: { $regex: search, $options: "i" } },
            ],
          },
        ];
      }
    } else {
      query_object = {
        ...query_object,
      };
      if (!!search) {
        query_object.$and = [
          {
            $or: [
              { full_name: { $regex: search, $options: "i" } },
              { email: { $regex: search, $options: "i" } },
            ],
          },
        ];
      }
    }
  } else if (user.role.title == "Lead" || user.role.title == "Team Lead") {
    query_object = {
      ...query_object,
      $or: [
        { "leads.user_id": user_id },
        { "tech_lead.user_id": user_id },
        { user_id: user_id },
      ],
    };

    if (!!search) {
      query_object.$and = [
        {
          $or: [
            { full_name: { $regex: search, $options: "i" } },
            { email: { $regex: search, $options: "i" } },
          ],
        },
      ];
    }
  }

  const team_members = await team_members_of_lead_tech_lead(query_object);

  const data = {
    team_members: team_members,
  };
  resp.data = data;
  return resp;
};

const searchTeamMembersForLeadTechLeadForFeedbackImprovement = async (
  user_id,
  search,
  filter_by
) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _searchTeamMembersForLeadTechLeadForFeedbackImprovement(
    user_id,
    search,
    filter_by,
    resp
  );
  return resp;
};

module.exports = {
  addEmployee,
  editEmployee,
  getEmployees,
  getAllEmployees,
  getAllActiveEmployees,
  getAllActiveEmployeesForLoan,
  detailEmployee,
  detailEmployeeByID,
  deleteEmployee,
  getEmployeesForDepartment,
  updateSidebarStatusForEmployee,
  getEmployeesForPayroll,
  getEmployeesForPayrollV1,
  addMemberToTeam,
  searchTeamMembers,
  removeMemberFromTeam,
  getAllTeamMembers,
  getLeadsAndTheirTeams,
  getMembersLeadsForEachOther,
  updateTechLeadForTeamMember,
  searchTeamMembersV1,
  getMemberListForMyTeam,
  getMemberBirthdayAnniversary,
  getMemberBirthdayAnniversaryV1,
  getEmployeesV1,
  getEmployeesV2,
  getIncrementForEmployee,
  detailEmployeeByIDForSettings,
  editEmployeeForSettings,
  detailEmployeeByIDForPopup,
  updateEmployeeAllowance,
  getEmployeeAllowance,
  getAllActiveEmployeesWithSearch,
  searchTeamMembersForLeadTechLead,
  getEmployeesForPayrollV2,
  searchTeamMembersForLeadTechLeadForFeedbackImprovement,
};
