const { find_user, find_user_by_id } = require("../DAL/user");
const {
  add_expense_category,
  find_expense_category_by_id,
  pagination_expense_category,
  all_expense_categories_active,
  all_expense_categories_active_count,
  delete_expense_category_by_id,
  get_expense_category_search,
  expense_category_search_count,
  find_expense_category_by_name,
  all_expense_categories_active_v1,
} = require("../DAL/expense_category");
const {
  update_expense_category_in_expense,
  delete_expense_category_in_expenses,
} = require("../DAL/expense");
const { find_company_by_id } = require("../DAL/company");
const { UPLOAD_IMAGE } = require("../utils/utils");
const { PREVILLAGES } = require("../utils/constants");
const {
  get_all_active_employees_for_expense_screen,
} = require("../DAL/employee");

const _addExpenseCategory = async (body, resp) => {
  const expense_category_detail = await find_expense_category_by_name(
    body.title
  );
  if (expense_category_detail) {
    resp.error = true;
    resp.error_message = "Expense Category already exists";
    return resp;
  }
  let expense_category_obj = {
    title: body.title,
    description: body.description,
  };

  const final_expense_category = await add_expense_category(
    expense_category_obj
  );
  resp.data = final_expense_category;
  return resp;
};
const addExpenseCategory = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addExpenseCategory(body, resp);
  return resp;
};

const _editExpenseCategory = async (body, expense_category_id, resp) => {
  const expense_category_detail = await find_expense_category_by_id(
    expense_category_id
  );
  if (!expense_category_detail) {
    resp.error = true;
    resp.error_message = "Invalid Expense Category";
    return resp;
  }
  const old_title = expense_category_detail.title;
  // let active_status = false;
  // if (body.active_status.toLowerCase() == "true") {
  //   active_status = true;
  // }

  expense_category_detail.title = body.title;
  expense_category_detail.description = body.description;
  expense_category_detail.active_status = body.active_status;

  if (old_title != body.title) {
    const expense_category_check = await find_expense_category_by_name(
      body.title
    );
    if (expense_category_check) {
      resp.error = true;
      resp.error_message = "Expense Category already exists";
      return resp;
    }
    await update_expense_category_in_expense(expense_category_id, body.title);
  }

  await expense_category_detail.save();
  resp.data = expense_category_detail;
  return resp;
};
const editExpenseCategory = async (body, expense_category_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editExpenseCategory(body, expense_category_id, resp);
  return resp;
};

const _getExpenseCategory = async (resp) => {
  const expense_category = await all_expense_categories_active();
  // const total_pages = await all_expense_categories_active_count();
  const data = {
    expense_category: expense_category,
  };
  resp.data = data;
  return resp;
};

const getExpenseCategory = async () => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getExpenseCategory(resp);
  return resp;
};
const _detailExpenseCategory = async (expense_category_id, resp) => {
  const expense_category = await find_expense_category_by_id(
    expense_category_id
  );
  if (!expense_category) {
    resp.error = true;
    resp.error_message = "Invalid Expense Category ID!";
    return resp;
  }
  resp.data = expense_category;
  return resp;
};

const detailExpenseCategory = async (expense_category_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailExpenseCategory(expense_category_id, resp);
  return resp;
};

const _deleteExpenseCategory = async (expense_category_id, resp) => {
  const deleted_expense_category = await delete_expense_category_by_id(
    expense_category_id
  );
  if (!deleted_expense_category) {
    resp.error = true;
    resp.error_message = "Invalid Expense Category ID!";
    return resp;
  }
  await delete_expense_category_in_expenses(expense_category_id);
  return resp;
};

const deleteExpenseCategory = async (expense_category_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteExpenseCategory(expense_category_id, resp);
  return resp;
};

const _searchExpenseCategory = async (Limit, page, search, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;
  const expense_category = await get_expense_category_search(
    limit,
    skip,
    search
  );
  const total_pages = await expense_category_search_count(search);
  resp.data = {
    expense_category: expense_category,
    total_pages: total_pages,
    load_more_url: `/expense_category/get_expense_category?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchExpenseCategory = async (limit, page, search) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchExpenseCategory(limit, page, search, resp);
  return resp;
};

const _getExpenseCategoryAndActiveUser = async (type, resp) => {
  let expense_category = [];
  let employee = [];

  if (type == "expense_category") {
    expense_category = await all_expense_categories_active_v1();
  } else if (type == "user") {
    employee = await get_all_active_employees_for_expense_screen();
  }

  const data = {
    expense_category: expense_category,
    employee: employee,
  };
  resp.data = data;
  return resp;
};

const getExpenseCategoryAndActiveUser = async (type) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getExpenseCategoryAndActiveUser(type, resp);
  return resp;
};
module.exports = {
  addExpenseCategory,
  editExpenseCategory,
  getExpenseCategory,
  detailExpenseCategory,
  deleteExpenseCategory,
  searchExpenseCategory,
  getExpenseCategoryAndActiveUser,
};
