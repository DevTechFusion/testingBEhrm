const { find_user, find_user_by_id } = require("../DAL/user");
const { find_employee_by_user_id } = require("../DAL/employee");
const {
  find_notification_by_id,
  get_notification_search,
  notification_search_count,
  count_read_notifications,
  count_unread_notifications,
  mark_notification_as_read,
  mark_all_notifications_as_read,
} = require("../DAL/notification");

const _getNotifications = async (user_id, Limit, page, resp) => {
  const emp_details = await find_employee_by_user_id(user_id);
  // if (!emp_details) {
  //   resp.error = true;
  //   resp.error_message = "Member not found";
  //   return resp;
  // }
  let notification = [];
  let total_pages = 0;
  let total_notifications = 0;
  let total_read_notifications = 0;
  let total_unread_notifications = 0;

  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  if (emp_details) {
    notification = await get_notification_search(user_id, limit, skip);
    total_pages = await notification_search_count(user_id);
    total_read_notifications = await count_read_notifications(user_id);
    total_unread_notifications = await count_unread_notifications(user_id);
    total_notifications = total_read_notifications + total_unread_notifications;
  }
  resp.data = {
    notification,
    total_pages,
    total_notifications,
    total_read_notifications,
    total_unread_notifications,
    load_more_url: `/notification/get_notification?page=${page}&limit=${limit}`,
  };

  return resp;
};

const getNotifications = async (user_id, limit, page) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getNotifications(user_id, limit, page, resp);
  return resp;
};

const _markNotificationAsRead = async (user_id, notification_id, resp) => {
  const notification_details = await mark_notification_as_read(notification_id);
  if (!notification_details) {
    resp.error = true;
    resp.error_message = "Unable to mark notification as read";
    return resp;
  }

  resp.data = notification_details;

  return resp;
};

const markNotificationAsRead = async (user_id, notification_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _markNotificationAsRead(user_id, notification_id, resp);
  return resp;
};

const _markAllNotificationsAsRead = async (user_id, resp) => {
  const notification_details = await mark_all_notifications_as_read(user_id);
  if (!notification_details) {
    resp.error = true;
    resp.error_message = "Unable to mark notifications as read";
    return resp;
  }

  return resp;
};

const markAllNotificationsAsRead = async (user_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _markAllNotificationsAsRead(user_id, resp);
  return resp;
};

module.exports = {
  getNotifications,
  markNotificationAsRead,
  markAllNotificationsAsRead,
};
