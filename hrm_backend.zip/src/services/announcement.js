const { find_user, find_user_by_id } = require("../DAL/user");
const {
  add_announcement,
  find_announcement_by_id,
  pagination_announcement,
  all_announcement_categories_active,
  all_announcement_categories_active_count,
  delete_announcement_by_id,
  get_announcement_search,
  announcement_search_count,
  find_announcement_by_name,
  announcement_search_by_query_obj,
  announcement_search_by_query_obj_count,
} = require("../DAL/announcement");
const {
  find_employee_by_id,
  get_all_active_employees,
  get_active_employees_role_based,
} = require("../DAL/employee");
const { find_role_by_id } = require("../DAL/role");
const {
  add_notification,
  delete_announcement_notifications,
} = require("../DAL/notification");

const { NOTIFICATION_TYPE } = require("../utils/constants");

const moment = require("moment");

const _addAnnouncement = async (body, resp) => {
  let all_employees_role_based = [];
  const role_detail = await find_role_by_id(body.role);
  if (!role_detail) {
    resp.error = true;
    resp.error_message = "Role not found";
    return resp;
  }
  if (role_detail.title == "All") {
    all_employees_role_based = await get_all_active_employees();
  } else {
    all_employees_role_based = await get_active_employees_role_based(
      role_detail._id
    );
  }
  let role = { _id: role_detail._id, title: role_detail.title };

  let announcement_obj = {
    title: body.title,
    description: body.description,
    attachment: body.attachment,
    // date: moment().utc(true),
    role: role,
    reactions: [],
  };

  const final_announcement = await add_announcement(announcement_obj);

  for (let j = 0; j < all_employees_role_based.length; j++) {
    if (all_employees_role_based[j].previllages.announcement.view) {
      let notification_obj = {
        user_id: all_employees_role_based[j].user_id,
        announcement_id: final_announcement._id,
        title: "Announcement",
        description: "Hi! An announcement is just made",
        type: NOTIFICATION_TYPE.announcement,
      };
      await add_notification(notification_obj);
    }
  }
  resp.data = final_announcement;
  return resp;
};
const addAnnouncement = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addAnnouncement(body, resp);
  return resp;
};

const _editAnnouncement = async (body, announcement_id, resp) => {
  const announcement_detail = await find_announcement_by_id(announcement_id);
  if (!announcement_detail) {
    resp.error = true;
    resp.error_message = "Invalid Announcement ID";
    return resp;
  }

  let old_role = announcement_detail.role._id;
  let all_employees_role_based = [];
  let role = announcement_detail.role;
  if (old_role != body.role) {
    const role_detail = await find_role_by_id(body.role);
    if (!role_detail) {
      resp.error = true;
      resp.error_message = "Role not found";
      return resp;
    }
    if (role_detail.title == "All") {
      all_employees_role_based = await get_all_active_employees();
    } else {
      all_employees_role_based = await get_active_employees_role_based(
        role_detail._id
      );
    }
    role._id = role_detail._id;
    role.title = role_detail.title;
  }

  announcement_detail.title = body.title;
  announcement_detail.description = body.description;
  announcement_detail.attachment = body.attachment;
  // announcement_detail.date = moment(body.date, "DD-MM-YYYY").utc(true);
  announcement_detail.active_status = body.active_status;
  announcement_detail.role = role;
  announcement_detail.reactions = body.reactions;

  await announcement_detail.save();

  if (old_role != body.role) {
    for (let j = 0; j < all_employees_role_based.length; j++) {
      if (all_employees_role_based[j].previllages.announcement.view) {
        let notification_obj = {
          user_id: all_employees_role_based[j].user_id,
          announcement_id: announcement_detail._id,
          title: "Announcement",
          description: "Hi! An announcement is just made",
          type: NOTIFICATION_TYPE.announcement,
        };
        await add_notification(notification_obj);
      }
    }
  }

  resp.data = announcement_detail;
  return resp;
};
const editAnnouncement = async (body, announcement_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editAnnouncement(body, announcement_id, resp);
  return resp;
};

const _detailAnnouncement = async (announcement_id, resp) => {
  const announcement = await find_announcement_by_id(announcement_id);
  if (!announcement) {
    resp.error = true;
    resp.error_message = "Invalid Announcement  ID!";
    return resp;
  }
  resp.data = announcement;
  return resp;
};

const detailAnnouncement = async (announcement_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailAnnouncement(announcement_id, resp);
  return resp;
};

const _deleteAnnouncement = async (announcement_id, resp) => {
  const deleted_announcement = await delete_announcement_by_id(announcement_id);
  if (!deleted_announcement) {
    resp.error = true;
    resp.error_message = "Invalid Announcement ID!";
    return resp;
  } else {
    await delete_announcement_notifications(deleted_announcement._id);
  }
  return resp;
};

const deleteAnnouncement = async (announcement_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteAnnouncement(announcement_id, resp);
  return resp;
};

const _searchAnnouncement = async (Limit, page, body, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let query_obj = {};
  // if (
  //   body.date_from &&
  //   body.date_to &&
  //   body.date_from != "" &&
  //   body.date_to != "" &&
  //   body.date_from != null &&
  //   body.date_to != null &&
  //   body.date_from != undefined &&
  //   body.date_to != undefined
  // ) {
  //   query_obj.date = {
  //     $gte: moment(body.date_from, "DD-MM-YYYY").utc(true),
  //     $lte: moment(body.date_to, "DD-MM-YYYY").utc(true),
  //   };
  // }
  if (body.search && body.search != "") {
    query_obj.$or = [{ title: { $regex: new RegExp(body.search, "i") } }];
  }

  const announcement = await get_announcement_search(limit, skip, query_obj);
  const total_pages = await announcement_search_count(query_obj);
  resp.data = {
    announcement,
    total_pages,
    load_more_url: `/announcement/get_announcement?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchAnnouncement = async (limit, page, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchAnnouncement(limit, page, body, resp);
  return resp;
};
module.exports = {
  addAnnouncement,
  editAnnouncement,
  detailAnnouncement,
  deleteAnnouncement,
  searchAnnouncement,
};
