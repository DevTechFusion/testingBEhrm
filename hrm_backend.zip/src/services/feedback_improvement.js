const {
  add_feedback_improvement,
  update_feedback_improvement,
  get_feedback_improvement_by_id,
  list_feedback_improvements,
  delete_feedback_improvement,
  feedback_improvement_count,
} = require("../DAL/feedback_improvement");

const {
  find_employee_by_id,
  find_employee_by_user_id,
  team_members_of_lead_tech_lead,
  find_team_members_of_lead_tech_lead_for_feedback_improvement,
} = require("../DAL/employee");

const _addFeedbackImprovement = async (user_id, body, resp) => {
  // let team_member_info = {};
  let action_info = {};

  // if (!!body.employee_id) {
  //   const find_member = await find_employee_by_id(body.employee_id);

  //   if (!find_member) {
  //     resp.error = true;
  //     resp.error_message = "Member not found";
  //     return resp;
  //   }
  //   team_member_info = {
  //     employee_id: find_member._id,
  //     user_id: find_member.user_id,
  //     full_name: find_member.full_name ? find_member.full_name : "",
  //     designation: find_member.designation ? find_member.designation : "",
  //   };
  // }

  const find_user = await find_employee_by_user_id(user_id);

  action_info = {
    employee_id: find_user._id,
    user_id: user_id,
    full_name: find_user.full_name ? find_user.full_name : "",
    designation: find_user.designation ? find_user.designation : "",
  };

  // body.team_member_info = team_member_info;
  body.action_info = action_info;

  const feedback_improvement = await add_feedback_improvement(body);

  resp.data = {
    feedback_improvement: feedback_improvement,
  };
  return resp;
};

const addFeedbackImprovement = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addFeedbackImprovement(user_id, body, resp);
  return resp;
};

const _updateFeedbackImprovement = async (id, body, resp) => {
  const find_feedback_improvement = await get_feedback_improvement_by_id(id);
  if (!find_feedback_improvement) {
    resp.error = true;
    resp.error_message = "Feedback Improvement not found";
    return resp;
  }

  const feedback_improvement = await update_feedback_improvement(id, body);
  if (!feedback_improvement) {
    resp.error = true;
    resp.error_message = "Feedback Improvement not updated";
    return resp;
  }

  resp.data = {
    feedback_improvement: feedback_improvement,
  };
  return resp;
};

const updateFeedbackImprovement = async (id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _updateFeedbackImprovement(id, body, resp);
  return resp;
};

const _getFeedbackImprovementById = async (id, resp) => {
  const find_feedback_improvement = await get_feedback_improvement_by_id(id);
  if (!find_feedback_improvement) {
    resp.error = true;
    resp.error_message = "Feedback Improvement Not Found";
    return resp;
  }

  resp.data = {
    feedback_improvement: find_feedback_improvement,
  };
  return resp;
};

const getFeedbackImprovementById = async (id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getFeedbackImprovementById(id, resp);
  return resp;
};

const _listFeedbackImprovement = async (user_id, body, page, Limit, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;

  let query_obj = {};

  const find_user = await find_employee_by_user_id(user_id);
  let login_employee_id = find_user._id;

  if (!find_user) {
    resp.error = true;
    resp.error_message = "User not found";
    return resp;
  }

  if (
    find_user.role.title == "HR" ||
    find_user.role.title == "Admin" ||
    find_user.role.title == "All"
  ) {
    if (!!body.employee_id) {
      if (body.employee_id.toString() == login_employee_id.toString()) {
        query_obj = {
          $or: [
            {
              $and: [
                {
                  team_member_info: {
                    $elemMatch: { employee_id: body.employee_id },
                  },
                },
                { show_to_team: true },
              ],
            },
            {
              $and: [
                { "action_info.employee_id": body.employee_id },
                { team_member_info: { $eq: [] } },
              ],
            },
          ],
        };
   
      } else if (!!body.employee_id && body.filter_type == "All") {
        query_obj = {
          $or: [
            {
              $and: [{ "team_member_info.employee_id": body.employee_id }],
            },
            {
              $and: [
                { "action_info.employee_id": body.employee_id },
                { "team_member_info.user_id": { $ne: user_id } },
              ],
            },
            {
              $and: [
                { "action_info.employee_id": body.employee_id },
                { "team_member_info.user_id": user_id },
                { show_to_team: true },
              ],
            },
          ],
        };
      } else {
        query_obj = {
          $or: [
            {
              $and: [
                { "action_info.user_id": user_id },
                { "team_member_info.employee_id": body.employee_id },
              ],
            },
            {
              $and: [
                { "action_info.employee_id": body.employee_id },
                { team_member_info: { $eq: [] } },
              ],
            },
          ],
        };
      }
    } else if (!!body.filter_type && body.filter_type == "All") {
      console.log("All find_user.role.title", find_user.role.title);
      query_obj = {
        $nor: [
          {
            $and: [
              { "team_member_info.employee_id": login_employee_id },
              { show_to_team: false },
            ],
          },
        ],
      };
    } else {
      var employees =
        await find_team_members_of_lead_tech_lead_for_feedback_improvement(
          user_id
        );

      var employee_ids = employees.map((employee) => {
        return employee.user_id;
      });

      employee_ids = employee_ids ? employee_ids : [];

      query_obj = {
        $or: [
          { "action_info.user_id": { $in: employee_ids } },
          { "action_info.user_id": user_id },
          {
            $and: [
              { "action_info.user_id": { $in: employee_ids } },
              { "team_member_info.user_id": user_id },
              { show_to_team: true },
            ],
          },
        ],
      };
    }
  } else if (
    find_user.role.title == "Lead" ||
    find_user.role.title == "Team Lead"
  ) {
    console.log("lead Team Lead find_user.role.title", find_user.role.title);
    if (!!body.employee_id) {
      if (body.employee_id.toString() == login_employee_id.toString()) {
        query_obj = {
          $or: [
            {
              $and: [
                {
                  team_member_info: {
                    $elemMatch: { employee_id: body.employee_id },
                  },
                },
                { show_to_team: true },
              ],
            },
            {
              $and: [
                { "action_info.employee_id": body.employee_id },
                { team_member_info: { $eq: [] } },
              ],
            },
          ],
        };
      } else {
        query_obj = {
          $or: [
            { "action_info.employee_id": body.employee_id },
            // { "team_member_info.employee_id": body.employee_id },
            {
              $and: [
                { "team_member_info.employee_id": body.employee_id },
                { "action_info.user_id": user_id },
              ],
            },
          ],
        };
      }

      // query_obj = {
      //   $or: [
      //     { "action_info.employee_id": body.employee_id },
      //     { "team_member_info.employee_id": body.employee_id },
      //   ],
      // };
    } else {
      var employees =
        await find_team_members_of_lead_tech_lead_for_feedback_improvement(
          user_id
        );

      var employee_ids = employees.map((employee) => {
        return employee.user_id;
      });

      employee_ids = employee_ids ? employee_ids : [];

      query_obj = {
        $or: [
          { "action_info.user_id": { $in: employee_ids } },
          // { "team_member_info.user_id": { $in: employee_ids } },
          { "action_info.user_id": user_id },
          {
            $and: [
              { "team_member_info.user_id": user_id },
              { show_to_team: true },
            ],
          },
        ],
      };
    }
  } else if (find_user.role.title == "Team") {
    console.log("Team find_user.role.title", find_user.role.title);
    query_obj = {
      show_to_team: true,
      $or: [
        { "action_info.user_id": user_id },
        { "team_member_info.user_id": user_id },
      ],
    };
  } else {
    query_obj = {
      show_to_team: true,
      "action_info.user_id": user_id,
    };
  }

  if (!!body.search) {
    const searchCondition = {
      title: { $regex: body.search.trim(), $options: "i" },
    };

    if (query_obj.$and) {
      query_obj.$and.push(searchCondition);
    } else {
      query_obj.$and = [searchCondition];
    }
  }

  console.log("Final Query Object:", JSON.stringify(query_obj, null, 2));
  const feedback_improvement = await list_feedback_improvements(
    query_obj,
    limit,
    skip
  );

  const total_count = await feedback_improvement_count(query_obj);

  let total_pages = Math.ceil(total_count / limit);

  resp.data = {
    feedback_improvement: feedback_improvement,
    total_pages: total_pages - 1,
    total_feedback_improvement: total_count,
  };
  return resp;
};

const listFeedbackImprovement = async (user_id, body, page, limit) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _listFeedbackImprovement(user_id, body, page, limit, resp);
  return resp;
};

const _deleteFeedbackImprovement = async (id, resp) => {
  const feedbackImprovement = await delete_feedback_improvement(id);
  if (!feedbackImprovement) {
    resp.error = true;
    resp.error_message = "Feedback Improvement not deleted";
    return resp;
  }

  resp.data = {};
  return resp;
};

const deleteFeedbackImprovement = async (id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteFeedbackImprovement(id, resp);
  return resp;
};

module.exports = {
  addFeedbackImprovement,
  updateFeedbackImprovement,
  getFeedbackImprovementById,
  listFeedbackImprovement,
  deleteFeedbackImprovement,
};
