const { find_user, find_user_by_id } = require("../DAL/user");
const {
  Add_company,
  find_company_by_id,
  pagination_company,
  all_company_count,
  delete_company_by_id,
  get_company_search,
  company_search_count,
  find_company_by_name,
  all_active_companies,
  all_active_companies_count,
} = require("../DAL/company");
const { update_company_in_department } = require("../DAL/department");
const { update_company_in_company_assets } = require("../DAL/company_asset");

const _addCompany = async (body, resp) => {
  const company = await find_company_by_name(body.title);
  if (company) {
    resp.error = true;
    resp.error_message = "Company with same Title already exists";
    return resp;
  }
  body.active_status = true;
  let company_obj = {
    title: body.title,
    description: body.description,
    active_status: body.active_status,
    phone: body.phone,
    email: body.email,
    address: body.address,
  };

  const final_company = await Add_company(company_obj);
  resp.data = final_company;
  return resp;
};
const addCompany = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addCompany(body, resp);
  return resp;
};

const _editCompany = async (body, company_id, resp) => {
  const company_detail = await find_company_by_id(company_id);
  if (!company_detail) {
    resp.error = true;
    resp.error_message = "Invalid Company";
    return resp;
  }
  const old_title = company_detail.title;

  if (old_title !== body.title) {
    const comp_by_title = await find_company_by_name(body.title);
    if (comp_by_title) {
      resp.error = true;
      resp.error_message = "Company with this Title already exists";
      return resp;
    }
  }

  company_detail.title = body.title;
  company_detail.description = body.description;
  company_detail.active_status = body.active_status;
  company_detail.phone = body.phone;
  company_detail.email = body.email;
  company_detail.address = body.address;
  if (old_title !== body.title) {
    await update_company_in_department(company_id, body.title);
    await update_company_in_company_assets(company_id, body.title);
  }

  await company_detail.save();
  resp.data = company_detail;
  return resp;
};
const editCompany = async (body, company_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editCompany(body, company_id, resp);
  return resp;
};

const _getCompany = async (search, Limit, page, resp) => {
  // pagination
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;
  const company = await get_company_search(search, skip, limit);
  const total_pages = await company_search_count(search);
  const data = {
    company: company,
    total_pages: total_pages,
    load_more_url: `/company/get_company?page=${page}&limit=${limit}`,
  };
  resp.data = data;
  return resp;
};

const getCompany = async (search, limit, page) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getCompany(search, limit, page, resp);
  return resp;
};
const _detailCompany = async (company_id, resp) => {
  const company = await find_company_by_id(company_id);
  if (!company) {
    resp.error = true;
    resp.error_message = "Invalid Company ID!";
    return resp;
  }
  resp.data = company;
  return resp;
};

const detailCompany = async (company_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailCompany(company_id, resp);
  return resp;
};

const _deleteCompany = async (company_id, resp) => {
  const company = await find_company_by_id(company_id);
  if (!company) {
    resp.error = true;
    resp.error_message = "Invalid Company ID!";
    return resp;
  }
  await delete_company_by_id(company_id);
  return resp;
};

const deleteCompany = async (company_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteCompany(company_id, resp);
  return resp;
};

const _getAllActiveCompanies = async (resp) => {
  const company = await all_active_companies();
  const data = {
    company: company,
  };
  resp.data = data;
  return resp;
};

const getAllActiveCompanies = async () => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getAllActiveCompanies(resp);
  return resp;
};

module.exports = {
  addCompany,
  editCompany,
  getCompany,
  detailCompany,
  deleteCompany,
  getAllActiveCompanies,
};
