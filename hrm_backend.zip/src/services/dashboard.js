const ObjectId = require("mongodb");
const mongoose = require("mongoose");

const { get_all_active_departments_v1 } = require("../DAL/department");
const { all_roles_active_v1 } = require("../DAL/role");
const { all_active_companies_v1 } = require("../DAL/company");
const {
  get_all_free_active_company_assets_v1,
} = require("../DAL/company_asset");
const { get_all_active_employees_v1 } = require("../DAL/employee");

const { find_user_by_id } = require("../DAL/user");
const {
  find_employee_by_user_id,
  get_all_active_employees,
  get_active_employees_for_birthday_increments,
  find_employee_by_id,
  get_team_members,
} = require("../DAL/employee");

const {
  get_unpaid_fines,
  get_employee_leaves_for_dashboard_count,
} = require("../DAL/attendance");

const {
  get_unpaid_lunches,
  find_lunch_for_emp_month_year,
} = require("../DAL/lunch");

const {
  get_data_monthly_for_user,
  get_monthly_late_mins_and_absents_for_user,
  get_absent_count_yearly,
  get_attendance_by_date_month_year_for_user,
  get_attendance_by_date_for_user,
} = require("../DAL/dashboard");

const {
  find_leave_request_by_emp_and_date,
  get_leave_requests_pending_approved_today_onwards,
  find_leave_request_by_emp_date_tomorrow_pending_approved,
  find_leaves_from_leave_request,
} = require("../DAL/leave_request");

const {
  get_feedbacks_query_obj,
  get_performance_by_emp_obj_id,
  get_performance_by_emp_obj_id_yearly,
  get_last_performance_month,
  get_feedbacks_query_obj_count,
} = require("../DAL/feedback");

const moment = require("moment");
const _ = require("lodash");
const {
  latest_support_ticket_with_role,
  latest_support_ticket_with_role_v1,
} = require("../DAL/support_ticket");
const e = require("express");

const _getDashboardData = async (user_id, resp) => {
  const emp_details = await find_employee_by_user_id(user_id);

  let month_names = {
    1: "Jan",
    2: "Feb",
    3: "Mar",
    4: "Apr",
    5: "May",
    6: "Jun",
    7: "Jul",
    8: "Aug",
    9: "Sep",
    10: "Oct",
    11: "Nov",
    12: "Dec",
  };

  let is_lead = false;
  let total_absent_yearly = 0;
  let today_late_minutes = 0;
  let late_mins_monthly = 0;
  let current_month_fineable_mins = 0;
  let current_month_absents = 0;
  let seven_days_attendance = [];
  let birthday_employees = [];
  let increment_employees = [];
  let on_leave_employees = [];
  let fines = [];
  let lunches = [];
  let all_on_leave = [];
  let current_month_lunch = {};
  let pending_feedbacks = [];
  let latest_tickets = [];
  let last_month_performance = 0;
  let current_year_performance = {};
  let want_lunch = null;
  let allowed_leaves = 15;
  let today_date = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY").utc(
    true
  );
  let tomorrow = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY")
    .utc(true)
    .add(1, "days");

  // let last_month_start_date = moment()
  //   .subtract(1, "months")
  //   .startOf("month")
  //   .format("YYYY-MM-DD");
  // let last_month_end_date = moment()
  //   .subtract(1, "months")
  //   .endOf("month")
  //   .format("YYYY-MM-DD");

  const date = new Date();
  let day = date.getDate() - 1;
  let month = date.getMonth() + 1;
  let year = date.getFullYear();

  // console.log("last_month_start_date: ", last_month_start_date);
  // console.log("last_month_end_date: ", last_month_end_date);

  // console.log("today_date 1: ", today_date);
  // console.log("tomorrow 1: ", tomorrow);

  if (emp_details) {
    allowed_leaves = emp_details.allowed_leaves;
    want_lunch = emp_details.want_lunch;
    let feedback_query = { submission_status: "pending" };
    if (
      emp_details.role.title == "HR" ||
      emp_details.role.title == "Admin" ||
      emp_details.role.title == "All"
    ) {
      let all_employees = await get_active_employees_for_birthday_increments();
      let start_date = moment();
      let birthday_end_date = moment().add(15, "days");
      let inc_end_date = moment().add(1, "months");

      for (let i = 0; i < all_employees.length; i++) {
        let [day, month, year] = all_employees[i].date_of_birth.split("-");
        let temp_birth_date = day + "-" + month + "-" + moment().format("YYYY");
        let birth_date = moment(temp_birth_date, "DD-MM-YYYY");

        if (birth_date.isBetween(start_date, birthday_end_date)) {
          birthday_employees.push(all_employees[i]);
        }

        let inc_date = moment(
          all_employees[i].date_of_increment,
          "DD-MM-YYYY"
        ).add(6, "months");

        if (inc_date.isBetween(start_date, inc_end_date)) {
          increment_employees.push(all_employees[i]);
        }
      }
      increment_employees.sort(function (a, b) {
        a_date_of_increment = a.date_of_increment.split("-").reverse().join("");
        b_date_of_increment = b.date_of_increment.split("-").reverse().join("");
        return a_date_of_increment > b_date_of_increment
          ? 1
          : a_date_of_increment < b_date_of_increment
          ? -1
          : 0;
      });
      birthday_employees.sort(function (a, b) {
        a_date_of_birth = a.date_of_birth
          .split("-")
          .slice(0, 2)
          .reverse()
          .join("");
        b_date_of_birth = b.date_of_birth
          .split("-")
          .slice(0, 2)
          .reverse()
          .join("");
        return a_date_of_birth > b_date_of_birth
          ? 1
          : a_date_of_birth < b_date_of_birth
          ? -1
          : 0;
        // return a.date_of_birth.localeCompare(b.date_of_birth);
        // return a.date_of_birth - b.date_of_birth;
      });
      // Get all pending feedbacks if HR, Admin, All
      // console.log("feedback_query: ", feedback_query);
      pending_feedbacks = await get_feedbacks_query_obj(feedback_query);
      latest_tickets = await latest_support_ticket_with_role(
        emp_details.role._id
      );
    } else {
      // Get all pending feedbacks for normal user
      feedback_query["send_to._id"] = emp_details._id;
      // console.log("feedback_query: ", feedback_query);
      pending_feedbacks = await get_feedbacks_query_obj(feedback_query);
    }
  }

  // let last_year = date.getFullYear() - 1;
  let month_name = date.toLocaleString("default", { month: "long" });
  if (day < 10) {
    day = "0" + day;
  }
  if (month < 10) {
    month = "0" + month;
  }
  let current_date = `${day}/${month}/${year}`;

  if (emp_details) {
    const get_late_mins = await get_attendance_by_date_month_year_for_user(
      emp_details._id,
      month,
      year,
      current_date
    );
    if (get_late_mins) {
      today_late_minutes = get_late_mins.attendance[0].late;
    }

    const monthly_late_mins_and_absents =
      await get_monthly_late_mins_and_absents_for_user(
        emp_details._id,
        month,
        year
      );
    if (monthly_late_mins_and_absents) {
      late_mins_monthly = monthly_late_mins_and_absents.total_late_minutes;
      current_month_absents = monthly_late_mins_and_absents.total_absents;
      if (late_mins_monthly >= 60) {
        current_month_fineable_mins = late_mins_monthly - 60;
      }
    }

    let absent_query = { emp_obj_id: emp_details._id };
    total_absent_yearly = await get_absent_count_yearly(absent_query);

    // console.log("absents_data_yearly: ", absents_data_yearly);

    // for (let index = 0; index < absents_data_yearly.length; index++) {
    //   const monthly_data = absents_data_yearly[index];
    //   if (
    //     (monthly_data.month < 7 && monthly_data.year == absents_curr_year) ||
    //     (monthly_data.month >= 7 && monthly_data.year == absents_curr_year - 1)
    //   ) {
    //     total_absent_yearly += monthly_data.total_absents;
    //   } else if (
    //     monthly_data.month >= 7 &&
    //     monthly_data.year == absents_curr_year
    //   ) {
    //     total_absent_yearly += monthly_data.total_absents;
    //   }
    // }

    // let current_month_attendance_arr = dashboard_data_monthly.attendance;
    // for (let j = 0; j < current_month_attendance_arr.length; j++) {
    //   if (current_month_attendance_arr[j].date == current_date) {
    //     today_late_minutes = current_month_attendance_arr[j].late;
    //   }
    // }

    // let dates_arr = [];
    // // let current_date_moment = moment().format("DD/MM/YYYY");
    // let date_counter = 1;
    // while (dates_arr.length < 7) {
    //   //
    //   let temp_date = moment()
    //     .add(-parseInt(date_counter), "days")
    //     .format("DD/MM/YYYY");
    //   //
    //   let week_day = moment(temp_date, "DD/MM/YYYY").isoWeekday();
    //   //
    //   if (week_day != 6 && week_day != 7) {
    //     dates_arr.push(temp_date);
    //   }
    //   date_counter += 1;
    // }

    // for (let j = 0; j < dates_arr.length; j++) {
    //   const get_late_mins = await get_attendance_by_date_for_user(
    //     emp_details._id,
    //     dates_arr[j]
    //   );
    //   if (get_late_mins) {
    //     seven_days_attendance.push(get_late_mins.attendance[0]);
    //   }
    // }
  }

  if (emp_details) {
    // if (emp_details.role.title == "HR") {
    //   is_lead = true;
    //   let all_employees = await get_all_active_employees();
    //   for (let a = 0; a < all_employees.length; a++) {
    //     const leave =
    //       await find_leave_request_by_emp_date_tomorrow_pending_approved(
    //         all_employees[a]._id,
    //         today_date,
    //         tomorrow
    //       );
    //     console.log("leave hr: ", leave);
    //     if (leave.length > 0) {
    //       // let on_leave_obj = {
    //       //   _id: leave._id,
    //       //   emp_obj_id: leave.emp_obj_id,
    //       //   emp_name: leave.emp_name,
    //       //   // emp_profile_pic: all_employees[a].profile_pic,
    //       //   leave_type: leave.leave_type,
    //       //   status: leave.status,
    //       //   leave_reason: leave.leave_reason,
    //       //   leave_date: leave.leave_date,
    //       //   rejection_reason: leave.rejection_reason,
    //       //   createdAt: leave.createdAt,
    //       //   updatedAt: leave.updatedAt,
    //       // };
    //       // on_leave_employees.push(on_leave_obj);
    //       on_leave_employees.push.apply(on_leave_employees, leave);
    //     }
    //   }
    // } else {
    const team_members = await get_team_members(emp_details._id);
    if (!_.isEmpty(team_members)) {
      is_lead = true;
      for (let t = 0; t < team_members.length; t++) {
        const leave =
          await find_leave_request_by_emp_date_tomorrow_pending_approved(
            team_members[t]._id,
            today_date,
            tomorrow
          );
        // console.log("leave leads: ", leave);
        if (leave.length > 0) {
          // let on_leave_obj = {
          //   _id: leave._id,
          //   emp_obj_id: leave.emp_obj_id,
          //   emp_name: leave.emp_name,
          //   emp_profile_pic: team_members[t].profile_pic,
          //   leave_type: leave.leave_type,
          //   status: leave.status,
          //   leave_reason: leave.leave_reason,
          //   leave_date: leave.leave_date,
          //   rejection_reason: leave.rejection_reason,
          //   createdAt: leave.createdAt,
          //   updatedAt: leave.updatedAt,
          // };
          // on_leave_employees.push(on_leave_obj);
          on_leave_employees.push.apply(on_leave_employees, leave);
        }
      }
    }
    // }
    // console.log("bedore: ", on_leave_employees);
    on_leave_employees.sort((a, b) =>
      moment(a.leave_date).diff(moment(b.leave_date))
    );
    // console.log("after: ", on_leave_employees);
  }

  if (emp_details) {
    let emp_fines = await get_unpaid_fines(emp_details._id);
    if (!_.isEmpty(emp_fines)) {
      for (let x = 0; x < emp_fines.length; x++) {
        let total_fine = emp_fines[x].fine + emp_fines[x].late_fine;
        let fine_obj = {
          emp_obj_id: emp_fines[x].emp_obj_id,
          emp_name: emp_fines[x].emp_name,
          year: emp_fines[x].year,
          month: emp_fines[x].month,
          deadline: emp_fines[x].deadline,
          total_absent: emp_fines[x].total_absent,
          due_fine: emp_fines[x].due_fine,
          total_fine: total_fine,
          paid_status: emp_fines[x].paid_status,
          late_fine: emp_fines[x].late_fine,
          createdAt: emp_fines[x].createdAt,
          updatedAt: emp_fines[x].updatedAt,
        };
        fines.push(fine_obj);
      }
    }

    let emp_lunches = await get_unpaid_lunches(emp_details._id);
    if (!_.isEmpty(emp_lunches)) {
      for (let x = 0; x < emp_lunches.length; x++) {
        let total_amount = emp_lunches[x].amount + emp_lunches[x].late_fine;
        let lunch_obj = {
          emplyee: emp_lunches[x].emplyee,
          year: emp_lunches[x].year,
          month: emp_lunches[x].month,
          paid_status: emp_lunches[x].paid_status,
          late_fine: emp_lunches[x].late_fine,
          deadline: emp_lunches[x].deadline,
          total_amount: total_amount,
          createdAt: emp_lunches[x].createdAt,
          updatedAt: emp_lunches[x].updatedAt,
        };
        lunches.push(lunch_obj);
      }
    }
    const current_lunch = await find_lunch_for_emp_month_year(
      emp_details._id,
      month,
      year
    );
    if (current_lunch) {
      current_month_lunch = current_lunch;
    }
  }

  let today_date_2 = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY").utc(
    true
  );
  // console.log("today_date_1: ", today_date);

  const get_all_on_leaves =
    await get_leave_requests_pending_approved_today_onwards(today_date_2);
  if (get_all_on_leaves.length > 0) {
    all_on_leave = get_all_on_leaves;
    // console.log("bedore: ", all_on_leave);
    all_on_leave.sort((a, b) =>
      moment(a.leave_date).diff(moment(b.leave_date))
    );
    // console.log("after: ", all_on_leave);
  }

  // console.log("all_on_leave: ", all_on_leave);
  // console.log("emp_details: ", emp_details);
  // console.log("is_lead: ", is_lead);

  if (emp_details) {
    let perf_query_obj = {
      "send_for._id": emp_details._id,
    };

    let perf_detail = await get_last_performance_month(perf_query_obj);

    if (perf_detail.length > 0) {
      let performance_query_obj = {
        "send_for._id": emp_details._id,
        month: perf_detail[0].month,
        year: perf_detail[0].year,
      };
      const performance = await get_performance_by_emp_obj_id(
        performance_query_obj
      );

      if (performance.length > 0) {
        last_month_performance = performance[0].performancePercentage;
      }
    }
    let next_year = year + 1;
    let full_year = [
      { month: 7, year: year, performance: 0 },
      { month: 8, year: year, performance: 0 },
      { month: 9, year: year, performance: 0 },
      { month: 10, year: year, performance: 0 },
      { month: 11, year: year, performance: 0 },
      { month: 12, year: year, performance: 0 },
      { month: 1, year: next_year, performance: 0 },
      { month: 2, year: next_year, performance: 0 },
      { month: 3, year: next_year, performance: 0 },
      { month: 4, year: next_year, performance: 0 },
      { month: 5, year: next_year, performance: 0 },
      { month: 6, year: next_year, performance: 0 },
    ];

    let yearly_performance = await get_performance_by_emp_obj_id_yearly(
      emp_details._id,
      year
    );
    // console.log("yearly_performance: ", yearly_performance);
    if (yearly_performance.length > 0) {
      yearly_performance.forEach((db_item) => {
        let full_item = full_year.find(
          (item) => item.month === db_item.month && item.year === db_item.year
        );
        if (full_item) {
          full_item.performance = Math.round(db_item.performance);
        }
      });

      console.log("full_year: ", full_year);
      current_year_performance.month_year = [];
      current_year_performance.performance = [];
      full_year.forEach((item) => {
        current_year_performance.month_year.push(
          month_names[item.month] + " " + item.year
        );
        current_year_performance.performance.push(item.performance);
      });
      // console.log("month_year: ", month_year);
      console.log("current_year_performance: ", current_year_performance);

      // full_year.forEach((item) => {
      //   month_year.push(month_names[item.month] + " " + item.year);
      // });

      // current_year_performance = yearly_performance;
    }
  }

  const data = {
    birthday_employees,
    increment_employees,
    month_name,
    current_month_absents,
    current_month_fineable_mins,
    late_mins_monthly,
    total_absent_yearly,
    today_late_minutes,
    // seven_days_attendance,
    on_leave_employees,
    all_on_leave,
    is_lead,
    fines,
    lunches,
    current_month_lunch,
    pending_feedbacks,
    last_month_performance,
    current_year_performance,
    want_lunch,
    latest_tickets,
    allowed_leaves,
  };
  resp.data = data;
  return resp;
};

const getDashboardData = async (user_id) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getDashboardData(user_id, resp);
  return resp;
};

//********************************{V1 get DashBoard Data }***************************//
const _getDashboardDataV1 = async (user_id, resp) => {
  const emp_details = await find_employee_by_user_id(user_id);

  console.log("emp_details:=================", emp_details);

  let month_names = {
    1: "Jan",
    2: "Feb",
    3: "Mar",
    4: "Apr",
    5: "May",
    6: "Jun",
    7: "Jul",
    8: "Aug",
    9: "Sep",
    10: "Oct",
    11: "Nov",
    12: "Dec",
  };

  let is_lead = false;
  let total_absent_yearly = 0;
  let today_late_minutes = 0;
  let late_mins_monthly = 0;
  let current_month_fineable_mins = 0;
  let current_month_absents = 0;
  let seven_days_attendance = [];
  // let birthday_employees = [];
  let increment_employees = [];
  let on_leave_employees = [];
  // let fines = [];
  // let lunches = [];
  let all_on_leave = [];
  let current_month_lunch = {};
  let pending_feedbacks = 0;
  let latest_tickets = [];
  let last_month_performance = 0;
  let current_year_performance = {};
  let want_lunch = null;
  let allowed_leaves = 15;
  let today_date = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY").utc(
    true
  );
  let tomorrow = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY")
    .utc(true)
    .add(1, "days");

  // let last_month_start_date = moment()
  //   .subtract(1, "months")
  //   .startOf("month")
  //   .format("YYYY-MM-DD");
  // let last_month_end_date = moment()
  //   .subtract(1, "months")
  //   .endOf("month")
  //   .format("YYYY-MM-DD");

  const date = new Date();
  let day = date.getDate() - 1;
  let month = date.getMonth() + 1;
  let year = date.getFullYear();

  // console.log("last_month_start_date: ", last_month_start_date);
  // console.log("last_month_end_date: ", last_month_end_date);

  // console.log("today_date 1: ", today_date);
  // console.log("tomorrow 1: ", tomorrow);

  if (emp_details) {
    allowed_leaves = emp_details.allowed_leaves;
    want_lunch = emp_details.want_lunch;
    let feedback_query = { submission_status: "pending" };
    if (
      emp_details.role.title == "HR" ||
      emp_details.role.title == "Admin" ||
      emp_details.role.title == "All"
    ) {
      // let all_employees = await get_active_employees_for_birthday_increments();
      // let start_date = moment();
      // let birthday_end_date = moment().add(15, "days");
      // let inc_end_date = moment().add(1, "months");

      // for (let i = 0; i < all_employees.length; i++) {
      //   let [day, month, year] = all_employees[i].date_of_birth.split("-");
      //   let temp_birth_date = day + "-" + month + "-" + moment().format("YYYY");
      //   let birth_date = moment(temp_birth_date, "DD-MM-YYYY");

      //   if (birth_date.isBetween(start_date, birthday_end_date)) {
      //     birthday_employees.push(all_employees[i]);
      //   }

      //   let inc_date = moment(
      //     all_employees[i].date_of_increment,
      //     "DD-MM-YYYY"
      //   ).add(6, "months");

      //   if (inc_date.isBetween(start_date, inc_end_date)) {
      //     increment_employees.push(all_employees[i]);
      //   }
      // }
      // increment_employees.sort(function (a, b) {
      //   a_date_of_increment = a.date_of_increment.split("-").reverse().join("");
      //   b_date_of_increment = b.date_of_increment.split("-").reverse().join("");
      //   return a_date_of_increment > b_date_of_increment
      //     ? 1
      //     : a_date_of_increment < b_date_of_increment
      //     ? -1
      //     : 0;
      // });
      // birthday_employees.sort(function (a, b) {
      //   a_date_of_birth = a.date_of_birth
      //     .split("-")
      //     .slice(0, 2)
      //     .reverse()
      //     .join("");
      //   b_date_of_birth = b.date_of_birth
      //     .split("-")
      //     .slice(0, 2)
      //     .reverse()
      //     .join("");
      //   return a_date_of_birth > b_date_of_birth
      //     ? 1
      //     : a_date_of_birth < b_date_of_birth
      //     ? -1
      //     : 0;
      //   // return a.date_of_birth.localeCompare(b.date_of_birth);
      //   // return a.date_of_birth - b.date_of_birth;
      // });
      // Get all pending feedbacks if HR, Admin, All
      // console.log("feedback_query: ", feedback_query);
      pending_feedbacks = await get_feedbacks_query_obj_count(feedback_query);
      latest_tickets = await latest_support_ticket_with_role_v1(
        emp_details.role._id
      );
    } else {
      // Get all pending feedbacks for normal user
      feedback_query["send_to._id"] = emp_details._id;
      // console.log("feedback_query: ", feedback_query);
      pending_feedbacks = await get_feedbacks_query_obj_count(feedback_query);
    }
  }

  // let last_year = date.getFullYear() - 1;
  let month_name = date.toLocaleString("default", { month: "long" });
  if (day < 10) {
    day = "0" + day;
  }
  if (month < 10) {
    month = "0" + month;
  }
  let current_date = `${day}/${month}/${year}`;

  if (emp_details) {
    const get_late_mins = await get_attendance_by_date_month_year_for_user(
      emp_details._id,
      month,
      year,
      current_date
    );
    if (get_late_mins) {
      today_late_minutes = get_late_mins.attendance[0].late;
    }

    const monthly_late_mins_and_absents =
      await get_monthly_late_mins_and_absents_for_user(
        emp_details._id,
        month,
        year
      );
    if (monthly_late_mins_and_absents) {
      late_mins_monthly = monthly_late_mins_and_absents.total_late_minutes;
      current_month_absents = monthly_late_mins_and_absents.total_absents;
      if (late_mins_monthly >= 60) {
        current_month_fineable_mins = late_mins_monthly - 60;
      }
    }

    // let absent_query = { emp_obj_id: emp_details._id };
    // total_absent_yearly = await get_absent_count_yearly(absent_query);

    //current year absent count

    //find current year with moment

    function getFiscalYear() {
      const currentDate = moment();
      let fiscalYearStart, fiscalYearEnd;

      if (currentDate.month() >= 6) {
        // If the current month is July or later
        fiscalYearStart = moment({
          year: currentDate.year(),
          month: 6,
          day: 1,
        }).format("YYYY-MM-DD");
        fiscalYearEnd = moment({
          year: currentDate.year() + 1,
          month: 5,
          day: 30,
        }).format("YYYY-MM-DD");
      } else {
        // If the current month is June or earlier
        fiscalYearStart = moment({
          year: currentDate.year() - 1,
          month: 6,
          day: 1,
        }).format("YYYY-MM-DD");
        fiscalYearEnd = moment({
          year: currentDate.year(),
          month: 5,
          day: 30,
        }).format("YYYY-MM-DD");
      }

      return { fiscalYearStart, fiscalYearEnd };
    }

    const { fiscalYearStart, fiscalYearEnd } = getFiscalYear();

    let current_year_absent = await get_employee_leaves_for_dashboard_count(
      emp_details._id,
      fiscalYearStart,
      fiscalYearEnd
    );

    if (current_year_absent.length > 0) {
      current_year_absent.forEach((element) => {
        if (element.half_leave_type == 0) {
          total_absent_yearly += 1;
        } else if (
          element.half_leave_type == 1 ||
          element.half_leave_type == 2
        ) {
          total_absent_yearly += 0.5;
        }
      });
    }

    console.log("current_year_absent", current_year_absent);
    console.log("total_absent_yearly", total_absent_yearly);

    // console.log("absents_data_yearly: ", absents_data_yearly);

    // for (let index = 0; index < absents_data_yearly.length; index++) {
    //   const monthly_data = absents_data_yearly[index];
    //   if (
    //     (monthly_data.month < 7 && monthly_data.year == absents_curr_year) ||
    //     (monthly_data.month >= 7 && monthly_data.year == absents_curr_year - 1)
    //   ) {
    //     total_absent_yearly += monthly_data.total_absents;
    //   } else if (
    //     monthly_data.month >= 7 &&
    //     monthly_data.year == absents_curr_year
    //   ) {
    //     total_absent_yearly += monthly_data.total_absents;
    //   }
    // }

    // let current_month_attendance_arr = dashboard_data_monthly.attendance;
    // for (let j = 0; j < current_month_attendance_arr.length; j++) {
    //   if (current_month_attendance_arr[j].date == current_date) {
    //     today_late_minutes = current_month_attendance_arr[j].late;
    //   }
    // }

    // let dates_arr = [];
    // // let current_date_moment = moment().format("DD/MM/YYYY");
    // let date_counter = 1;
    // while (dates_arr.length < 7) {
    //   //
    //   let temp_date = moment()
    //     .add(-parseInt(date_counter), "days")
    //     .format("DD/MM/YYYY");
    //   //
    //   let week_day = moment(temp_date, "DD/MM/YYYY").isoWeekday();
    //   //
    //   if (week_day != 6 && week_day != 7) {
    //     dates_arr.push(temp_date);
    //   }
    //   date_counter += 1;
    // }

    // for (let j = 0; j < dates_arr.length; j++) {
    //   const get_late_mins = await get_attendance_by_date_for_user(
    //     emp_details._id,
    //     dates_arr[j]
    //   );
    //   if (get_late_mins) {
    //     seven_days_attendance.push(get_late_mins.attendance[0]);
    //   }
    // }
  }

  if (emp_details) {
    // if (emp_details.role.title == "HR") {
    //   is_lead = true;
    //   let all_employees = await get_all_active_employees();
    //   for (let a = 0; a < all_employees.length; a++) {
    //     const leave =
    //       await find_leave_request_by_emp_date_tomorrow_pending_approved(
    //         all_employees[a]._id,
    //         today_date,
    //         tomorrow
    //       );
    //     console.log("leave hr: ", leave);
    //     if (leave.length > 0) {
    //       // let on_leave_obj = {
    //       //   _id: leave._id,
    //       //   emp_obj_id: leave.emp_obj_id,
    //       //   emp_name: leave.emp_name,
    //       //   // emp_profile_pic: all_employees[a].profile_pic,
    //       //   leave_type: leave.leave_type,
    //       //   status: leave.status,
    //       //   leave_reason: leave.leave_reason,
    //       //   leave_date: leave.leave_date,
    //       //   rejection_reason: leave.rejection_reason,
    //       //   createdAt: leave.createdAt,
    //       //   updatedAt: leave.updatedAt,
    //       // };
    //       // on_leave_employees.push(on_leave_obj);
    //       on_leave_employees.push.apply(on_leave_employees, leave);
    //     }
    //   }
    // } else {
    const team_members = await get_team_members(emp_details._id);
    if (!_.isEmpty(team_members)) {
      is_lead = true;
      for (let t = 0; t < team_members.length; t++) {
        const leave =
          await find_leave_request_by_emp_date_tomorrow_pending_approved(
            team_members[t]._id,
            today_date,
            tomorrow
          );
        // console.log("leave leads: ", leave);
        if (leave.length > 0) {
          // let on_leave_obj = {
          //   _id: leave._id,
          //   emp_obj_id: leave.emp_obj_id,
          //   emp_name: leave.emp_name,
          //   emp_profile_pic: team_members[t].profile_pic,
          //   leave_type: leave.leave_type,
          //   status: leave.status,
          //   leave_reason: leave.leave_reason,
          //   leave_date: leave.leave_date,
          //   rejection_reason: leave.rejection_reason,
          //   createdAt: leave.createdAt,
          //   updatedAt: leave.updatedAt,
          // };
          // on_leave_employees.push(on_leave_obj);
          on_leave_employees.push.apply(on_leave_employees, leave);
        }
      }
    }
    // }
    // console.log("bedore: ", on_leave_employees);
    on_leave_employees.sort((a, b) =>
      moment(a.leave_date).diff(moment(b.leave_date))
    );
    // console.log("after: ", on_leave_employees);
  }

  if (emp_details) {
    // let emp_fines = await get_unpaid_fines(emp_details._id);
    // if (!_.isEmpty(emp_fines)) {
    //   for (let x = 0; x < emp_fines.length; x++) {
    //     let total_fine = emp_fines[x].fine + emp_fines[x].late_fine;
    //     let fine_obj = {
    //       emp_obj_id: emp_fines[x].emp_obj_id,
    //       emp_name: emp_fines[x].emp_name,
    //       year: emp_fines[x].year,
    //       month: emp_fines[x].month,
    //       deadline: emp_fines[x].deadline,
    //       total_absent: emp_fines[x].total_absent,
    //       due_fine: emp_fines[x].due_fine,
    //       total_fine: total_fine,
    //       paid_status: emp_fines[x].paid_status,
    //       late_fine: emp_fines[x].late_fine,
    //       createdAt: emp_fines[x].createdAt,
    //       updatedAt: emp_fines[x].updatedAt,
    //     };
    //     fines.push(fine_obj);
    //   }
    // }

    // let emp_lunches = await get_unpaid_lunches(emp_details._id);
    // if (!_.isEmpty(emp_lunches)) {
    //   for (let x = 0; x < emp_lunches.length; x++) {
    //     let total_amount = emp_lunches[x].amount + emp_lunches[x].late_fine;
    //     let lunch_obj = {
    //       emplyee: emp_lunches[x].emplyee,
    //       year: emp_lunches[x].year,
    //       month: emp_lunches[x].month,
    //       paid_status: emp_lunches[x].paid_status,
    //       late_fine: emp_lunches[x].late_fine,
    //       deadline: emp_lunches[x].deadline,
    //       total_amount: total_amount,
    //       createdAt: emp_lunches[x].createdAt,
    //       updatedAt: emp_lunches[x].updatedAt,
    //     };
    //     lunches.push(lunch_obj);
    //   }
    // }
    const current_lunch = await find_lunch_for_emp_month_year(
      emp_details._id,
      month,
      year
    );
    if (current_lunch) {
      current_month_lunch = current_lunch;
    }
  }

  let today_date_2 = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY").utc(
    true
  );
  // console.log("today_date_1: ", today_date);

  const get_all_on_leaves =
    await get_leave_requests_pending_approved_today_onwards(today_date_2);
  if (get_all_on_leaves.length > 0) {
    all_on_leave = get_all_on_leaves;
    // console.log("bedore: ", all_on_leave);
    all_on_leave.sort((a, b) =>
      moment(a.leave_date).diff(moment(b.leave_date))
    );
    // console.log("after: ", all_on_leave);
  }

  // console.log("all_on_leave: ", all_on_leave);
  // console.log("emp_details: ", emp_details);
  // console.log("is_lead: ", is_lead);

  if (emp_details) {
    let perf_query_obj = {
      "send_for._id": emp_details._id,
    };

    let perf_detail = await get_last_performance_month(perf_query_obj);

    if (perf_detail.length > 0) {
      let performance_query_obj = {
        "send_for._id": emp_details._id,
        month: perf_detail[0].month,
        year: perf_detail[0].year,
      };
      const performance = await get_performance_by_emp_obj_id(
        performance_query_obj
      );

      if (performance.length > 0) {
        last_month_performance = performance[0].performancePercentage;
      }
    }
    let next_year = year + 1;
    let full_year = [
      { month: 7, year: year, performance: 0 },
      { month: 8, year: year, performance: 0 },
      { month: 9, year: year, performance: 0 },
      { month: 10, year: year, performance: 0 },
      { month: 11, year: year, performance: 0 },
      { month: 12, year: year, performance: 0 },
      { month: 1, year: next_year, performance: 0 },
      { month: 2, year: next_year, performance: 0 },
      { month: 3, year: next_year, performance: 0 },
      { month: 4, year: next_year, performance: 0 },
      { month: 5, year: next_year, performance: 0 },
      { month: 6, year: next_year, performance: 0 },
    ];

    let yearly_performance = await get_performance_by_emp_obj_id_yearly(
      emp_details._id,
      year
    );
    // console.log("yearly_performance: ", yearly_performance);
    if (yearly_performance.length > 0) {
      yearly_performance.forEach((db_item) => {
        let full_item = full_year.find(
          (item) => item.month === db_item.month && item.year === db_item.year
        );
        if (full_item) {
          full_item.performance = Math.round(db_item.performance);
        }
      });

      console.log("full_year: ", full_year);
      current_year_performance.month_year = [];
      current_year_performance.performance = [];
      full_year.forEach((item) => {
        current_year_performance.month_year.push(
          month_names[item.month] + " " + item.year
        );
        current_year_performance.performance.push(item.performance);
      });
      // console.log("month_year: ", month_year);
      console.log("current_year_performance: ", current_year_performance);

      // full_year.forEach((item) => {
      //   month_year.push(month_names[item.month] + " " + item.year);
      // });

      // current_year_performance = yearly_performance;
    }
  }

  const data = {
    // birthday_employees,
    // increment_employees,
    month_name,
    current_month_absents,
    current_month_fineable_mins,
    late_mins_monthly,
    total_absent_yearly,
    today_late_minutes,
    // seven_days_attendance,
    on_leave_employees,
    all_on_leave,
    is_lead,
    // fines,
    // lunches,
    current_month_lunch,
    pending_feedbacks,
    last_month_performance,
    current_year_performance,
    want_lunch,
    latest_tickets,
    allowed_leaves,
  };
  resp.data = data;
  return resp;
};

const getDashboardDataV1 = async (user_id) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getDashboardDataV1(user_id, resp);
  return resp;
};

//********************************{V2 get DashBoard Data }***************************//
const _getDashboardDataV2 = async (user_id, resp) => {
  const emp_details = await find_employee_by_user_id(user_id);

  // console.log("emp_details:=================", emp_details);

  let month_names = {
    1: "Jan",
    2: "Feb",
    3: "Mar",
    4: "Apr",
    5: "May",
    6: "Jun",
    7: "Jul",
    8: "Aug",
    9: "Sep",
    10: "Oct",
    11: "Nov",
    12: "Dec",
  };

  let is_lead = false;
  let total_absent_yearly = 0;
  let today_late_minutes = 0;
  let late_mins_monthly = 0;
  let current_month_fineable_mins = 0;
  let current_month_absents = 0;
  let seven_days_attendance = [];
  // let birthday_employees = [];
  let increment_employees = [];
  let on_leave_employees = [];
  // let fines = [];
  // let lunches = [];
  let all_on_leave = [];
  let current_month_lunch = {};
  let pending_feedbacks = 0;
  let latest_tickets = [];
  let last_month_performance = 0;
  let current_year_performance = {};
  let want_lunch = null;
  let allowed_leaves = 15;
  let today_date = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY").utc(
    true
  );
  let tomorrow = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY")
    .utc(true)
    .add(1, "days");

  // let last_month_start_date = moment()
  //   .subtract(1, "months")
  //   .startOf("month")
  //   .format("YYYY-MM-DD");
  // let last_month_end_date = moment()
  //   .subtract(1, "months")
  //   .endOf("month")
  //   .format("YYYY-MM-DD");

  const date = new Date();
  let day = date.getDate() - 1;
  let month = date.getMonth() + 1;
  let year = date.getFullYear();

  // console.log("last_month_start_date: ", last_month_start_date);
  // console.log("last_month_end_date: ", last_month_end_date);

  // console.log("today_date 1: ", today_date);
  // console.log("tomorrow 1: ", tomorrow);

  if (emp_details) {
    allowed_leaves = emp_details.allowed_leaves;
    want_lunch = emp_details.want_lunch;
    let feedback_query = { submission_status: "pending" };
    if (
      emp_details.role.title == "HR" ||
      emp_details.role.title == "Admin" ||
      emp_details.role.title == "All"
    ) {
      // let all_employees = await get_active_employees_for_birthday_increments();
      // let start_date = moment();
      // let birthday_end_date = moment().add(15, "days");
      // let inc_end_date = moment().add(1, "months");

      // for (let i = 0; i < all_employees.length; i++) {
      //   let [day, month, year] = all_employees[i].date_of_birth.split("-");
      //   let temp_birth_date = day + "-" + month + "-" + moment().format("YYYY");
      //   let birth_date = moment(temp_birth_date, "DD-MM-YYYY");

      //   if (birth_date.isBetween(start_date, birthday_end_date)) {
      //     birthday_employees.push(all_employees[i]);
      //   }

      //   let inc_date = moment(
      //     all_employees[i].date_of_increment,
      //     "DD-MM-YYYY"
      //   ).add(6, "months");

      //   if (inc_date.isBetween(start_date, inc_end_date)) {
      //     increment_employees.push(all_employees[i]);
      //   }
      // }
      // increment_employees.sort(function (a, b) {
      //   a_date_of_increment = a.date_of_increment.split("-").reverse().join("");
      //   b_date_of_increment = b.date_of_increment.split("-").reverse().join("");
      //   return a_date_of_increment > b_date_of_increment
      //     ? 1
      //     : a_date_of_increment < b_date_of_increment
      //     ? -1
      //     : 0;
      // });
      // birthday_employees.sort(function (a, b) {
      //   a_date_of_birth = a.date_of_birth
      //     .split("-")
      //     .slice(0, 2)
      //     .reverse()
      //     .join("");
      //   b_date_of_birth = b.date_of_birth
      //     .split("-")
      //     .slice(0, 2)
      //     .reverse()
      //     .join("");
      //   return a_date_of_birth > b_date_of_birth
      //     ? 1
      //     : a_date_of_birth < b_date_of_birth
      //     ? -1
      //     : 0;
      //   // return a.date_of_birth.localeCompare(b.date_of_birth);
      //   // return a.date_of_birth - b.date_of_birth;
      // });
      // Get all pending feedbacks if HR, Admin, All
      // console.log("feedback_query: ", feedback_query);
      pending_feedbacks = await get_feedbacks_query_obj_count(feedback_query);
      latest_tickets = await latest_support_ticket_with_role_v1(
        emp_details.role._id
      );
    } else {
      // Get all pending feedbacks for normal user
      feedback_query["send_to._id"] = emp_details._id;
      // console.log("feedback_query: ", feedback_query);
      pending_feedbacks = await get_feedbacks_query_obj_count(feedback_query);
    }
  }

  // let last_year = date.getFullYear() - 1;
  let month_name = date.toLocaleString("default", { month: "long" });
  if (day < 10) {
    day = "0" + day;
  }
  if (month < 10) {
    month = "0" + month;
  }
  let current_date = `${day}/${month}/${year}`;

  if (emp_details) {
    const get_late_mins = await get_attendance_by_date_month_year_for_user(
      emp_details._id,
      month,
      year,
      current_date
    );
    if (get_late_mins) {
      today_late_minutes = get_late_mins.attendance[0].late;
    }

    const monthly_late_mins_and_absents =
      await get_monthly_late_mins_and_absents_for_user(
        emp_details._id,
        month,
        year
      );
    if (monthly_late_mins_and_absents) {
      late_mins_monthly = monthly_late_mins_and_absents.total_late_minutes;
      // current_month_absents = monthly_late_mins_and_absents.total_absents;
      if (late_mins_monthly >= 60) {
        current_month_fineable_mins = late_mins_monthly - 60;
      }
    }

    // let absent_query = { emp_obj_id: emp_details._id };
    // total_absent_yearly = await get_absent_count_yearly(absent_query);

    //find current month start and end date
    function getCurrentMonthStartAndEnd() {
      let start_date_of_month = moment().startOf("month").format("YYYY-MM-DD");
      let end_date_of_month = moment().endOf("month").format("YYYY-MM-DD");

      return { start_date_of_month, end_date_of_month };
    }

    const { start_date_of_month, end_date_of_month } =
      getCurrentMonthStartAndEnd();

    let current_month_absent = await find_leaves_from_leave_request(
      emp_details._id,
      start_date_of_month,
      end_date_of_month
    );
    // console.log("current_year_absent", current_year_absent);
    if (current_month_absent.length > 0) {
      current_month_absent.forEach((element) => {
        if (element.count_in_yearly_leaves == true) {
          if (element.leave_type == "full") {
            current_month_absents += 1;
          } else if (
            element.leave_type == "first_half" ||
            element.leave_type == "second_half"
          ) {
            current_month_absents += 0.5;
          }
        }
      });
    }

    //current year absent count
    //find current year with moment

    function getFiscalYear() {
      const currentDate = moment();
      let fiscalYearStart, fiscalYearEnd;

      if (currentDate.month() >= 6) {
        // If the current month is July or later
        fiscalYearStart = moment({
          year: currentDate.year(),
          month: 6,
          day: 1,
        }).format("YYYY-MM-DD");
        fiscalYearEnd = moment({
          year: currentDate.year() + 1,
          month: 5,
          day: 30,
        }).format("YYYY-MM-DD");
      } else {
        // If the current month is June or earlier
        fiscalYearStart = moment({
          year: currentDate.year() - 1,
          month: 6,
          day: 1,
        }).format("YYYY-MM-DD");
        fiscalYearEnd = moment({
          year: currentDate.year(),
          month: 5,
          day: 30,
        }).format("YYYY-MM-DD");
      }

      return { fiscalYearStart, fiscalYearEnd };
    }

    const { fiscalYearStart, fiscalYearEnd } = getFiscalYear();

    let current_year_absent = await find_leaves_from_leave_request(
      emp_details._id,
      fiscalYearStart,
      fiscalYearEnd
    );

    if (current_year_absent.length > 0) {
      current_year_absent.forEach((element) => {
        if (element.count_in_yearly_leaves == true) {
          if (element.leave_type == "full") {
            total_absent_yearly += 1;
          } else if (
            element.leave_type == "first_half" ||
            element.leave_type == "second_half"
          ) {
            total_absent_yearly += 0.5;
          }
        }
      });
    }

    // let current_year_absent = await get_employee_leaves_for_dashboard_count(
    //   emp_details._id,
    //   fiscalYearStart,
    //   fiscalYearEnd
    // );

    // if (current_year_absent.length > 0) {
    //   current_year_absent.forEach((element) => {
    //     if (element.half_leave_type == 0) {
    //       total_absent_yearly += 1;
    //     } else if (element.half_leave_type == 1 || element.half_leave_type == 2){
    //       total_absent_yearly += 0.5;
    //     }
    //   });
    // }

    // console.log("current_year_absent", current_year_absent);
    // console.log("total_absent_yearly", total_absent_yearly);

    // console.log("absents_data_yearly: ", absents_data_yearly);

    // for (let index = 0; index < absents_data_yearly.length; index++) {
    //   const monthly_data = absents_data_yearly[index];
    //   if (
    //     (monthly_data.month < 7 && monthly_data.year == absents_curr_year) ||
    //     (monthly_data.month >= 7 && monthly_data.year == absents_curr_year - 1)
    //   ) {
    //     total_absent_yearly += monthly_data.total_absents;
    //   } else if (
    //     monthly_data.month >= 7 &&
    //     monthly_data.year == absents_curr_year
    //   ) {
    //     total_absent_yearly += monthly_data.total_absents;
    //   }
    // }

    // let current_month_attendance_arr = dashboard_data_monthly.attendance;
    // for (let j = 0; j < current_month_attendance_arr.length; j++) {
    //   if (current_month_attendance_arr[j].date == current_date) {
    //     today_late_minutes = current_month_attendance_arr[j].late;
    //   }
    // }

    // let dates_arr = [];
    // // let current_date_moment = moment().format("DD/MM/YYYY");
    // let date_counter = 1;
    // while (dates_arr.length < 7) {
    //   //
    //   let temp_date = moment()
    //     .add(-parseInt(date_counter), "days")
    //     .format("DD/MM/YYYY");
    //   //
    //   let week_day = moment(temp_date, "DD/MM/YYYY").isoWeekday();
    //   //
    //   if (week_day != 6 && week_day != 7) {
    //     dates_arr.push(temp_date);
    //   }
    //   date_counter += 1;
    // }

    // for (let j = 0; j < dates_arr.length; j++) {
    //   const get_late_mins = await get_attendance_by_date_for_user(
    //     emp_details._id,
    //     dates_arr[j]
    //   );
    //   if (get_late_mins) {
    //     seven_days_attendance.push(get_late_mins.attendance[0]);
    //   }
    // }
  }

  if (emp_details) {
    // if (emp_details.role.title == "HR") {
    //   is_lead = true;
    //   let all_employees = await get_all_active_employees();
    //   for (let a = 0; a < all_employees.length; a++) {
    //     const leave =
    //       await find_leave_request_by_emp_date_tomorrow_pending_approved(
    //         all_employees[a]._id,
    //         today_date,
    //         tomorrow
    //       );
    //     console.log("leave hr: ", leave);
    //     if (leave.length > 0) {
    //       // let on_leave_obj = {
    //       //   _id: leave._id,
    //       //   emp_obj_id: leave.emp_obj_id,
    //       //   emp_name: leave.emp_name,
    //       //   // emp_profile_pic: all_employees[a].profile_pic,
    //       //   leave_type: leave.leave_type,
    //       //   status: leave.status,
    //       //   leave_reason: leave.leave_reason,
    //       //   leave_date: leave.leave_date,
    //       //   rejection_reason: leave.rejection_reason,
    //       //   createdAt: leave.createdAt,
    //       //   updatedAt: leave.updatedAt,
    //       // };
    //       // on_leave_employees.push(on_leave_obj);
    //       on_leave_employees.push.apply(on_leave_employees, leave);
    //     }
    //   }
    // } else {
    const team_members = await get_team_members(emp_details._id);
    if (!_.isEmpty(team_members)) {
      is_lead = true;
      for (let t = 0; t < team_members.length; t++) {
        const leave =
          await find_leave_request_by_emp_date_tomorrow_pending_approved(
            team_members[t]._id,
            today_date,
            tomorrow
          );
        // console.log("leave leads: ", leave);
        if (leave.length > 0) {
          // let on_leave_obj = {
          //   _id: leave._id,
          //   emp_obj_id: leave.emp_obj_id,
          //   emp_name: leave.emp_name,
          //   emp_profile_pic: team_members[t].profile_pic,
          //   leave_type: leave.leave_type,
          //   status: leave.status,
          //   leave_reason: leave.leave_reason,
          //   leave_date: leave.leave_date,
          //   rejection_reason: leave.rejection_reason,
          //   createdAt: leave.createdAt,
          //   updatedAt: leave.updatedAt,
          // };
          // on_leave_employees.push(on_leave_obj);
          on_leave_employees.push.apply(on_leave_employees, leave);
        }
      }
    }
    // }
    // console.log("bedore: ", on_leave_employees);
    on_leave_employees.sort((a, b) =>
      moment(a.leave_date).diff(moment(b.leave_date))
    );
    // console.log("after: ", on_leave_employees);
  }

  if (emp_details) {
    // let emp_fines = await get_unpaid_fines(emp_details._id);
    // if (!_.isEmpty(emp_fines)) {
    //   for (let x = 0; x < emp_fines.length; x++) {
    //     let total_fine = emp_fines[x].fine + emp_fines[x].late_fine;
    //     let fine_obj = {
    //       emp_obj_id: emp_fines[x].emp_obj_id,
    //       emp_name: emp_fines[x].emp_name,
    //       year: emp_fines[x].year,
    //       month: emp_fines[x].month,
    //       deadline: emp_fines[x].deadline,
    //       total_absent: emp_fines[x].total_absent,
    //       due_fine: emp_fines[x].due_fine,
    //       total_fine: total_fine,
    //       paid_status: emp_fines[x].paid_status,
    //       late_fine: emp_fines[x].late_fine,
    //       createdAt: emp_fines[x].createdAt,
    //       updatedAt: emp_fines[x].updatedAt,
    //     };
    //     fines.push(fine_obj);
    //   }
    // }

    // let emp_lunches = await get_unpaid_lunches(emp_details._id);
    // if (!_.isEmpty(emp_lunches)) {
    //   for (let x = 0; x < emp_lunches.length; x++) {
    //     let total_amount = emp_lunches[x].amount + emp_lunches[x].late_fine;
    //     let lunch_obj = {
    //       emplyee: emp_lunches[x].emplyee,
    //       year: emp_lunches[x].year,
    //       month: emp_lunches[x].month,
    //       paid_status: emp_lunches[x].paid_status,
    //       late_fine: emp_lunches[x].late_fine,
    //       deadline: emp_lunches[x].deadline,
    //       total_amount: total_amount,
    //       createdAt: emp_lunches[x].createdAt,
    //       updatedAt: emp_lunches[x].updatedAt,
    //     };
    //     lunches.push(lunch_obj);
    //   }
    // }
    const current_lunch = await find_lunch_for_emp_month_year(
      emp_details._id,
      month,
      year
    );
    if (current_lunch) {
      current_month_lunch = current_lunch;
    }
  }

  let today_date_2 = moment(moment().format("DD-MM-YYYY"), "DD-MM-YYYY").utc(
    true
  );
  // console.log("today_date_1: ", today_date);

  const get_all_on_leaves =
    await get_leave_requests_pending_approved_today_onwards(today_date_2);
  if (get_all_on_leaves.length > 0) {
    all_on_leave = get_all_on_leaves;
    // console.log("bedore: ", all_on_leave);
    all_on_leave.sort((a, b) =>
      moment(a.leave_date).diff(moment(b.leave_date))
    );
    // console.log("after: ", all_on_leave);
  }

  // console.log("all_on_leave: ", all_on_leave);
  // console.log("emp_details: ", emp_details);
  // console.log("is_lead: ", is_lead);

  if (emp_details) {
    let perf_query_obj = {
      "send_for._id": emp_details._id,
    };

    let perf_detail = await get_last_performance_month(perf_query_obj);

    if (perf_detail.length > 0) {
      let performance_query_obj = {
        "send_for._id": emp_details._id,
        month: perf_detail[0].month,
        year: perf_detail[0].year,
      };
      const performance = await get_performance_by_emp_obj_id(
        performance_query_obj
      );

      if (performance.length > 0) {
        last_month_performance = performance[0].performancePercentage;
      }
    }
    let next_year = year + 1;
    let full_year = [
      { month: 7, year: year, performance: 0 },
      { month: 8, year: year, performance: 0 },
      { month: 9, year: year, performance: 0 },
      { month: 10, year: year, performance: 0 },
      { month: 11, year: year, performance: 0 },
      { month: 12, year: year, performance: 0 },
      { month: 1, year: next_year, performance: 0 },
      { month: 2, year: next_year, performance: 0 },
      { month: 3, year: next_year, performance: 0 },
      { month: 4, year: next_year, performance: 0 },
      { month: 5, year: next_year, performance: 0 },
      { month: 6, year: next_year, performance: 0 },
    ];

    let yearly_performance = await get_performance_by_emp_obj_id_yearly(
      emp_details._id,
      year
    );
    // console.log("yearly_performance: ", yearly_performance);
    if (yearly_performance.length > 0) {
      yearly_performance.forEach((db_item) => {
        let full_item = full_year.find(
          (item) => item.month === db_item.month && item.year === db_item.year
        );
        if (full_item) {
          full_item.performance = Math.round(db_item.performance);
        }
      });

      console.log("full_year: ", full_year);
      current_year_performance.month_year = [];
      current_year_performance.performance = [];
      full_year.forEach((item) => {
        current_year_performance.month_year.push(
          month_names[item.month] + " " + item.year
        );
        current_year_performance.performance.push(item.performance);
      });
      // console.log("month_year: ", month_year);
      console.log("current_year_performance: ", current_year_performance);

      // full_year.forEach((item) => {
      //   month_year.push(month_names[item.month] + " " + item.year);
      // });

      // current_year_performance = yearly_performance;
    }
  }

  const data = {
    // birthday_employees,
    // increment_employees,
    month_name,
    current_month_absents,
    current_month_fineable_mins,
    late_mins_monthly,
    total_absent_yearly,
    today_late_minutes,
    // seven_days_attendance,
    on_leave_employees,
    all_on_leave,
    is_lead,
    // fines,
    // lunches,
    current_month_lunch,
    pending_feedbacks,
    last_month_performance,
    current_year_performance,
    want_lunch,
    latest_tickets,
    allowed_leaves,
  };
  resp.data = data;
  return resp;
};

const getDashboardDataV2 = async (user_id) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getDashboardDataV2(user_id, resp);
  return resp;
};

//********************************{get data for add employee}***************************//
const _getDataForAddEmployee = async (resp) => {
  const departments = await get_all_active_departments_v1();
  const roles = await all_roles_active_v1();
  const companies = await all_active_companies_v1();
  const company_assets = await get_all_free_active_company_assets_v1();
  const active_employees = await get_all_active_employees_v1();

  resp.data = {
    departments: departments,
    roles: roles,
    companies: companies,
    company_assets: company_assets,
    active_employees: active_employees,
  };

  return resp;
};

const getDataForAddEmployee = async () => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getDataForAddEmployee(resp);
  return resp;
};

module.exports = {
  getDashboardData,
  getDashboardDataV1,
  getDashboardDataV2,
  getDataForAddEmployee,
};
