const {
  add_website_setting,
  get_website_setting,
  add_website_gernal_setting,
  get_website_gernal_setting,
  add_twilio_setting,
} = require("../DAL/website_setting");

const {
  get_all_departments_ids,
  find_department_by_id,
} = require("../DAL/department");
const {
  get_all_employees_ids,
  find_employee_by_id,
} = require("../DAL/employee");

const _ = require("lodash");

// Edit Website Settings
const _editWebsiteSetting = async (body, resp) => {
  const website_setting = await get_website_setting();

  if (!website_setting) {
    add_website_setting(body);
    return resp;
  }

  website_setting.support_email = body.support_email;
  website_setting.privacy_policy = body.privacy_policy;
  website_setting.terms_and_conditions = body.terms_and_conditions;
  website_setting.all_previllages = body.all_previllages;

  let editWebsiteSetting = await website_setting.save();

  if (!editWebsiteSetting) {
    resp.error = true;
    resp.error_message = "Website Settings Update Failed";
    return resp;
  }

  const website_setting_previllages_keys = Object.keys(
    editWebsiteSetting.all_previllages
  );

  const get_departments = await get_all_departments_ids();

  for (let i = 0; i < get_departments.length; i++) {
    const dept_id = get_departments[i];
    const dept = await find_department_by_id(dept_id);
    const dept_previllages_keys = Object.keys(dept.previllages);

    let dept_previllages = { ...dept.previllages };

    for (let j = 0; j < website_setting_previllages_keys.length; j++) {
      if (
        !dept_previllages_keys.includes(website_setting_previllages_keys[j])
      ) {
        const new_key = website_setting_previllages_keys[j];
        const new_values = editWebsiteSetting.all_previllages[new_key];

        dept_previllages[new_key] = new_values;
      }
    }
    dept.previllages = dept_previllages;

    await dept.save();
  }

  const get_employees = await get_all_employees_ids();

  for (let i = 0; i < get_employees.length; i++) {
    const emp_obj_id = get_employees[i];
    const employee = await find_employee_by_id(emp_obj_id);
    const employee_previllages_keys = Object.keys(employee.previllages);

    let employee_previllages = { ...employee.previllages };

    for (let j = 0; j < website_setting_previllages_keys.length; j++) {
      if (
        !employee_previllages_keys.includes(website_setting_previllages_keys[j])
      ) {
        const new_key = website_setting_previllages_keys[j];
        const new_values = editWebsiteSetting.all_previllages[new_key];

        employee_previllages[new_key] = new_values;
      }
    }
    employee.previllages = employee_previllages;

    await employee.save();
  }

  return resp;
};
const editWebsiteSetting = async (body) => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _editWebsiteSetting(body, resp);
  return resp;
};
// Get Website Settings
const _getWebsiteSetting = async (resp) => {
  const website_setting = await get_website_setting();

  resp.data = {
    website_setting: website_setting,
  };
  return resp;
};

const getWebsiteSetting = async () => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getWebsiteSetting(resp);
  return resp;
};

//*************************************{Get Website Gernal Settings}************************************************
const _getWebsiteGernalSetting = async (resp) => {
  const website_setting = await get_website_gernal_setting();

  resp.data = {
    website_setting: website_setting.general_settings,
  };
  return resp;
};
const getWebsiteGernalSetting = async () => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getWebsiteGernalSetting(resp);
  return resp;
};

//*************************************{Update website Gernal settings}************************************************

const _editWebsiteGernalSettings = async (body, resp) => {
  var website_setting_exist = await get_website_gernal_setting();
  // console.log("get website setting",website_setting_exist);
  if (!website_setting_exist) {
    console.log("body.general_settings", body);
    // console.log("body.general_settings", body.general_settings);
    website_setting_exist = await add_website_gernal_setting(body);
    console.log("website_setting_exist", website_setting_exist);
  } else {
    console.log("body.general_settings", body.general_settings);
    website_setting_exist.general_settings = body.general_settings;
    website_setting_exist = await website_setting_exist.save();
  }

  resp.data = {
    gerenal_settings: website_setting_exist.general_settings,
  };

  return resp;
};
const editWebsiteGernalSettings = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editWebsiteGernalSettings(body, resp);
  return resp;
};

//*************************************{Update Twilio settings}************************************************

const _updateTwilioSettings = async (body, resp) => {
  var website_setting_exist = await add_twilio_setting(body);
  if (!website_setting_exist) {
    resp.error = true;
    resp.error_message = "Something is wrong while updating Twilio settings";
    return resp;
  }
  resp.data = website_setting_exist.twilio_settings;

  return resp;
};
const updateTwilioSettings = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _updateTwilioSettings(body, resp);
  return resp;
};

module.exports = {
  editWebsiteSetting,
  getWebsiteSetting,
  getWebsiteGernalSetting,
  editWebsiteGernalSettings,
  updateTwilioSettings,
};
