const {
  add_tax_slabs,
  update_tax_slabs,
  get_tax_slabs_by_id,
  list_tax_slabs,
  delete_tax_slabs,
} = require("../DAL/tax_slabs");

const _addTaxSlabs = async (body, resp) => {
  const tax_slabs = await add_tax_slabs(body);

  resp.data = {
    tax_slabs: tax_slabs,
  };
  return resp;
};

const addTaxSlabs = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addTaxSlabs(body, resp);
  return resp;
};

const _updateTaxSlabs = async (id, body, resp) => {
  const find_tax_slab = await get_tax_slabs_by_id(id);
  if (!find_tax_slab) {
    resp.error = true;
    resp.error_message = "Tax slab not found";
    return resp;
  }

  const tax_slabs = await update_tax_slabs(id, body);
  if (!tax_slabs) {
    resp.error = true;
    resp.error_message = "Tax slab not updated";
    return resp;
  }

  resp.data = {
    tax_slabs: tax_slabs,
  };
  return resp;
};

const updateTaxSlabs = async (id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _updateTaxSlabs(id, body, resp);
  return resp;
};

const _getTaxSlabsById = async (id, resp) => {
  const find_tax_slab = await get_tax_slabs_by_id(id);
  if (!find_tax_slab) {
    resp.error = true;
    resp.error_message = "Tax slab not found";
    return resp;
  }

  resp.data = {
    tax_slabs: find_tax_slab,
  };
  return resp;
};

const getTaxSlabsById = async (id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getTaxSlabsById(id, resp);
  return resp;
};

const _listTaxSlabs = async (query_obj, resp) => {
  const tax_slabs = await list_tax_slabs(query_obj);

  resp.data = {
    tax_slabs: tax_slabs,
  };
  return resp;
};

const listTaxSlabs = async (query_obj) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _listTaxSlabs(query_obj, resp);
  return resp;
};

const _deleteTaxSlabs = async (id, resp) => {
  const tax_slab = await delete_tax_slabs(id);
  if (!tax_slab) {
    resp.error = true;
    resp.error_message = "Tax slab not deleted";
    return resp;
  }

  resp.data = {};
  return resp;
};

const deleteTaxSlabs = async (id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteTaxSlabs(id, resp);
  return resp;
};

module.exports = {
  addTaxSlabs,
  updateTaxSlabs,
  getTaxSlabsById,
  listTaxSlabs,
  deleteTaxSlabs,
};
