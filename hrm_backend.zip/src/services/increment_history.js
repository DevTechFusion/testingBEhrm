const mongoose = require("mongoose");
const {
  add_increment_history,
  update_increment_history,
  get_increment_history_by_id,
  list_increment_history,
  delete_increment_history,
} = require("../DAL/increment_history");

const {
  find_employee_by_user_id,
  find_employee_by_id,
} = require("../DAL/employee");

const moment = require("moment");
const _addIncrementHistory = async (user_id, body, resp) => {
  const find_admin = await find_employee_by_user_id(user_id);
  if (!find_admin) {
    resp.error = true;
    resp.error_message = "User not found";
    return resp;
  }

  const find_employee = await find_employee_by_id(body.employee_id);
  if (!find_employee) {
    resp.error = true;
    resp.error_message = "Employee not found";
    return resp;
  }

  let action_info_obj = {
    user_id: user_id,
    full_name: find_admin.full_name ? find_admin.full_name : "",
    designation: find_admin.designation ? find_admin.designation : "",
  };

  let employee_info_obj = {
    employee_id: find_employee._id,
    full_name: find_employee.full_name ? find_employee.full_name : "",
    designation: find_employee.designation ? find_employee.designation : "",
  };

  let increment_history_object = {
    employee_info: employee_info_obj,
    action_info: action_info_obj,
    additional_note: body.additional_note ? body.additional_note : "",
    increment_amount: body.increment_amount,
    increment_date: body.increment_date,
  };

  const increment_history = await add_increment_history(
    increment_history_object
  );

  resp.data = {
    increment_history: increment_history,
  };
  return resp;
};
const addIncrementHistory = async (user_id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addIncrementHistory(user_id, body, resp);
  return resp;
};

const _updateIncrementHistory = async (id, body, resp) => {
  const find_increment_history = await get_increment_history_by_id(id);
  if (!find_increment_history) {
    resp.error = true;
    resp.error_message = "Increment History not found";
    return resp;
  }

  let object = {
    increment_amount: body.increment_amount,
    increment_date: body.increment_date,
    additional_note: body.additional_note ? body.additional_note : "",
  };

  const increment_history = await update_increment_history(id, object);
  if (!increment_history) {
    resp.error = true;
    resp.error_message = "Increment History not updated";
    return resp;
  }

  resp.data = {
    increment_history: increment_history,
  };
  return resp;
};
const updateIncrementHistory = async (id, body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _updateIncrementHistory(id, body, resp);
  return resp;
};

const _getIncrementHistoryById = async (id, resp) => {
  const find_increment_history = await get_increment_history_by_id(id);
  if (!find_increment_history) {
    resp.error = true;
    resp.error_message = "Increment History not found";
    return resp;
  }

  resp.data = {
    increment_history: find_increment_history,
  };
  return resp;
};
const getIncrementHistoryById = async (id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _getIncrementHistoryById(id, resp);
  return resp;
};

const _listIncrementHistory = async (body, resp) => {
  let query_obj = {};

  if (!!body.employee_id) {
    query_obj["employee_info.employee_id"] = mongoose.Types.ObjectId(
      body.employee_id
    );
  }

  const increment_history = await list_increment_history(query_obj);

  resp.data = {
    increment_history: increment_history,
  };
  return resp;
};

const listIncrementHistory = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _listIncrementHistory(body, resp);
  return resp;
};

const _deleteIncrementHistory = async (id, resp) => {
  const increment_history = await delete_increment_history(id);
  if (!increment_history) {
    resp.error = true;
    resp.error_message = "Increment History not deleted";
    return resp;
  }

  resp.data = {};
  return resp;
};

const deleteIncrementHistory = async (id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteIncrementHistory(id, resp);
  return resp;
};

module.exports = {
  addIncrementHistory,
  updateIncrementHistory,
  getIncrementHistoryById,
  listIncrementHistory,
  deleteIncrementHistory,
};
