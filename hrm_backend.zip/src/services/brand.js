const { find_user, find_user_by_id } = require("../DAL/user");
const {
  add_brand,
  find_brand_by_id,
  pagination_brand,
  all_brands_active,
  all_brands_active_count,
  delete_brand_by_id,
  get_brand_search,
  brand_search_count,
  find_brand_by_name,
} = require("../DAL/brand");
const { update_brand_in_company_assets } = require("../DAL/company_asset");

const _addBrand = async (body, resp) => {
  const brand_detail = await find_brand_by_name(body.title);
  if (brand_detail) {
    resp.error = true;
    resp.error_message = "Brand already exists";
    return resp;
  }
  let brand_obj = {
    title: body.title,
    description: body.description,
  };

  const final_brand = await add_brand(brand_obj);
  resp.data = final_brand;
  return resp;
};
const addBrand = async (body) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _addBrand(body, resp);
  return resp;
};

const _editBrand = async (body, brand_id, resp) => {
  const brand_detail = await find_brand_by_id(brand_id);
  if (!brand_detail) {
    resp.error = true;
    resp.error_message = "Invalid Brand";
    return resp;
  }

  const old_title = brand_detail.title;

  brand_detail.title = body.title;
  brand_detail.description = body.description;
  brand_detail.active_status = body.active_status;

  if (old_title != body.title) {
    await update_brand_in_company_assets(brand_id, body.title);
  }

  await brand_detail.save();
  resp.data = brand_detail;
  return resp;
};
const editBrand = async (body, brand_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _editBrand(body, brand_id, resp);
  return resp;
};

const _getBrand = async (resp) => {
  const brand = await all_brands_active();
  // const total_pages = await all_brands_active_count();
  const data = {
    brand: brand,
  };
  resp.data = data;
  return resp;
};

const getBrand = async () => {
  let resp = {
    error: false,
    auth: true,
    error_message: "",
    data: {},
  };

  resp = await _getBrand(resp);
  return resp;
};
const _detailBrand = async (brand_id, resp) => {
  const brand = await find_brand_by_id(brand_id);
  if (!brand) {
    resp.error = true;
    resp.error_message = "Invalid Brand ID!";
    return resp;
  }
  resp.data = brand;
  return resp;
};

const detailBrand = async (brand_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _detailBrand(brand_id, resp);
  return resp;
};

const _deleteBrand = async (brand_id, resp) => {
  const deleted_brand = await delete_brand_by_id(brand_id);
  if (!deleted_brand) {
    resp.error = true;
    resp.error_message = "Invalid Brand ID!";
    return resp;
  }
  return resp;
};

const deleteBrand = async (brand_id) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _deleteBrand(brand_id, resp);
  return resp;
};

const _searchBrand = async (Limit, page, search, resp) => {
  let limit = parseInt(Limit);
  if (!limit) {
    limit = 15;
  }

  if (page) {
    page = parseInt(page) + 1;
    if (isNaN(page)) {
      page = 1;
    }
  } else {
    page = 1;
  }
  let skip = (page - 1) * limit;
  const brand = await get_brand_search(limit, skip, search);
  const total_pages = await brand_search_count(search);
  resp.data = {
    brand: brand,
    total_pages: total_pages,
    load_more_url: `/brand/get_brand?page=${page}&limit=${limit}`,
  };

  return resp;
};

const searchBrand = async (limit, page, search) => {
  let resp = {
    error: false,
    error_message: "",
    data: {},
  };

  resp = await _searchBrand(limit, page, search, resp);
  return resp;
};
module.exports = {
  addBrand,
  editBrand,
  getBrand,
  detailBrand,
  deleteBrand,
  searchBrand,
};
