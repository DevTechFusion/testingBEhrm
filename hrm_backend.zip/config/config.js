// //const env = process.env.NODE_ENV || 'development';
// const env = process.env.NODE_ENV || 'local';
// if (env === 'local' || env === 'dev' || env=== 'prod') {
//     process.env.NODE_ENV = env;
//     const config = require('./config.json');
//     const envConfig = config[env];

//     Object.keys(envConfig).forEach((key) => {
//         process.env[key] = envConfig[key];
//          //console.log(key , " ", process.env[key] );
//     });
// }
process.env.AWS_ACCESS_KEY = process.env.SUPPORT_PORTAL_AWS_ACCESS_KEY;
process.env.AWS_SECRET_ACCESS_KEY =
  process.env.SUPPORT_PORTAL_AWS_SECRET_ACCESS_KEY;
process.env.PORT = process.env.SUPPORT_PORTAL_PORT;
process.env.IP = process.env.SUPPORT_PORTAL_IP;
process.env.MONGODB_URI = process.env.SUPPORT_PORTAL_MONGODB_URI;
process.env.EMAIL_API_KEY = process.env.SUPPORT_PORTAL_EMAIL_API_KEY;
process.env.EMAIL_FROM = process.env.SUPPORT_PORTAL_EMAIL_FROM;
process.env.JWT_SECRET = process.env.SUPPORT_PORTAL_JWT_SECRET;
process.env.BASE_UPLOAD_DIR = process.env.SUPPORT_PORTAL_BASE_UPLOAD_DIR;
process.env.NODE_ENV = process.env.SUPPORT_PORTAL_NODE_ENV;
process.env.Bucket = process.env.SUPPORT_PORTAL_Bucket;
process.env.REGION = process.env.SUPPORT_PORTAL_REGION;
process.env.AWS_SES_ACCESS_KEY = process.env.SUPPORT_PORTAL_AWS_SES_ACCESS_KEY;
process.env.AWS_SES_SECRET_ACCESS_KEY = process.env.SUPPORT_PORTAL_AWS_SES_SECRET_ACCESS_KEY;
process.env.SES_REGION = process.env.SUPPORT_PORTAL_SES_REGION;
